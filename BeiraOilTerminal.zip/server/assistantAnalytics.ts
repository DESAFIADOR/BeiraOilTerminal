import { db } from "./db";
import { chatSessions, chatMessages } from "@shared/schema";
import { eq, count, avg, gte, sql } from "drizzle-orm";

export class AssistantAnalytics {
  
  // Get performance metrics for dashboard
  async getPerformanceMetrics(days: number = 30): Promise<{
    responseTime: number;
    accuracy: number;
    satisfactionRating: number;
    totalSessions: number;
    escalationRate: number;
  }> {
    try {
      const dateThreshold = new Date();
      dateThreshold.setDate(dateThreshold.getDate() - days);
      
      // Get session count
      const sessionCount = await db
        .select({ count: count() })
        .from(chatSessions)
        .where(gte(chatSessions.startTime, dateThreshold));
      
      // Get average satisfaction rating
      const satisfactionData = await db
        .select({ avg: avg(chatSessions.satisfactionRating) })
        .from(chatSessions)
        .where(gte(chatSessions.startTime, dateThreshold));
      
      // Get escalation rate
      const escalationCount = await db
        .select({ count: count() })
        .from(chatSessions)
        .where(eq(chatSessions.status, 'escalated'));
      
      // Get average confidence (proxy for accuracy)
      const confidenceData = await db
        .select({ avg: avg(chatMessages.confidence) })
        .from(chatMessages)
        .innerJoin(chatSessions, eq(chatMessages.sessionId, chatSessions.id))
        .where(gte(chatSessions.startTime, dateThreshold));
      
      const totalSessions = sessionCount[0]?.count || 0;
      const escalationRate = totalSessions > 0 ? 
        ((escalationCount[0]?.count || 0) / totalSessions) * 100 : 0;
      
      return {
        responseTime: 1.8, // Average response time (would be measured in real implementation)
        accuracy: Number(confidenceData[0]?.avg || 0) * 100,
        satisfactionRating: Number(satisfactionData[0]?.avg || 0),
        totalSessions,
        escalationRate
      };
    } catch (error) {
      console.error('Error getting performance metrics:', error);
      return {
        responseTime: 0,
        accuracy: 0,
        satisfactionRating: 0,
        totalSessions: 0,
        escalationRate: 0
      };
    }
  }
  
  // Get usage statistics by user role
  async getUsageByRole(): Promise<Array<{ role: string; count: number }>> {
    try {
      const results = await db
        .select({
          role: chatSessions.userRole,
          count: count()
        })
        .from(chatSessions)
        .groupBy(chatSessions.userRole);
      
      return results.map(r => ({ role: r.role, count: r.count }));
    } catch (error) {
      console.error('Error getting usage by role:', error);
      return [];
    }
  }
  
  // Get language distribution
  async getLanguageDistribution(): Promise<Array<{ language: string; count: number }>> {
    try {
      const results = await db
        .select({
          language: chatSessions.language,
          count: count()
        })
        .from(chatSessions)
        .groupBy(chatSessions.language);
      
      return results.map(r => ({ language: r.language, count: r.count }));
    } catch (error) {
      console.error('Error getting language distribution:', error);
      return [];
    }
  }
}

export const assistantAnalytics = new AssistantAnalytics();