import type { Express } from "express";
import { communicationService } from "./communicationService";
import { isAuthenticated, isOperator, isAdmin } from "./auth";
import { db } from "./db";
import { communicationLogs, notificationSettings, validationTokens } from "@shared/schema";
import { eq, desc, and, gte, sql } from "drizzle-orm";

export function registerCommunicationRoutes(app: Express) {
  
  // ====== EMAIL ROUTES ======
  
  // Send single email
  app.post('/api/communication/email/send', isAuthenticated, isOperator, async (req, res) => {
    try {
      const { to, subject, content, type = 'html' } = req.body;
      
      console.log('Email send request received:', { to, subject, type });
      
      if (!to || !subject || !content) {
        return res.status(400).json({ 
          message: "Campos obrigatórios: to, subject, content" 
        });
      }

      // Validate email format
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(to)) {
        return res.status(400).json({ 
          message: "Formato de email inválido" 
        });
      }

      await communicationService.sendEmail({
        to,
        subject,
        html: type === 'html' ? content : undefined,
        text: type === 'text' ? content : undefined
      });

      res.json({ 
        message: "Email enviado com sucesso",
        status: "sent"
      });
    } catch (error) {
      console.error('Email sending error:', error);
      
      let statusCode = 500;
      let errorMessage = "Erro interno do servidor";
      
      if (error.message?.includes('Forbidden')) {
        statusCode = 403;
        errorMessage = "Email não autorizado - domínio não verificado no SendGrid";
      } else if (error.message?.includes('Unauthorized')) {
        statusCode = 401;
        errorMessage = "Chave API do SendGrid inválida";
      } else if (error.message?.includes('Bad Request')) {
        statusCode = 400;
        errorMessage = "Dados do email inválidos";
      } else if (error.message) {
        errorMessage = error.message;
      }
      
      res.status(statusCode).json({ 
        message: errorMessage,
        error: error.message
      });
    }
  });

  // Send ship notification email
  app.post('/api/communication/email/ship-notification', isAuthenticated, isOperator, async (req, res) => {
    try {
      const { shipName, recipientEmail, notificationType, additionalData } = req.body;
      
      if (!shipName || !recipientEmail || !notificationType) {
        return res.status(400).json({ 
          message: "Campos obrigatórios: shipName, recipientEmail, notificationType" 
        });
      }

      const success = await communicationService.sendShipNotificationEmail(
        shipName, 
        recipientEmail, 
        notificationType, 
        additionalData
      );

      if (success) {
        res.json({ 
          message: "Notificação de navio enviada com sucesso",
          status: "sent"
        });
      } else {
        res.status(500).json({ 
          message: "Falha ao enviar notificação" 
        });
      }
    } catch (error) {
      console.error('Ship notification error:', error);
      res.status(500).json({ 
        message: "Erro interno do servidor" 
      });
    }
  });

  // ====== WHATSAPP ROUTES ======
  
  // Send WhatsApp message
  app.post('/api/communication/whatsapp/send', isAuthenticated, isOperator, async (req, res) => {
    try {
      const { phoneNumber, message, mediaUrl } = req.body;
      
      if (!phoneNumber || !message) {
        return res.status(400).json({ 
          message: "Campos obrigatórios: phoneNumber, message" 
        });
      }

      const success = await communicationService.sendWhatsApp({
        to: phoneNumber,
        message,
        mediaUrl
      });

      if (success) {
        res.json({ 
          message: "WhatsApp enviado com sucesso",
          status: "sent"
        });
      } else {
        res.status(500).json({ 
          message: "Falha ao enviar WhatsApp" 
        });
      }
    } catch (error) {
      console.error('WhatsApp sending error:', error);
      res.status(500).json({ 
        message: "Erro interno do servidor" 
      });
    }
  });

  // Send ship WhatsApp notification
  app.post('/api/communication/whatsapp/ship-notification', isAuthenticated, isOperator, async (req, res) => {
    try {
      const { shipName, phoneNumber, notificationType } = req.body;
      
      if (!shipName || !phoneNumber || !notificationType) {
        return res.status(400).json({ 
          message: "Campos obrigatórios: shipName, phoneNumber, notificationType" 
        });
      }

      const success = await communicationService.sendShipWhatsAppNotification(
        shipName, 
        phoneNumber, 
        notificationType
      );

      if (success) {
        res.json({ 
          message: "Notificação WhatsApp enviada com sucesso",
          status: "sent"
        });
      } else {
        res.status(500).json({ 
          message: "Falha ao enviar notificação WhatsApp" 
        });
      }
    } catch (error) {
      console.error('WhatsApp ship notification error:', error);
      res.status(500).json({ 
        message: "Erro interno do servidor" 
      });
    }
  });

  // ====== SMS ROUTES ======
  
  // Send SMS
  app.post('/api/communication/sms/send', isAuthenticated, isOperator, async (req, res) => {
    try {
      const { phoneNumber, message } = req.body;
      
      if (!phoneNumber || !message) {
        return res.status(400).json({ 
          message: "Campos obrigatórios: phoneNumber, message" 
        });
      }

      const success = await communicationService.sendSMS({
        to: phoneNumber,
        message
      });

      if (success) {
        res.json({ 
          message: "SMS enviado com sucesso",
          status: "sent"
        });
      } else {
        res.status(500).json({ 
          message: "Falha ao enviar SMS" 
        });
      }
    } catch (error) {
      console.error('SMS sending error:', error);
      res.status(500).json({ 
        message: "Erro interno do servidor" 
      });
    }
  });

  // ====== VALIDATION TOKEN ROUTES ======
  
  // Generate validation token
  app.post('/api/communication/token/generate', isAuthenticated, async (req, res) => {
    try {
      const { phoneNumber, email, purpose = 'verification' } = req.body;
      
      if (!phoneNumber) {
        return res.status(400).json({ 
          message: "Campo obrigatório: phoneNumber" 
        });
      }

      const token = await communicationService.generateValidationToken(
        phoneNumber, 
        email, 
        purpose
      );

      res.json({ 
        message: "Token de validação enviado por SMS",
        tokenGenerated: true,
        expiresIn: "10 minutos"
      });
    } catch (error) {
      console.error('Token generation error:', error);
      res.status(500).json({ 
        message: "Erro ao gerar token de validação" 
      });
    }
  });

  // Validate token
  app.post('/api/communication/token/validate', isAuthenticated, async (req, res) => {
    try {
      const { token, phoneNumber } = req.body;
      
      if (!token || !phoneNumber) {
        return res.status(400).json({ 
          message: "Campos obrigatórios: token, phoneNumber" 
        });
      }

      const isValid = await communicationService.validateToken(token, phoneNumber);

      if (isValid) {
        res.json({ 
          message: "Token validado com sucesso",
          valid: true
        });
      } else {
        res.status(400).json({ 
          message: "Token inválido ou expirado",
          valid: false
        });
      }
    } catch (error) {
      console.error('Token validation error:', error);
      res.status(500).json({ 
        message: "Erro ao validar token" 
      });
    }
  });

  // ====== BULK OPERATIONS ======
  
  // Send bulk notifications
  app.post('/api/communication/bulk/send', isAuthenticated, isAdmin, async (req, res) => {
    try {
      const { recipients, message } = req.body;
      
      if (!recipients || !Array.isArray(recipients) || recipients.length === 0) {
        return res.status(400).json({ 
          message: "Campo obrigatório: recipients (array)" 
        });
      }

      if (!message || (!message.emailContent && !message.smsContent && !message.whatsappContent)) {
        return res.status(400).json({ 
          message: "Pelo menos um tipo de mensagem deve ser fornecido" 
        });
      }

      const result = await communicationService.sendBulkNotification(recipients, message);

      res.json({ 
        message: "Notificações em lote processadas",
        sent: result.sent,
        failed: result.failed,
        total: recipients.length
      });
    } catch (error) {
      console.error('Bulk notification error:', error);
      res.status(500).json({ 
        message: "Erro ao enviar notificações em lote" 
      });
    }
  });

  // ====== NOTIFICATION SETTINGS ======
  
  // Get user notification settings
  app.get('/api/communication/settings/:userId?', isAuthenticated, async (req, res) => {
    try {
      const userId = req.params.userId || req.user?.id;
      
      if (!userId) {
        return res.status(400).json({ 
          message: "ID do usuário necessário" 
        });
      }

      const settings = await db
        .select()
        .from(notificationSettings)
        .where(eq(notificationSettings.userId, parseInt(userId)));

      res.json(settings);
    } catch (error) {
      console.error('Get notification settings error:', error);
      res.status(500).json({ 
        message: "Erro ao buscar configurações de notificação" 
      });
    }
  });

  // Update notification settings
  app.post('/api/communication/settings', isAuthenticated, async (req, res) => {
    try {
      const { 
        userId, 
        shipId, 
        notificationType, 
        emailEnabled, 
        smsEnabled, 
        whatsappEnabled,
        email,
        phoneNumber,
        whatsappNumber
      } = req.body;

      const userIdToUse = userId || req.user?.id;

      if (!userIdToUse || !notificationType) {
        return res.status(400).json({ 
          message: "Campos obrigatórios: userId, notificationType" 
        });
      }

      const [setting] = await db
        .insert(notificationSettings)
        .values({
          userId: userIdToUse,
          shipId,
          notificationType,
          emailEnabled: emailEnabled ?? true,
          smsEnabled: smsEnabled ?? false,
          whatsappEnabled: whatsappEnabled ?? false,
          email,
          phoneNumber,
          whatsappNumber,
          createdAt: new Date(),
          updatedAt: new Date()
        })
        .onConflictDoUpdate({
          target: [notificationSettings.userId, notificationSettings.notificationType],
          set: {
            emailEnabled: emailEnabled ?? true,
            smsEnabled: smsEnabled ?? false,
            whatsappEnabled: whatsappEnabled ?? false,
            email,
            phoneNumber,
            whatsappNumber,
            updatedAt: new Date()
          }
        })
        .returning();

      res.json({ 
        message: "Configurações de notificação atualizadas",
        setting
      });
    } catch (error) {
      console.error('Update notification settings error:', error);
      res.status(500).json({ 
        message: "Erro ao atualizar configurações" 
      });
    }
  });

  // ====== LOGS AND MONITORING ======
  
  // Get communication logs
  app.get('/api/communication/logs', isAuthenticated, isOperator, async (req, res) => {
    try {
      const { limit = 50, type, status } = req.query;
      
      let query = db
        .select()
        .from(communicationLogs)
        .orderBy(desc(communicationLogs.sentAt))
        .limit(parseInt(limit as string));

      if (type) {
        query = query.where(eq(communicationLogs.type, type as string));
      }

      if (status) {
        query = query.where(eq(communicationLogs.status, status as string));
      }

      const logs = await query;
      res.json(logs);
    } catch (error) {
      console.error('Get communication logs error:', error);
      res.status(500).json({ 
        message: "Erro ao buscar logs de comunicação" 
      });
    }
  });

  // Get service status
  app.get('/api/communication/status', isAuthenticated, isOperator, async (req, res) => {
    try {
      const status = communicationService.getServiceStatus();
      
      res.json({
        services: status,
        timestamp: new Date().toISOString(),
        allServicesOperational: Object.values(status).every(s => s)
      });
    } catch (error) {
      console.error('Get service status error:', error);
      res.status(500).json({ 
        message: "Erro ao verificar status dos serviços" 
      });
    }
  });

  // Get communication statistics
  app.get('/api/communication/stats', isAuthenticated, isOperator, async (req, res) => {
    try {
      const { days = 7 } = req.query;
      const daysAgo = new Date(Date.now() - parseInt(days as string) * 24 * 60 * 60 * 1000);

      const stats = await db
        .select({
          type: communicationLogs.type,
          status: communicationLogs.status,
          count: sql<number>`count(*)`
        })
        .from(communicationLogs)
        .where(gte(communicationLogs.sentAt, daysAgo))
        .groupBy(communicationLogs.type, communicationLogs.status);

      const summary = {
        email: { sent: 0, failed: 0, total: 0 },
        sms: { sent: 0, failed: 0, total: 0 },
        whatsapp: { sent: 0, failed: 0, total: 0 },
        total: { sent: 0, failed: 0, total: 0 }
      };

      stats.forEach(stat => {
        if (summary[stat.type]) {
          summary[stat.type][stat.status] = stat.count;
          summary[stat.type].total += stat.count;
          summary.total[stat.status] += stat.count;
          summary.total.total += stat.count;
        }
      });

      res.json({
        period: `${days} dias`,
        stats: summary,
        timestamp: new Date().toISOString()
      });
    } catch (error) {
      console.error('Get communication stats error:', error);
      res.status(500).json({ 
        message: "Erro ao buscar estatísticas" 
      });
    }
  });
}