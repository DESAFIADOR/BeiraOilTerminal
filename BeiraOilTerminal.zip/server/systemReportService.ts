import { ChartJSNodeCanvas } from 'chartjs-node-canvas';
import puppeteer from 'puppeteer';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import fs from 'fs/promises';
import path from 'path';
import { sendEmail } from './emailService';

class SystemReportService {
  private readonly chartWidth = 800;
  private readonly chartHeight = 400;

  async generateSystemCapabilitiesReport(): Promise<string> {
    console.log('Gerando relatório de capacidades do sistema...');
    
    const reportData = this.getSystemCapabilities();
    const pdfPath = await this.generatePDF(reportData);
    
    // Enviar por email
    await this.sendReportEmail(pdfPath);
    
    return pdfPath;
  }

  private getSystemCapabilities() {
    return {
      title: "Sistema de Gestão de Navios - Terminal Petrolífero da Beira",
      subtitle: "Relatório Completo de Funcionalidades e Capacidades",
      generatedAt: new Date(),
      version: "2.0",
      
      mainFeatures: [
        {
          category: "Gestão de Navios",
          features: [
            "Registro completo de navios com informações detalhadas (nome, contra marca, calado, agentes)",
            "Sistema de status em tempo real (esperado, na barra, próximo a atracar, no cais, partido)",
            "Controle de tipos de operação (Trânsito e Combinado) com regras de atracação 2:1",
            "Sistema de priorização IMOPETRO conforme Decreto 89/2019",
            "Gestão de parcelas de carga com volumes e destinatários",
            "Rastreamento de progresso de descarga em tempo real"
          ]
        },
        {
          category: "Controle de Atracação",
          features: [
            "Registro de tempos de atracação (primeira e última amarra)",
            "Verificação automática de condições de atracação baseada no calado e maré",
            "Sistema de confirmação de instruções de descarga via email",
            "Controle de berço com status de manutenção programada",
            "Fluxo automatizado de movimentação entre status"
          ]
        },
        {
          category: "Sistema de Priorização Inteligente",
          features: [
            "Prioridade absoluta para navios IMOPETRO (Decreto 89/2019)",
            "Regra de atracação 2:1: 2 navios trânsito + 1 navio combinado",
            "Ordenação cronológica por data de chegada na barra",
            "Badges visuais diferenciando tipos de operação",
            "Alertas de prioridade em tempo real"
          ]
        },
        {
          category: "Monitoramento Ambiental",
          features: [
            "Monitoramento de marés em tempo real para Porto da Beira",
            "Previsões de maré com análise harmônica (constituintes M2, S2, N2)",
            "Alertas meteorológicos para ventos acima de 25 nós",
            "Dados de temperatura, umidade e pressão atmosférica",
            "Integração com APIs meteorológicas (OpenWeather e Open-Meteo)"
          ]
        },
        {
          category: "Sistema de Notificações",
          features: [
            "Emails automáticos de confirmação de atracação",
            "Notificações de mudança de status via SendGrid",
            "Sistema de tokens seguros para confirmação de instruções",
            "Alertas personalizáveis por navio",
            "Notificações para agentes de navios e carga"
          ]
        },
        {
          category: "Relatórios e Analytics",
          features: [
            "Relatórios mensais automáticos em PDF",
            "Gráficos de operações com Chart.js",
            "Análise de volumes por destinatário",
            "Estatísticas de tempos de operação",
            "Limpeza automática de dados após 30 dias",
            "Log de acesso a relatórios para auditoria"
          ]
        },
        {
          category: "Controle de Acesso",
          features: [
            "Sistema de autenticação com Replit Auth",
            "Controle de permissões granular (update_discharge, confirm_ship, move_ship, manage_maintenance)",
            "Aprovação administrativa para operadores",
            "Acesso público para visualização de status",
            "Senha administrativa para ações sensíveis"
          ]
        },
        {
          category: "Interface e Usabilidade",
          features: [
            "Interface responsiva para dispositivos móveis",
            "Design otimizado para ambiente marítimo",
            "Visualização em tempo real da fila de navios",
            "Modais informativos com abas organizadas",
            "Suporte a português brasileiro",
            "Temas claro/escuro automáticos"
          ]
        }
      ],
      
      technicalSpecs: {
        frontend: "React 18 com TypeScript, Tailwind CSS, shadcn/ui",
        backend: "Express.js com TypeScript, Drizzle ORM",
        database: "PostgreSQL (Neon Serverless)",
        authentication: "Replit Auth com OpenID Connect",
        email: "SendGrid para notificações profissionais",
        charts: "Chart.js e Puppeteer para relatórios PDF",
        weather: "APIs OpenWeather e Open-Meteo",
        deployment: "Replit com domínio personalizado beiraoilterminal-vessels-lineup.com"
      },
      
      operationalBenefits: [
        "Redução significativa do tempo de coordenação de navios",
        "Transparência total no processo de atracação",
        "Conformidade regulatória automática (Decreto 89/2019)",
        "Otimização da utilização do berço único",
        "Rastreamento preciso de operações de descarga",
        "Melhoria na comunicação com agentes marítimos",
        "Relatórios automáticos para gestão superior",
        "Alertas preventivos para condições adversas"
      ]
    };
  }

  private async generatePDF(reportData: any): Promise<string> {
    const browser = await puppeteer.launch({
      headless: true,
      args: ['--no-sandbox', '--disable-setuid-sandbox']
    });

    const page = await browser.newPage();
    
    const htmlContent = this.getReportTemplate(reportData);
    await page.setContent(htmlContent, { waitUntil: 'networkidle0' });
    
    const fileName = `relatorio-sistema-${format(new Date(), 'yyyy-MM-dd-HHmm', { locale: ptBR })}.pdf`;
    const filePath = path.join(process.cwd(), 'reports', fileName);
    
    // Criar diretório se não existir
    await fs.mkdir(path.dirname(filePath), { recursive: true });
    
    await page.pdf({
      path: filePath,
      format: 'A4',
      printBackground: true,
      margin: {
        top: '20mm',
        right: '15mm',
        bottom: '20mm',
        left: '15mm'
      }
    });

    await browser.close();
    
    console.log(`Relatório do sistema gerado: ${filePath}`);
    return filePath;
  }

  private getReportTemplate(data: any): string {
    return `
    <!DOCTYPE html>
    <html lang="pt-BR">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Relatório do Sistema</title>
        <style>
            body {
                font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                line-height: 1.6;
                color: #333;
                max-width: 210mm;
                margin: 0 auto;
                padding: 20px;
                background: white;
            }
            
            .header {
                text-align: center;
                border-bottom: 3px solid #1e40af;
                padding-bottom: 20px;
                margin-bottom: 30px;
            }
            
            .header h1 {
                color: #1e40af;
                font-size: 28px;
                margin: 0 0 10px 0;
                font-weight: bold;
            }
            
            .header h2 {
                color: #64748b;
                font-size: 18px;
                margin: 0;
                font-weight: normal;
            }
            
            .meta-info {
                background: #f8fafc;
                padding: 15px;
                border-radius: 8px;
                margin: 20px 0;
                border-left: 4px solid #1e40af;
            }
            
            .meta-info p {
                margin: 5px 0;
                font-size: 14px;
            }
            
            .section {
                margin: 30px 0;
                page-break-inside: avoid;
            }
            
            .section h3 {
                color: #1e40af;
                border-bottom: 2px solid #e2e8f0;
                padding-bottom: 8px;
                font-size: 20px;
                margin-bottom: 20px;
            }
            
            .feature-category {
                margin: 25px 0;
                background: #f9fafb;
                padding: 20px;
                border-radius: 10px;
                border: 1px solid #e5e7eb;
            }
            
            .feature-category h4 {
                color: #059669;
                font-size: 16px;
                margin: 0 0 15px 0;
                font-weight: bold;
            }
            
            .feature-list {
                list-style: none;
                padding: 0;
                margin: 0;
            }
            
            .feature-list li {
                padding: 8px 0;
                border-bottom: 1px solid #e5e7eb;
                padding-left: 20px;
                position: relative;
            }
            
            .feature-list li:last-child {
                border-bottom: none;
            }
            
            .feature-list li:before {
                content: "✓";
                color: #059669;
                font-weight: bold;
                position: absolute;
                left: 0;
            }
            
            .tech-grid {
                display: grid;
                grid-template-columns: 1fr 1fr;
                gap: 15px;
                margin: 20px 0;
            }
            
            .tech-item {
                background: #eff6ff;
                padding: 15px;
                border-radius: 8px;
                border: 1px solid #bfdbfe;
            }
            
            .tech-item strong {
                color: #1d4ed8;
                display: block;
                margin-bottom: 5px;
            }
            
            .benefits-grid {
                display: grid;
                grid-template-columns: 1fr 1fr;
                gap: 10px;
                margin: 20px 0;
            }
            
            .benefit-item {
                background: #f0fdf4;
                padding: 12px;
                border-radius: 6px;
                border-left: 4px solid #22c55e;
                font-size: 14px;
            }
            
            .footer {
                margin-top: 40px;
                text-align: center;
                color: #64748b;
                font-size: 12px;
                border-top: 1px solid #e2e8f0;
                padding-top: 20px;
            }
            
            .logo-section {
                text-align: center;
                margin: 20px 0;
            }
            
            .logo-text {
                font-size: 24px;
                color: #1e40af;
                font-weight: bold;
                margin: 10px 0;
            }
        </style>
    </head>
    <body>
        <div class="header">
            <div class="logo-section">
                <div class="logo-text">⚓ SISTEMA DE GESTÃO PORTUÁRIA</div>
            </div>
            <h1>${data.title}</h1>
            <h2>${data.subtitle}</h2>
        </div>

        <div class="meta-info">
            <p><strong>Data de Geração:</strong> ${format(data.generatedAt, "dd 'de' MMMM 'de' yyyy 'às' HH:mm", { locale: ptBR })}</p>
            <p><strong>Versão do Sistema:</strong> ${data.version}</p>
            <p><strong>Domínio:</strong> beiraoilterminal-vessels-lineup.com</p>
            <p><strong>Destinatário:</strong> manuel.antonio@cfm.co.mz</p>
        </div>

        <div class="section">
            <h3>🚢 Funcionalidades Principais</h3>
            ${data.mainFeatures.map((category: any) => `
                <div class="feature-category">
                    <h4>${category.category}</h4>
                    <ul class="feature-list">
                        ${category.features.map((feature: string) => `<li>${feature}</li>`).join('')}
                    </ul>
                </div>
            `).join('')}
        </div>

        <div class="section">
            <h3>⚙️ Especificações Técnicas</h3>
            <div class="tech-grid">
                <div class="tech-item">
                    <strong>Frontend:</strong>
                    ${data.technicalSpecs.frontend}
                </div>
                <div class="tech-item">
                    <strong>Backend:</strong>
                    ${data.technicalSpecs.backend}
                </div>
                <div class="tech-item">
                    <strong>Banco de Dados:</strong>
                    ${data.technicalSpecs.database}
                </div>
                <div class="tech-item">
                    <strong>Autenticação:</strong>
                    ${data.technicalSpecs.authentication}
                </div>
                <div class="tech-item">
                    <strong>Notificações:</strong>
                    ${data.technicalSpecs.email}
                </div>
                <div class="tech-item">
                    <strong>Relatórios:</strong>
                    ${data.technicalSpecs.charts}
                </div>
                <div class="tech-item">
                    <strong>Clima/Marés:</strong>
                    ${data.technicalSpecs.weather}
                </div>
                <div class="tech-item">
                    <strong>Deployment:</strong>
                    ${data.technicalSpecs.deployment}
                </div>
            </div>
        </div>

        <div class="section">
            <h3>📈 Benefícios Operacionais</h3>
            <div class="benefits-grid">
                ${data.operationalBenefits.map((benefit: string) => `
                    <div class="benefit-item">${benefit}</div>
                `).join('')}
            </div>
        </div>

        <div class="section">
            <h3>🔧 Recursos Avançados</h3>
            <div class="feature-category">
                <h4>Sistema de Priorização Inteligente</h4>
                <ul class="feature-list">
                    <li>Prioridade automática para navios IMOPETRO conforme Decreto 89/2019</li>
                    <li>Algoritmo 2:1 para navios trânsito e combinados</li>
                    <li>Ordenação cronológica por data de chegada</li>
                    <li>Badges visuais diferenciando tipos de operação</li>
                </ul>
            </div>
            
            <div class="feature-category">
                <h4>Monitoramento Ambiental em Tempo Real</h4>
                <ul class="feature-list">
                    <li>Dados de maré com análise harmônica para Porto da Beira</li>
                    <li>Alertas meteorológicos automáticos</li>
                    <li>Verificação de condições de atracação baseada no calado</li>
                    <li>Previsões de maré para planejamento operacional</li>
                </ul>
            </div>

            <div class="feature-category">
                <h4>Automação e Relatórios</h4>
                <ul class="feature-list">
                    <li>Relatórios mensais automáticos em PDF</li>
                    <li>Limpeza automática de dados históricos</li>
                    <li>Gráficos operacionais detalhados</li>
                    <li>Log de auditoria para acesso a relatórios</li>
                </ul>
            </div>
        </div>

        <div class="footer">
            <p>Sistema desenvolvido para CFM-EP | Terminal Petrolífero da Beira</p>
            <p>Relatório gerado automaticamente pelo sistema de gestão portuária</p>
            <p>Para suporte técnico, contate o administrador do sistema</p>
        </div>
    </body>
    </html>
    `;
  }

  private async sendReportEmail(pdfPath: string): Promise<void> {
    const emailData = {
      to: 'manuel.antonio@cfm.co.mz',
      from: 'noreply@beiraoilterminal.com',
      subject: 'Relatório Completo de Funcionalidades - Sistema de Gestão Portuária',
      html: this.getEmailTemplate(),
      attachments: [{
        filename: path.basename(pdfPath),
        path: pdfPath,
        contentType: 'application/pdf'
      }]
    };

    const success = await sendEmail(emailData);
    
    if (success) {
      console.log('Relatório do sistema enviado com sucesso para manuel.antonio@cfm.co.mz');
    } else {
      console.log('Erro ao enviar relatório do sistema - usando modo mock');
    }
  }

  private getEmailTemplate(): string {
    return `
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; background-color: #f9fafb;">
        <div style="background: white; padding: 30px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1);">
            <div style="text-align: center; margin-bottom: 30px;">
                <h1 style="color: #1e40af; margin: 0; font-size: 28px;">⚓ Sistema de Gestão Portuária</h1>
                <h2 style="color: #64748b; margin: 10px 0 0 0; font-size: 18px; font-weight: normal;">Terminal Petrolífero da Beira</h2>
            </div>
            
            <div style="background: #eff6ff; padding: 20px; border-radius: 8px; border-left: 4px solid #1e40af; margin: 20px 0;">
                <h3 style="color: #1e40af; margin: 0 0 10px 0;">Relatório de Funcionalidades do Sistema</h3>
                <p style="margin: 0; color: #374151;">
                    Segue em anexo o relatório completo das funcionalidades e capacidades do sistema de gestão de navios 
                    do Terminal Petrolífero da Beira.
                </p>
            </div>
            
            <div style="margin: 25px 0;">
                <h4 style="color: #059669; margin-bottom: 15px;">📋 Conteúdo do Relatório:</h4>
                <ul style="color: #374151; line-height: 1.8; padding-left: 20px;">
                    <li><strong>Funcionalidades Principais:</strong> Gestão completa de navios, controle de atracação, sistema de priorização</li>
                    <li><strong>Especificações Técnicas:</strong> Arquitetura do sistema, tecnologias utilizadas</li>
                    <li><strong>Benefícios Operacionais:</strong> Melhorias em eficiência e conformidade regulatória</li>
                    <li><strong>Recursos Avançados:</strong> Monitoramento ambiental, automação e relatórios</li>
                </ul>
            </div>
            
            <div style="background: #f0fdf4; padding: 20px; border-radius: 8px; border-left: 4px solid #22c55e; margin: 20px 0;">
                <h4 style="color: #15803d; margin: 0 0 10px 0;">🎯 Principais Destaques:</h4>
                <ul style="margin: 10px 0; color: #374151; line-height: 1.6;">
                    <li>Sistema de priorização IMOPETRO (Decreto 89/2019)</li>
                    <li>Regras de atracação 2:1 (trânsito/combinado)</li>
                    <li>Monitoramento de marés em tempo real</li>
                    <li>Relatórios automáticos mensais</li>
                    <li>Interface responsiva para dispositivos móveis</li>
                </ul>
            </div>
            
            <div style="margin: 30px 0; text-align: center;">
                <p style="color: #6b7280; font-size: 14px; margin: 0;">
                    Sistema acessível em: <strong style="color: #1e40af;">beiraoilterminal-vessels-lineup.com</strong>
                </p>
            </div>
            
            <div style="border-top: 1px solid #e5e7eb; padding-top: 20px; text-align: center; color: #9ca3af; font-size: 12px;">
                <p style="margin: 0;">Este relatório foi gerado automaticamente pelo sistema de gestão portuária</p>
                <p style="margin: 5px 0 0 0;">CFM-EP | Terminal Petrolífero da Beira</p>
            </div>
        </div>
    </div>
    `;
  }
}

export const systemReportService = new SystemReportService();