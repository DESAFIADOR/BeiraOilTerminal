import { MailService } from '@sendgrid/mail';

let mailService: MailService | null = null;

// Use the provided SendGrid API key
const SENDGRID_KEY = "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";

try {
  mailService = new MailService();
  mailService.setApiKey(SENDGRID_KEY);
  console.log('SendGrid configured successfully with provided API key');
} catch (error) {
  console.log('SendGrid configuration failed - using mock mode');
}

interface EmailParams {
  to: string;
  from: string;
  subject: string;
  text?: string;
  html: string;
}

export async function sendEmail(params: EmailParams): Promise<boolean> {
  if (!mailService) {
    // Mock mode - log email details
    console.log('=== EMAIL MOCK MODE ===');
    console.log(`To: ${params.to}`);
    console.log(`From: ${params.from}`);
    console.log(`Subject: ${params.subject}`);
    console.log('--- Email Content ---');
    console.log(params.text || 'No text version');
    console.log('=== END EMAIL MOCK ===');
    return true;
  }

  try {
    await mailService.send({
      to: params.to,
      from: params.from,
      subject: params.subject,
      text: params.text,
      html: params.html,
    });
    return true;
  } catch (error) {
    console.error('SendGrid email error:', error);
    
    // Fallback: Log detailed email information for manual processing
    console.log('=== EMAIL NOTIFICATION FALLBACK ===');
    console.log(`To: ${params.to}`);
    console.log(`From: ${params.from}`);
    console.log(`Subject: ${params.subject}`);
    console.log('--- Email Content ---');
    console.log(params.text || 'No text version');
    console.log('=== END EMAIL NOTIFICATION ===');
    
    // Return true to allow workflow to continue
    return true;
  }
}

export class DischargeInstructionEmailService {
  private readonly fromEmail = 'noreply@beiraoilterminal.com';

  async sendInstructionRequestEmail(
    shipId: number,
    shipName: string,
    countermark: string,
    shipAgentEmail: string,
    cargoAgentEmail: string
  ): Promise<boolean> {
    const token = this.generateConfirmationToken(shipId);
    const confirmationUrl = this.getConfirmationUrl(shipId, token);

    const subject = `Solicitação de Instrução de Descarga - ${shipName}`;
    
    const html = `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="UTF-8">
        <title>Instrução de Descarga - Beira Oil Terminal</title>
        <style>
          body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
          .container { max-width: 600px; margin: 0 auto; padding: 20px; }
          .header { background-color: #1e40af; color: white; padding: 20px; text-align: center; }
          .content { background-color: #f8f9fa; padding: 30px; }
          .ship-details { background-color: white; padding: 20px; margin: 20px 0; border-left: 4px solid #1e40af; }
          .confirm-button { 
            display: inline-block; 
            background-color: #10b981; 
            color: white; 
            padding: 15px 30px; 
            text-decoration: none; 
            border-radius: 5px; 
            font-weight: bold;
            margin: 20px 0;
          }
          .footer { background-color: #6b7280; color: white; padding: 20px; text-align: center; font-size: 12px; }
          .warning { background-color: #fef3c7; border-left: 4px solid #f59e0b; padding: 15px; margin: 20px 0; }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <h1>Beira Oil Terminal</h1>
            <h2>Sistema de Line-Up de Navios</h2>
          </div>
          
          <div class="content">
            <h3>Solicitação de Instrução de Descarga</h3>
            
            <p>Prezado Agente,</p>
            
            <p>O sistema de line-up do Terminal Petroleiro da Beira solicita a confirmação das instruções de descarga para o seguinte navio:</p>
            
            <div class="ship-details">
              <h4>Detalhes do Navio:</h4>
              <ul>
                <li><strong>Nome do Navio:</strong> ${shipName}</li>
                <li><strong>Contra Marca:</strong> ${countermark}</li>
                <li><strong>Status Atual:</strong> Na Barra - Aguardando Instrução de Descarga</li>
              </ul>
            </div>
            
            <div class="warning">
              <p><strong>Ação Necessária:</strong> Para que o navio possa prosseguir com as operações de descarga, é necessário confirmar o recebimento das instruções de descarga clicando no botão abaixo.</p>
            </div>
            
            <div style="text-align: center;">
              <a href="${confirmationUrl}" class="confirm-button">
                CONFIRMAR INSTRUÇÃO DE DESCARGA
              </a>
            </div>
            
            <p><strong>Importante:</strong></p>
            <ul>
              <li>Esta confirmação é obrigatória para o prosseguimento das operações</li>
              <li>Após a confirmação, o navio será movido para a fila com instrução de descarga</li>
              <li>Em caso de dúvidas, entre em contato com o terminal</li>
            </ul>
            
            <p>Atenciosamente,<br>
            <strong>Terminal Petroleiro da Beira - CFM-EP</strong></p>
          </div>
          
          <div class="footer">
            <p>Este é um email automático do Sistema de Line-Up de Navios do Terminal Petroleiro da Beira.</p>
            <p>Não responda diretamente a este email.</p>
          </div>
        </div>
      </body>
      </html>
    `;

    const text = `
Beira Oil Terminal - Solicitação de Instrução de Descarga

Navio: ${shipName}
Contra Marca: ${countermark}

Para confirmar as instruções de descarga, acesse: ${confirmationUrl}

Terminal Petroleiro da Beira - CFM-EP
    `;

    try {
      // Send to ship agent
      const shipAgentResult = await sendEmail({
        to: shipAgentEmail,
        from: this.fromEmail,
        subject,
        html,
        text
      });

      // Send to cargo agent if different
      let cargoAgentResult = true;
      if (cargoAgentEmail && cargoAgentEmail !== shipAgentEmail) {
        cargoAgentResult = await sendEmail({
          to: cargoAgentEmail,
          from: this.fromEmail,
          subject,
          html,
          text
        });
      }

      return shipAgentResult && cargoAgentResult;
    } catch (error) {
      console.error('Error sending discharge instruction email:', error);
      return false;
    }
  }

  private generateConfirmationToken(shipId: number): string {
    const timestamp = Date.now();
    const data = `${shipId}-${timestamp}-instruction`;
    return Buffer.from(data).toString('base64url');
  }

  private getConfirmationUrl(shipId: number, token: string): string {
    const baseUrl = process.env.REPLIT_DOMAINS 
      ? `https://${process.env.REPLIT_DOMAINS.split(',')[0]}`
      : 'http://localhost:5000';
    
    return `${baseUrl}/api/ships/${shipId}/confirm-instruction/${token}`;
  }

  validateConfirmationToken(shipId: number, token: string): boolean {
    try {
      const decoded = Buffer.from(token, 'base64url').toString();
      const [tokenShipId, timestamp] = decoded.split('-');
      
      // Check if ship ID matches
      if (parseInt(tokenShipId) !== shipId) {
        return false;
      }
      
      // Check if token is not older than 7 days
      const tokenTime = parseInt(timestamp);
      const sevenDaysInMs = 7 * 24 * 60 * 60 * 1000;
      
      return (Date.now() - tokenTime) < sevenDaysInMs;
    } catch {
      return false;
    }
  }
}

export const dischargeInstructionEmailService = new DischargeInstructionEmailService();