import { ChartJSNodeCanvas } from 'chartjs-node-canvas';
import puppeteer from 'puppeteer';
import Handlebars from 'handlebars';
import { storage } from './storage';
import { sendEmail } from './emailService';
import { 
  MonthlyReport, 
  InsertMonthlyReport, 
  ShipRegistry,
  Ship,
  CargoParcel 
} from '@shared/schema';

interface ReportData {
  totalShips: number;
  totalParcels: number;
  uniqueReceivers: number;
  totalVolume: string;
  operationsData: any;
  shipDetails: Array<{
    name: string;
    countermark: string;
    status: string;
    parcels: number;
    totalVolume: string;
    receivers: string[];
    operationDuration?: string;
  }>;
}

class ReportService {
  private readonly chartWidth = 800;
  private readonly chartHeight = 400;
  private readonly adminEmail = 'manuel.antonio@cfm.co.mz';

  // Gerar relatório mensal automatizado
  async generateMonthlyReport(month?: number, year?: number): Promise<{ reportId: number; pdfPath: string }> {
    const now = new Date();
    const reportMonth = month || now.getMonth() + 1;
    const reportYear = year || now.getFullYear();

    console.log(`Generating monthly report for ${reportMonth}/${reportYear}`);

    // Coletar dados do período
    const reportData = await this.collectReportData(reportMonth, reportYear);
    
    // Gerar gráficos
    const chartsData = await this.generateCharts(reportData);
    
    // Criar PDF
    const pdfPath = await this.generatePDF(reportData, chartsData, reportMonth, reportYear);
    
    // Salvar relatório no banco
    const report = await this.saveReport(reportData, reportMonth, reportYear);
    
    // Enviar por email
    await this.sendReportEmail(pdfPath, reportMonth, reportYear);
    
    // Limpar dados antigos após envio
    await this.cleanupOldData(reportMonth, reportYear);
    
    return { reportId: report.id, pdfPath };
  }

  // Coletar dados dos navios do período
  private async collectReportData(month: number, year: number): Promise<ReportData> {
    const startDate = new Date(year, month - 1, 1);
    const endDate = new Date(year, month, 0, 23, 59, 59);

    // Buscar apenas navios desatracados (departed) do período
    const ships = await storage.getDepartedShipsForPeriod(startDate, endDate);
    const shipDetails = [];
    let totalParcels = 0;
    let totalVolumeNum = 0;
    const receiversSet = new Set<string>();

    for (const ship of ships) {
      const parcelsCount = ship.parcels.length;
      const shipVolume = ship.parcels.reduce((sum: number, parcel: any) => sum + parseFloat(parcel.volume || '0'), 0);
      
      // Adicionar recebedores únicos
      ship.parcels.forEach((parcel: any) => {
        if (parcel.receiver) receiversSet.add(parcel.receiver);
        if (parcel.owner) receiversSet.add(parcel.owner);
      });

      totalParcels += parcelsCount;
      totalVolumeNum += shipVolume;

      // Calcular duração da operação
      let operationDuration = undefined;
      if (ship.berthingStartedAt && ship.status === 'departed') {
        const start = new Date(ship.berthingStartedAt);
        const end = new Date(ship.updatedAt || start);
        const hours = Math.round((end.getTime() - start.getTime()) / (1000 * 60 * 60));
        operationDuration = `${hours}h`;
      }

      shipDetails.push({
        name: ship.name,
        countermark: ship.countermark || 'N/A',
        status: this.translateStatus(ship.status),
        parcels: parcelsCount,
        totalVolume: shipVolume.toFixed(2) + ' MT',
        receivers: ship.parcels.map((p: any) => p.receiver || p.owner || 'N/A').filter((v: any, i: any, a: any) => a.indexOf(v) === i),
        operationDuration
      });
    }

    // Dados para gráficos
    const operationsData = this.prepareChartsData(ships);

    return {
      totalShips: ships.length,
      totalParcels,
      uniqueReceivers: receiversSet.size,
      totalVolume: totalVolumeNum.toFixed(2) + ' MT',
      operationsData,
      shipDetails
    };
  }

  // Preparar dados para gráficos
  private prepareChartsData(ships: any[]): any {
    const statusCount = ships.reduce((acc, ship) => {
      acc[ship.status] = (acc[ship.status] || 0) + 1;
      return acc;
    }, {});

    const dailyOperations = ships.reduce((acc, ship) => {
      if (ship.berthingStartedAt) {
        const date = new Date(ship.berthingStartedAt).toISOString().split('T')[0];
        acc[date] = (acc[date] || 0) + 1;
      }
      return acc;
    }, {});

    return {
      statusDistribution: statusCount,
      dailyOperations: dailyOperations,
      volumeByReceiver: this.calculateVolumeByReceiver(ships)
    };
  }

  // Calcular volume por recebedor
  private calculateVolumeByReceiver(ships: any[]): Record<string, number> {
    const volumeByReceiver: Record<string, number> = {};
    
    ships.forEach(ship => {
      ship.parcels.forEach((parcel: any) => {
        const receiver = parcel.receiver || parcel.parcelOwner || 'N/A';
        const volume = parseFloat(parcel.volume || '0');
        volumeByReceiver[receiver] = (volumeByReceiver[receiver] || 0) + volume;
      });
    });

    return volumeByReceiver;
  }

  // Gerar gráficos usando Chart.js
  private async generateCharts(reportData: ReportData): Promise<{ statusChart: Buffer; volumeChart: Buffer; operationsChart: Buffer }> {
    const chartJSNodeCanvas = new ChartJSNodeCanvas({
      width: this.chartWidth,
      height: this.chartHeight,
      backgroundColour: 'white'
    });

    // Gráfico de status dos navios
    const statusChart = await chartJSNodeCanvas.renderToBuffer({
      type: 'pie',
      data: {
        labels: Object.keys(reportData.operationsData.statusDistribution).map(status => this.translateStatus(status)),
        datasets: [{
          data: Object.values(reportData.operationsData.statusDistribution),
          backgroundColor: ['#8B5CF6', '#06B6D4', '#10B981', '#F59E0B', '#EF4444']
        }]
      },
      options: {
        plugins: {
          title: {
            display: true,
            text: 'Distribuição por Status dos Navios'
          }
        }
      }
    });

    // Gráfico de volume por recebedor
    const volumeChart = await chartJSNodeCanvas.renderToBuffer({
      type: 'bar',
      data: {
        labels: Object.keys(reportData.operationsData.volumeByReceiver),
        datasets: [{
          label: 'Volume (MT)',
          data: Object.values(reportData.operationsData.volumeByReceiver),
          backgroundColor: '#8B5CF6'
        }]
      },
      options: {
        plugins: {
          title: {
            display: true,
            text: 'Volume por Recebedor'
          }
        },
        scales: {
          y: {
            beginAtZero: true
          }
        }
      }
    });

    // Gráfico de operações diárias
    const operationsChart = await chartJSNodeCanvas.renderToBuffer({
      type: 'line',
      data: {
        labels: Object.keys(reportData.operationsData.dailyOperations),
        datasets: [{
          label: 'Operações',
          data: Object.values(reportData.operationsData.dailyOperations),
          borderColor: '#06B6D4',
          backgroundColor: 'rgba(6, 182, 212, 0.1)',
          fill: true
        }]
      },
      options: {
        plugins: {
          title: {
            display: true,
            text: 'Operações Diárias'
          }
        },
        scales: {
          y: {
            beginAtZero: true
          }
        }
      }
    });

    return { statusChart, volumeChart, operationsChart };
  }

  // Gerar PDF usando Puppeteer
  private async generatePDF(reportData: ReportData, charts: any, month: number, year: number): Promise<string> {
    const template = this.getReportTemplate();
    const compiledTemplate = Handlebars.compile(template);

    // Converter gráficos para base64
    const statusChartBase64 = charts.statusChart.toString('base64');
    const volumeChartBase64 = charts.volumeChart.toString('base64');
    const operationsChartBase64 = charts.operationsChart.toString('base64');

    const html = compiledTemplate({
      month,
      year,
      monthName: this.getMonthName(month),
      reportData,
      statusChartBase64,
      volumeChartBase64,
      operationsChartBase64,
      generatedDate: new Date().toLocaleDateString('pt-PT')
    });

    const browser = await puppeteer.launch({
      headless: true,
      args: ['--no-sandbox', '--disable-setuid-sandbox']
    });

    try {
      const page = await browser.newPage();
      await page.setContent(html, { waitUntil: 'networkidle0' });
      
      const pdfPath = `/tmp/relatorio_${year}_${month.toString().padStart(2, '0')}.pdf`;
      await page.pdf({
        path: pdfPath,
        format: 'A4',
        margin: { top: '1cm', right: '1cm', bottom: '1cm', left: '1cm' }
      });

      return pdfPath;
    } finally {
      await browser.close();
    }
  }

  // Template HTML para o relatório
  private getReportTemplate(): string {
    return `
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Relatório Mensal - {{monthName}} {{year}}</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 0; padding: 20px; }
        .header { text-align: center; border-bottom: 2px solid #8B5CF6; padding-bottom: 20px; margin-bottom: 30px; }
        .logo { color: #8B5CF6; font-size: 24px; font-weight: bold; }
        .subtitle { color: #666; margin-top: 10px; }
        .summary { display: grid; grid-template-columns: 1fr 1fr 1fr 1fr; gap: 20px; margin-bottom: 30px; }
        .summary-item { background: #f8fafc; padding: 15px; border-radius: 8px; text-align: center; }
        .summary-value { font-size: 24px; font-weight: bold; color: #8B5CF6; }
        .summary-label { color: #666; margin-top: 5px; }
        .chart { text-align: center; margin: 30px 0; }
        .chart img { max-width: 100%; height: auto; }
        .ships-table { width: 100%; border-collapse: collapse; margin-top: 30px; }
        .ships-table th, .ships-table td { border: 1px solid #ddd; padding: 8px; text-align: left; }
        .ships-table th { background-color: #8B5CF6; color: white; }
        .ships-table tr:nth-child(even) { background-color: #f9f9f9; }
        .footer { text-align: center; margin-top: 50px; color: #666; font-size: 12px; }
        .page-break { page-break-before: always; }
    </style>
</head>
<body>
    <div class="header">
        <div class="logo">TERMINAL DE PETROLÍFEROS DE BEIRA - CFM-EP</div>
        <div class="subtitle">Relatório Mensal de Operações - {{monthName}} {{year}}</div>
        <div class="subtitle">Gerado em: {{generatedDate}}</div>
    </div>

    <div class="summary">
        <div class="summary-item">
            <div class="summary-value">{{reportData.totalShips}}</div>
            <div class="summary-label">Total de Navios</div>
        </div>
        <div class="summary-item">
            <div class="summary-value">{{reportData.totalParcels}}</div>
            <div class="summary-label">Total de Parcelas</div>
        </div>
        <div class="summary-item">
            <div class="summary-value">{{reportData.uniqueReceivers}}</div>
            <div class="summary-label">Recebedores Únicos</div>
        </div>
        <div class="summary-item">
            <div class="summary-value">{{reportData.totalVolume}}</div>
            <div class="summary-label">Volume Total</div>
        </div>
    </div>

    <div class="chart">
        <img src="data:image/png;base64,{{statusChartBase64}}" alt="Distribuição por Status">
    </div>

    <div class="page-break"></div>

    <div class="chart">
        <img src="data:image/png;base64,{{volumeChartBase64}}" alt="Volume por Recebedor">
    </div>

    <div class="chart">
        <img src="data:image/png;base64,{{operationsChartBase64}}" alt="Operações Diárias">
    </div>

    <table class="ships-table">
        <thead>
            <tr>
                <th>Navio</th>
                <th>Contramarca</th>
                <th>Status</th>
                <th>Parcelas</th>
                <th>Volume</th>
                <th>Duração</th>
                <th>Recebedores</th>
            </tr>
        </thead>
        <tbody>
            {{#each reportData.shipDetails}}
            <tr>
                <td>{{name}}</td>
                <td>{{countermark}}</td>
                <td>{{status}}</td>
                <td>{{parcels}}</td>
                <td>{{totalVolume}}</td>
                <td>{{operationDuration}}</td>
                <td>{{#each receivers}}{{this}}{{#unless @last}}, {{/unless}}{{/each}}</td>
            </tr>
            {{/each}}
        </tbody>
    </table>

    <div class="footer">
        <p>Relatório gerado automaticamente pelo Sistema de Gestão de Navios - Terminal de Beira</p>
        <p>Este documento é confidencial e destinado exclusivamente ao uso interno da CFM-EP</p>
    </div>
</body>
</html>
    `;
  }

  // Enviar relatório por email
  private async sendReportEmail(pdfPath: string, month: number, year: number): Promise<void> {
    const monthName = this.getMonthName(month);
    const subject = `Relatório Mensal - ${monthName} ${year} - Terminal de Beira`;
    
    const emailHtml = `
      <h2>Relatório Mensal de Operações</h2>
      <p>Segue em anexo o relatório mensal de operações do Terminal de Petrolíferos de Beira referente a <strong>${monthName} de ${year}</strong>.</p>
      
      <p>Este relatório contém:</p>
      <ul>
        <li>Resumo estatístico das operações</li>
        <li>Gráficos de análise operacional</li>
        <li>Detalhamento de todos os navios operados</li>
        <li>Volume total movimentado por recebedor</li>
      </ul>
      
      <p>Para qualquer esclarecimento adicional, entre em contato com a equipe operacional.</p>
      
      <hr>
      <p><small>Este email foi gerado automaticamente pelo Sistema de Gestão de Navios - CFM-EP</small></p>
    `;

    await sendEmail({
      to: this.adminEmail,
      from: 'noreply@beiraoilterminal.com',
      subject,
      html: emailHtml
    });

    console.log(`Monthly report sent to ${this.adminEmail}`);
  }

  // Salvar relatório no banco de dados
  private async saveReport(reportData: ReportData, month: number, year: number): Promise<MonthlyReport> {
    const reportRecord: InsertMonthlyReport = {
      reportMonth: month,
      reportYear: year,
      totalShips: reportData.totalShips,
      totalParcels: reportData.totalParcels,
      uniqueReceivers: reportData.uniqueReceivers,
      totalVolume: reportData.totalVolume,
      operationsData: reportData.operationsData,
      generatedBy: null // Sistema automático
    };

    return await storage.createMonthlyReport(reportRecord);
  }

  // Método público para gerar relatórios (compatibilidade com routes.ts)
  async generateReport(month: number, year: number): Promise<{ reportId: number; pdfPath: string }> {
    return await this.generateMonthlyReport(month, year);
  }

  // Limpar dados antigos após geração do relatório
  private async cleanupOldData(month: number, year: number): Promise<void> {
    const startDate = new Date(year, month - 1, 1);
    const endDate = new Date(year, month, 0, 23, 59, 59);

    console.log(`Cleaning up ships data for period ${month}/${year}`);
    
    // Remover navios completados do período
    await storage.cleanupCompletedShips(startDate, endDate);
    
    console.log('Ship data cleanup completed');
  }

  // Utilitários
  private translateStatus(status: string): string {
    const translations: Record<string, string> = {
      'expected': 'Esperado',
      'at_bar': 'Na Barra',
      'next_to_berth': 'Próximo do Cais',
      'at_berth': 'No Cais',
      'departed': 'Partido'
    };
    return translations[status] || status;
  }

  private getMonthName(month: number): string {
    const months = [
      'Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho',
      'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'
    ];
    return months[month - 1] || 'Mês';
  }

  // Agendar relatório automático (chamado pelo cron job)
  async scheduleMonthlyReport(): Promise<void> {
    const now = new Date();
    const lastMonth = now.getMonth(); // 0-indexed
    const year = lastMonth === 0 ? now.getFullYear() - 1 : now.getFullYear();
    const month = lastMonth === 0 ? 12 : lastMonth;

    try {
      await this.generateMonthlyReport(month, year);
      console.log(`Scheduled monthly report generated for ${month}/${year}`);
    } catch (error) {
      console.error('Error generating scheduled monthly report:', error);
    }
  }
}

export const reportService = new ReportService();