import { db } from "./db";
import { ships, cargoParcels, instructionConfirmations, users } from "@shared/schema";
import { eq, and, desc, asc } from "drizzle-orm";
import { communicationService } from "./communicationService";
import { storage } from "./storage";

export interface ShipArrivalData {
  name: string;
  countermark: string;
  shipAgentEmail: string;
  cargoAgentEmail: string;
  armador: string;
  destinoCarga: string;
  operationType: string;
  expectedArrivalDate: Date;
  draft: number;
  cargoType: string;
}

export interface InstructionConfirmationData {
  shipId: number;
  attachmentFileName?: string;
  attachmentUrl?: string;
  attachmentMimeType?: string;
  confirmationNotes?: string;
  confirmationType: 'manual' | 'email';
}

export class AgentService {
  
  /**
   * Adiciona um novo navio ao sistema (Agente do Navio)
   */
  async addShipToExpected(agentId: number, shipData: ShipArrivalData): Promise<any> {
    try {
      console.log("Adding ship to expected arrivals:", shipData);
      
      // Garantir que expectedArrivalDate é um Date válido
      const arrivalDate = typeof shipData.expectedArrivalDate === 'string' 
        ? new Date(shipData.expectedArrivalDate) 
        : shipData.expectedArrivalDate;
      
      // Inserir navio na tabela ships usando a interface de storage
      const newShip = await storage.createShip({
        name: shipData.name,
        countermark: shipData.countermark,
        arrivalDateTime: arrivalDate,
        draft: shipData.draft.toString(),
        shipAgent: shipData.shipAgentEmail ? "Agente Marítimo" : "agente@terminal.com",
        shipAgentEmail: shipData.shipAgentEmail || "agente@terminal.com", 
        cargoAgent: shipData.cargoAgentEmail ? "Agente de Carga" : "carga@terminal.com",
        cargoAgentEmail: shipData.cargoAgentEmail || "carga@terminal.com",
        shipowner: shipData.armador,
        cargoType: shipData.cargoType,
        cargoDestination: shipData.destinoCarga,
        operationType: shipData.operationType,
        status: "expected",
        hasDischargeInstructions: false
      }, []);

      console.log("Ship added successfully:", newShip);
      return newShip;
    } catch (error) {
      console.error("Error adding ship:", error);
      throw new Error("Falha ao adicionar navio: " + (error instanceof Error ? error.message : String(error)));
    }
  }

  /**
   * Confirma a chegada de um navio na barra
   */
  async confirmShipArrival(agentId: number, shipId: number, arrivalDateTime: Date): Promise<any> {
    try {
      console.log("Confirming ship arrival:", { shipId, arrivalDateTime });
      
      // Atualizar status do navio para "at_bar" e definir data de chegada
      const [updatedShip] = await db.update(ships)
        .set({
          status: "at_bar",
          updatedAt: new Date(),
        })
        .where(eq(ships.id, shipId))
        .returning();

      if (!updatedShip) {
        throw new Error("Navio não encontrado");
      }

      console.log("Ship arrival confirmed:", updatedShip);
      return updatedShip;
    } catch (error) {
      console.error("Error confirming ship arrival:", error);
      throw new Error("Falha ao confirmar chegada do navio");
    }
  }

  /**
   * Confirma instruções de descarga com anexo e envia email automático
   */
  async confirmInstructions(agentId: number, confirmationData: InstructionConfirmationData): Promise<any> {
    try {
      console.log("Confirming discharge instructions:", confirmationData);
      
      // Verificar se o navio existe e está no status correto
      const [ship] = await db.select().from(ships).where(eq(ships.id, confirmationData.shipId));
      
      if (!ship) {
        throw new Error("Navio não encontrado");
      }

      if (ship.status !== "at_bar") {
        throw new Error("Navio deve estar na barra para confirmar instruções");
      }

      // Inserir confirmação na tabela instruction_confirmations
      const [confirmation] = await db.insert(instructionConfirmations).values({
        shipId: confirmationData.shipId,
        agentId: agentId,
        confirmationType: confirmationData.confirmationType,
        attachmentFileName: confirmationData.attachmentFileName,
        attachmentUrl: confirmationData.attachmentUrl,
        attachmentMimeType: confirmationData.attachmentMimeType,
        confirmationNotes: confirmationData.confirmationNotes,
        emailSentToDoptp: false,
      }).returning();

      // Atualizar navio para ter instruções
      const [updatedShip] = await db.update(ships)
        .set({
          hasDischargeInstructions: true,
          updatedAt: new Date(),
        })
        .where(eq(ships.id, confirmationData.shipId))
        .returning();

      // Enviar email automático para doptp03@gmail.com
      await this.sendInstructionEmail(confirmation, ship);

      // Marcar email como enviado
      await db.update(instructionConfirmations)
        .set({
          emailSentToDoptp: true,
          emailSentAt: new Date(),
        })
        .where(eq(instructionConfirmations.id, confirmation.id));

      console.log("Instructions confirmed and email sent:", confirmation);
      return { confirmation, ship: updatedShip };
    } catch (error) {
      console.error("Error confirming instructions:", error);
      throw new Error("Falha ao confirmar instruções");
    }
  }

  /**
   * Envia email automático para doptp03@gmail.com com confirmação de instruções
   */
  private async sendInstructionEmail(confirmation: any, ship: any): Promise<void> {
    try {
      const subject = `Confirmação de Instruções de Descarga - ${ship.name}`;
      
      const htmlContent = `
        <h2>Confirmação de Instruções de Descarga</h2>
        <h3>Informações do Navio:</h3>
        <ul>
          <li><strong>Nome:</strong> ${ship.name}</li>
          <li><strong>Contramarque:</strong> ${ship.countermark}</li>
          <li><strong>Tipo de Operação:</strong> ${ship.operationType}</li>
          <li><strong>Armador:</strong> ${ship.armador}</li>
          <li><strong>Data de Chegada na Barra:</strong> ${ship.arrivalDateTime ? new Date(ship.arrivalDateTime).toLocaleString('pt-BR', { timeZone: 'Africa/Maputo' }) : 'Não informada'}</li>
        </ul>
        
        <h3>Confirmação:</h3>
        <ul>
          <li><strong>Tipo:</strong> ${confirmation.confirmationType === 'manual' ? 'Manual' : 'Por Email'}</li>
          <li><strong>Data de Confirmação:</strong> ${new Date(confirmation.confirmedAt).toLocaleString('pt-BR', { timeZone: 'Africa/Maputo' })}</li>
          ${confirmation.confirmationNotes ? `<li><strong>Observações:</strong> ${confirmation.confirmationNotes}</li>` : ''}
          ${confirmation.attachmentFileName ? `<li><strong>Anexo:</strong> ${confirmation.attachmentFileName}</li>` : ''}
        </ul>
        
        <p><em>Este email foi enviado automaticamente pelo sistema de gestão do Terminal da Beira.</em></p>
      `;

      const emailData = {
        to: "doptp03@gmail.com",
        from: "noreply@beiraoilterminal.com",
        subject: subject,
        html: htmlContent,
        text: `Confirmação de Instruções de Descarga - ${ship.name}\n\nInformações do navio: ${ship.name} (${ship.countermark})\nTipo de Operação: ${ship.operationType}\nConfirmado em: ${new Date(confirmation.confirmedAt).toLocaleString('pt-BR', { timeZone: 'Africa/Maputo' })}`,
      };

      // Note: Attachments functionality simplified for now

      const emailSent = await communicationService.sendEmail(emailData);
      
      if (!emailSent) {
        console.warn("Failed to send instruction confirmation email to doptp03@gmail.com");
      } else {
        console.log("Instruction confirmation email sent successfully to doptp03@gmail.com");
      }
    } catch (error) {
      console.error("Error sending instruction email:", error);
      // Não lançar erro aqui para não bloquear o processo principal
    }
  }

  /**
   * Aplica regras de ordenação complexas para navios com instrução
   * Prioridade: Nacional/LPG imediatos, depois 2 Trânsito : 1 Combinada
   */
  async getOrderedShipsWithInstructions(): Promise<any[]> {
    try {
      // Buscar todos os navios com instruções (at_bar com hasDischargeInstructions = true)
      const shipsWithInstructions = await db.select()
        .from(ships)
        .where(and(
          eq(ships.status, "at_bar"),
          eq(ships.hasDischargeInstructions, true)
        ))
        .orderBy(asc(ships.arrivalDateTime));

      console.log("Ships with instructions found:", shipsWithInstructions.length);

      // Separar por tipo de operação
      const nacionalShips = shipsWithInstructions.filter(ship => 
        ship.operationType?.toLowerCase() === 'nacional'
      );
      const lgpShips = shipsWithInstructions.filter(ship => 
        ship.operationType?.toLowerCase() === 'lgp'
      );
      const transitoShips = shipsWithInstructions.filter(ship => 
        ship.operationType?.toLowerCase() === 'trânsito' || ship.operationType?.toLowerCase() === 'transito'
      );
      const combinadaShips = shipsWithInstructions.filter(ship => 
        ship.operationType?.toLowerCase() === 'combinada'
      );

      console.log("Ships by type:", {
        nacional: nacionalShips.length,
        lgp: lgpShips.length,
        transito: transitoShips.length,
        combinada: combinadaShips.length
      });

      // Aplicar regras de priorização
      const orderedShips = [];

      // 1. Adicionar Nacional e LPG primeiro (prioridade imediata)
      orderedShips.push(...nacionalShips.sort((a, b) => {
        const dateA = a.arrivalDateTime ? new Date(a.arrivalDateTime).getTime() : 0;
        const dateB = b.arrivalDateTime ? new Date(b.arrivalDateTime).getTime() : 0;
        return dateA - dateB;
      }));
      
      orderedShips.push(...lgpShips.sort((a, b) => {
        const dateA = a.arrivalDateTime ? new Date(a.arrivalDateTime).getTime() : 0;
        const dateB = b.arrivalDateTime ? new Date(b.arrivalDateTime).getTime() : 0;
        return dateA - dateB;
      }));

      // 2. Aplicar regra 2:1 para Trânsito e Combinada
      const transitoSorted = transitoShips.sort((a, b) => {
        const dateA = a.arrivalDateTime ? new Date(a.arrivalDateTime).getTime() : 0;
        const dateB = b.arrivalDateTime ? new Date(b.arrivalDateTime).getTime() : 0;
        return dateA - dateB;
      });
      const combinadaSorted = combinadaShips.sort((a, b) => {
        const dateA = a.arrivalDateTime ? new Date(a.arrivalDateTime).getTime() : 0;
        const dateB = b.arrivalDateTime ? new Date(b.arrivalDateTime).getTime() : 0;
        return dateA - dateB;
      });

      let transitoIndex = 0;
      let combinadaIndex = 0;
      let transitoCount = 0;

      while (transitoIndex < transitoSorted.length || combinadaIndex < combinadaSorted.length) {
        // Adicionar até 2 navios de trânsito
        if (transitoIndex < transitoSorted.length && transitoCount < 2) {
          orderedShips.push(transitoSorted[transitoIndex]);
          transitoIndex++;
          transitoCount++;
        }
        
        // Se já adicionamos 2 trânsitos ou não há mais trânsitos, adicionar 1 combinada
        if ((transitoCount === 2 || transitoIndex >= transitoSorted.length) && combinadaIndex < combinadaSorted.length) {
          orderedShips.push(combinadaSorted[combinadaIndex]);
          combinadaIndex++;
          transitoCount = 0; // Reset contador
        }
        
        // Se não há mais combinadas mas ainda há trânsitos, continuar adicionando trânsitos
        if (combinadaIndex >= combinadaSorted.length && transitoIndex < transitoSorted.length) {
          orderedShips.push(transitoSorted[transitoIndex]);
          transitoIndex++;
        }
      }

      console.log("Final ordered ships:", orderedShips.length);
      return orderedShips;
    } catch (error) {
      console.error("Error getting ordered ships:", error);
      throw new Error("Falha ao obter navios ordenados");
    }
  }

  /**
   * Busca navios adicionados por um agente específico
   */
  async getShipsByAgent(agentId: number): Promise<any[]> {
    try {
      // For now, return all ships as we simplified the schema
      const allShips = await db.select().from(ships).orderBy(desc(ships.createdAt));
      return allShips;
    } catch (error) {
      console.error("Error getting ships by agent:", error);
      throw new Error("Falha ao buscar navios do agente");
    }
  }

  /**
   * Busca confirmações de instruções por agente
   */
  async getInstructionConfirmationsByAgent(agentId: number): Promise<any[]> {
    try {
      const confirmations = await db.select({
        confirmation: instructionConfirmations,
        ship: ships,
      })
      .from(instructionConfirmations)
      .leftJoin(ships, eq(instructionConfirmations.shipId, ships.id))
      .where(eq(instructionConfirmations.agentId, agentId))
      .orderBy(desc(instructionConfirmations.createdAt));

      return confirmations;
    } catch (error) {
      console.error("Error getting confirmations by agent:", error);
      throw new Error("Falha ao buscar confirmações do agente");
    }
  }
}

export const agentService = new AgentService();