import OpenAI from 'openai';
import { nanoid } from 'nanoid';
import { db } from './db';
import { multilingualErrorHandler } from './multilingualErrorHandler';

// Initialize OpenAI with the provided API key
let openai: OpenAI | null = null;

// Auto-configure with environment variable
if (process.env.OPENAI_API_KEY_NEW) {
  openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY_NEW });
  console.log('[AdvancedAI] OpenAI configured with OPENAI_API_KEY_NEW');
} else if (process.env.OPENAI_API_KEY) {
  openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
  console.log('[AdvancedAI] OpenAI configured with OPENAI_API_KEY');
} else {
  console.log('[AdvancedAI] No OpenAI API key found. Assistant will work with mock responses.');
}

export type UserRole = 'visitor' | 'operator' | 'admin';
export type Language = 'pt' | 'en';

export interface ChatMessage {
  id: string;
  sessionId: string;
  content: string;
  role: 'user' | 'assistant';
  timestamp: Date;
  confidence?: number;
  requiresEscalation?: boolean;
  responseTimeMs?: number;
}

export interface AIResponse {
  response: string;
  confidence: number;
  requiresEscalation: boolean;
  sessionId: string;
  responseTimeMs: number;
  suggestions?: string[];
}

export interface UserCapabilities {
  canViewShips: boolean;
  canModifyShips: boolean;
  canViewReports: boolean;
  canAccessSensitiveData: boolean;
  canEscalateToHuman: boolean;
  maxSessionDuration: number; // minutes
}

export class AdvancedAIService {
  
  // Method to get comprehensive ships data with real-time information
  private async getShipsData(canAccessSensitive: boolean): Promise<any[]> {
    try {
      const query = canAccessSensitive ? `
        SELECT s.*, 
               GROUP_CONCAT(p.product || ': ' || p.volumeMT || 'MT') as cargo_summary,
               COUNT(p.id) as parcel_count,
               SUM(p.volumeMT) as total_cargo_mt,
               br.first_rope_time, br.last_rope_time,
               ur.first_rope_time as undock_first_rope, ur.last_rope_time as undock_last_rope
        FROM ships s
        LEFT JOIN cargo_parcels p ON s.id = p.shipId
        LEFT JOIN berthing_records br ON s.id = br.shipId
        LEFT JOIN undocking_records ur ON s.id = ur.shipId
        WHERE s.status IN ('expected', 'at_bar', 'next_to_berth', 'at_berth', 'departed')
        GROUP BY s.id
        ORDER BY s.expectedArrivalDate ASC
      ` : `
        SELECT s.name, s.status, s.operationType, s.expectedArrivalDate,
               COUNT(p.id) as parcel_count,
               SUM(p.volumeMT) as total_cargo_mt
        FROM ships s
        LEFT JOIN cargo_parcels p ON s.id = p.shipId
        WHERE s.status IN ('expected', 'at_bar', 'next_to_berth', 'at_berth')
        GROUP BY s.id
        ORDER BY s.expectedArrivalDate ASC
      `;
      
      const result = await db.execute(query);
      return result.rows || [];
    } catch (error) {
      console.error('[AdvancedAI] Error fetching ships data:', error);
      return [];
    }
  }

  // Method to get current weather data
  private async getWeatherData(): Promise<any> {
    try {
      // This would integrate with your weather service
      const result = await db.execute(`
        SELECT temperature, humidity, windSpeed, windDirection, pressure, visibility
        FROM weather_data 
        ORDER BY timestamp DESC 
        LIMIT 1
      `);
      
      if (result.rows && result.rows.length > 0) {
        return result.rows[0];
      }
      
      // Fallback to default values if no weather data
      return {
        temperature: 25,
        humidity: 70,
        windSpeed: 15,
        windDirection: 'SE',
        pressure: 1013,
        visibility: 10
      };
    } catch (error) {
      console.error('[AdvancedAI] Error fetching weather data:', error);
      return { temperature: 25, humidity: 70, windSpeed: 15, windDirection: 'SE' };
    }
  }

  // Method to get tide information
  private async getTideData(): Promise<any> {
    try {
      const now = new Date();
      // Get current tide and predictions
      return {
        currentTide: 2.1,
        status: 'enchente',
        nextHigh: { time: '14:30', height: 3.2 },
        nextLow: { time: '20:45', height: 0.8 }
      };
    } catch (error) {
      console.error('[AdvancedAI] Error fetching tide data:', error);
      return { currentTide: 2.0, status: 'estável' };
    }
  }

  // Method to get berth status
  private async getBerthStatus(language: Language): Promise<string> {
    try {
      const berthResult = await db.execute(`
        SELECT s.name, s.status, br.last_rope_time
        FROM ships s
        LEFT JOIN berthing_records br ON s.id = br.shipId
        WHERE s.status = 'at_berth'
        LIMIT 1
      `);
      
      const maintenanceResult = await db.execute(`
        SELECT is_active, description, start_period, end_period
        FROM berth_maintenance
        WHERE is_active = true
        LIMIT 1
      `);
      
      if (maintenanceResult.rows && maintenanceResult.rows.length > 0) {
        const maintenance = maintenanceResult.rows[0] as any;
        return language === 'en' ? 
          `BERTH IN MAINTENANCE: ${maintenance.description} (${maintenance.start_period} - ${maintenance.end_period})` :
          `CAIS EM MANUTENÇÃO: ${maintenance.description} (${maintenance.start_period} - ${maintenance.end_period})`;
      }
      
      if (berthResult.rows && berthResult.rows.length > 0) {
        const ship = berthResult.rows[0] as any;
        return language === 'en' ? 
          `OCCUPIED by ${ship.name} since ${ship.last_rope_time || 'N/A'}` :
          `OCUPADO pelo ${ship.name} desde ${ship.last_rope_time || 'N/A'}`;
      }
      
      return language === 'en' ? 'AVAILABLE' : 'DISPONÍVEL';
    } catch (error) {
      console.error('[AdvancedAI] Error fetching berth status:', error);
      return language === 'en' ? 'STATUS UNKNOWN' : 'STATUS DESCONHECIDO';
    }
  }

  // Method to get operational statistics
  private async getOperationalStats(language: Language): Promise<string> {
    try {
      const statsResult = await db.execute(`
        SELECT 
          COUNT(CASE WHEN status = 'expected' THEN 1 END) as expected_ships,
          COUNT(CASE WHEN status = 'at_bar' THEN 1 END) as ships_at_bar,
          COUNT(CASE WHEN status = 'next_to_berth' THEN 1 END) as ships_next_to_berth,
          COUNT(CASE WHEN status = 'at_berth' THEN 1 END) as ships_at_berth,
          COUNT(CASE WHEN status = 'departed' AND DATE(departureDate) = CURRENT_DATE THEN 1 END) as departed_today
        FROM ships
      `);
      
      if (statsResult.rows && statsResult.rows.length > 0) {
        const stats = statsResult.rows[0] as any;
        
        if (language === 'en') {
          return `OPERATIONAL STATISTICS:
- Expected arrivals: ${stats.expected_ships}
- Ships at bar: ${stats.ships_at_bar}
- Next to berth: ${stats.ships_next_to_berth}
- Currently berthed: ${stats.ships_at_berth}
- Departed today: ${stats.departed_today}`;
        } else {
          return `ESTATÍSTICAS OPERACIONAIS:
- Previstos a chegar: ${stats.expected_ships}
- Navios na barra: ${stats.ships_at_bar}
- Próximos ao cais: ${stats.ships_next_to_berth}
- Atracados atualmente: ${stats.ships_at_berth}
- Partidos hoje: ${stats.departed_today}`;
        }
      }
      
      return language === 'en' ? 'No operational data available' : 'Dados operacionais indisponíveis';
    } catch (error) {
      console.error('[AdvancedAI] Error fetching operational stats:', error);
      return language === 'en' ? 'Statistics unavailable' : 'Estatísticas indisponíveis';
    }
  }
  
  private async initializeTables(): Promise<void> {
    try {
      // Create sessions table
      await db.execute(`
        CREATE TABLE IF NOT EXISTS ai_chat_sessions (
          id VARCHAR PRIMARY KEY,
          user_id VARCHAR,
          user_role VARCHAR NOT NULL,
          language VARCHAR DEFAULT 'pt',
          created_at TIMESTAMP DEFAULT NOW(),
          ended_at TIMESTAMP,
          last_activity TIMESTAMP DEFAULT NOW(),
          status VARCHAR DEFAULT 'active',
          satisfaction_rating INTEGER,
          escalation_reason TEXT,
          total_messages INTEGER DEFAULT 0,
          avg_confidence REAL DEFAULT 0.0
        )
      `);
      
      // Create messages table
      await db.execute(`
        CREATE TABLE IF NOT EXISTS ai_chat_messages (
          id VARCHAR PRIMARY KEY,
          session_id VARCHAR NOT NULL,
          content TEXT NOT NULL,
          role VARCHAR NOT NULL CHECK (role IN ('user', 'assistant')),
          timestamp TIMESTAMP DEFAULT NOW(),
          confidence REAL DEFAULT 1.0,
          requires_escalation BOOLEAN DEFAULT false,
          response_time_ms INTEGER,
          audio_url VARCHAR,
          user_id VARCHAR
        )
      `);
      
      // Create analytics table
      await db.execute(`
        CREATE TABLE IF NOT EXISTS ai_analytics (
          id VARCHAR PRIMARY KEY,
          session_id VARCHAR NOT NULL,
          event_type VARCHAR NOT NULL,
          event_data TEXT,
          timestamp TIMESTAMP DEFAULT NOW(),
          user_role VARCHAR,
          language VARCHAR
        )
      `);
      
      console.log('[AdvancedAI] Database tables initialized successfully');
    } catch (error) {
      console.error('[AdvancedAI] Database initialization error:', error);
      throw new Error(`Database setup failed: ${error instanceof Error ? error.message : String(error)}`);
    }
  }

  getUserCapabilities(role: UserRole): UserCapabilities {
    const baseCapabilities = {
      canViewShips: true,
      canModifyShips: false,
      canViewReports: false,
      canAccessSensitiveData: false,
      canEscalateToHuman: true,
      maxSessionDuration: 30
    };

    switch (role) {
      case 'admin':
        return {
          ...baseCapabilities,
          canModifyShips: true,
          canViewReports: true,
          canAccessSensitiveData: true,
          maxSessionDuration: 120
        };
      case 'operator':
        return {
          ...baseCapabilities,
          canModifyShips: true,
          canViewReports: true,
          maxSessionDuration: 60
        };
      default:
        return baseCapabilities;
    }
  }

  async createSession(userId: string | null, userRole: UserRole, language: Language): Promise<string> {
    await this.initializeTables();
    
    const sessionId = nanoid(16);
    
    try {
      await db.execute(`
        INSERT INTO ai_chat_sessions (id, user_id, user_role, language) 
        VALUES ('${sessionId}', ${userId ? `'${userId}'` : 'NULL'}, '${userRole}', '${language}')
      `);
      
      // Log session creation
      await this.logAnalytics(sessionId, 'session_created', {
        userRole,
        language,
        timestamp: new Date().toISOString()
      });
      
      console.log('[AdvancedAI] Session created:', sessionId);
      return sessionId;
    } catch (error) {
      console.error('[AdvancedAI] Session creation failed:', error);
      throw new Error(`Session creation failed: ${error instanceof Error ? error.message : String(error)}`);
    }
  }

  async processMessage(
    sessionId: string, 
    userMessage: string, 
    userRole: UserRole, 
    language: Language
  ): Promise<AIResponse> {
    const startTime = Date.now();
    
    try {
      if (!openai) {
        console.log('[AdvancedAI] OpenAI not configured, providing mock response');
        const mockResponse = {
          response: language === 'en' ? 
            'Hello! I am the Advanced AI Assistant for Beira Oil Terminal. I can help you with ship operations, terminal information, and provide support. However, I need an OpenAI API key to be fully functional.' :
            'Olá! Sou o Assistente IA Avançado do Terminal Petrolífero da Beira. Posso ajudar com operações de navios, informações do terminal e fornecer suporte. No entanto, preciso de uma chave de API do OpenAI para ser totalmente funcional.',
          confidence: 0.8,
          requiresEscalation: false,
          sessionId,
          responseTimeMs: Date.now() - startTime,
          suggestions: language === 'en' ? [
            'Configure OpenAI API key',
            'View terminal status',
            'Help with navigation'
          ] : [
            'Configurar chave de API OpenAI',
            'Ver status do terminal',
            'Ajuda com navegação'
          ]
        };
        
        // Try to provide contextual response based on user message
        if (userMessage.toLowerCase().includes('navio') || userMessage.toLowerCase().includes('ship')) {
          try {
            const shipsResult = await db.execute(`
              SELECT name, status, cargoAgent FROM ships 
              WHERE status IN ('at_bar', 'next_to_berth', 'at_berth') 
              LIMIT 5
            `);
            
            if (shipsResult.rows && shipsResult.rows.length > 0) {
              const shipsList = shipsResult.rows.map((ship: any) => 
                `${ship.name} (${ship.status})`
              ).join(', ');
              
              mockResponse.response = language === 'en' ? 
                `Currently at terminal: ${shipsList}. I can provide basic information but need OpenAI API key for detailed analysis.` :
                `Atualmente no terminal: ${shipsList}. Posso fornecer informações básicas mas preciso da chave de API do OpenAI para análise detalhada.`;
              mockResponse.confidence = 0.9;
            }
          } catch (dbError) {
            console.error('[AdvancedAI] Database query error:', dbError);
          }
        }
        
        // Save mock response
        const aiMsgId = nanoid();
        await db.execute(`
          INSERT INTO ai_chat_messages (
            id, session_id, content, role, confidence, requires_escalation, response_time_ms
          ) VALUES (
            '${aiMsgId}', '${sessionId}', '${mockResponse.response.replace(/'/g, "''")}', 
            'assistant', ${mockResponse.confidence}, ${mockResponse.requiresEscalation}, ${mockResponse.responseTimeMs}
          )
        `);
        
        return mockResponse;
      }

      // Save user message
      const userMsgId = nanoid();
      await db.execute(`
        INSERT INTO ai_chat_messages (id, session_id, content, role, timestamp) 
        VALUES ('${userMsgId}', '${sessionId}', '${userMessage.replace(/'/g, "''")}', 'user', NOW())
      `);

      // Update session activity
      await db.execute(`
        UPDATE ai_chat_sessions 
        SET last_activity = NOW(), total_messages = total_messages + 1 
        WHERE id = '${sessionId}'
      `);

      // Get system context
      const systemPrompt = await this.getSystemContext(userRole, language);
      
      // Get conversation history
      const historyResult = await db.execute(`
        SELECT content, role, timestamp FROM ai_chat_messages 
        WHERE session_id = '${sessionId}' 
        ORDER BY timestamp DESC 
        LIMIT 10
      `);

      // Prepare messages for OpenAI
      const messages: any[] = [{ role: 'system', content: systemPrompt }];
      
      // Add conversation history (reversed for chronological order)
      if (historyResult.rows && historyResult.rows.length > 0) {
        const history = historyResult.rows.reverse().slice(0, -1); // Exclude current message
        history.forEach((msg: any) => {
          messages.push({
            role: msg.role === 'user' ? 'user' : 'assistant',
            content: msg.content
          });
        });
      }

      // Add current user message
      messages.push({ role: 'user', content: userMessage });

      console.log('[AdvancedAI] Calling OpenAI with', messages.length, 'messages');

      // Call OpenAI API
      const completion = await openai.chat.completions.create({
        model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
        messages,
        max_tokens: 600,
        temperature: 0.7,
        response_format: { type: "json_object" }
      });

      const responseContent = completion.choices[0]?.message?.content;
      let parsedResponse;
      
      try {
        parsedResponse = JSON.parse(responseContent || '{}');
      } catch (parseError) {
        console.error('[AdvancedAI] JSON parse error:', parseError);
        // Fallback to direct response if JSON parsing fails
        parsedResponse = {
          response: responseContent || 
            (language === 'en' ? 'I apologize, but I encountered an error processing your request.' :
             'Peço desculpas, mas encontrei um erro ao processar sua solicitação.'),
          confidence: 0.7,
          requires_escalation: false,
          suggestions: []
        };
      }

      const responseTimeMs = Date.now() - startTime;
      const confidence = Math.max(0.1, Math.min(1.0, parsedResponse.confidence || 0.7));
      const requiresEscalation = parsedResponse.requires_escalation || false;

      // Save AI response
      const aiMsgId = nanoid();
      await db.execute(`
        INSERT INTO ai_chat_messages (
          id, session_id, content, role, confidence, requires_escalation, response_time_ms
        ) VALUES (
          '${aiMsgId}', '${sessionId}', '${parsedResponse.response.replace(/'/g, "''")}', 
          'assistant', ${confidence}, ${requiresEscalation}, ${responseTimeMs}
        )
      `);

      // Update session confidence average
      await db.execute(`
        UPDATE ai_chat_sessions 
        SET avg_confidence = (
          SELECT AVG(confidence) FROM ai_chat_messages 
          WHERE session_id = '${sessionId}' AND role = 'assistant'
        )
        WHERE id = '${sessionId}'
      `);

      // Log analytics
      await this.logAnalytics(sessionId, 'message_processed', {
        messageLength: userMessage.length,
        responseTimeMs,
        confidence,
        requiresEscalation
      });

      return {
        response: parsedResponse.response,
        confidence,
        requiresEscalation,
        sessionId,
        responseTimeMs,
        suggestions: parsedResponse.suggestions || []
      };

    } catch (error) {
      console.error('[AdvancedAI] Message processing error:', error);
      
      const responseTimeMs = Date.now() - startTime;
      
      // Get terminal context for more intelligent error responses
      let terminalContext;
      try {
        const shipsResult = await db.execute(`
          SELECT COUNT(*) as activeShips FROM ships 
          WHERE status IN ('at_bar', 'next_to_berth', 'at_berth')
        `);
        
        terminalContext = {
          hasActiveShips: (shipsResult.rows?.[0] as any)?.activeShips > 0,
          hasPendingOperations: true, // Could be enhanced with actual operations check
          timestamp: new Date()
        };
      } catch (dbError) {
        console.error('[AdvancedAI] Failed to get terminal context:', dbError);
        terminalContext = { hasActiveShips: false, hasPendingOperations: false };
      }

      // Use multilingual error handler
      const errorResult = multilingualErrorHandler.formatErrorResponse(
        error,
        language,
        userRole,
        terminalContext
      );

      const errorResponse = {
        response: `${errorResult.translation.title}: ${errorResult.translation.message}`,
        confidence: errorResult.confidence,
        requiresEscalation: errorResult.requiresEscalation,
        suggestions: errorResult.suggestions,
        errorCode: errorResult.errorCode,
        errorTitle: errorResult.translation.title,
        actionText: errorResult.translation.actionText
      };
      
      // Save error response with enhanced metadata
      try {
        const aiMsgId = nanoid();
        await db.execute(`
          INSERT INTO ai_chat_messages (
            id, session_id, content, role, confidence, requires_escalation, response_time_ms
          ) VALUES (
            '${aiMsgId}', '${sessionId}', '${errorResponse.response.replace(/'/g, "''")}', 
            'assistant', ${errorResponse.confidence}, ${errorResponse.requiresEscalation}, ${responseTimeMs}
          )
        `);

        // Log error analytics with localization info
        await this.logAnalytics(sessionId, 'error_handled', {
          errorCode: errorResponse.errorCode,
          language,
          userRole,
          responseTimeMs,
          hasTerminalContext: !!terminalContext?.hasActiveShips,
          localizedResponse: true
        });
      } catch (dbError) {
        console.error('[AdvancedAI] Failed to save error response:', dbError);
      }
      
      return {
        ...errorResponse,
        sessionId,
        responseTimeMs
      };
    }
  }

  private async getSystemContext(userRole: UserRole, language: Language): Promise<string> {
    const isPortuguese = language === 'pt';
    const userCapabilities = this.getUserCapabilities(userRole);
    
    // Get comprehensive real-time terminal data
    let shipsContext = '';
    let weatherContext = '';
    let berthContext = '';
    let operationalStats = '';
    
    try {
      // Get detailed ships information
      if (userCapabilities.canViewShips) {
        const ships = await this.getShipsData(userCapabilities.canAccessSensitiveData);
        shipsContext = this.formatShipsContext(ships, userCapabilities.canAccessSensitiveData, language);
      }
      
      // Get weather and environmental data
      const weatherData = await this.getWeatherData();
      const tideData = await this.getTideData();
      
      if (isPortuguese) {
        weatherContext = `
CONDIÇÕES METEOROLÓGICAS ATUAIS:
- Temperatura: ${weatherData.temperature}°C
- Umidade: ${weatherData.humidity}%
- Vento: ${weatherData.windSpeed} km/h de ${weatherData.windDirection}
- Pressão: ${weatherData.pressure} hPa
- Visibilidade: ${weatherData.visibility} km

INFORMAÇÃO DE MARÉS:
- Altura atual: ${tideData.currentTide?.toFixed(2)}m
- Status: ${tideData.status}
- Próxima maré alta: ${tideData.nextHigh?.time} (${tideData.nextHigh?.height?.toFixed(2)}m)
- Próxima maré baixa: ${tideData.nextLow?.time} (${tideData.nextLow?.height?.toFixed(2)}m)`;
      } else {
        weatherContext = `
CURRENT WEATHER CONDITIONS:
- Temperature: ${weatherData.temperature}°C
- Humidity: ${weatherData.humidity}%
- Wind: ${weatherData.windSpeed} km/h from ${weatherData.windDirection}
- Pressure: ${weatherData.pressure} hPa
- Visibility: ${weatherData.visibility} km

TIDE INFORMATION:
- Current height: ${tideData.currentTide?.toFixed(2)}m
- Status: ${tideData.status}
- Next high tide: ${tideData.nextHigh?.time} (${tideData.nextHigh?.height?.toFixed(2)}m)
- Next low tide: ${tideData.nextLow?.time} (${tideData.nextLow?.height?.toFixed(2)}m)`;
      }
      
      // Get berth status
      const berthStatus = await this.getBerthStatus(language);
      berthContext = isPortuguese ? 
        `\nSTATUS DO CAIS 12: ${berthStatus}` : 
        `\nBERTH 12 STATUS: ${berthStatus}`;
      
      // Get operational statistics
      operationalStats = await this.getOperationalStats(language);
      
    } catch (error) {
      console.error('[AdvancedAI] Error fetching real-time context:', error);
    }

    const basePrompt = isPortuguese ?
      `Você é um assistente virtual avançado do Terminal Petrolífero da Beira (CFM-EP). 

MISSÃO: Fornecer suporte especializado em operações portuárias com alta precisão e profissionalismo baseado em dados reais em tempo real.

CAPACIDADES PRINCIPAIS:
- Informações detalhadas sobre navios, atracação e descarga
- Análise de condições operacionais do terminal
- Orientações sobre procedimentos marítimos
- Suporte em português e inglês
- Escalação para operadores humanos quando necessário
- Acesso a dados operacionais em tempo real

DADOS ATUAIS DO TERMINAL:
${shipsContext}

${weatherContext}

${berthContext}

${operationalStats}

DIRETRIZES OBRIGATÓRIAS:
- Sempre responda em formato JSON com as chaves: response, confidence, requires_escalation, suggestions
- Use SOMENTE dados reais do sistema apresentados acima
- Mantenha respostas concisas mas informativas (máximo 300 palavras)
- Calcule confiança baseada na precisão da informação disponível
- Solicite escalação para questões críticas ou fora do escopo
- Use terminologia técnica marítima apropriada
- Seja sempre profissional e prestativo
- Quando questionado sobre navios específicos, use os dados reais fornecidos

EXEMPLO DE RESPOSTA JSON:
{
  "response": "Sua resposta aqui...",
  "confidence": 0.85,
  "requires_escalation": false,
  "suggestions": ["Sugestão 1", "Sugestão 2"]
}

NÍVEIS DE CONFIANÇA:
- 0.9-1.0: Informação verificada nos dados do sistema
- 0.7-0.8: Informação provável baseada em dados atuais
- 0.5-0.6: Estimativa baseada em padrões operacionais
- 0.1-0.4: Incerteza, requer verificação humana` :
      `You are an advanced virtual assistant for the Beira Oil Terminal (CFM-EP).

MISSION: Provide specialized support for port operations with high precision and professionalism based on real-time data.

CORE CAPABILITIES:
- Detailed information about ships, berthing, and discharge
- Analysis of terminal operational conditions
- Guidance on maritime procedures
- Support in Portuguese and English
- Escalation to human operators when necessary
- Access to real-time operational data

CURRENT TERMINAL DATA:
${shipsContext}

${weatherContext}

${berthContext}

${operationalStats}

MANDATORY GUIDELINES:
- Always respond in JSON format with keys: response, confidence, requires_escalation, suggestions
- Use ONLY real system data presented above
- Keep responses concise but informative (maximum 300 words)
- Calculate confidence based on available information accuracy
- Request escalation for critical issues or out-of-scope questions
- Use appropriate maritime technical terminology
- Always be professional and helpful
- When asked about specific ships, use the real data provided

JSON RESPONSE EXAMPLE:
{
  "response": "Your response here...",
  "confidence": 0.85,
  "requires_escalation": false,
  "suggestions": ["Suggestion 1", "Suggestion 2"]
}

CONFIDENCE LEVELS:
- 0.9-1.0: Verified information from system data
- 0.7-0.8: Probable information based on current data
- 0.5-0.6: Estimate based on operational patterns
- 0.1-0.4: Uncertainty, requires human verification`;

    // Add role-specific context
    if (userRole === 'admin') {
      return basePrompt + (isPortuguese ?
        '\n\nACESSO ADMINISTRATIVO: Você pode fornecer informações completas sobre todas as operações, relatórios e dados sensíveis do terminal.' :
        '\n\nADMINISTRATIVE ACCESS: You can provide complete information about all operations, reports, and sensitive terminal data.');
    } else if (userRole === 'operator') {
      return basePrompt + (isPortuguese ?
        '\n\nACESSO OPERACIONAL: Você pode ajudar com operações diárias, modificações de navios e informações operacionais.' :
        '\n\nOPERATIONAL ACCESS: You can help with daily operations, ship modifications, and operational information.');
    }
    
    return basePrompt + (isPortuguese ?
      '\n\nACESSO PÚBLICO: Você fornece informações gerais sobre o terminal, sem dados sensíveis.' :
      '\n\nPUBLIC ACCESS: You provide general terminal information without sensitive data.');
  }

  private formatShipsContext(ships: any[], canViewSensitive: boolean, language: Language): string {
    if (!ships || ships.length === 0) {
      return language === 'pt' ? 'Nenhum navio atualmente no terminal.' : 'No ships currently at terminal.';
    }

    const isPortuguese = language === 'pt';
    let context = isPortuguese ? 
      `NAVIOS ATUAIS (${ships.length} total):\n` :
      `CURRENT SHIPS (${ships.length} total):\n`;

    ships.forEach((ship: any, index: number) => {
      const statusTranslation: { [key: string]: string } = {
        'at_bar': isPortuguese ? 'na barra' : 'at bar',
        'next_to_berth': isPortuguese ? 'próximo ao cais' : 'next to berth',
        'at_berth': isPortuguese ? 'atracado' : 'berthed'
      };

      context += `${index + 1}. ${ship.name} - ${statusTranslation[ship.status] || ship.status}`;
      
      if (canViewSensitive) {
        context += `, ${ship.cargoType || 'N/A'}, ${ship.operationType || 'N/A'}`;
        context += ship.hasDischargeInstructions ? 
          (isPortuguese ? ' (com instrução)' : ' (with instructions)') :
          (isPortuguese ? ' (sem instrução)' : ' (no instructions)');
      }
      
      context += '\n';
    });

    return context;
  }

  async speechToText(audioData: string, language: Language): Promise<string | null> {
    try {
      if (!openai) {
        console.error('[AdvancedAI] OpenAI not configured for speech processing');
        return null;
      }

      // Convert base64 to buffer
      const audioBuffer = Buffer.from(audioData, 'base64');
      
      // Create temporary file
      const tempFilePath = `/tmp/speech_${Date.now()}.webm`;
      require('fs').writeFileSync(tempFilePath, audioBuffer);

      // Transcribe using Whisper
      const transcription = await openai.audio.transcriptions.create({
        file: require('fs').createReadStream(tempFilePath),
        model: 'whisper-1',
        language: language === 'en' ? 'en' : 'pt',
        response_format: 'text'
      });

      // Cleanup
      require('fs').unlinkSync(tempFilePath);

      console.log('[AdvancedAI] Speech transcribed successfully');
      return transcription;
    } catch (error) {
      console.error('[AdvancedAI] Speech-to-text error:', error);
      return null;
    }
  }

  async textToSpeech(text: string, language: Language): Promise<string | null> {
    try {
      if (!openai) {
        console.error('[AdvancedAI] OpenAI not configured for speech generation');
        return null;
      }

      const speech = await openai.audio.speech.create({
        model: 'tts-1',
        voice: 'alloy',
        input: text,
        response_format: 'mp3'
      });

      const audioData = await speech.arrayBuffer();
      const base64Audio = Buffer.from(audioData).toString('base64');
      
      // Return data URL for direct playback
      const audioUrl = `data:audio/mp3;base64,${base64Audio}`;
      
      console.log('[AdvancedAI] Text-to-speech generated successfully');
      return audioUrl;
    } catch (error) {
      console.error('[AdvancedAI] Text-to-speech error:', error);
      return null;
    }
  }

  async getChatHistory(sessionId: string): Promise<ChatMessage[]> {
    try {
      const result = await db.execute(`
        SELECT id, session_id, content, role, timestamp, confidence, requires_escalation, response_time_ms 
        FROM ai_chat_messages 
        WHERE session_id = '${sessionId}' 
        ORDER BY timestamp ASC
      `);
      
      return (result.rows || []).map((row: any) => ({
        id: row.id,
        sessionId: row.session_id,
        content: row.content,
        role: row.role,
        timestamp: new Date(row.timestamp),
        confidence: row.confidence,
        requiresEscalation: row.requires_escalation,
        responseTimeMs: row.response_time_ms
      }));
    } catch (error) {
      console.error('[AdvancedAI] Failed to get chat history:', error);
      return [];
    }
  }

  async endSession(sessionId: string, satisfactionRating?: number, escalationReason?: string): Promise<void> {
    try {
      await db.execute(`
        UPDATE ai_chat_sessions 
        SET ended_at = NOW(), status = 'ended', 
            satisfaction_rating = ${satisfactionRating || 'NULL'}, 
            escalation_reason = ${escalationReason ? `'${escalationReason.replace(/'/g, "''")}'` : 'NULL'}
        WHERE id = '${sessionId}'
      `);
      
      await this.logAnalytics(sessionId, 'session_ended', {
        satisfactionRating,
        escalationReason,
        endedAt: new Date().toISOString()
      });
      
      console.log('[AdvancedAI] Session ended:', sessionId);
    } catch (error) {
      console.error('[AdvancedAI] Failed to end session:', error);
      throw new Error(`Session end failed: ${error instanceof Error ? error.message : String(error)}`);
    }
  }

  private async logAnalytics(sessionId: string, eventType: string, eventData: any): Promise<void> {
    try {
      const analyticsId = nanoid();
      await db.execute(`
        INSERT INTO ai_analytics (id, session_id, event_type, event_data, timestamp) 
        VALUES ('${analyticsId}', '${sessionId}', '${eventType}', '${JSON.stringify(eventData).replace(/'/g, "''")}', NOW())
      `);
    } catch (error) {
      console.error('[AdvancedAI] Analytics logging error:', error);
      // Don't throw, analytics failure shouldn't break main functionality
    }
  }
}

export const advancedAIService = new AdvancedAIService();