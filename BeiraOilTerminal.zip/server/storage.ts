import {
  users,
  userPermissions,
  ships,
  cargoParcels,
  dischargeProgress,
  dischargeRecords,
  operationalDischargeRecords,
  terminalSettings,
  notificationSubscriptions,
  berthingRecords,
  undockingRecords,
  berthMaintenance,
  cargoAgents,
  monthlyReports,
  reportAccessLogs,
  swapOperations,
  dischargeEvents,
  parcelDischargeControl,
  hourlyDischargeRecords,
  dischargeStoppages,
  waitingTimes,
  agents,
  predictedArrivals,
  type User,
  type InsertUser,
  type UserPermission,
  type InsertUserPermission,

  type Ship,
  type InsertShip,
  type CargoParcel,
  type InsertCargoParcel,
  type DischargeProgress,
  type InsertDischargeProgress,
  type OperationalDischargeRecord,
  type InsertOperationalDischargeRecord,
  type TerminalSettings,
  type UpdateShipStatus,
  type NotificationSubscription,
  type InsertNotificationSubscription,
  type BerthingRecord,
  type InsertBerthingRecord,
  type UndockingRecord,
  type InsertUndockingRecord,
  type BerthMaintenance,
  type InsertBerthMaintenance,
  type UpdateBerthMaintenance,
  type CargoAgent,
  type InsertCargoAgent,
  type MonthlyReport,
  type InsertMonthlyReport,
  type ReportAccessLog,
  type InsertReportAccessLog,
  type Agent,
  type InsertAgent,
  type PredictedArrival,
  type InsertPredictedArrival,
  customDischargeRates,
  type CustomDischargeRate,
  type InsertCustomDischargeRate,
  type SwapOperation,
  type InsertSwapOperation,
  type DischargeEvent,
  type InsertDischargeEvent,
  type ParcelDischargeControl,
  type InsertParcelDischargeControl,
  type HourlyDischargeRecord,
  type InsertHourlyDischargeRecord,
  type DischargeStoppage,
  type InsertDischargeStoppage,
  type WaitingTime,
  type InsertWaitingTime,
} from "@shared/schema";
import { Permission, UserRole, getDefaultPermissions } from "@shared/permissions";
import { db } from "./db";
import { eq, desc, and, or, isNull, gte, lte, inArray, sql } from "drizzle-orm";
import { dischargeInstructionEmailService } from "./emailService";

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserById(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  upsertUser(userData: any): Promise<User>;
  getAllUsers(): Promise<User[]>;
  getUsersByStatus(status: string): Promise<User[]>;
  getPendingUsers(): Promise<User[]>;
  approveUser(userId: number, approvedBy: number, role: string): Promise<User>;
  rejectUser(userId: number): Promise<boolean>;
  updateUser(userId: number, updateData: Partial<User>): Promise<User>;
  deleteUser(userId: number): Promise<boolean>;
  
  // Permission operations
  getUserPermissions(userId: number): Promise<UserPermission[]>;
  grantPermission(permission: InsertUserPermission): Promise<UserPermission>;
  revokePermission(userId: number, permission: Permission): Promise<boolean>;
  hasPermission(userId: number, permission: Permission): Promise<boolean>;
  
  // Ship operations
  createShip(ship: InsertShip, parcels: InsertCargoParcel[]): Promise<Ship>;
  getShips(): Promise<(Ship & { parcels: CargoParcel[]; latestProgress?: DischargeProgress })[]>;
  getShipById(id: number): Promise<(Ship & { parcels: CargoParcel[]; latestProgress?: DischargeProgress }) | undefined>;
  updateShipStatus(id: number, status: UpdateShipStatus): Promise<Ship>;
  updateCompleteShipInfo(id: number, data: Partial<Ship>, parcels?: any[]): Promise<Ship>;
  updateShipOperationType(id: number, operationType: string): Promise<Ship>;
  addParcelToShip(shipId: number, parcelData: InsertCargoParcel): Promise<CargoParcel>;
  
  // Cargo parcels operations
  createParcel(parcel: InsertCargoParcel): Promise<CargoParcel>;
  updateParcel(id: number, parcel: Partial<CargoParcel>): Promise<CargoParcel>;
  deleteParcel(id: number): Promise<boolean>;
  getParcelsForShip(shipId: number): Promise<CargoParcel[]>;
  
  // Discharge progress operations
  createDischargeProgress(progress: InsertDischargeProgress): Promise<DischargeProgress>;
  getLatestDischargeProgress(shipId: number): Promise<DischargeProgress | undefined>;
  
  // Terminal settings
  getTerminalSettings(): Promise<TerminalSettings>;
  updateCurrentTide(tide: number): Promise<TerminalSettings>;
  
  // Berthing calculations
  canShipBerth(shipDraft: number): Promise<{ canBerth: boolean; message?: string }>;
  
  // Email notifications
  sendBerthingConfirmationEmail(shipId: number): Promise<boolean>;
  sendInstructionRequestEmail(shipId: number): Promise<boolean>;
  confirmDischargeInstruction(shipId: number, token: string): Promise<{ success: boolean; ship?: Ship; message?: string }>;
  
  // Notification subscription management
  createNotificationSubscription(subscription: InsertNotificationSubscription): Promise<NotificationSubscription>;
  getNotificationSubscriptions(shipId: number): Promise<NotificationSubscription[]>;
  updateNotificationSubscription(id: number, updates: Partial<NotificationSubscription>): Promise<NotificationSubscription>;
  deleteNotificationSubscription(id: number): Promise<boolean>;
  
  // Send automated alerts
  sendShipStatusChangeAlerts(shipId: number, oldStatus: string, newStatus: string): Promise<void>;
  
  // Cargo agents operations
  createCargoAgent(agent: InsertCargoAgent, shipId: number): Promise<CargoAgent>;
  getCargoAgents(shipId: number): Promise<CargoAgent[]>;
  updateCargoAgent(id: number, updates: Partial<CargoAgent>): Promise<CargoAgent>;
  deleteCargoAgent(id: number): Promise<boolean>;
  
  // Berthing records
  createBerthingRecord(record: InsertBerthingRecord): Promise<BerthingRecord>;
  getBerthingRecord(shipId: number): Promise<BerthingRecord | undefined>;
  getAllBerthingRecords(): Promise<BerthingRecord[]>;
  
  // Undocking records
  createUndockingRecord(record: InsertUndockingRecord): Promise<UndockingRecord>;
  getUndockingRecord(shipId: number): Promise<UndockingRecord | undefined>;
  createOrUpdateUndockingRecord(undockingData: any): Promise<UndockingRecord>;
  
  // Berth maintenance operations
  getBerthMaintenanceStatus(): Promise<BerthMaintenance | undefined>;
  setBerthMaintenance(maintenance: UpdateBerthMaintenance, userId: number): Promise<BerthMaintenance>;
  endBerthMaintenance(userId: number): Promise<BerthMaintenance>;
  
  // SWAP operations
  getSwapOperations(): Promise<SwapOperation[]>;
  createSwapOperation(swapOp: InsertSwapOperation): Promise<SwapOperation>;
  updateSwapOperation(id: number, swapOp: Partial<InsertSwapOperation>): Promise<SwapOperation>;
  deleteSwapOperation(id: number): Promise<void>;


  
  // Ship registry and reporting operations
  getShipsForPeriod(startDate: Date, endDate: Date): Promise<(Ship & { parcels: CargoParcel[] })[]>;
  getDepartedShipsForPeriod(startDate: Date, endDate: Date): Promise<(Ship & { parcels: CargoParcel[] })[]>;
  createMonthlyReport(report: InsertMonthlyReport): Promise<MonthlyReport>;
  getMonthlyReports(): Promise<MonthlyReport[]>;
  getMonthlyReport(id: number): Promise<MonthlyReport | undefined>;
  cleanupCompletedShips(startDate: Date, endDate: Date): Promise<void>;
  logReportAccess(reportId: number, userId: number, ipAddress?: string): Promise<void>;
  
  // Custom discharge rates operations
  createCustomDischargeRate(rateData: InsertCustomDischargeRate): Promise<CustomDischargeRate>;
  getCustomDischargeRates(): Promise<CustomDischargeRate[]>;
  getCustomRatesForShip(shipId: number): Promise<CustomDischargeRate[]>;
  deleteCustomDischargeRate(id: number): Promise<boolean>;
  
  // Operational discharge control
  createOperationalDischargeRecord(record: InsertOperationalDischargeRecord): Promise<OperationalDischargeRecord>;
  getOperationalDischargeRecords(shipId: number): Promise<OperationalDischargeRecord[]>;
  updateOperationalDischargeRecord(recordId: number, updates: any): Promise<OperationalDischargeRecord>;
  getLatestOperationalRecord(shipId: number, operationType?: string): Promise<OperationalDischargeRecord | undefined>;
  getOperationalDischargeHistory(filters: { date?: string; ship?: string; operation?: string }): Promise<any[]>;
  getShipsSummary(): Promise<any[]>;

  // Agent operations
  createAgent(agentData: InsertAgent): Promise<Agent>;
  getAgentById(id: number): Promise<Agent | undefined>;
  getAgentByUsername(username: string): Promise<Agent | undefined>;
  getAllAgents(): Promise<Agent[]>;
  getPendingAgents(): Promise<Agent[]>;
  approveAgent(agentId: number, approvedBy: number, permissionLevel: string): Promise<Agent>;
  rejectAgent(agentId: number, rejectedBy: number, reason: string): Promise<Agent>;
  updateAgent(id: number, updates: Partial<Agent>): Promise<Agent>;

  // Predicted arrivals operations
  createPredictedArrival(arrivalData: InsertPredictedArrival): Promise<PredictedArrival>;
  getPredictedArrivals(agentId?: number): Promise<PredictedArrival[]>;
  getPredictedArrivalById(id: number): Promise<PredictedArrival | undefined>;
  updatePredictedArrival(id: number, updates: Partial<PredictedArrival>): Promise<PredictedArrival>;
  confirmPredictedArrival(id: number, arrivalDateTime: Date, countermark: string): Promise<PredictedArrival>;

  // Discharge Control System operations
  createDischargeEvent(eventData: any): Promise<any>;
  getDischargeEvents(shipId: number): Promise<any[]>;
  updateDischargeEvent(eventId: number, updates: any): Promise<any>;
  createParcelDischargeControl(controlData: any): Promise<any>;
  getParcelDischargeControls(shipId: number): Promise<any[]>;
  createHourlyDischargeRecord(recordData: any): Promise<any>;
  getHourlyDischargeRecords(shipId: number): Promise<any[]>;
  createDischargeStoppage(stoppageData: any): Promise<any>;
  getDischargeStoppages(shipId: number): Promise<any[]>;
  createWaitingTime(waitingData: any): Promise<any>;
  getWaitingTimes(shipId: number): Promise<any[]>;
  convertPredictionToShip(predictionId: number): Promise<Ship>;
  
  // Agreed discharge rate management
  getAgreedDischargeRate(shipId: number): Promise<any>;
  updateAgreedDischargeRate(shipId: number, agreedRate: number): Promise<void>;
  setAgreedDischargeRate(rateData: any): Promise<any>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserById(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user;
  }

  async createUser(userData: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(userData).returning();
    return user;
  }

  async getAllUsers(): Promise<User[]> {
    return await db.select().from(users);
  }

  async getUsersByStatus(status: string): Promise<User[]> {
    return await db.select().from(users).where(eq(users.status, status));
  }

  async getPendingUsers(): Promise<User[]> {
    return await db.select().from(users).where(eq(users.status, "pending"));
  }

  async approveUser(userId: number, approvedBy: number, role: string): Promise<User> {
    try {
      const [user] = await db
        .update(users)
        .set({
          status: "active",
          role: role,
          approvedBy: approvedBy,
          approvedAt: new Date(),
          updatedAt: new Date(),
        })
        .where(eq(users.id, userId))
        .returning();
      
      if (!user) {
        throw new Error(`User with ID ${userId} not found`);
      }
      
      return user;
    } catch (error) {
      console.error(`Error approving user ${userId}:`, error);
      throw error;
    }
  }

  async rejectUser(userId: number): Promise<boolean> {
    const [user] = await db
      .update(users)
      .set({
        status: "rejected",
        updatedAt: new Date(),
      })
      .where(eq(users.id, userId))
      .returning();
    return !!user;
  }

  async updateUser(userId: number, updateData: Partial<User>): Promise<User> {
    const [user] = await db
      .update(users)
      .set({
        ...updateData,
        updatedAt: new Date(),
      })
      .where(eq(users.id, userId))
      .returning();
    
    if (!user) {
      throw new Error(`User with ID ${userId} not found`);
    }
    
    return user;
  }

  async upsertUser(userData: any): Promise<User> {
    const [user] = await db
      .insert(users)
      .values({
        username: userData.sub || userData.id,
        password: 'replit_auth', // Placeholder for Replit auth
        email: userData.email,
        firstName: userData.first_name,
        lastName: userData.last_name,
        role: 'user',
        status: 'approved'
      })
      .onConflictDoUpdate({
        target: users.username,
        set: {
          email: userData.email,
          firstName: userData.first_name,
          lastName: userData.last_name,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  async deleteUser(userId: number): Promise<boolean> {
    // First delete related records
    await db.delete(userPermissions).where(eq(userPermissions.userId, userId));
    
    // Then delete the user
    const [user] = await db
      .delete(users)
      .where(eq(users.id, userId))
      .returning();
    
    return !!user;
  }

  // Permission operations
  async getUserPermissions(userId: number): Promise<UserPermission[]> {
    return await db
      .select()
      .from(userPermissions)
      .where(eq(userPermissions.userId, userId));
  }

  async grantPermission(permission: InsertUserPermission): Promise<UserPermission> {
    // Check if permission already exists
    const existing = await db
      .select()
      .from(userPermissions)
      .where(
        and(
          eq(userPermissions.userId, permission.userId),
          eq(userPermissions.permission, permission.permission)
        )
      );

    if (existing.length > 0) {
      return existing[0];
    }

    const [newPermission] = await db
      .insert(userPermissions)
      .values(permission)
      .returning();
    return newPermission;
  }

  async revokePermission(userId: number, permission: Permission): Promise<boolean> {
    const result = await db
      .delete(userPermissions)
      .where(
        and(
          eq(userPermissions.userId, userId),
          eq(userPermissions.permission, permission)
        )
      );
    return (result.rowCount || 0) > 0;
  }

  async hasPermission(userId: number, permission: Permission): Promise<boolean> {
    const result = await db
      .select()
      .from(userPermissions)
      .where(
        and(
          eq(userPermissions.userId, userId),
          eq(userPermissions.permission, permission)
        )
      );
    return result.length > 0;
  }

  // Ship operations (sobrecarga de método)
  async createShip(ship: InsertShip): Promise<Ship>;
  async createShip(ship: InsertShip, parcels: InsertCargoParcel[]): Promise<Ship>;
  async createShip(ship: InsertShip, parcels?: InsertCargoParcel[]): Promise<Ship> {
    const [newShip] = await db.insert(ships).values(ship).returning();
    
    if (parcels && parcels.length > 0) {
      const parcelsWithShipId = parcels.map(parcel => ({
        ...parcel,
        shipId: newShip.id,
      }));
      await db.insert(cargoParcels).values(parcelsWithShipId);
    }
    
    return newShip;
  }

  async getShips(): Promise<(Ship & { parcels: CargoParcel[]; latestProgress?: DischargeProgress })[]> {
    const allShips = await db.select().from(ships);
    
    const shipsWithData = await Promise.all(
      allShips.map(async (ship) => {
        const parcels = await db.select().from(cargoParcels).where(eq(cargoParcels.shipId, ship.id));
        const latestProgress = await this.getLatestDischargeProgress(ship.id);
        

        
        return {
          ...ship,
          parcels,
          latestProgress,
        };
      })
    );
    
    // Ordenação personalizada: IMOPETRO primeiro, depois regra 2:1 (2 trânsitos, 1 combinado)
    const sortedShips = this.applyBerthingRules(shipsWithData);
    
    return sortedShips;
  }

  private applyBerthingRules(ships: (Ship & { parcels: CargoParcel[]; latestProgress?: DischargeProgress })[]): (Ship & { parcels: CargoParcel[]; latestProgress?: DischargeProgress })[] {
    // Primeiro, separar navios IMOPETRO (sempre têm prioridade absoluta)
    const imopetroShips = ships.filter(ship => ship.cargoAgent?.toUpperCase().includes('IMOPETRO'));
    const nonImopetroShips = ships.filter(ship => !ship.cargoAgent?.toUpperCase().includes('IMOPETRO'));
    
    // Ordenar IMOPETRO por data de chegada
    imopetroShips.sort((a, b) => new Date(a.arrivalDateTime).getTime() - new Date(b.arrivalDateTime).getTime());
    
    // Separar navios não-IMOPETRO por tipo de operação (case-insensitive e tolerante a acentos)
    const normalizeOperationType = (type?: string) => {
      if (!type) return '';
      return type.toLowerCase()
        .replace('ã', 'a')
        .replace('â', 'a')
        .replace('ç', 'c')
        .replace('ê', 'e')
        .replace('í', 'i')
        .replace('ô', 'o')
        .replace('õ', 'o')
        .replace('ú', 'u');
    };

    const nacionalShips = nonImopetroShips.filter(ship => 
      normalizeOperationType(ship.operationType) === 'nacional'
    );
    const transitoShips = nonImopetroShips.filter(ship => 
      normalizeOperationType(ship.operationType) === 'transito'
    );
    const combinadoShips = nonImopetroShips.filter(ship => 
      normalizeOperationType(ship.operationType) === 'combinado'
    );
    
    // Ordenar cada tipo por data de chegada
    nacionalShips.sort((a, b) => new Date(a.arrivalDateTime).getTime() - new Date(b.arrivalDateTime).getTime());
    transitoShips.sort((a, b) => new Date(a.arrivalDateTime).getTime() - new Date(b.arrivalDateTime).getTime());
    combinadoShips.sort((a, b) => new Date(a.arrivalDateTime).getTime() - new Date(b.arrivalDateTime).getTime());
    
    const orderedShips: (Ship & { parcels: CargoParcel[]; latestProgress?: DischargeProgress })[] = [];
    
    // Primeiro adicionar todos os navios IMOPETRO
    orderedShips.push(...imopetroShips);
    
    // Segundo, adicionar todos os navios Nacional por ordem de chegada
    orderedShips.push(...nacionalShips);
    
    // Aplicar regra 2:1 (2 trânsitos para 1 combinado) para os restantes
    let transitoIndex = 0;
    let combinadoIndex = 0;
    let transitoCount = 0;
    
    while (transitoIndex < transitoShips.length || combinadoIndex < combinadoShips.length) {
      // Adicionar até 2 trânsitos
      if (transitoCount < 2 && transitoIndex < transitoShips.length) {
        orderedShips.push(transitoShips[transitoIndex]);
        transitoIndex++;
        transitoCount++;
      }
      // Se já adicionamos 2 trânsitos, adicionar 1 combinado (se disponível)
      else if (transitoCount === 2 && combinadoIndex < combinadoShips.length) {
        orderedShips.push(combinadoShips[combinadoIndex]);
        combinadoIndex++;
        transitoCount = 0; // Reset contador para próximo ciclo
      }
      // Se não há mais combinados mas ainda há trânsitos, continuar com trânsitos
      else if (combinadoIndex >= combinadoShips.length && transitoIndex < transitoShips.length) {
        orderedShips.push(transitoShips[transitoIndex]);
        transitoIndex++;
      }
      // Se não há mais trânsitos mas ainda há combinados, adicionar combinados
      else if (transitoIndex >= transitoShips.length && combinadoIndex < combinadoShips.length) {
        orderedShips.push(combinadoShips[combinadoIndex]);
        combinadoIndex++;
      }
      // Caso não tenha mais navios, sair do loop
      else {
        break;
      }
    }
    
    return orderedShips;
  }

  async getShipById(id: number): Promise<(Ship & { parcels: CargoParcel[]; latestProgress?: DischargeProgress }) | undefined> {
    const [ship] = await db.select().from(ships).where(eq(ships.id, id));
    if (!ship) return undefined;
    
    const parcels = await db.select().from(cargoParcels).where(eq(cargoParcels.shipId, id));
    const latestProgress = await this.getLatestDischargeProgress(id);
    
    return {
      ...ship,
      parcels,
      latestProgress,
    };
  }

  async updateShipStatus(id: number, statusUpdate: UpdateShipStatus): Promise<Ship> {
    // Get current ship data for status comparison
    const [currentShip] = await db.select().from(ships).where(eq(ships.id, id));
    const oldStatus = currentShip?.status;
    
    const updateData: any = { ...statusUpdate, updatedAt: new Date() };
    
    if (statusUpdate.status === "at_berth") {
      updateData.berthingStartedAt = new Date();
    } else if (statusUpdate.status === "departed") {
      updateData.departedAt = new Date();
    }
    
    const [updatedShip] = await db
      .update(ships)
      .set(updateData)
      .where(eq(ships.id, id))
      .returning();

    // Send automated alerts if status changed
    if (oldStatus && statusUpdate.status && oldStatus !== statusUpdate.status) {
      await this.sendShipStatusChangeAlerts(id, oldStatus, statusUpdate.status);
    }
    
    return updatedShip;
  }

  async updateCompleteShipInfo(id: number, data: Partial<Ship>, parcels?: any[]): Promise<Ship> {
    const [updatedShip] = await db
      .update(ships)
      .set({
        ...data,
        updatedAt: new Date(),
      })
      .where(eq(ships.id, id))
      .returning();

    if (!updatedShip) {
      throw new Error('Ship not found');
    }

    // Se parcelas foram fornecidas, atualiza as parcelas
    if (parcels && parcels.length > 0) {
      // Remove parcelas existentes
      await db
        .delete(cargoParcels)
        .where(eq(cargoParcels.shipId, id));

      // Adiciona as novas parcelas - SEM valores automáticos de densidade
      const parcelsWithShipId = parcels.map(parcel => ({
        shipId: id,
        parcelNumber: parcel.parcelNumber,
        product: parcel.product || '',
        volumeMT: parcel.volumeMT || '',
        volumeM3: parcel.volumeM3 || '',
        density15C: parcel.density15C || '', // REQUER entrada manual de dados reais do laboratório
        receiver: parcel.receiver,
        owner: parcel.owner,
        status: parcel.status || 'pending',
      }));

      await db.insert(cargoParcels).values(parcelsWithShipId);
    }

    return updatedShip;
  }

  async updateShipOperationType(id: number, operationType: string): Promise<Ship> {
    const [updatedShip] = await db
      .update(ships)
      .set({
        operationType,
        updatedAt: new Date(),
      })
      .where(eq(ships.id, id))
      .returning();

    if (!updatedShip) {
      throw new Error('Ship not found');
    }

    return updatedShip;
  }



  // Discharge progress operations
  async createDischargeProgress(progress: InsertDischargeProgress): Promise<DischargeProgress> {
    const [newProgress] = await db.insert(dischargeProgress).values(progress).returning();
    return newProgress;
  }

  async getLatestDischargeProgress(shipId: number): Promise<DischargeProgress | undefined> {
    const [latest] = await db
      .select()
      .from(dischargeProgress)
      .where(eq(dischargeProgress.shipId, shipId))
      .orderBy(desc(dischargeProgress.recordedAt))
      .limit(1);
    
    return latest;
  }

  // Terminal settings
  async getTerminalSettings(): Promise<TerminalSettings> {
    let [settings] = await db.select().from(terminalSettings).limit(1);
    
    if (!settings) {
      [settings] = await db.insert(terminalSettings).values({}).returning();
    }
    
    return settings;
  }

  async updateCurrentTide(tide: number): Promise<TerminalSettings> {
    const settings = await this.getTerminalSettings();
    
    const [updated] = await db
      .update(terminalSettings)
      .set({ currentTide: tide.toString(), updatedAt: new Date() })
      .where(eq(terminalSettings.id, settings.id))
      .returning();
    
    return updated;
  }

  // Berthing calculations
  async canShipBerth(shipDraft: number): Promise<{ canBerth: boolean; message?: string }> {
    const settings = await this.getTerminalSettings();
    const availableDepth = parseFloat(settings.currentTide) + parseFloat(settings.tolerance);
    
    if (shipDraft <= availableDepth) {
      return { canBerth: true };
    } else {
      return { 
        canBerth: false, 
        message: "Não é possível atracar o seu navio hoje. Vamos verificar na próxima maré." 
      };
    }
  }

  // Email notifications (mock for MVP)
  async sendBerthingConfirmationEmail(shipId: number): Promise<boolean> {
    const ship = await this.getShipById(shipId);
    if (!ship) return false;
    
    // Generate confirmation token
    const token = Buffer.from(`ship-${shipId}-confirm`).toString('base64');
    const confirmationUrl = `${process.env.REPLIT_DOMAINS ? `https://${process.env.REPLIT_DOMAINS.split(',')[0]}` : 'http://localhost:5000'}/api/ships/${shipId}/confirm/${token}`;
    
    // Mock email sending - in production, use nodemailer or similar
    console.log(`Mock email sent to ${ship.shipAgent} for ship ${ship.name} berthing confirmation`);
    console.log(`Confirmation URL: ${confirmationUrl}`);
    
    // Update confirmation email sent timestamp
    await db
      .update(ships)
      .set({ confirmationEmailSentAt: new Date() })
      .where(eq(ships.id, shipId));
    
    return true;
  }

  async sendInstructionRequestEmail(shipId: number): Promise<boolean> {
    const ship = await this.getShipById(shipId);
    if (!ship) return false;
    
    // Check if ship has valid email addresses
    if (!ship.shipAgentEmail) {
      console.error(`Ship ${ship.name} missing ship agent email address`);
      return false;
    }
    
    try {
      const success = await dischargeInstructionEmailService.sendInstructionRequestEmail(
        shipId,
        ship.name,
        ship.countermark,
        ship.shipAgentEmail,
        ship.cargoAgentEmail || ship.shipAgentEmail // Use ship agent email as fallback
      );
      
      if (success) {
        console.log(`Discharge instruction email sent successfully to ${ship.shipAgentEmail} for ship ${ship.name}`);
      } else {
        console.error(`Failed to send discharge instruction email for ship ${ship.name}`);
      }
      
      return success;
    } catch (error) {
      console.error(`Error sending discharge instruction email for ship ${ship.name}:`, error);
      return false;
    }
  }

  async confirmDischargeInstruction(shipId: number, token: string): Promise<{ success: boolean; ship?: Ship; message?: string }> {
    // Validate token
    if (!dischargeInstructionEmailService.validateConfirmationToken(shipId, token)) {
      return { 
        success: false, 
        message: "Token inválido ou expirado. Solicite uma nova confirmação." 
      };
    }

    // Get ship
    const ship = await this.getShipById(shipId);
    if (!ship) {
      return { 
        success: false, 
        message: "Navio não encontrado." 
      };
    }

    // Check if ship is in correct status
    if (ship.status !== 'at_bar') {
      return { 
        success: false, 
        message: "O navio não está no status correto para confirmar instruções de descarga." 
      };
    }

    // Check if already has discharge instructions
    if (ship.hasDischargeInstructions) {
      return { 
        success: false, 
        message: "As instruções de descarga já foram confirmadas para este navio." 
      };
    }

    try {
      // Update ship to have discharge instructions but keep status as 'at_bar'
      // Ship will remain in "Com Instrução" list awaiting priorities
      const [updatedShip] = await db
        .update(ships)
        .set({ 
          hasDischargeInstructions: true,
          updatedAt: new Date()
        })
        .where(eq(ships.id, shipId))
        .returning();

      // Send status change alerts
      await this.sendShipStatusChangeAlerts(shipId, 'without_instructions', 'with_instructions');

      return { 
        success: true, 
        ship: updatedShip,
        message: "Instruções de descarga confirmadas com sucesso! O navio aguarda na lista 'Com Instrução' conforme prioridades." 
      };
    } catch (error) {
      console.error(`Error confirming discharge instructions for ship ${shipId}:`, error);
      return { 
        success: false, 
        message: "Erro interno. Tente novamente." 
      };
    }
  }

  // Notification subscription management
  async createNotificationSubscription(subscription: InsertNotificationSubscription): Promise<NotificationSubscription> {
    const [newSubscription] = await db.insert(notificationSubscriptions).values(subscription).returning();
    return newSubscription;
  }

  async getNotificationSubscriptions(shipId: number): Promise<NotificationSubscription[]> {
    return await db
      .select()
      .from(notificationSubscriptions)
      .where(and(eq(notificationSubscriptions.shipId, shipId), eq(notificationSubscriptions.isActive, true)));
  }

  async updateNotificationSubscription(id: number, updates: Partial<NotificationSubscription>): Promise<NotificationSubscription> {
    const [updatedSubscription] = await db
      .update(notificationSubscriptions)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(notificationSubscriptions.id, id))
      .returning();
    
    return updatedSubscription;
  }

  async deleteNotificationSubscription(id: number): Promise<boolean> {
    const result = await db
      .update(notificationSubscriptions)
      .set({ isActive: false, updatedAt: new Date() })
      .where(eq(notificationSubscriptions.id, id));
    
    return (result.rowCount || 0) > 0;
  }

  async sendShipStatusChangeAlerts(shipId: number, oldStatus: string, newStatus: string): Promise<void> {
    try {
      const ship = await this.getShipById(shipId);
      if (!ship) return;

      const subscriptions = await this.getNotificationSubscriptions(shipId);
      
      if (subscriptions.length === 0) {
        // Create default subscriptions if none exist
        await this.createDefaultNotificationSubscriptions(shipId, ship);
      }

      const recipients = subscriptions
        .filter(sub => sub.statusesToNotify.includes(newStatus) || sub.statusesToNotify.includes('all'))
        .map(sub => ({
          email: sub.contactType === 'email' ? sub.contactValue : undefined,
          phone: sub.contactType === 'sms' ? sub.contactValue : undefined,
        }));

      if (recipients.length > 0) {
        const { notificationManager } = await import('./notifications');
        await notificationManager.sendShipStatusAlert(ship, oldStatus, newStatus, recipients);
        console.log(`Status change alerts sent for ship ${ship.name}: ${oldStatus} → ${newStatus}`);
      }
    } catch (error) {
      console.error('Error sending ship status change alerts:', error);
    }
  }

  private async createDefaultNotificationSubscriptions(shipId: number, ship: Ship): Promise<void> {
    const defaultSubscriptions: InsertNotificationSubscription[] = [
      {
        shipId,
        contactType: 'email',
        contactValue: `${ship.shipAgent.toLowerCase().replace(/\s+/g, '.')}@maritime.com`,
        contactName: ship.shipAgent,
        role: 'ship_agent',
        statusesToNotify: ['at_bar', 'next_to_berth', 'at_berth', 'departed'],
      },
      {
        shipId,
        contactType: 'email',
        contactValue: `${ship.cargoAgent.toLowerCase().replace(/\s+/g, '.')}@cargo.com`,
        contactName: ship.cargoAgent,
        role: 'cargo_agent',
        statusesToNotify: ['at_berth', 'departed'],
      },
      {
        shipId,
        contactType: 'email',
        contactValue: 'operations@beiraoilterminal.co.mz',
        contactName: 'Terminal Operations',
        role: 'terminal_operator',
        statusesToNotify: ['all'],
      }
    ];

    for (const subscription of defaultSubscriptions) {
      await this.createNotificationSubscription(subscription);
    }
  }

  // Cargo agents operations
  async createCargoAgent(agent: InsertCargoAgent, shipId: number): Promise<CargoAgent> {
    const [newAgent] = await db
      .insert(cargoAgents)
      .values({ ...agent, shipId })
      .returning();
    return newAgent;
  }

  async getCargoAgents(shipId: number): Promise<CargoAgent[]> {
    return await db
      .select()
      .from(cargoAgents)
      .where(eq(cargoAgents.shipId, shipId))
      .orderBy(desc(cargoAgents.isPrimary), desc(cargoAgents.createdAt));
  }

  async getCargoParcelsByShip(shipId: number): Promise<CargoParcel[]> {
    return await db.select().from(cargoParcels).where(eq(cargoParcels.shipId, shipId));
  }

  async updateCargoAgent(id: number, updates: Partial<CargoAgent>): Promise<CargoAgent> {
    const [updatedAgent] = await db
      .update(cargoAgents)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(cargoAgents.id, id))
      .returning();
    return updatedAgent;
  }

  async deleteCargoAgent(id: number): Promise<boolean> {
    const result = await db
      .delete(cargoAgents)
      .where(eq(cargoAgents.id, id));
    return (result.rowCount || 0) > 0;
  }

  async createBerthingRecord(record: InsertBerthingRecord): Promise<BerthingRecord> {
    const [berthingRecord] = await db
      .insert(berthingRecords)
      .values(record)
      .returning();
    return berthingRecord;
  }

  async getAllBerthingRecords(): Promise<BerthingRecord[]> {
    return await db
      .select()
      .from(berthingRecords)
      .orderBy(desc(berthingRecords.createdAt));
  }

  async getBerthingRecord(shipId: number): Promise<BerthingRecord | undefined> {
    const [berthingRecord] = await db
      .select()
      .from(berthingRecords)
      .where(eq(berthingRecords.shipId, shipId))
      .orderBy(desc(berthingRecords.createdAt))
      .limit(1);
    return berthingRecord;
  }

  async updateBerthingRecord(shipId: number, updates: { firstRopeTime: string; lastRopeTime: string }): Promise<BerthingRecord | undefined> {
    // Parse datetime-local values as Maputo timezone (UTC+2)
    // Convert from "YYYY-MM-DDTHH:MM" to proper UTC timestamp that represents Maputo time
    const firstDate = new Date(updates.firstRopeTime + ':00+02:00');
    const lastDate = new Date(updates.lastRopeTime + ':00+02:00');
    
    const [updatedRecord] = await db
      .update(berthingRecords)
      .set({
        firstRopeTime: firstDate,
        lastRopeTime: lastDate,
      })
      .where(eq(berthingRecords.shipId, shipId))
      .returning();
    return updatedRecord;
  }

  async createUndockingRecord(undockingData: InsertUndockingRecord): Promise<UndockingRecord> {
    const [undockingRecord] = await db
      .insert(undockingRecords)
      .values(undockingData)
      .returning();
    return undockingRecord;
  }

  async getUndockingRecord(shipId: number): Promise<UndockingRecord | undefined> {
    const [undockingRecord] = await db
      .select()
      .from(undockingRecords)
      .where(eq(undockingRecords.shipId, shipId))
      .orderBy(desc(undockingRecords.createdAt))
      .limit(1);
    return undockingRecord;
  }

  async createOrUpdateUndockingRecord(undockingData: any): Promise<UndockingRecord> {
    // Check if undocking record already exists for this ship
    const existingRecord = await this.getUndockingRecord(undockingData.shipId);
    
    if (existingRecord) {
      // Update existing record
      const [updatedRecord] = await db
        .update(undockingRecords)
        .set({
          firstRopeTime: undockingData.firstRopeTime,
          lastRopeTime: undockingData.lastRopeTime,
        })
        .where(eq(undockingRecords.shipId, undockingData.shipId))
        .returning();
      return updatedRecord;
    } else {
      // Create new record
      const [newRecord] = await db
        .insert(undockingRecords)
        .values(undockingData)
        .returning();
      return newRecord;
    }
  }

  // Berth maintenance operations
  async getBerthMaintenanceStatus(): Promise<BerthMaintenance | undefined> {
    const [maintenanceRecord] = await db
      .select()
      .from(berthMaintenance)
      .orderBy(desc(berthMaintenance.createdAt))
      .limit(1);
    return maintenanceRecord;
  }

  async setBerthMaintenance(maintenance: UpdateBerthMaintenance, userId: number): Promise<BerthMaintenance> {
    const maintenanceData: InsertBerthMaintenance = {
      isUnderMaintenance: maintenance.isUnderMaintenance,
      maintenancePeriod: maintenance.maintenancePeriod,
      description: maintenance.description,
      startedAt: maintenance.isUnderMaintenance ? new Date() : null,
      endedAt: null,
      createdBy: userId,
    };

    const [newMaintenance] = await db
      .insert(berthMaintenance)
      .values(maintenanceData)
      .returning();
    return newMaintenance;
  }

  async endBerthMaintenance(userId: number): Promise<BerthMaintenance> {
    const maintenanceData: InsertBerthMaintenance = {
      isUnderMaintenance: false,
      maintenancePeriod: null,
      description: "Manutenção finalizada",
      startedAt: null,
      endedAt: new Date(),
      createdBy: userId,
    };

    const [endedMaintenance] = await db
      .insert(berthMaintenance)
      .values(maintenanceData)
      .returning();
    return endedMaintenance;
  }

  // Ship registry and reporting operations
  async getShipsForPeriod(startDate: Date, endDate: Date): Promise<(Ship & { parcels: CargoParcel[] })[]> {
    const shipsWithParcels = await db
      .select()
      .from(ships)
      .where(
        and(
          gte(ships.createdAt, startDate),
          lte(ships.createdAt, endDate)
        )
      )
      .orderBy(desc(ships.createdAt));

    const shipsWithParcelsData = await Promise.all(
      shipsWithParcels.map(async (ship) => {
        const parcels = await db
          .select()
          .from(cargoParcels)
          .where(eq(cargoParcels.shipId, ship.id));
        
        return { ...ship, parcels };
      })
    );

    return shipsWithParcelsData;
  }

  async getDepartedShipsForPeriod(startDate: Date, endDate: Date): Promise<(Ship & { parcels: CargoParcel[] })[]> {
    const departedShips = await db
      .select()
      .from(ships)
      .where(
        and(
          gte(ships.createdAt, startDate),
          lte(ships.createdAt, endDate),
          eq(ships.status, 'departed')
        )
      )
      .orderBy(desc(ships.updatedAt));

    const shipsWithParcelsData = await Promise.all(
      departedShips.map(async (ship) => {
        const parcels = await db
          .select()
          .from(cargoParcels)
          .where(eq(cargoParcels.shipId, ship.id));
        
        return { ...ship, parcels };
      })
    );

    return shipsWithParcelsData;
  }

  async createMonthlyReport(report: InsertMonthlyReport): Promise<MonthlyReport> {
    const [newReport] = await db
      .insert(monthlyReports)
      .values(report)
      .returning();
    return newReport;
  }

  async getMonthlyReports(): Promise<MonthlyReport[]> {
    return await db
      .select()
      .from(monthlyReports)
      .orderBy(desc(monthlyReports.generatedAt));
  }

  async getMonthlyReport(id: number): Promise<MonthlyReport | undefined> {
    const [report] = await db
      .select()
      .from(monthlyReports)
      .where(eq(monthlyReports.id, id));
    return report;
  }

  async cleanupCompletedShips(startDate: Date, endDate: Date): Promise<void> {
    // Buscar navios completados no período
    const completedShips = await db
      .select({ id: ships.id })
      .from(ships)
      .where(
        and(
          gte(ships.createdAt, startDate),
          lte(ships.createdAt, endDate),
          eq(ships.status, 'departed')
        )
      );

    if (completedShips.length === 0) {
      return;
    }

    const shipIds = completedShips.map(ship => ship.id);

    // Remover dados relacionados em ordem
    await db.delete(dischargeProgress).where(inArray(dischargeProgress.shipId, shipIds));
    await db.delete(notificationSubscriptions).where(inArray(notificationSubscriptions.shipId, shipIds));
    await db.delete(berthingRecords).where(inArray(berthingRecords.shipId, shipIds));
    await db.delete(cargoParcels).where(inArray(cargoParcels.shipId, shipIds));
    await db.delete(ships).where(inArray(ships.id, shipIds));

    console.log(`Cleaned up ${shipIds.length} completed ships from the database`);
  }

  async logReportAccess(reportId: number, userId: number, ipAddress?: string): Promise<void> {
    const accessLog: InsertReportAccessLog = {
      reportId,
      accessedBy: userId,
      ipAddress: ipAddress || null
    };

    await db.insert(reportAccessLogs).values(accessLog);
  }

  // SWAP Operations
  async getSwapOperations(): Promise<SwapOperation[]> {
    try {
      const result = await db.select({
        id: swapOperations.id,
        shipId: swapOperations.shipId,
        swapType: swapOperations.swapType,
        originalValue: swapOperations.originalValue,
        newValue: swapOperations.newValue,
        reason: swapOperations.reason,
        authorizedBy: swapOperations.authorizedBy,
        status: swapOperations.status,
        createdAt: swapOperations.createdAt,
        completedAt: swapOperations.completedAt,
        shipName: ships.name,
        shipCountermark: ships.countermark
      })
      .from(swapOperations)
      .leftJoin(ships, eq(swapOperations.shipId, ships.id))
      .orderBy(desc(swapOperations.createdAt));
      
      return result as SwapOperation[];
    } catch (error) {
      console.error("Error in getSwapOperations:", error);
      return [];
    }
  }

  async createSwapOperation(swapOp: InsertSwapOperation): Promise<SwapOperation> {
    const [createdSwapOp] = await db.insert(swapOperations).values(swapOp).returning();
    return createdSwapOp;
  }

  async updateSwapOperation(id: number, swapOp: Partial<InsertSwapOperation>): Promise<SwapOperation> {
    const [updatedSwapOp] = await db
      .update(swapOperations)
      .set(swapOp)
      .where(eq(swapOperations.id, id))
      .returning();
    return updatedSwapOp;
  }

  async deleteSwapOperation(id: number): Promise<void> {
    await db.delete(swapOperations).where(eq(swapOperations.id, id));
  }

  // Operational Statistics operations
  async getOperationalStats(shipId: number): Promise<OperationalStats[]> {
    try {
      return await db
        .select()
        .from(operationalStats)
        .where(eq(operationalStats.shipId, shipId))
        .orderBy(desc(operationalStats.createdAt));
    } catch (error) {
      console.error("Error fetching operational stats:", error);
      return [];
    }
  }

  async createOperationalStats(data: InsertOperationalStats): Promise<OperationalStats> {
    const [created] = await db.insert(operationalStats).values(data).returning();
    return created;
  }

  async getHourlyDischarge(shipId: number): Promise<HourlyDischarge[]> {
    try {
      return await db
        .select()
        .from(hourlyDischarge)
        .where(eq(hourlyDischarge.shipId, shipId))
        .orderBy(desc(hourlyDischarge.recordTime));
    } catch (error) {
      console.error("Error fetching hourly discharge:", error);
      return [];
    }
  }

  async createHourlyDischarge(data: InsertHourlyDischarge): Promise<HourlyDischarge> {
    const [created] = await db.insert(hourlyDischarge).values(data).returning();
    return created;
  }

  // Stoppage Records operations
  async getStoppageRecords(shipId: number): Promise<StoppageRecord[]> {
    try {
      return await db
        .select()
        .from(stoppageRecords)
        .where(eq(stoppageRecords.shipId, shipId))
        .orderBy(desc(stoppageRecords.createdAt));
    } catch (error) {
      console.error("Error fetching stoppage records:", error);
      return [];
    }
  }

  async createStoppageRecord(data: InsertStoppageRecord): Promise<StoppageRecord> {
    const [created] = await db.insert(stoppageRecords).values(data).returning();
    return created;
  }

  async updateStoppageRecord(id: number, data: Partial<InsertStoppageRecord>): Promise<StoppageRecord> {
    const [updated] = await db
      .update(stoppageRecords)
      .set(data)
      .where(eq(stoppageRecords.id, id))
      .returning();
    return updated;
  }

  // Parcel Discharge Time operations
  async getParcelDischargeTimes(shipId: number): Promise<ParcelDischargeTime[]> {
    try {
      return await db
        .select()
        .from(parcelDischargeTime)
        .where(eq(parcelDischargeTime.shipId, shipId))
        .orderBy(desc(parcelDischargeTime.createdAt));
    } catch (error) {
      console.error("Error fetching parcel discharge times:", error);
      return [];
    }
  }

  async createParcelDischargeTime(data: InsertParcelDischargeTime): Promise<ParcelDischargeTime> {
    const [created] = await db.insert(parcelDischargeTime).values(data).returning();
    return created;
  }

  async updateParcelDischargeTime(id: number, data: Partial<InsertParcelDischargeTime>): Promise<ParcelDischargeTime> {
    const [updated] = await db
      .update(parcelDischargeTime)
      .set(data)
      .where(eq(parcelDischargeTime.id, id))
      .returning();
    return updated;
  }

  async getParcelById(id: number): Promise<CargoParcel | undefined> {
    const [parcel] = await db
      .select()
      .from(cargoParcels)
      .where(eq(cargoParcels.id, id))
      .limit(1);
    return parcel;
  }

  // Advanced discharge records operations
  async createDischargeRecord(record: any): Promise<any> {
    const [dischargeRecord] = await db
      .insert(dischargeRecords)
      .values(record)
      .returning();
    return dischargeRecord;
  }

  // Operational discharge records methods
  async createOperationalDischargeRecord(record: InsertOperationalDischargeRecord): Promise<OperationalDischargeRecord> {
    const [operationalRecord] = await db
      .insert(operationalDischargeRecords)
      .values(record)
      .returning();
    return operationalRecord;
  }

  async getOperationalDischargeRecords(shipId: number): Promise<OperationalDischargeRecord[]> {
    return await db
      .select()
      .from(operationalDischargeRecords)
      .where(eq(operationalDischargeRecords.shipId, shipId))
      .orderBy(desc(operationalDischargeRecords.recordedAt));
  }

  async getLatestOperationalRecord(shipId: number, operationType?: string): Promise<OperationalDischargeRecord | undefined> {
    const conditions = [eq(operationalDischargeRecords.shipId, shipId)];
    
    if (operationType) {
      conditions.push(eq(operationalDischargeRecords.operationType, operationType));
    }
    
    const [record] = await db
      .select()
      .from(operationalDischargeRecords)
      .where(and(...conditions))
      .orderBy(desc(operationalDischargeRecords.recordedAt))
      .limit(1);
    
    return record;
  }

  async updateOperationalDischargeRecord(id: number, updates: Partial<InsertOperationalDischargeRecord>): Promise<OperationalDischargeRecord> {
    const [record] = await db
      .update(operationalDischargeRecords)
      .set(updates)
      .where(eq(operationalDischargeRecords.id, id))
      .returning();
    return record;
  }

  async updateDischargeRecord(recordId: number, updates: any): Promise<any> {
    const [dischargeRecord] = await db
      .update(dischargeRecords)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(dischargeRecords.id, recordId))
      .returning();
    return dischargeRecord;
  }

  async addDischargeStop(recordId: number, stopType: string, timestamp: string): Promise<any> {
    // Primeiro buscar o registro atual
    const [currentRecord] = await db
      .select()
      .from(dischargeRecords)
      .where(eq(dischargeRecords.id, recordId));

    if (!currentRecord) {
      throw new Error('Discharge record not found');
    }

    // Adicionar nova parada ao array apropriado
    let updates: any = { updatedAt: new Date() };
    
    switch (stopType) {
      case 'line_displacement':
        updates.lineDisplacementStops = [...(currentRecord.lineDisplacementStops || []), timestamp];
        break;
      case 'parcel_change':
        updates.parcelChangeStops = [...(currentRecord.parcelChangeStops || []), timestamp];
        break;
      case 'completion':
        updates.completionStops = [...(currentRecord.completionStops || []), timestamp];
        break;
      default:
        throw new Error('Invalid stop type');
    }

    const [updatedRecord] = await db
      .update(dischargeRecords)
      .set(updates)
      .where(eq(dischargeRecords.id, recordId))
      .returning();

    return updatedRecord;
  }

  async getDischargeRecords(shipId: number): Promise<any[]> {
    return await db
      .select()
      .from(dischargeRecords)
      .where(eq(dischargeRecords.shipId, shipId))
      .orderBy(dischargeRecords.createdAt);
  }

  // Enhanced cargo parcel operations with sequential numbering
  async addParcelToShip(shipId: number, parcelData: any): Promise<CargoParcel> {
    // Get existing parcels to determine next parcel number
    const existingParcels = await db
      .select()
      .from(cargoParcels)
      .where(eq(cargoParcels.shipId, shipId));
    
    // Find the next available parcel number
    let nextNumber = 1;
    if (existingParcels.length > 0) {
      const existingNumbers = existingParcels
        .map(p => {
          const match = p.parcelNumber?.match(/P(\d+)/);
          return match ? parseInt(match[1]) : 0;
        })
        .filter(n => n > 0);
      
      if (existingNumbers.length > 0) {
        nextNumber = Math.max(...existingNumbers) + 1;
      }
    }
    
    const parcelNumber = `P${nextNumber.toString().padStart(3, '0')}`;
    
    const [newParcel] = await db
      .insert(cargoParcels)
      .values({
        shipId,
        parcelNumber,
        product: parcelData.product || '',
        volumeMT: parcelData.volumeMT || null, // Aceita null para campos numéricos vazios
        volumeM3: parcelData.volumeM3 || null, // Aceita null para campos numéricos vazios
        density15C: parcelData.density15C || null, // NUNCA valores automáticos - requer dados reais do laboratório
        receiver: parcelData.receiver || '',
        owner: parcelData.owner || '',
      })
      .returning();
    
    return newParcel;
  }

  async updateParcel(parcelId: number, updateData: any): Promise<CargoParcel> {
    console.log('updateParcel called with:', { parcelId, updateData });
    
    // Verify parcel exists first
    const existingParcel = await db
      .select()
      .from(cargoParcels)
      .where(eq(cargoParcels.id, parcelId))
      .limit(1);
    
    if (existingParcel.length === 0) {
      throw new Error(`Parcel with ID ${parcelId} not found`);
    }
    
    console.log('Existing parcel found:', existingParcel[0]);
    
    const [updatedParcel] = await db
      .update(cargoParcels)
      .set({
        ...updateData,
        updatedAt: new Date(),
      })
      .where(eq(cargoParcels.id, parcelId))
      .returning();
    
    console.log('Parcel updated successfully:', updatedParcel);
    
    if (!updatedParcel) {
      throw new Error(`Failed to update parcel with ID ${parcelId}`);
    }
    
    return updatedParcel;
  }

  async deleteParcel(parcelId: number): Promise<boolean> {
    const result = await db
      .delete(cargoParcels)
      .where(eq(cargoParcels.id, parcelId));
    
    return (result.rowCount || 0) > 0;
  }

  async getParcelsForShip(shipId: number): Promise<CargoParcel[]> {
    const parcels = await db
      .select()
      .from(cargoParcels)
      .where(eq(cargoParcels.shipId, shipId))
      .orderBy(cargoParcels.parcelNumber);
    
    return parcels;
  }

  async getShipParcels(shipId: number): Promise<CargoParcel[]> {
    const parcels = await db
      .select()
      .from(cargoParcels)
      .where(eq(cargoParcels.shipId, shipId))
      .orderBy(cargoParcels.parcelNumber);
    
    return parcels;
  }

  async createParcel(parcel: InsertCargoParcel): Promise<CargoParcel> {
    const [newParcel] = await db
      .insert(cargoParcels)
      .values(parcel)
      .returning();
    
    return newParcel;
  }

  // Custom discharge rates operations
  async createCustomDischargeRate(rateData: InsertCustomDischargeRate): Promise<CustomDischargeRate> {
    // Delete existing rate for this parcel if exists
    await db.delete(customDischargeRates).where(eq(customDischargeRates.parcelId, rateData.parcelId));
    
    const [rate] = await db
      .insert(customDischargeRates)
      .values(rateData)
      .returning();
    return rate;
  }

  async getCustomDischargeRates(): Promise<CustomDischargeRate[]> {
    return await db.select().from(customDischargeRates);
  }

  async getCustomRatesForShip(shipId: number): Promise<CustomDischargeRate[]> {
    return await db
      .select()
      .from(customDischargeRates)
      .where(eq(customDischargeRates.shipId, shipId));
  }

  async deleteCustomDischargeRate(id: number): Promise<boolean> {
    const result = await db
      .delete(customDischargeRates)
      .where(eq(customDischargeRates.id, id));
    return (result.rowCount || 0) > 0;
  }

  // Sistema hierárquico de usuários - métodos simplificados
  async updateUserRole(userId: number, role: string): Promise<User> {
    const [user] = await db
      .update(users)
      .set({ role, updatedAt: new Date() })
      .where(eq(users.id, userId))
      .returning();
    
    if (!user) {
      throw new Error("User not found");
    }
    
    return user;
  }

  async activateUser(userId: number): Promise<User> {
    const [user] = await db
      .update(users)
      .set({ isActive: true, updatedAt: new Date() })
      .where(eq(users.id, userId))
      .returning();
    
    if (!user) {
      throw new Error("User not found");
    }
    
    return user;
  }

  async deactivateUser(userId: number): Promise<User> {
    const [user] = await db
      .update(users)
      .set({ isActive: false, updatedAt: new Date() })
      .where(eq(users.id, userId))
      .returning();
    
    if (!user) {
      throw new Error("User not found");
    }
    
    return user;
  }

  // Operational discharge history methods for management
  async getOperationalDischargeHistory(filters: { date?: string; ship?: string; operation?: string }): Promise<any[]> {
    const { ilike, lt, gte } = await import("drizzle-orm");
    
    let query = db
      .select({
        id: operationalDischargeRecords.id,
        shipId: operationalDischargeRecords.shipId,
        shipName: ships.name,
        operationType: operationalDischargeRecords.operationType,
        pressure: operationalDischargeRecords.pressure,
        dischargeRate: operationalDischargeRecords.dischargeRate,
        dischargeStartTime: operationalDischargeRecords.dischargeStartTime,
        dischargeEndTime: operationalDischargeRecords.dischargeEndTime,
        stopStartTime: operationalDischargeRecords.stopStartTime,
        stopEndTime: operationalDischargeRecords.stopEndTime,
        stopType: operationalDischargeRecords.stopType,
        stopComment: operationalDischargeRecords.stopComment,
        resumeComment: operationalDischargeRecords.resumeComment,
        hasLineDisplacement: operationalDischargeRecords.hasLineDisplacement,
        lineDisplacementDuration: operationalDischargeRecords.lineDisplacementDuration,
        parcelId: operationalDischargeRecords.parcelId,
        recordedAt: operationalDischargeRecords.recordedAt,
      })
      .from(operationalDischargeRecords)
      .leftJoin(ships, eq(operationalDischargeRecords.shipId, ships.id))
      .orderBy(desc(operationalDischargeRecords.recordedAt));

    // Apply filters
    const conditions = [];
    
    if (filters.date) {
      const startDate = new Date(filters.date);
      const endDate = new Date(filters.date);
      endDate.setDate(endDate.getDate() + 1);
      conditions.push(
        and(
          gte(operationalDischargeRecords.recordedAt, startDate),
          lt(operationalDischargeRecords.recordedAt, endDate)
        )
      );
    }
    
    if (filters.ship) {
      conditions.push(ilike(ships.name, `%${filters.ship}%`));
    }
    
    if (filters.operation) {
      conditions.push(eq(operationalDischargeRecords.operationType, filters.operation));
    }

    if (conditions.length > 0) {
      query = query.where(and(...conditions));
    }

    return await query;
  }

  async getShipsSummary(): Promise<any[]> {
    const shipsData = await db
      .select({
        id: ships.id,
        name: ships.name,
      })
      .from(ships);

    const result = [];
    for (const ship of shipsData) {
      const parcels = await db
        .select()
        .from(cargoParcels)
        .where(eq(cargoParcels.shipId, ship.id));
      
      result.push({
        ...ship,
        parcels
      });
    }

    return result;
  }

  // Agent operations
  async createAgent(agentData: InsertAgent): Promise<Agent> {
    const [agent] = await db.insert(agents).values(agentData).returning();
    return agent;
  }

  async getAgentById(id: number): Promise<Agent | undefined> {
    const [agent] = await db.select().from(agents).where(eq(agents.id, id));
    return agent;
  }

  async getAgentByUsername(username: string): Promise<Agent | undefined> {
    const [agent] = await db.select().from(agents).where(eq(agents.username, username));
    return agent;
  }

  async getAllAgents(): Promise<Agent[]> {
    return await db.select().from(agents);
  }

  async getPendingAgents(): Promise<Agent[]> {
    return await db.select().from(agents).where(eq(agents.status, 'pending'));
  }

  async approveAgent(agentId: number, approvedBy: number, permissionLevel: string): Promise<Agent> {
    const [agent] = await db
      .update(agents)
      .set({
        status: 'approved',
        permissionLevel: permissionLevel,
        approvedBy: approvedBy,
        approvedAt: new Date(),
      })
      .where(eq(agents.id, agentId))
      .returning();
    return agent;
  }

  async rejectAgent(agentId: number, rejectedBy: number, reason: string): Promise<Agent> {
    const [agent] = await db
      .update(agents)
      .set({
        status: 'rejected',
        rejectedAt: new Date(),
        rejectionReason: reason,
      })
      .where(eq(agents.id, agentId))
      .returning();
    return agent;
  }

  async updateAgent(id: number, updates: Partial<Agent>): Promise<Agent> {
    const [agent] = await db
      .update(agents)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(agents.id, id))
      .returning();
    return agent;
  }

  // Predicted arrivals operations
  async createPredictedArrival(arrivalData: InsertPredictedArrival): Promise<PredictedArrival> {
    const [arrival] = await db.insert(predictedArrivals).values(arrivalData).returning();
    return arrival;
  }

  async getPredictedArrivals(agentId?: number): Promise<PredictedArrival[]> {
    if (agentId) {
      return await db.select().from(predictedArrivals).where(eq(predictedArrivals.agentId, agentId));
    }
    return await db.select().from(predictedArrivals);
  }

  async getPredictedArrivalById(id: number): Promise<PredictedArrival | undefined> {
    const [arrival] = await db.select().from(predictedArrivals).where(eq(predictedArrivals.id, id));
    return arrival;
  }

  async updatePredictedArrival(id: number, updates: Partial<PredictedArrival>): Promise<PredictedArrival> {
    const [arrival] = await db
      .update(predictedArrivals)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(predictedArrivals.id, id))
      .returning();
    return arrival;
  }

  async confirmPredictedArrival(id: number, arrivalDateTime: Date, countermark: string): Promise<PredictedArrival> {
    const [arrival] = await db
      .update(predictedArrivals)
      .set({
        arrivalDateTime,
        countermark,
        status: 'confirmed',
        isConfirmed: true,
        updatedAt: new Date(),
      })
      .where(eq(predictedArrivals.id, id))
      .returning();
    return arrival;
  }

  async convertPredictionToShip(predictionId: number): Promise<Ship> {
    // Get the prediction
    const prediction = await this.getPredictedArrivalById(predictionId);
    if (!prediction) {
      throw new Error('Prediction not found');
    }

    // Create ship from prediction data
    const shipData = {
      name: prediction.shipName,
      countermark: prediction.countermark || '',
      arrivalDateTime: prediction.arrivalDateTime || new Date(),
      draft: prediction.arrivalDraft || '',
      shipAgent: '', // Will be filled by agent
      cargoAgent: '', // Will be filled by agent
      shipowner: '',
      cargoType: prediction.product,
      cargoDestination: '',
      status: 'at_bar',
      hasDischargeInstructions: false,
      berthingConfirmed: false,
      operationType: 'Nacional', // Default
    };

    const [ship] = await db.insert(ships).values(shipData).returning();

    // NOTE: Parcel data must be entered manually by operators with real laboratory data
    // No automatic parcels are created - operators must input authentic density values

    // Update prediction status
    await this.updatePredictedArrival(predictionId, {
      status: 'confirmed',
      isConfirmed: true,
    });

    return ship;
  }

  // ============= DISCHARGE CONTROL SYSTEM METHODS =============

  async createDischargeEvent(eventData: InsertDischargeEvent): Promise<DischargeEvent> {
    const [event] = await db.insert(dischargeEvents).values(eventData).returning();
    return event;
  }

  async getDischargeEvents(shipId: number): Promise<DischargeEvent[]> {
    return await db.select()
      .from(dischargeEvents)
      .where(eq(dischargeEvents.shipId, shipId))
      .orderBy(desc(dischargeEvents.eventDate));
  }

  async updateDischargeEvent(eventId: number, updates: Partial<DischargeEvent>): Promise<DischargeEvent> {
    const [event] = await db.update(dischargeEvents)
      .set(updates)
      .where(eq(dischargeEvents.id, eventId))
      .returning();
    return event;
  }

  async createParcelDischargeControl(controlData: InsertParcelDischargeControl): Promise<ParcelDischargeControl> {
    const [control] = await db.insert(parcelDischargeControl).values(controlData).returning();
    return control;
  }

  async getParcelDischargeControls(shipId: number): Promise<ParcelDischargeControl[]> {
    return await db.select()
      .from(parcelDischargeControl)
      .where(eq(parcelDischargeControl.shipId, shipId))
      .orderBy(desc(parcelDischargeControl.createdAt));
  }

  async createHourlyDischargeRecord(recordData: InsertHourlyDischargeRecord): Promise<HourlyDischargeRecord> {
    const [record] = await db.insert(hourlyDischargeRecords).values(recordData).returning();
    return record;
  }

  async getHourlyDischargeRecords(shipId: number): Promise<HourlyDischargeRecord[]> {
    return await db.select()
      .from(hourlyDischargeRecords)
      .where(eq(hourlyDischargeRecords.shipId, shipId))
      .orderBy(desc(hourlyDischargeRecords.recordTime));
  }

  async createDischargeStoppage(stoppageData: InsertDischargeStoppage): Promise<DischargeStoppage> {
    const [stoppage] = await db.insert(dischargeStoppages).values(stoppageData).returning();
    return stoppage;
  }

  async getDischargeStoppages(shipId: number): Promise<DischargeStoppage[]> {
    return await db.select()
      .from(dischargeStoppages)
      .where(eq(dischargeStoppages.shipId, shipId))
      .orderBy(desc(dischargeStoppages.startTime));
  }

  async createWaitingTime(waitingData: InsertWaitingTime): Promise<WaitingTime> {
    const [waiting] = await db.insert(waitingTimes).values(waitingData).returning();
    return waiting;
  }

  async getWaitingTimes(shipId: number): Promise<WaitingTime[]> {
    return await db.select()
      .from(waitingTimes)
      .where(eq(waitingTimes.shipId, shipId))
      .orderBy(desc(waitingTimes.startTime));
  }

  async getShip(id: number): Promise<Ship | undefined> {
    const [ship] = await db.select()
      .from(ships)
      .where(eq(ships.id, id));
    return ship;
  }

  async getCargoParcelsByShip(shipId: number): Promise<CargoParcel[]> {
    return await db.select()
      .from(cargoParcels)
      .where(eq(cargoParcels.shipId, shipId));
  }

  // Agreed discharge rate management methods
  async getAgreedDischargeRate(shipId: number): Promise<any> {
    try {
      // First try to get from hourly discharge records table if it exists
      const result = await db.execute(sql`
        SELECT agreed_rate, current_rate, updated_at, updated_by
        FROM ship_agreed_rates 
        WHERE ship_id = ${shipId} 
        ORDER BY updated_at DESC 
        LIMIT 1
      `);
      
      if (result.rows && result.rows.length > 0) {
        const row = result.rows[0] as any;
        return {
          agreedRate: row.agreed_rate,
          currentRate: row.current_rate || row.agreed_rate,
          updatedAt: row.updated_at,
          updatedBy: row.updated_by
        };
      }
      
      return null;
    } catch (error) {
      console.log('ship_agreed_rates table may not exist, returning default rates');
      return {
        agreedRate: 300,
        currentRate: 300
      };
    }
  }

  async updateAgreedDischargeRate(shipId: number, agreedRate: number): Promise<void> {
    try {
      // First, create the table if it doesn't exist
      await db.execute(sql`
        CREATE TABLE IF NOT EXISTS ship_agreed_rates (
          id SERIAL PRIMARY KEY,
          ship_id INTEGER NOT NULL,
          agreed_rate INTEGER NOT NULL,
          current_rate INTEGER,
          updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
          updated_by VARCHAR(255)
        )
      `);

      // Check if a rate already exists for this ship
      const existingRate = await db.execute(sql`
        SELECT id FROM ship_agreed_rates 
        WHERE ship_id = ${shipId}
        ORDER BY updated_at DESC 
        LIMIT 1
      `);

      if (existingRate.rows && existingRate.rows.length > 0) {
        // Update existing rate
        await db.execute(sql`
          UPDATE ship_agreed_rates 
          SET agreed_rate = ${agreedRate},
              current_rate = ${agreedRate},
              updated_at = CURRENT_TIMESTAMP
          WHERE ship_id = ${shipId}
        `);
      } else {
        // Insert new rate
        await db.execute(sql`
          INSERT INTO ship_agreed_rates (ship_id, agreed_rate, current_rate, updated_at)
          VALUES (${shipId}, ${agreedRate}, ${agreedRate}, CURRENT_TIMESTAMP)
        `);
      }
    } catch (error) {
      console.error('Error updating agreed discharge rate:', error);
      throw error;
    }
  }

  async setAgreedDischargeRate(rateData: any): Promise<any> {
    try {
      // Create table if it doesn't exist - simplified approach
      await db.execute(sql`
        CREATE TABLE IF NOT EXISTS ship_agreed_rates (
          id SERIAL PRIMARY KEY,
          ship_id INTEGER NOT NULL,
          agreed_rate INTEGER NOT NULL,
          current_rate INTEGER,
          updated_by INTEGER,
          updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
      `);

      // Delete existing record for this ship (if any)
      await db.execute(sql`
        DELETE FROM ship_agreed_rates WHERE ship_id = ${rateData.shipId}
      `);

      // Insert new record
      const result = await db.execute(sql`
        INSERT INTO ship_agreed_rates (ship_id, agreed_rate, current_rate, updated_by, updated_at)
        VALUES (${rateData.shipId}, ${rateData.agreedRate}, ${rateData.agreedRate}, ${rateData.updatedBy}, ${rateData.updatedAt})
        RETURNING id, ship_id, agreed_rate, current_rate, updated_by, updated_at
      `);

      if (result.rows && result.rows.length > 0) {
        const row = result.rows[0] as any;
        return {
          id: row.id,
          shipId: row.ship_id,
          agreedRate: row.agreed_rate,
          currentRate: row.current_rate,
          updatedBy: row.updated_by,
          updatedAt: row.updated_at
        };
      }

      return {
        shipId: rateData.shipId,
        agreedRate: rateData.agreedRate,
        currentRate: rateData.agreedRate,
        updatedBy: rateData.updatedBy,
        updatedAt: rateData.updatedAt
      };
    } catch (error) {
      console.error('Error setting agreed discharge rate:', error);
      throw error;
    }
  }

  async getShipReport(shipId: number): Promise<any> {
    try {
      // Create table if it doesn't exist
      await db.execute(sql`
        CREATE TABLE IF NOT EXISTS ship_reports (
          id SERIAL PRIMARY KEY,
          ship_id INTEGER NOT NULL,
          report_data JSONB NOT NULL,
          updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
      `);

      const result = await db.execute(sql`
        SELECT * FROM ship_reports WHERE ship_id = ${shipId}
        ORDER BY updated_at DESC LIMIT 1
      `);

      if (result.rows && result.rows.length > 0) {
        const row = result.rows[0] as any;
        return {
          id: row.id,
          shipId: row.ship_id,
          reportData: row.report_data,
          updatedAt: row.updated_at
        };
      }

      return null;
    } catch (error) {
      console.error('Error fetching ship report:', error);
      return null;
    }
  }

  async saveShipReport(data: { shipId: number; reportData: any; updatedAt: string }): Promise<any> {
    try {
      // Create table if it doesn't exist
      await db.execute(sql`
        CREATE TABLE IF NOT EXISTS ship_reports (
          id SERIAL PRIMARY KEY,
          ship_id INTEGER NOT NULL,
          report_data JSONB NOT NULL,
          updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
      `);

      // Delete existing report for this ship
      await db.execute(sql`
        DELETE FROM ship_reports WHERE ship_id = ${data.shipId}
      `);

      // Insert new report
      const result = await db.execute(sql`
        INSERT INTO ship_reports (ship_id, report_data, updated_at)
        VALUES (${data.shipId}, ${JSON.stringify(data.reportData)}, ${data.updatedAt})
        RETURNING id, ship_id, report_data, updated_at
      `);

      if (result.rows && result.rows.length > 0) {
        const row = result.rows[0] as any;
        return {
          id: row.id,
          shipId: row.ship_id,
          reportData: row.report_data,
          updatedAt: row.updated_at
        };
      }

      return {
        shipId: data.shipId,
        reportData: data.reportData,
        updatedAt: data.updatedAt
      };
    } catch (error) {
      console.error('Error saving ship report:', error);
      throw error;
    }
  }

  // OPERATIONAL STATUS METHODS
  async getOperationalStatusForShip(shipId: number): Promise<any> {
    try {
      // Get latest operational record
      const latestOperational = await db.execute(sql`
        SELECT discharge_rate, pressure, recorded_at, operation_type
        FROM operational_discharge_records 
        WHERE ship_id = ${shipId} 
        ORDER BY recorded_at DESC 
        LIMIT 1
      `);

      // Get discharge progress
      const progress = await db.execute(sql`
        SELECT percentage, discharged, remaining, estimated_completion_hours, recorded_at
        FROM discharge_progress 
        WHERE ship_id = ${shipId} 
        ORDER BY recorded_at DESC 
        LIMIT 1
      `);

      // Get berthing data
      const berthing = await db.execute(sql`
        SELECT first_rope_time, last_rope_time
        FROM berthing_records 
        WHERE ship_id = ${shipId} 
        LIMIT 1
      `);

      const operational = latestOperational.rows[0] as any;
      const progressData = progress.rows[0] as any;
      const berthingData = berthing.rows[0] as any;

      return {
        currentRate: operational?.discharge_rate || 0,
        pressure: operational?.pressure || 0,
        lastUpdate: operational?.recorded_at || null,
        operationType: operational?.operation_type || 'unknown',
        dischargeProgress: progressData?.percentage || 0,
        discharged: progressData?.discharged || 0,
        remaining: progressData?.remaining || 0,
        estimatedCompletionHours: progressData?.estimated_completion_hours || 0,
        progressLastUpdate: progressData?.recorded_at || null,
        berthingStarted: berthingData?.first_rope_time || null,
        berthingCompleted: berthingData?.last_rope_time || null,
        operationalStatus: operational?.operation_type === 'current' ? 'active' : 'historical'
      };
    } catch (error) {
      console.error('Error fetching operational status:', error);
      throw error;
    }
  }

  async getOperationalHistoryForShip(shipId: number): Promise<any[]> {
    try {
      const history = await db.execute(sql`
        SELECT 
          id,
          pressure,
          discharge_rate,
          discharge_start_time,
          discharge_end_time,
          stop_start_time,
          stop_end_time,
          stop_type,
          stop_comment,
          resume_comment,
          operation_type,
          recorded_at,
          recorded_by
        FROM operational_discharge_records 
        WHERE ship_id = ${shipId} 
        ORDER BY recorded_at DESC 
        LIMIT 20
      `);

      return history.rows || [];
    } catch (error) {
      console.error('Error fetching operational history:', error);
      throw error;
    }
  }

  async addOperationalRecord(shipId: number, data: any): Promise<any> {
    try {
      const result = await db.execute(sql`
        INSERT INTO operational_discharge_records 
        (ship_id, pressure, discharge_rate, operation_type, recorded_at, recorded_by)
        VALUES (${shipId}, ${data.pressure}, ${data.dischargeRate}, ${data.operationType}, NOW(), ${data.recordedBy})
        RETURNING *
      `);

      return result.rows[0];
    } catch (error) {
      console.error('Error adding operational record:', error);
      throw error;
    }
  }

}

export const storage = new DatabaseStorage();
