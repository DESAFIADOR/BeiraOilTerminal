import passport from "passport";
import { Strategy as LocalStrategy } from "passport-local";
import { Express } from "express";
import session from "express-session";
import { scrypt, randomBytes, timingSafeEqual } from "crypto";
import { promisify } from "util";
import bcrypt from "bcrypt";
import { storage } from "./storage";
import { User } from "@shared/schema";
import connectPg from "connect-pg-simple";

declare global {
  namespace Express {
    interface User {
      id: number;
      username: string;
      password: string;
      email: string | null;
      firstName: string | null;
      lastName: string | null;
      role: string;
      createdAt: Date | null;
      updatedAt: Date | null;
    }
  }
}

declare module 'express-session' {
  interface SessionData {
    agentId?: number;
    agentRole?: string;
    userId?: string | number;
    user?: any;
  }
}

const scryptAsync = promisify(scrypt);

async function hashPassword(password: string) {
  const salt = randomBytes(16).toString("hex");
  const buf = (await scryptAsync(password, salt, 64)) as Buffer;
  return `${buf.toString("hex")}.${salt}`;
}

async function comparePasswords(supplied: string, stored: string) {
  // Check if password is bcrypt format (starts with $2b$)
  if (stored.startsWith('$2b$') || stored.startsWith('$2a$')) {
    return await bcrypt.compare(supplied, stored);
  }
  
  // Legacy scrypt format
  const [hashed, salt] = stored.split(".");
  if (!salt) {
    console.error('Invalid password format - missing salt');
    return false;
  }
  const hashedBuf = Buffer.from(hashed, "hex");
  const suppliedBuf = (await scryptAsync(supplied, salt, 64)) as Buffer;
  return timingSafeEqual(hashedBuf, suppliedBuf);
}

export function setupAuth(app: Express) {
  const sessionTtl = 7 * 24 * 60 * 60 * 1000; // 1 week
  const pgStore = connectPg(session);
  const sessionStore = new pgStore({
    conString: process.env.DATABASE_URL,
    createTableIfMissing: true,
    ttl: sessionTtl,
    tableName: "sessions",
  });

  const sessionSettings: session.SessionOptions = {
    secret: process.env.SESSION_SECRET || "terminal-management-secret-key",
    resave: false,
    saveUninitialized: false,
    store: sessionStore,
    cookie: {
      httpOnly: true,
      secure: false, // Set to true in production with HTTPS
      maxAge: sessionTtl,
      sameSite: 'lax', // Allow cross-site requests for development
    },
  };

  app.set("trust proxy", 1);
  app.use(session(sessionSettings));
  app.use(passport.initialize());
  app.use(passport.session());

  passport.use(
    new LocalStrategy(async (username, password, done) => {
      try {
        console.log('LocalStrategy: Looking up user:', username);
        const user = await storage.getUserByUsername(username);
        
        if (!user) {
          console.log('LocalStrategy: User not found:', username);
          return done(null, false, { message: "Invalid username or password" });
        }
        
        console.log('LocalStrategy: User found, checking password');
        const passwordMatch = await comparePasswords(password, user.password);
        
        if (!passwordMatch) {
          console.log('LocalStrategy: Password mismatch for user:', username);
          return done(null, false, { message: "Invalid username or password" });
        }
        
        console.log('LocalStrategy: Authentication successful for:', username);
        return done(null, user);
      } catch (error) {
        console.error('LocalStrategy error:', error);
        return done(error);
      }
    }),
  );

  passport.serializeUser((user, done) => done(null, user.id));
  passport.deserializeUser(async (id: number, done) => {
    try {
      const user = await storage.getUser(id);
      done(null, user);
    } catch (error) {
      done(error);
    }
  });

  // Register route
  app.post("/api/register", async (req, res, next) => {
    try {
      console.log("Registration request received:", {
        body: req.body,
        headers: req.headers['user-agent'],
        ip: req.ip
      });
      
      const { username, password, email, firstName, lastName, role } = req.body;
      
      if (!username || !password) {
        console.log("Missing required fields:", { username: !!username, password: !!password });
        return res.status(400).json({ message: "Username and password are required" });
      }

      if (!firstName || !lastName) {
        console.log("Missing name fields:", { firstName: !!firstName, lastName: !!lastName });
        return res.status(400).json({ message: "First name and last name are required" });
      }

      // Check for existing user with normalized username
      const normalizedUsername = username.toLowerCase().trim();
      const existingUser = await storage.getUserByUsername(normalizedUsername);
      if (existingUser) {
        return res.status(400).json({ message: "Username already exists" });
      }

      // Check email if provided
      if (email && email.trim()) {
        const normalizedEmail = email.toLowerCase().trim();
        const existingEmail = await storage.getUserByEmail(normalizedEmail);
        if (existingEmail) {
          return res.status(400).json({ message: "Email already registered" });
        }
      }

      const hashedPassword = await hashPassword(password);
      
      // Sistema de controle de acesso baseado nas regras definidas
      let userStatus = "active";
      let userRole = role || "publico";
      let requestedRole = role || "publico";
      
      // Implementar regras de aprovação
      switch (role) {
        case "publico":
          // Público não precisa aprovação
          userStatus = "active";
          userRole = "publico";
          break;
        case "line_up":
        case "gestores":
        case "ctos":
          // Precisam aprovação do administrador
          userStatus = "pending";
          userRole = "publico"; // Role temporário até aprovação
          requestedRole = role;
          break;
        case "admin":
          // Administrador precisa aprovação do desenvolvedor
          userStatus = "pending";
          userRole = "publico";
          requestedRole = role;
          break;
        case "agente_navio":
          // Agentes de navio precisam aprovação do administrador
          userStatus = "pending";
          userRole = "publico"; // Role temporário até aprovação
          requestedRole = role;
          break;
        default:
          userStatus = "active";
          userRole = "publico";
      }
      
      // Definir permissões baseadas no sistema de controle de acesso
      let userPermissions = [];
      
      switch (userRole) {
        case "publico":
          userPermissions = [
            "view_ships_public",
            "view_discharge_percentage", 
            "view_ship_count",
            "view_weather_tide"
          ];
          break;
        case "line_up":
          userPermissions = [
            "view_ships",
            "create_ships",
            "update_ships_basic",
            "manage_parcels_pre_berth",
            "view_discharge_percentage",
            "view_ship_details"
          ];
          break;
        case "gestores":
          userPermissions = [
            "view_ships",
            "view_ship_details",
            "view_parcel_details",
            "view_statistics",
            "view_live_operations",
            "view_discharge_details",
            "view_reports",
            "view_analytics"
          ];
          break;
        case "ctos":
          userPermissions = [
            "view_ships",
            "view_ship_details",
            "view_parcel_details",
            "manage_parcels_full",
            "update_discharge_progress",
            "berth_unberth_ships",
            "operational_control",
            "view_statistics",
            "view_live_operations",
            "view_reports",
            "export_data"
          ];
          break;
        case "admin":
          userPermissions = [
            "view_ships",
            "create_ships",
            "update_ships",
            "delete_ships",
            "move_ships",
            "confirm_ships",
            "update_discharge",
            "register_undocking",
            "view_ship_details",
            "view_parcel_details",
            "manage_parcels_full",
            "berth_unberth_ships",
            "operational_control",
            "view_statistics",
            "view_live_operations",
            "view_reports",
            "create_reports",
            "approve_operations",
            "manage_users_full",
            "approve_users",
            "view_analytics",
            "export_data",
            "system_configuration_basic"
          ];
          break;
        case "agente_navio":
          userPermissions = [
            "view_ships",
            "view_weather",
            "view_ship_details",     // Visualizar detalhes dos navios
            "view_ships_at_bar",     // Visualizar navios na barra
            "view_ships_at_berth",   // Visualizar navio no cais
            "view_discharge_progress", // Visualizar progresso da descarga
            "announce_arrival",      // 1. Anunciar chegada de navio
            "add_ship",              // 2. Adicionar Navios
            "add_parcels",           // 2. Adicionar Parcelas
            "confirm_berthing"       // 3. Confirmar instrução de Atracação
          ];
          break;
        case "desenvolvedor":
          userPermissions = [
            "view_ships",
            "create_ships",
            "update_ships",
            "delete_ships",
            "move_ships",
            "confirm_ships",
            "update_discharge",
            "register_undocking",
            "approve_admins",
            "view_analytics",
            "view_financial_data",
            "export_data",
            "system_configuration_basic",
            "system_configuration_advanced",
            "database_access",
            "api_access",
            "debug_mode",
            "manage_integrations",
            "system_maintenance"
          ];
          break;
        default:
          userPermissions = ["view_ships_public", "view_weather_tide"];
      }

      const user = await storage.createUser({
        username: normalizedUsername,
        password: hashedPassword,
        email: email ? email.toLowerCase().trim() : null,
        firstName,
        lastName,
        role: userRole,
        status: userStatus,
        requestedRole,
        permissions: userPermissions,
      });

      // Remove password from response
      const { password: _, ...userResponse } = user;
      
      // Only login immediately if user is active (public users)
      if (userStatus === "active") {
        req.login(user, (err) => {
          if (err) return next(err);
          res.status(201).json({
            ...userResponse,
            message: "Conta criada com sucesso!"
          });
        });
      } else {
        // Operator requests need approval
        res.status(201).json({
          ...userResponse,
          message: "Solicitação de conta de operador enviada. Aguarde aprovação do administrador."
        });
      }
    } catch (error) {
      console.error("Registration error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Login route
  app.post("/api/login", (req, res, next) => {
    console.log('Login attempt:', { username: req.body.username, hasPassword: !!req.body.password });
    
    passport.authenticate("local", (err: any, user: any, info: any) => {
      console.log('Passport authenticate result:', { err: !!err, user: !!user, info });
      
      if (err) {
        console.error('Passport authentication error:', err);
        return next(err);
      }
      
      if (!user) {
        console.log('Authentication failed:', info?.message);
        return res.status(401).json({ message: info?.message || "Authentication failed" });
      }
      
      console.log('User found:', { username: user.username, status: user.status });
      
      // Check user status before allowing login
      if (user.status === "pending") {
        return res.status(403).json({ 
          message: "Sua conta está aguardando aprovação do administrador." 
        });
      }
      
      if (user.status === "rejected") {
        return res.status(403).json({ 
          message: "Sua solicitação de conta foi rejeitada." 
        });
      }
      
      if (user.status !== "active") {
        return res.status(403).json({ 
          message: "Sua conta não está ativa." 
        });
      }
      
      req.login(user, (err) => {
        if (err) {
          console.error('req.login error:', err);
          return next(err);
        }
        
        // Remove password from response
        const { password: _, ...userResponse } = user;
        console.log('Login successful for user:', user.username);
        res.json(userResponse);
      });
    })(req, res, next);
  });

  // Logout route
  app.post("/api/logout", (req, res, next) => {
    req.logout((err) => {
      if (err) return next(err);
      
      // Destroy the session completely
      req.session.destroy((err) => {
        if (err) {
          console.error("Session destruction error:", err);
          return res.status(500).json({ message: "Error destroying session" });
        }
        
        // Clear the session cookie
        res.clearCookie('connect.sid');
        res.json({ message: "Logged out successfully" });
      });
    });
  });

  // Get current user
  app.get("/api/user", (req, res) => {
    if (!req.isAuthenticated() || !req.user) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    // Remove password from response
    const { password: _, ...userResponse } = req.user;
    res.json(userResponse);
  });
}

// Middleware to check if user is authenticated
export function isAuthenticated(req: any, res: any, next: any) {
  if (req.isAuthenticated()) {
    return next();
  }
  res.status(401).json({ message: "Unauthorized" });
}

// Middleware to check if user is an operator
export function isOperator(req: any, res: any, next: any) {
  if (req.isAuthenticated() && (req.user?.role === "operator" || req.user?.role === "admin")) {
    return next();
  }
  res.status(403).json({ message: "Access denied. Operator role required." });
}

export function isAdmin(req: any, res: any, next: any) {
  if (req.isAuthenticated() && req.user?.role === "admin") {
    return next();
  }
  res.status(403).json({ message: "Access denied. Admin role required." });
}