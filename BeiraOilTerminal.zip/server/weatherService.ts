import { db } from "./db";
import { weatherData, weatherAlerts, type InsertWeatherData, type InsertWeatherAlert } from "@shared/schema";
import { desc, and, eq, gte } from "drizzle-orm";

export interface WeatherResponse {
  current: {
    temp: number;
    humidity: number;
    pressure: number;
    visibility: number;
    wind_speed: number;
    wind_deg: number;
    wind_gust?: number;
    weather: Array<{
      main: string;
      description: string;
    }>;
  };
  alerts?: Array<{
    event: string;
    description: string;
    start: number;
    end: number;
  }>;
}

export interface MarineWeatherResponse {
  current: {
    significant_wave_height: number;
    wind_wave_height: number;
    wind_wave_direction: number;
    wind_wave_period: number;
    swell_wave_height: number;
    swell_wave_direction: number;
    swell_wave_period: number;
  };
}

export interface CurrentWeatherData {
  temperature: number;
  humidity: number;
  pressure: number;
  visibility: number;
  windSpeed: number;
  windDirection: number;
  windGust?: number;
  weatherCondition: string;
  waveHeight?: number;
  seaState?: number;
  alerts: WeatherAlert[];
  lastUpdated: Date;
}

export interface WeatherAlert {
  id: number;
  type: string;
  severity: 'low' | 'medium' | 'high' | 'critical';
  title: string;
  description: string;
  windSpeed?: number;
  isActive: boolean;
  triggeredAt: Date;
}

class WeatherService {
  private readonly BEIRA_LAT = -19.8242;
  private readonly BEIRA_LON = 34.8383;
  private readonly OPENWEATHER_API_URL = 'https://api.openweathermap.org/data/3.0/onecall';
  private readonly MARINE_API_URL = 'https://marine-api.open-meteo.com/v1/marine';
  private readonly WIND_ALERT_THRESHOLD = 25; // 25 knots

  async getCurrentWeatherData(): Promise<CurrentWeatherData> {
    try {
      // Try to fetch from OpenWeatherMap first
      const weatherResponse = await this.fetchFromOpenWeather();
      if (weatherResponse) {
        await this.saveWeatherData(weatherResponse);
        return weatherResponse;
      }
    } catch (error) {
      console.log('OpenWeather API not available, using Open-Meteo fallback');
    }

    try {
      // Fallback to Open-Meteo (free API)
      const weatherResponse = await this.fetchFromOpenMeteo();
      await this.saveWeatherData(weatherResponse);
      return weatherResponse;
    } catch (error) {
      console.error('All weather APIs failed:', error);
      // Return last known data from database
      return await this.getLastKnownWeatherData();
    }
  }

  private async fetchFromOpenWeather(): Promise<CurrentWeatherData | null> {
    const apiKey = process.env.OPENWEATHER_API_KEY;
    if (!apiKey) {
      throw new Error('OpenWeather API key not provided');
    }

    const weatherUrl = `${this.OPENWEATHER_API_URL}?lat=${this.BEIRA_LAT}&lon=${this.BEIRA_LON}&appid=${apiKey}&units=metric&exclude=minutely,hourly,daily`;
    
    const response = await fetch(weatherUrl);
    if (!response.ok) {
      throw new Error(`OpenWeather API error: ${response.status}`);
    }

    const data: WeatherResponse = await response.json();
    
    // Convert wind speed from m/s to knots
    const windSpeedKnots = data.current.wind_speed * 1.944;
    const windGustKnots = data.current.wind_gust ? data.current.wind_gust * 1.944 : undefined;

    // Get marine data for wave height
    let waveHeight: number | undefined;
    try {
      const marineData = await this.fetchMarineData();
      waveHeight = marineData?.current.significant_wave_height;
    } catch (error) {
      console.log('Marine data not available');
    }

    const alerts = await this.checkAndCreateAlerts(windSpeedKnots, data.alerts);

    return {
      temperature: data.current.temp,
      humidity: data.current.humidity,
      pressure: data.current.pressure,
      visibility: data.current.visibility / 1000, // Convert to km
      windSpeed: windSpeedKnots,
      windDirection: data.current.wind_deg,
      windGust: windGustKnots,
      weatherCondition: data.current.weather[0]?.description || 'Unknown',
      waveHeight,
      seaState: this.calculateSeaState(windSpeedKnots),
      alerts,
      lastUpdated: new Date(),
    };
  }

  private async fetchFromOpenMeteo(): Promise<CurrentWeatherData> {
    const weatherUrl = `https://api.open-meteo.com/v1/forecast?latitude=${this.BEIRA_LAT}&longitude=${this.BEIRA_LON}&current=temperature_2m,relative_humidity_2m,surface_pressure,visibility,wind_speed_10m,wind_direction_10m,wind_gusts_10m,weather_code&wind_speed_unit=kn&timezone=Africa/Maputo`;
    
    const response = await fetch(weatherUrl);
    if (!response.ok) {
      throw new Error(`Open-Meteo API error: ${response.status}`);
    }

    const data = await response.json();
    const current = data.current;

    const alerts = await this.checkAndCreateAlerts(current.wind_speed_10m);

    return {
      temperature: current.temperature_2m,
      humidity: current.relative_humidity_2m,
      pressure: current.surface_pressure,
      visibility: current.visibility / 1000,
      windSpeed: current.wind_speed_10m,
      windDirection: current.wind_direction_10m,
      windGust: current.wind_gusts_10m,
      weatherCondition: this.getWeatherDescription(current.weather_code),
      seaState: this.calculateSeaState(current.wind_speed_10m),
      alerts,
      lastUpdated: new Date(),
    };
  }

  private async fetchMarineData(): Promise<MarineWeatherResponse | null> {
    const marineUrl = `${this.MARINE_API_URL}?latitude=${this.BEIRA_LAT}&longitude=${this.BEIRA_LON}&current=significant_wave_height,wind_wave_height,wind_wave_direction,wind_wave_period&timezone=Africa/Maputo`;
    
    const response = await fetch(marineUrl);
    if (!response.ok) {
      return null;
    }

    return await response.json();
  }

  private async saveWeatherData(currentWeather: CurrentWeatherData): Promise<void> {
    try {
      const insertData: InsertWeatherData = {
        timestamp: new Date(),
        windSpeed: currentWeather.windSpeed.toString(),
        windDirection: currentWeather.windDirection,
        windGust: currentWeather.windGust?.toString(),
        temperature: currentWeather.temperature.toString(),
        humidity: currentWeather.humidity,
        pressure: currentWeather.pressure.toString(),
        visibility: currentWeather.visibility?.toString(),
        weatherCondition: currentWeather.weatherCondition,
        seaState: currentWeather.seaState,
        waveHeight: currentWeather.waveHeight?.toString(),
        source: 'openweather',
      };

      await db.insert(weatherData).values(insertData);
    } catch (error) {
      console.error('Error saving weather data:', error);
    }
  }

  private async checkAndCreateAlerts(windSpeed: number, externalAlerts?: any[]): Promise<WeatherAlert[]> {
    const alerts: WeatherAlert[] = [];

    // Check for high wind alert (25+ knots)
    if (windSpeed >= this.WIND_ALERT_THRESHOLD) {
      const severity = this.getWindSeverity(windSpeed);
      const existingAlert = await this.getActiveWindAlert();

      if (!existingAlert || (existingAlert.windSpeed && parseFloat(existingAlert.windSpeed || '0') < windSpeed)) {
        // Resolve existing alert if wind speed increased
        if (existingAlert) {
          await this.resolveAlert(existingAlert.id);
        }

        const alertData: InsertWeatherAlert = {
          alertType: 'high_wind',
          severity,
          title: 'Alerta de Mau Tempo - Ventos Fortes',
          description: `Ventos de ${windSpeed.toFixed(1)} nós detectados. Operações portuárias podem ser afetadas. Recomenda-se cautela nas operações de atracação e movimentação de navios.`,
          windSpeed: windSpeed.toString(),
          isActive: true,
        };

        const [newAlert] = await db.insert(weatherAlerts).values(alertData).returning();
        alerts.push({
          id: newAlert.id,
          type: newAlert.alertType,
          severity: newAlert.severity as any,
          title: newAlert.title,
          description: newAlert.description,
          windSpeed: parseFloat(newAlert.windSpeed || '0'),
          isActive: newAlert.isActive,
          triggeredAt: newAlert.triggeredAt,
        });
      } else if (existingAlert) {
        alerts.push({
          id: existingAlert.id,
          type: existingAlert.alertType,
          severity: existingAlert.severity as any,
          title: existingAlert.title,
          description: existingAlert.description,
          windSpeed: parseFloat(existingAlert.windSpeed || '0'),
          isActive: existingAlert.isActive,
          triggeredAt: existingAlert.triggeredAt,
        });
      }
    } else {
      // Resolve any active wind alerts if wind speed is below threshold
      const activeAlert = await this.getActiveWindAlert();
      if (activeAlert) {
        await this.resolveAlert(activeAlert.id);
      }
    }

    return alerts;
  }

  private getWindSeverity(windSpeed: number): 'low' | 'medium' | 'high' | 'critical' {
    if (windSpeed >= 50) return 'critical';  // 50+ knots - Very dangerous
    if (windSpeed >= 40) return 'high';      // 40-49 knots - Dangerous
    if (windSpeed >= 30) return 'medium';    // 30-39 knots - Caution
    return 'low';                            // 25-29 knots - Monitor
  }

  private async getActiveWindAlert() {
    const [alert] = await db
      .select()
      .from(weatherAlerts)
      .where(
        and(
          eq(weatherAlerts.alertType, 'high_wind'),
          eq(weatherAlerts.isActive, true)
        )
      )
      .orderBy(desc(weatherAlerts.triggeredAt))
      .limit(1);
    
    return alert;
  }

  private async resolveAlert(alertId: number): Promise<void> {
    await db
      .update(weatherAlerts)
      .set({ 
        isActive: false, 
        resolvedAt: new Date() 
      })
      .where(eq(weatherAlerts.id, alertId));
  }

  private calculateSeaState(windSpeedKnots: number): number {
    // Beaufort Scale to Sea State conversion
    if (windSpeedKnots < 1) return 0;       // Calm
    if (windSpeedKnots < 4) return 1;       // Ripples
    if (windSpeedKnots < 7) return 2;       // Small wavelets
    if (windSpeedKnots < 11) return 2;      // Large wavelets
    if (windSpeedKnots < 16) return 3;      // Small waves
    if (windSpeedKnots < 22) return 4;      // Moderate waves
    if (windSpeedKnots < 28) return 5;      // Large waves
    if (windSpeedKnots < 34) return 6;      // Very large waves
    if (windSpeedKnots < 41) return 7;      // High waves
    if (windSpeedKnots < 48) return 8;      // Very high waves
    return 9;                               // Phenomenal waves
  }

  private getWeatherDescription(weatherCode: number): string {
    const weatherCodes: { [key: number]: string } = {
      0: 'Céu limpo',
      1: 'Principalmente limpo',
      2: 'Parcialmente nublado',
      3: 'Nublado',
      45: 'Nevoeiro',
      48: 'Nevoeiro com geada',
      51: 'Chuvisco leve',
      53: 'Chuvisco moderado',
      55: 'Chuvisco intenso',
      61: 'Chuva leve',
      63: 'Chuva moderada',
      65: 'Chuva intensa',
      80: 'Pancadas de chuva leves',
      81: 'Pancadas de chuva moderadas',
      82: 'Pancadas de chuva intensas',
      95: 'Tempestade',
      96: 'Tempestade com granizo leve',
      99: 'Tempestade com granizo intenso',
    };

    return weatherCodes[weatherCode] || 'Condição desconhecida';
  }

  private async getLastKnownWeatherData(): Promise<CurrentWeatherData> {
    const [lastData] = await db
      .select()
      .from(weatherData)
      .orderBy(desc(weatherData.timestamp))
      .limit(1);

    const activeAlerts = await db
      .select()
      .from(weatherAlerts)
      .where(eq(weatherAlerts.isActive, true))
      .orderBy(desc(weatherAlerts.triggeredAt));

    const alerts: WeatherAlert[] = activeAlerts.map(alert => ({
      id: alert.id,
      type: alert.alertType,
      severity: alert.severity as any,
      title: alert.title,
      description: alert.description,
      windSpeed: parseFloat(alert.windSpeed || '0'),
      isActive: alert.isActive,
      triggeredAt: alert.triggeredAt,
    }));

    if (lastData) {
      return {
        temperature: parseFloat(lastData.temperature || '0'),
        humidity: lastData.humidity || 0,
        pressure: parseFloat(lastData.pressure || '0'),
        visibility: parseFloat(lastData.visibility || '0'),
        windSpeed: parseFloat(lastData.windSpeed || '0'),
        windDirection: lastData.windDirection || 0,
        windGust: lastData.windGust ? parseFloat(lastData.windGust) : undefined,
        weatherCondition: lastData.weatherCondition || 'Dados indisponíveis',
        waveHeight: lastData.waveHeight ? parseFloat(lastData.waveHeight) : undefined,
        seaState: lastData.seaState || 0,
        alerts,
        lastUpdated: lastData.timestamp,
      };
    }

    // Return default data if no previous data exists
    return {
      temperature: 0,
      humidity: 0,
      pressure: 0,
      visibility: 0,
      windSpeed: 0,
      windDirection: 0,
      weatherCondition: 'Dados não disponíveis',
      seaState: 0,
      alerts,
      lastUpdated: new Date(),
    };
  }

  async getActiveAlerts(): Promise<WeatherAlert[]> {
    const activeAlerts = await db
      .select()
      .from(weatherAlerts)
      .where(eq(weatherAlerts.isActive, true))
      .orderBy(desc(weatherAlerts.triggeredAt));

    return activeAlerts.map(alert => ({
      id: alert.id,
      type: alert.alertType,
      severity: alert.severity as any,
      title: alert.title,
      description: alert.description,
      windSpeed: parseFloat(alert.windSpeed || '0'),
      isActive: alert.isActive,
      triggeredAt: alert.triggeredAt,
    }));
  }

  async getWeatherHistory(hours: number = 24): Promise<any[]> {
    const startTime = new Date();
    startTime.setHours(startTime.getHours() - hours);

    const history = await db
      .select()
      .from(weatherData)
      .where(gte(weatherData.timestamp, startTime))
      .orderBy(desc(weatherData.timestamp));

    return history;
  }
}

export const weatherService = new WeatherService();