import { storage } from './storage';

export interface TideData {
  currentTide: number;
  tideTime: Date;
  nextHighTide: {
    height: number;
    time: Date;
  };
  nextLowTide: {
    height: number;
    time: Date;
  };
  tideStatus: 'rising' | 'falling';
  prediction24h: Array<{
    time: Date;
    height: number;
    type: 'high' | 'low';
  }>;
}

export interface TideApiResponse {
  data: Array<{
    t: string; // ISO timestamp
    v: number; // tide height in meters
  }>;
}

class TideService {
  private readonly BEIRA_LAT = -19.8242;
  private readonly BEIRA_LON = 34.8383;
  
  // Multiple API endpoints for better coverage
  private readonly APIS = {
    // WorldTides API - Global coverage including Indian Ocean
    worldtides: 'https://www.worldtides.info/api/v3',
    // Admiralty API - UK Hydrographic Office
    admiralty: 'https://admiraltyapi.azure-api.net/ukho/tides/api/V1',
    // FES (Finite Element Solution) - French hydrographic model
    aviso: 'https://www.aviso.altimetry.fr/en/data/products/auxiliary-products',
    // NOAA backup (limited coverage)
    noaa: 'https://api.tidesandcurrents.noaa.gov/api/prod/datagetter'
  };
  
  async getCurrentTideData(): Promise<TideData> {
    try {
      // Try WorldTides API first (best coverage for Indian Ocean)
      let tideData = await this.fetchFromWorldTides();
      if (tideData) {
        await this.updateDatabaseTide(tideData.currentTide);
        return tideData;
      }

      // Fallback to NOAA
      tideData = await this.fetchFromNOAA();
      if (tideData) {
        await this.updateDatabaseTide(tideData.currentTide);
        return tideData;
      }
    } catch (error) {
      console.log('External tide APIs unavailable, using calculated values');
    }
    
    // Fallback to harmonic calculation
    return this.getCalculatedTideData();
  }

  private async fetchFromWorldTides(): Promise<TideData | null> {
    try {
      if (!process.env.WORLDTIDES_API_KEY) {
        console.log('WorldTides API key not configured');
        return null;
      }

      const now = new Date();
      const params = new URLSearchParams({
        heights: 'true',
        extremes: 'true',
        lat: this.BEIRA_LAT.toString(),
        lon: this.BEIRA_LON.toString(),
        start: Math.floor(now.getTime() / 1000 - 3600).toString(), // 1 hour ago
        length: '86400', // 24 hours
        interval: '900', // 15 minutes
        format: 'json',
        key: process.env.WORLDTIDES_API_KEY
      });

      const response = await fetch(`${this.APIS.worldtides}?${params}`);
      
      if (!response.ok) {
        console.warn(`WorldTides API error: ${response.status}`);
        return null;
      }

      const data = await response.json();
      
      if (!data || !data.heights || !Array.isArray(data.heights)) {
        console.warn('WorldTides API returned invalid data structure');
        return null;
      }
      
      return this.processWorldTidesData(data);
    } catch (error) {
      console.error('Error fetching from WorldTides API:', error);
      return null;
    }
  }

  private processWorldTidesData(data: any): TideData {
    const now = new Date();
    
    // Process heights data from WorldTides
    const heights = data.heights.map((point: any) => ({
      time: new Date(point.dt * 1000), // Convert Unix timestamp
      height: point.height
    })).sort((a: any, b: any) => a.time.getTime() - b.time.getTime());

    // Find current tide (interpolate)
    const currentTide = this.interpolateCurrentTide(heights, now);
    
    // Process extremes from API
    const extremes = data.extremes || [];
    const futureExtremes = extremes
      .map((ext: any) => ({
        time: new Date(ext.dt * 1000),
        height: ext.height,
        type: ext.type
      }))
      .filter((ext: any) => ext.time > now)
      .sort((a: any, b: any) => a.time.getTime() - b.time.getTime());

    // Find next high and low tides
    const nextHighTide = futureExtremes.find((ext: any) => ext.type === 'High') || {
      height: 4.2,
      time: new Date(now.getTime() + 6 * 60 * 60 * 1000)
    };
    
    const nextLowTide = futureExtremes.find((ext: any) => ext.type === 'Low') || {
      height: 0.8,
      time: new Date(now.getTime() + 6 * 60 * 60 * 1000)
    };

    // Determine tide direction
    const recentHeights = heights.filter((h: any) => h.time <= now).slice(-2);
    const tideStatus: 'rising' | 'falling' = recentHeights.length >= 2 
      ? (recentHeights[1].height > recentHeights[0].height ? 'rising' : 'falling')
      : 'rising';

    // Generate 24h prediction from extremes
    const prediction24h = extremes
      .filter((ext: any) => {
        const extTime = new Date(ext.dt * 1000);
        return extTime >= now && extTime <= new Date(now.getTime() + 24 * 60 * 60 * 1000);
      })
      .map((ext: any) => ({
        time: new Date(ext.dt * 1000),
        height: ext.height,
        type: ext.type.toLowerCase() as 'high' | 'low'
      }))
      .slice(0, 8);

    return {
      currentTide,
      tideTime: now,
      nextHighTide,
      nextLowTide,
      tideStatus,
      prediction24h
    };
  }

  private async fetchFromNOAA(): Promise<TideData | null> {
    try {
      const now = new Date();
      const startDate = new Date(now.getTime() - 6 * 60 * 60 * 1000); // 6 hours ago
      const endDate = new Date(now.getTime() + 18 * 60 * 60 * 1000); // 18 hours ahead
      
      const params = new URLSearchParams({
        product: 'predictions',
        application: 'BeiraOilTerminal',
        begin_date: startDate.toISOString().split('T')[0].replace(/-/g, ''),
        end_date: endDate.toISOString().split('T')[0].replace(/-/g, ''),
        datum: 'MLLW',
        station: '8661070', // Using nearest available station
        time_zone: 'gmt',
        units: 'metric',
        interval: 'h',
        format: 'json'
      });

      const response = await fetch(`${this.APIS.noaa}?${params}`);
      
      if (!response.ok) {
        throw new Error(`Tide API error: ${response.status}`);
      }

      const data: TideApiResponse = await response.json();
      
      // Validate response structure before processing
      if (!data || !data.data || !Array.isArray(data.data) || data.data.length === 0) {
        console.warn('NOAA API returned invalid or empty data structure');
        return null;
      }
      
      return this.processTideData(data);
    } catch (error) {
      console.error('Error fetching tide data from NOAA:', error);
      return null;
    }
  }

  private processTideData(apiData: TideApiResponse): TideData {
    const now = new Date();
    
    // Validate API data structure
    if (!apiData || !apiData.data || !Array.isArray(apiData.data)) {
      throw new Error('Invalid API response structure');
    }
    
    const tidePoints = apiData.data.map(point => ({
      time: new Date(point.t),
      height: point.v
    })).sort((a, b) => a.time.getTime() - b.time.getTime());

    // Find current tide (interpolate between closest points)
    const currentTide = this.interpolateCurrentTide(tidePoints, now);
    
    // Determine tide direction
    const recentPoints = tidePoints.filter(p => p.time <= now).slice(-2);
    const tideStatus: 'rising' | 'falling' = recentPoints.length >= 2 
      ? (recentPoints[1].height > recentPoints[0].height ? 'rising' : 'falling')
      : 'rising';

    // Find next high and low tides
    const futurePoints = tidePoints.filter(p => p.time > now);
    const nextHighTide = this.findNextExtreme(futurePoints, 'high');
    const nextLowTide = this.findNextExtreme(futurePoints, 'low');

    // Generate 24h prediction
    const prediction24h = this.generatePredictions(tidePoints);

    return {
      currentTide,
      tideTime: now,
      nextHighTide,
      nextLowTide,
      tideStatus,
      prediction24h
    };
  }

  private interpolateCurrentTide(tidePoints: Array<{time: Date; height: number}>, now: Date): number {
    const before = tidePoints.filter(p => p.time <= now).pop();
    const after = tidePoints.find(p => p.time > now);

    if (!before || !after) {
      return tidePoints[0]?.height || 2.5; // Default for Beira
    }

    const timeDiff = after.time.getTime() - before.time.getTime();
    const heightDiff = after.height - before.height;
    const timeOffset = now.getTime() - before.time.getTime();
    
    return before.height + (heightDiff * timeOffset / timeDiff);
  }

  private findNextExtreme(points: Array<{time: Date; height: number}>, type: 'high' | 'low'): {height: number; time: Date} {
    if (points.length < 3) {
      const defaultTime = new Date(Date.now() + 6 * 60 * 60 * 1000);
      return {
        height: type === 'high' ? 4.2 : 0.8,
        time: defaultTime
      };
    }

    for (let i = 1; i < points.length - 1; i++) {
      const prev = points[i - 1];
      const curr = points[i];
      const next = points[i + 1];

      const isHigh = curr.height > prev.height && curr.height > next.height;
      const isLow = curr.height < prev.height && curr.height < next.height;

      if ((type === 'high' && isHigh) || (type === 'low' && isLow)) {
        return { height: curr.height, time: curr.time };
      }
    }

    // Fallback
    const defaultTime = new Date(Date.now() + 6 * 60 * 60 * 1000);
    return {
      height: type === 'high' ? 4.2 : 0.8,
      time: defaultTime
    };
  }

  private generatePredictions(tidePoints: Array<{time: Date; height: number}>): Array<{time: Date; height: number; type: 'high' | 'low'}> {
    const predictions: Array<{time: Date; height: number; type: 'high' | 'low'}> = [];
    
    for (let i = 1; i < tidePoints.length - 1; i++) {
      const prev = tidePoints[i - 1];
      const curr = tidePoints[i];
      const next = tidePoints[i + 1];

      const isHigh = curr.height > prev.height && curr.height > next.height;
      const isLow = curr.height < prev.height && curr.height < next.height;

      if (isHigh || isLow) {
        predictions.push({
          time: curr.time,
          height: curr.height,
          type: isHigh ? 'high' : 'low'
        });
      }
    }

    return predictions.slice(0, 8); // Next 8 tide changes (about 2 days)
  }

  private async getCalculatedTideData(): Promise<TideData> {
    const settings = await storage.getTerminalSettings();
    const now = new Date();
    
    // Use harmonic analysis for Beira Port (simplified)
    // Beira has semi-diurnal tides with mean range of ~3.5m
    const currentTide = this.calculateHarmonicTide(now);
    
    // Calculate next high/low based on tidal patterns
    const nextHigh = this.calculateNextTideExtreme(now, 'high');
    const nextLow = this.calculateNextTideExtreme(now, 'low');
    
    // Determine if tide is rising or falling
    const tideInHour = this.calculateHarmonicTide(new Date(now.getTime() + 60 * 60 * 1000));
    const tideStatus: 'rising' | 'falling' = tideInHour > currentTide ? 'rising' : 'falling';

    // Generate 24h predictions
    const prediction24h = this.generateHarmonicPredictions(now);

    await this.updateDatabaseTide(currentTide);

    return {
      currentTide,
      tideTime: now,
      nextHighTide: nextHigh,
      nextLowTide: nextLow,
      tideStatus,
      prediction24h
    };
  }

  private calculateHarmonicTide(date: Date): number {
    // Simplified harmonic analysis for Beira Port
    // Based on principal constituents: M2 (12.42h), S2 (12h), N2 (12.66h)
    const hours = date.getHours() + date.getMinutes() / 60;
    const dayOfYear = Math.floor((date.getTime() - new Date(date.getFullYear(), 0, 0).getTime()) / (1000 * 60 * 60 * 24));
    
    // M2 constituent (principal lunar semi-diurnal)
    const M2 = 1.8 * Math.cos(2 * Math.PI * (hours / 12.42 + dayOfYear * 0.035));
    
    // S2 constituent (principal solar semi-diurnal)
    const S2 = 0.4 * Math.cos(2 * Math.PI * (hours / 12.0));
    
    // N2 constituent (lunar elliptic semi-diurnal)
    const N2 = 0.3 * Math.cos(2 * Math.PI * (hours / 12.66 + dayOfYear * 0.028));
    
    // Mean sea level for Beira (~2.5m above chart datum)
    const meanLevel = 2.5;
    
    return meanLevel + M2 + S2 + N2;
  }

  private calculateNextTideExtreme(from: Date, type: 'high' | 'low'): {height: number; time: Date} {
    const searchStart = new Date(from.getTime());
    const searchEnd = new Date(from.getTime() + 24 * 60 * 60 * 1000); // Next 24 hours
    
    let extremeTime = searchStart;
    let extremeHeight = this.calculateHarmonicTide(searchStart);
    
    // Check every 15 minutes for the next extreme
    for (let time = new Date(searchStart.getTime()); time <= searchEnd; time.setMinutes(time.getMinutes() + 15)) {
      const height = this.calculateHarmonicTide(time);
      
      if ((type === 'high' && height > extremeHeight) || (type === 'low' && height < extremeHeight)) {
        extremeHeight = height;
        extremeTime = new Date(time);
      }
    }
    
    return {
      height: extremeHeight,
      time: extremeTime
    };
  }

  private generateHarmonicPredictions(from: Date): Array<{time: Date; height: number; type: 'high' | 'low'}> {
    const predictions: Array<{time: Date; height: number; type: 'high' | 'low'}> = [];
    const endTime = new Date(from.getTime() + 24 * 60 * 60 * 1000);
    
    let currentTime = new Date(from.getTime());
    let lastHeight = this.calculateHarmonicTide(currentTime);
    let trend: 'rising' | 'falling' = 'rising';
    
    while (currentTime < endTime && predictions.length < 8) {
      currentTime.setMinutes(currentTime.getMinutes() + 30); // Check every 30 minutes
      const currentHeight = this.calculateHarmonicTide(currentTime);
      
      const newTrend: 'rising' | 'falling' = currentHeight > lastHeight ? 'rising' : 'falling';
      
      // Detect tide turn (high or low)
      if (trend !== newTrend) {
        const type = trend === 'rising' ? 'high' : 'low';
        predictions.push({
          time: new Date(currentTime.getTime() - 15 * 60 * 1000), // Approximate turn time
          height: lastHeight,
          type
        });
        trend = newTrend;
      }
      
      lastHeight = currentHeight;
    }
    
    return predictions;
  }

  private async updateDatabaseTide(tideHeight: number): Promise<void> {
    try {
      await storage.updateCurrentTide(tideHeight);
    } catch (error) {
      console.error('Error updating tide in database:', error);
    }
  }

  // Get tide predictions for a specific date range
  async getTidePredictions(startDate: Date, endDate: Date): Promise<Array<{time: Date; height: number; type?: 'high' | 'low'}>> {
    const predictions: Array<{time: Date; height: number; type?: 'high' | 'low'}> = [];
    const interval = 60 * 60 * 1000; // 1 hour intervals
    
    for (let time = new Date(startDate); time <= endDate; time = new Date(time.getTime() + interval)) {
      const height = this.calculateHarmonicTide(time);
      predictions.push({ time: new Date(time), height });
    }
    
    return predictions;
  }
}

export const tideService = new TideService();