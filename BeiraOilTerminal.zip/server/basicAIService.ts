import { nanoid } from 'nanoid';
import { db } from './db';

export type UserRole = 'visitor' | 'operator' | 'admin';
export type Language = 'pt' | 'en';

export interface BasicChatMessage {
  id: string;
  sessionId: string;
  content: string;
  role: 'user' | 'assistant';
  timestamp: Date;
  confidence: number;
}

export interface BasicAIResponse {
  response: string;
  confidence: number;
  suggestions: string[];
  sessionId: string;
  responseTimeMs: number;
}

export class BasicAIService {
  
  // Knowledge base with terminal-specific responses
  private knowledgeBase = {
    pt: {
      greetings: [
        "Olá! Sou seu assistente do Terminal Petrolífero da Beira. Como posso ajudá-lo hoje?",
        "Bem-vindo ao sistema de gestão do Terminal da Beira! Em que posso ser útil?",
        "Oi! Estou aqui para ajudar com informações sobre navios e operações do terminal."
      ],
      farewells: [
        "Obrigado por usar o assistente do Terminal da Beira. Tenha um bom dia!",
        "Foi um prazer ajudar! Volte sempre que precisar de informações do terminal.",
        "Até logo! Estarei aqui quando precisar de assistência."
      ],
      help: [
        "Posso ajudar com: informações de navios, status do terminal, operações de atracação e descarga.",
        "Pergunte sobre navios atuais, condições do terminal, horários de maré ou procedimentos operacionais.",
        "Estou aqui para fornecer informações sobre o Terminal Petrolífero da Beira e suas operações."
      ],
      unknown: [
        "Não tenho certeza sobre isso. Pode reformular sua pergunta?",
        "Desculpe, não entendi completamente. Pode ser mais específico?",
        "Esta informação não está disponível no momento. Posso ajudar com algo mais?"
      ]
    },
    en: {
      greetings: [
        "Hello! I'm your assistant for the Beira Oil Terminal. How can I help you today?",
        "Welcome to the Beira Terminal management system! How may I assist you?",
        "Hi! I'm here to help with information about ships and terminal operations."
      ],
      farewells: [
        "Thank you for using the Beira Terminal assistant. Have a great day!",
        "It was a pleasure helping! Come back whenever you need terminal information.",
        "Goodbye! I'll be here when you need assistance."
      ],
      help: [
        "I can help with: ship information, terminal status, berthing and discharge operations.",
        "Ask about current ships, terminal conditions, tide schedules, or operational procedures.",
        "I'm here to provide information about the Beira Oil Terminal and its operations."
      ],
      unknown: [
        "I'm not sure about that. Could you rephrase your question?",
        "Sorry, I didn't fully understand. Could you be more specific?",
        "This information is not available at the moment. Can I help with something else?"
      ]
    }
  };

  // Pattern matching for different types of queries
  private patterns = {
    pt: {
      greeting: /\b(olá|oi|bom dia|boa tarde|boa noite|hey|hello)\b/i,
      farewell: /\b(tchau|adeus|até logo|obrigado|valeu|bye)\b/i,
      help: /\b(ajuda|help|o que|como|pode|consegue|funciona)\b/i,
      ships: /\b(navio|navios|embarcação|vessel|ship|ships)\b/i,
      terminal: /\b(terminal|porto|port|cais|berth|atracação)\b/i,
      status: /\b(status|estado|situação|condition|how)\b/i,
      tide: /\b(maré|tide|water level|nível)\b/i,
      weather: /\b(tempo|weather|clima|temperature)\b/i,
      operations: /\b(operação|operações|descarga|discharge|operation)\b/i
    },
    en: {
      greeting: /\b(hello|hi|good morning|good afternoon|good evening|hey)\b/i,
      farewell: /\b(bye|goodbye|see you|thanks|thank you)\b/i,
      help: /\b(help|what|how|can|able|function|assist)\b/i,
      ships: /\b(ship|ships|vessel|vessels|boat)\b/i,
      terminal: /\b(terminal|port|berth|berthing|dock)\b/i,
      status: /\b(status|state|condition|how|current)\b/i,
      tide: /\b(tide|water level|sea level)\b/i,
      weather: /\b(weather|climate|temperature|conditions)\b/i,
      operations: /\b(operation|operations|discharge|loading|unloading)\b/i
    }
  };

  async createSession(userId: string | null, userRole: UserRole, language: Language): Promise<string> {
    await this.initializeTables();
    
    const sessionId = nanoid(12);
    
    try {
      await db.execute(`
        INSERT INTO basic_ai_sessions (id, user_id, user_role, language, created_at) 
        VALUES ('${sessionId}', ${userId ? `'${userId}'` : 'NULL'}, '${userRole}', '${language}', NOW())
      `);
      
      console.log('[BasicAI] Session created:', sessionId);
      return sessionId;
    } catch (error) {
      console.error('[BasicAI] Session creation failed:', error);
      throw new Error(`Session creation failed: ${error.message}`);
    }
  }

  async processMessage(
    sessionId: string,
    userMessage: string,
    userRole: UserRole,
    language: Language
  ): Promise<BasicAIResponse> {
    const startTime = Date.now();
    
    try {
      // Save user message
      const userMsgId = nanoid();
      await db.execute(`
        INSERT INTO basic_ai_messages (id, session_id, content, role, timestamp, confidence) 
        VALUES ('${userMsgId}', '${sessionId}', '${userMessage.replace(/'/g, "''")}', 'user', NOW(), 1.0)
      `);

      // Generate response
      const response = await this.generateResponse(userMessage, userRole, language);
      const responseTimeMs = Date.now() - startTime;

      // Save AI response
      const aiMsgId = nanoid();
      await db.execute(`
        INSERT INTO basic_ai_messages (id, session_id, content, role, timestamp, confidence) 
        VALUES ('${aiMsgId}', '${sessionId}', '${response.response.replace(/'/g, "''")}', 'assistant', NOW(), ${response.confidence})
      `);

      return {
        ...response,
        sessionId,
        responseTimeMs
      };

    } catch (error) {
      console.error('[BasicAI] Message processing error:', error);
      
      const fallbackResponse = {
        response: language === 'en' ? 
          'I encountered a technical issue. Please try again.' :
          'Encontrei um problema técnico. Tente novamente.',
        confidence: 0.3,
        suggestions: [],
        sessionId,
        responseTimeMs: Date.now() - startTime
      };

      return fallbackResponse;
    }
  }

  private async generateResponse(message: string, userRole: UserRole, language: Language): Promise<Omit<BasicAIResponse, 'sessionId' | 'responseTimeMs'>> {
    const lang = language === 'en' ? 'en' : 'pt';
    const patterns = this.patterns[lang];
    const responses = this.knowledgeBase[lang];
    
    const lowerMessage = message.toLowerCase();

    // Greeting detection
    if (patterns.greeting.test(lowerMessage)) {
      return {
        response: this.getRandomResponse(responses.greetings),
        confidence: 0.9,
        suggestions: language === 'en' ? [
          'Show current ships',
          'Terminal status',
          'Operations info'
        ] : [
          'Mostrar navios atuais',
          'Status do terminal',
          'Informações operacionais'
        ]
      };
    }

    // Farewell detection
    if (patterns.farewell.test(lowerMessage)) {
      return {
        response: this.getRandomResponse(responses.farewells),
        confidence: 0.9,
        suggestions: []
      };
    }

    // Help detection
    if (patterns.help.test(lowerMessage)) {
      return {
        response: this.getRandomResponse(responses.help),
        confidence: 0.8,
        suggestions: language === 'en' ? [
          'Current ships status',
          'Terminal operations',
          'Weather and tide info'
        ] : [
          'Status dos navios atuais',
          'Operações do terminal',
          'Informações de tempo e maré'
        ]
      };
    }

    // Specific ship name queries
    if (await this.hasSpecificShipQuery(lowerMessage, language)) {
      return await this.getSpecificShipInfo(lowerMessage, userRole, language);
    }

    // Ships information
    if (patterns.ships.test(lowerMessage)) {
      return await this.getShipsInfo(userRole, language);
    }

    // Specific discharge/cargo queries
    if (/\b(descarga|discharge|cargo|volume|parcela|parcel)\b/i.test(lowerMessage)) {
      return await this.getDischargeInfo(userRole, language);
    }

    // Specific berth/berthing queries
    if (/\b(atracação|atracado|berthing|berth|cais|rope)\b/i.test(lowerMessage)) {
      return await this.getBerthingInfo(userRole, language);
    }

    // Agent information queries
    if (/\b(agente|agent|contact|contato)\b/i.test(lowerMessage)) {
      return await this.getAgentInfo(userRole, language);
    }

    // Terminal status
    if (patterns.terminal.test(lowerMessage) && patterns.status.test(lowerMessage)) {
      return await this.getTerminalStatus(userRole, language);
    }

    // Weather information
    if (patterns.weather.test(lowerMessage)) {
      return await this.getWeatherInfo(language);
    }

    // Tide information
    if (patterns.tide.test(lowerMessage)) {
      return await this.getTideInfo(language);
    }

    // Operations information
    if (patterns.operations.test(lowerMessage)) {
      return await this.getOperationsInfo(userRole, language);
    }

    // Count/statistics queries
    if (/\b(quantos|how many|total|count|número)\b/i.test(lowerMessage)) {
      return await this.getStatistics(userRole, language);
    }

    // Default unknown response
    return {
      response: this.getRandomResponse(responses.unknown),
      confidence: 0.4,
      suggestions: language === 'en' ? [
        'Ask about ships',
        'Terminal status',
        'Help with navigation'
      ] : [
        'Perguntar sobre navios',
        'Status do terminal',
        'Ajuda com navegação'
      ]
    };
  }

  private async getShipsInfo(userRole: UserRole, language: Language): Promise<Omit<BasicAIResponse, 'sessionId' | 'responseTimeMs'>> {
    try {
      // Get detailed ship information
      const shipsResult = await db.execute(`
        SELECT s.*, 
               COUNT(cp.id) as parcel_count,
               SUM(cp.volume) as total_volume,
               STRING_AGG(DISTINCT cp.receiver, ', ') as receivers,
               br.first_rope_time, br.last_rope_time,
               AVG(dp.percentage) as avg_discharge_progress
        FROM ships s
        LEFT JOIN cargo_parcels cp ON s.id = cp.ship_id
        LEFT JOIN berthing_records br ON s.id = br.ship_id
        LEFT JOIN discharge_progress dp ON cp.id = dp.parcel_id
        WHERE s.status IN ('expected', 'at_bar', 'next_to_berth', 'at_berth')
        GROUP BY s.id, s.name, s.countermark, s.cargo_agent, s.ship_agent, s.status, s.arrival_at_bar, br.first_rope_time, br.last_rope_time
        ORDER BY s.arrival_at_bar ASC
      `);
      
      if (shipsResult.rows && shipsResult.rows.length > 0) {
        let detailedInfo = '';
        
        shipsResult.rows.forEach((ship: any, index: number) => {
          const statusText = this.translateStatus(ship.status, language);
          const volume = ship.total_volume ? `${ship.total_volume.toLocaleString()} MT` : 'N/A';
          const progress = ship.avg_discharge_progress ? `${Math.round(ship.avg_discharge_progress)}%` : '0%';
          
          if (language === 'en') {
            detailedInfo += `${index + 1}. ${ship.name} (${ship.countermark})\n`;
            detailedInfo += `   Status: ${statusText}\n`;
            detailedInfo += `   Agent: ${ship.cargo_agent || 'N/A'}\n`;
            detailedInfo += `   Volume: ${volume}\n`;
            detailedInfo += `   Discharge: ${progress}\n`;
            if (ship.receivers) detailedInfo += `   Receivers: ${ship.receivers}\n`;
            detailedInfo += '\n';
          } else {
            detailedInfo += `${index + 1}. ${ship.name} (${ship.countermark})\n`;
            detailedInfo += `   Status: ${statusText}\n`;
            detailedInfo += `   Agente: ${ship.cargo_agent || 'N/A'}\n`;
            detailedInfo += `   Volume: ${volume}\n`;
            detailedInfo += `   Descarga: ${progress}\n`;
            if (ship.receivers) detailedInfo += `   Receptores: ${ship.receivers}\n`;
            detailedInfo += '\n';
          }
        });
        
        const summary = language === 'en' ? 
          `Ships Information (${shipsResult.rows.length} total):\n\n${detailedInfo}` :
          `Informações dos Navios (${shipsResult.rows.length} total):\n\n${detailedInfo}`;
        
        return {
          response: summary,
          confidence: 0.95,
          suggestions: language === 'en' ? [
            'Show berthing times',
            'Discharge progress details',
            'Agent contact info'
          ] : [
            'Mostrar horários de atracação',
            'Detalhes progresso descarga',
            'Informações contato agente'
          ]
        };
      } else {
        return {
          response: language === 'en' ? 
            'No ships currently registered at the terminal.' :
            'Nenhum navio atualmente registrado no terminal.',
          confidence: 0.8,
          suggestions: language === 'en' ? [
            'Terminal status',
            'Expected arrivals',
            'Operations info'
          ] : [
            'Status do terminal',
            'Chegadas previstas',
            'Informações operacionais'
          ]
        };
      }
    } catch (error) {
      console.error('[BasicAI] Ships info error:', error);
      return {
        response: language === 'en' ? 
          'Unable to retrieve ships information from database.' :
          'Não foi possível obter informações dos navios do banco de dados.',
        confidence: 0.3,
        suggestions: []
      };
    }
  }

  private async getTerminalStatus(userRole: UserRole, language: Language): Promise<Omit<BasicAIResponse, 'sessionId' | 'responseTimeMs'>> {
    try {
      // Get maintenance status
      const maintenanceResult = await db.execute(`
        SELECT is_active, description FROM berth_maintenance WHERE is_active = true LIMIT 1
      `);
      
      // Get active ships count
      const shipsResult = await db.execute(`
        SELECT COUNT(*) as total FROM ships WHERE status IN ('at_bar', 'next_to_berth', 'at_berth')
      `);
      
      const totalShips = (shipsResult.rows?.[0] as any)?.total || 0;
      const isInMaintenance = maintenanceResult.rows && maintenanceResult.rows.length > 0;
      
      let status = language === 'en' ? 'Terminal Status:\n' : 'Status do Terminal:\n';
      
      if (isInMaintenance) {
        status += language === 'en' ? 
          '🔧 Berth under maintenance\n' :
          '🔧 Cais em manutenção\n';
      } else {
        status += language === 'en' ? 
          '✅ Terminal operational\n' :
          '✅ Terminal operacional\n';
      }
      
      status += language === 'en' ? 
        `📊 Active ships: ${totalShips}` :
        `📊 Navios ativos: ${totalShips}`;
      
      return {
        response: status,
        confidence: 0.9,
        suggestions: language === 'en' ? [
          'Show ships details',
          'Weather conditions',
          'Operations schedule'
        ] : [
          'Mostrar detalhes dos navios',
          'Condições meteorológicas',
          'Cronograma de operações'
        ]
      };
    } catch (error) {
      console.error('[BasicAI] Terminal status error:', error);
      return {
        response: language === 'en' ? 
          'Unable to get terminal status information.' :
          'Não foi possível obter informações do status do terminal.',
        confidence: 0.3,
        suggestions: []
      };
    }
  }

  private async getWeatherInfo(language: Language): Promise<Omit<BasicAIResponse, 'sessionId' | 'responseTimeMs'>> {
    try {
      const response = await fetch('http://localhost:5000/api/weather');
      const weatherData = await response.json();
      
      const weatherInfo = language === 'en' ? 
        `Current Weather at Beira:\n🌡️ Temperature: ${weatherData.temperature}°C\n💧 Humidity: ${weatherData.humidity}%\n🌬️ Wind: ${weatherData.windSpeed} km/h` :
        `Condições Meteorológicas em Beira:\n🌡️ Temperatura: ${weatherData.temperature}°C\n💧 Umidade: ${weatherData.humidity}%\n🌬️ Vento: ${weatherData.windSpeed} km/h`;
      
      return {
        response: weatherInfo,
        confidence: 0.8,
        suggestions: language === 'en' ? [
          'Tide information',
          'Terminal conditions',
          'Ship operations'
        ] : [
          'Informações de maré',
          'Condições do terminal',
          'Operações de navios'
        ]
      };
    } catch (error) {
      return {
        response: language === 'en' ? 
          'Weather information is currently unavailable.' :
          'Informações meteorológicas indisponíveis no momento.',
        confidence: 0.4,
        suggestions: []
      };
    }
  }

  private async getTideInfo(language: Language): Promise<Omit<BasicAIResponse, 'sessionId' | 'responseTimeMs'>> {
    try {
      const response = await fetch('http://localhost:5000/api/tide');
      const tideData = await response.json();
      
      const tideInfo = language === 'en' ? 
        `Current Tide at Beira Port:\n🌊 Height: ${tideData.currentTide.toFixed(2)}m\n⏰ Time: ${new Date(tideData.tideTime).toLocaleTimeString('en-US', { timeZone: 'Africa/Maputo' })}` :
        `Maré Atual no Porto da Beira:\n🌊 Altura: ${tideData.currentTide.toFixed(2)}m\n⏰ Hora: ${new Date(tideData.tideTime).toLocaleTimeString('pt-MZ', { timeZone: 'Africa/Maputo' })}`;
      
      return {
        response: tideInfo,
        confidence: 0.8,
        suggestions: language === 'en' ? [
          'Weather conditions',
          'Ship operations',
          'Berthing conditions'
        ] : [
          'Condições meteorológicas',
          'Operações de navios',
          'Condições de atracação'
        ]
      };
    } catch (error) {
      return {
        response: language === 'en' ? 
          'Tide information is currently unavailable.' :
          'Informações de maré indisponíveis no momento.',
        confidence: 0.4,
        suggestions: []
      };
    }
  }

  private async getOperationsInfo(userRole: UserRole, language: Language): Promise<Omit<BasicAIResponse, 'sessionId' | 'responseTimeMs'>> {
    try {
      const shipsResult = await db.execute(`
        SELECT COUNT(*) as atBerth FROM ships WHERE status = 'at_berth'
      `);
      
      const atBerth = (shipsResult.rows?.[0] as any)?.atBerth || 0;
      
      const operationsInfo = language === 'en' ? 
        `Terminal Operations:\n🚢 Ships at berth: ${atBerth}\n⚡ Discharge operations: ${atBerth > 0 ? 'Active' : 'None'}\n📋 Status: ${atBerth > 0 ? 'Operational' : 'Standby'}` :
        `Operações do Terminal:\n🚢 Navios atracados: ${atBerth}\n⚡ Operações de descarga: ${atBerth > 0 ? 'Ativas' : 'Nenhuma'}\n📋 Status: ${atBerth > 0 ? 'Operacional' : 'Em espera'}`;
      
      return {
        response: operationsInfo,
        confidence: 0.8,
        suggestions: language === 'en' ? [
          'Ship details',
          'Discharge progress',
          'Schedule information'
        ] : [
          'Detalhes dos navios',
          'Progresso de descarga',
          'Informações de cronograma'
        ]
      };
    } catch (error) {
      return {
        response: language === 'en' ? 
          'Operations information is currently unavailable.' :
          'Informações operacionais indisponíveis no momento.',
        confidence: 0.4,
        suggestions: []
      };
    }
  }

  private translateStatus(status: string, language: Language): string {
    const translations = {
      pt: {
        'at_bar': 'na barra',
        'next_to_berth': 'próximo ao cais',
        'at_berth': 'atracado',
        'departed': 'partido'
      },
      en: {
        'at_bar': 'at bar',
        'next_to_berth': 'next to berth',
        'at_berth': 'berthed',
        'departed': 'departed'
      }
    };
    
    return translations[language === 'en' ? 'en' : 'pt'][status] || status;
  }

  private getRandomResponse(responses: string[]): string {
    return responses[Math.floor(Math.random() * responses.length)];
  }

  private async initializeTables(): Promise<void> {
    try {
      // Create sessions table
      await db.execute(`
        CREATE TABLE IF NOT EXISTS basic_ai_sessions (
          id VARCHAR PRIMARY KEY,
          user_id VARCHAR,
          user_role VARCHAR NOT NULL,
          language VARCHAR DEFAULT 'pt',
          created_at TIMESTAMP DEFAULT NOW(),
          ended_at TIMESTAMP,
          last_activity TIMESTAMP DEFAULT NOW()
        )
      `);
      
      // Create messages table
      await db.execute(`
        CREATE TABLE IF NOT EXISTS basic_ai_messages (
          id VARCHAR PRIMARY KEY,
          session_id VARCHAR NOT NULL,
          content TEXT NOT NULL,
          role VARCHAR NOT NULL CHECK (role IN ('user', 'assistant')),
          timestamp TIMESTAMP DEFAULT NOW(),
          confidence REAL DEFAULT 1.0
        )
      `);
      
    } catch (error) {
      console.error('[BasicAI] Database initialization error:', error);
    }
  }

  // New helper methods for specific queries
  private async hasSpecificShipQuery(message: string, language: Language): Promise<boolean> {
    try {
      const shipsResult = await db.execute(`SELECT name FROM ships WHERE status IN ('expected', 'at_bar', 'next_to_berth', 'at_berth')`);
      if (!shipsResult.rows) return false;
      
      return shipsResult.rows.some((ship: any) => 
        message.toLowerCase().includes(ship.name.toLowerCase())
      );
    } catch {
      return false;
    }
  }

  private async getSpecificShipInfo(message: string, userRole: UserRole, language: Language): Promise<Omit<BasicAIResponse, 'sessionId' | 'responseTimeMs'>> {
    try {
      const shipsResult = await db.execute(`
        SELECT s.*, 
               COUNT(cp.id) as parcel_count,
               SUM(cp.volume) as total_volume,
               STRING_AGG(DISTINCT cp.receiver, ', ') as receivers,
               br.first_rope_time, br.last_rope_time,
               AVG(dp.percentage) as avg_discharge_progress
        FROM ships s
        LEFT JOIN cargo_parcels cp ON s.id = cp.ship_id
        LEFT JOIN berthing_records br ON s.id = br.ship_id
        LEFT JOIN discharge_progress dp ON cp.id = dp.parcel_id
        WHERE s.status IN ('expected', 'at_bar', 'next_to_berth', 'at_berth')
        GROUP BY s.id, s.name, s.countermark, s.cargo_agent, s.ship_agent, s.status, s.arrival_at_bar, br.first_rope_time, br.last_rope_time
      `);

      const ship = shipsResult.rows?.find((s: any) => 
        message.toLowerCase().includes(s.name.toLowerCase())
      );

      if (ship) {
        const status = this.translateStatus(ship.status, language);
        const volume = ship.total_volume ? `${ship.total_volume.toLocaleString()} MT` : 'N/A';
        const progress = ship.avg_discharge_progress ? `${Math.round(ship.avg_discharge_progress)}%` : '0%';
        
        const response = language === 'en' ? 
          `Ship Information: ${ship.name}\n\nCountermark: ${ship.countermark}\nStatus: ${status}\nAgent: ${ship.cargo_agent || 'N/A'}\nTotal Volume: ${volume}\nDischarge Progress: ${progress}\nArrival at Bar: ${new Date(ship.arrival_at_bar).toLocaleDateString()}\n${ship.receivers ? `Receivers: ${ship.receivers}` : ''}` :
          `Informações do Navio: ${ship.name}\n\nContramarca: ${ship.countermark}\nStatus: ${status}\nAgente: ${ship.cargo_agent || 'N/A'}\nVolume Total: ${volume}\nProgresso Descarga: ${progress}\nChegada na Barra: ${new Date(ship.arrival_at_bar).toLocaleDateString()}\n${ship.receivers ? `Receptores: ${ship.receivers}` : ''}`;

        return {
          response,
          confidence: 0.95,
          suggestions: language === 'en' ? [
            'Discharge details',
            'Berthing information',
            'Agent contacts'
          ] : [
            'Detalhes da descarga',
            'Informações de atracação',
            'Contatos do agente'
          ]
        };
      }
    } catch (error) {
      console.error('[BasicAI] Specific ship query error:', error);
    }

    return {
      response: language === 'en' ? 
        'Ship not found or not currently at terminal.' :
        'Navio não encontrado ou não está atualmente no terminal.',
      confidence: 0.4,
      suggestions: []
    };
  }

  private async getDischargeInfo(userRole: UserRole, language: Language): Promise<Omit<BasicAIResponse, 'sessionId' | 'responseTimeMs'>> {
    try {
      const dischargeResult = await db.execute(`
        SELECT s.name, s.countermark, cp.receiver, cp.volume, dp.percentage, cp.parcel_owner
        FROM ships s
        JOIN cargo_parcels cp ON s.id = cp.ship_id
        LEFT JOIN discharge_progress dp ON cp.id = dp.parcel_id
        WHERE s.status IN ('at_berth', 'next_to_berth')
        ORDER BY s.name, cp.receiver
      `);

      if (dischargeResult.rows && dischargeResult.rows.length > 0) {
        let dischargeInfo = language === 'en' ? 'Discharge Operations:\n\n' : 'Operações de Descarga:\n\n';
        
        dischargeResult.rows.forEach((row: any) => {
          const progress = row.percentage || 0;
          dischargeInfo += language === 'en' ? 
            `${row.name}: ${row.receiver} - ${row.volume} MT (${progress}% complete)\n` :
            `${row.name}: ${row.receiver} - ${row.volume} MT (${progress}% concluído)\n`;
          if (row.parcel_owner) {
            dischargeInfo += language === 'en' ? `  Owner: ${row.parcel_owner}\n` : `  Dono: ${row.parcel_owner}\n`;
          }
        });

        return {
          response: dischargeInfo,
          confidence: 0.9,
          suggestions: language === 'en' ? [
            'Update discharge progress',
            'Show completed operations',
            'Berth availability'
          ] : [
            'Atualizar progresso descarga',
            'Mostrar operações concluídas',
            'Disponibilidade do cais'
          ]
        };
      }
    } catch (error) {
      console.error('[BasicAI] Discharge info error:', error);
    }

    return {
      response: language === 'en' ? 
        'No active discharge operations found.' :
        'Nenhuma operação de descarga ativa encontrada.',
      confidence: 0.6,
      suggestions: []
    };
  }

  private async getBerthingInfo(userRole: UserRole, language: Language): Promise<Omit<BasicAIResponse, 'sessionId' | 'responseTimeMs'>> {
    try {
      const berthingResult = await db.execute(`
        SELECT s.name, s.status, br.first_rope_time, br.last_rope_time,
               ur.first_rope_time as undock_first, ur.last_rope_time as undock_last
        FROM ships s
        LEFT JOIN berthing_records br ON s.id = br.ship_id
        LEFT JOIN undocking_records ur ON s.id = ur.ship_id
        WHERE s.status IN ('at_berth', 'next_to_berth', 'departed')
        ORDER BY br.last_rope_time DESC NULLS LAST
      `);

      if (berthingResult.rows && berthingResult.rows.length > 0) {
        let berthingInfo = language === 'en' ? 'Berthing Information:\n\n' : 'Informações de Atracação:\n\n';
        
        berthingResult.rows.forEach((row: any) => {
          berthingInfo += `${row.name}:\n`;
          if (row.last_rope_time) {
            const berthTime = new Date(row.last_rope_time).toLocaleString();
            berthingInfo += language === 'en' ? 
              `  Berthed: ${berthTime}\n` : 
              `  Atracado: ${berthTime}\n`;
          }
          if (row.undock_last) {
            const undockTime = new Date(row.undock_last).toLocaleString();
            berthingInfo += language === 'en' ? 
              `  Undocked: ${undockTime}\n` : 
              `  Desatracado: ${undockTime}\n`;
          }
          berthingInfo += `  Status: ${this.translateStatus(row.status, language)}\n\n`;
        });

        return {
          response: berthingInfo,
          confidence: 0.9,
          suggestions: language === 'en' ? [
            'Show berth availability',
            'Next ship to berth',
            'Berthing schedule'
          ] : [
            'Mostrar disponibilidade cais',
            'Próximo navio a atracar',
            'Cronograma atracação'
          ]
        };
      }
    } catch (error) {
      console.error('[BasicAI] Berthing info error:', error);
    }

    return {
      response: language === 'en' ? 
        'No berthing information available.' :
        'Nenhuma informação de atracação disponível.',
      confidence: 0.6,
      suggestions: []
    };
  }

  private async getAgentInfo(userRole: UserRole, language: Language): Promise<Omit<BasicAIResponse, 'sessionId' | 'responseTimeMs'>> {
    try {
      const agentResult = await db.execute(`
        SELECT DISTINCT s.cargo_agent, s.ship_agent, s.ship_agent_email, s.cargo_agent_email, s.name
        FROM ships s
        WHERE s.status IN ('expected', 'at_bar', 'next_to_berth', 'at_berth')
        AND (s.cargo_agent IS NOT NULL OR s.ship_agent IS NOT NULL)
      `);

      if (agentResult.rows && agentResult.rows.length > 0) {
        let agentInfo = language === 'en' ? 'Agent Information:\n\n' : 'Informações dos Agentes:\n\n';
        
        agentResult.rows.forEach((row: any) => {
          agentInfo += `${row.name}:\n`;
          if (row.cargo_agent) {
            agentInfo += language === 'en' ? 
              `  Cargo Agent: ${row.cargo_agent}\n` : 
              `  Agente Carga: ${row.cargo_agent}\n`;
            if (row.cargo_agent_email) {
              agentInfo += `  Email: ${row.cargo_agent_email}\n`;
            }
          }
          if (row.ship_agent) {
            agentInfo += language === 'en' ? 
              `  Ship Agent: ${row.ship_agent}\n` : 
              `  Agente Navio: ${row.ship_agent}\n`;
            if (row.ship_agent_email) {
              agentInfo += `  Email: ${row.ship_agent_email}\n`;
            }
          }
          agentInfo += '\n';
        });

        return {
          response: agentInfo,
          confidence: 0.9,
          suggestions: language === 'en' ? [
            'Contact specific agent',
            'Ship documentation',
            'Agent responsibilities'
          ] : [
            'Contactar agente específico',
            'Documentação do navio',
            'Responsabilidades do agente'
          ]
        };
      }
    } catch (error) {
      console.error('[BasicAI] Agent info error:', error);
    }

    return {
      response: language === 'en' ? 
        'No agent information available for current ships.' :
        'Nenhuma informação de agente disponível para navios atuais.',
      confidence: 0.6,
      suggestions: []
    };
  }

  private async getStatistics(userRole: UserRole, language: Language): Promise<Omit<BasicAIResponse, 'sessionId' | 'responseTimeMs'>> {
    try {
      const statsResult = await db.execute(`
        SELECT 
          COUNT(CASE WHEN status = 'expected' THEN 1 END) as expected_count,
          COUNT(CASE WHEN status = 'at_bar' THEN 1 END) as at_bar_count,
          COUNT(CASE WHEN status = 'next_to_berth' THEN 1 END) as next_to_berth_count,
          COUNT(CASE WHEN status = 'at_berth' THEN 1 END) as at_berth_count,
          COUNT(*) as total_ships,
          SUM((SELECT SUM(volume) FROM cargo_parcels WHERE ship_id = ships.id)) as total_volume
        FROM ships 
        WHERE status IN ('expected', 'at_bar', 'next_to_berth', 'at_berth')
      `);

      if (statsResult.rows && statsResult.rows[0]) {
        const stats = statsResult.rows[0] as any;
        
        const response = language === 'en' ? 
          `Terminal Statistics:\n\nTotal Ships: ${stats.total_ships}\nExpected: ${stats.expected_count}\nAt Bar: ${stats.at_bar_count}\nNext to Berth: ${stats.next_to_berth_count}\nAt Berth: ${stats.at_berth_count}\nTotal Volume: ${stats.total_volume ? `${stats.total_volume.toLocaleString()} MT` : 'N/A'}` :
          `Estatísticas do Terminal:\n\nTotal de Navios: ${stats.total_ships}\nEsperados: ${stats.expected_count}\nNa Barra: ${stats.at_bar_count}\nPróximo ao Cais: ${stats.next_to_berth_count}\nAtracados: ${stats.at_berth_count}\nVolume Total: ${stats.total_volume ? `${stats.total_volume.toLocaleString()} MT` : 'N/A'}`;

        return {
          response,
          confidence: 0.95,
          suggestions: language === 'en' ? [
            'Show ship details',
            'Discharge progress',
            'Terminal efficiency'
          ] : [
            'Mostrar detalhes navios',
            'Progresso descarga',
            'Eficiência terminal'
          ]
        };
      }
    } catch (error) {
      console.error('[BasicAI] Statistics error:', error);
    }

    return {
      response: language === 'en' ? 
        'Unable to retrieve terminal statistics.' :
        'Não foi possível obter estatísticas do terminal.',
      confidence: 0.4,
      suggestions: []
    };
  }

  async getChatHistory(sessionId: string): Promise<BasicChatMessage[]> {
    try {
      const result = await db.execute(`
        SELECT id, session_id, content, role, timestamp, confidence 
        FROM basic_ai_messages 
        WHERE session_id = '${sessionId}' 
        ORDER BY timestamp ASC
      `);
      
      return (result.rows || []).map((row: any) => ({
        id: row.id,
        sessionId: row.session_id,
        content: row.content,
        role: row.role,
        timestamp: new Date(row.timestamp),
        confidence: row.confidence
      }));
    } catch (error) {
      console.error('[BasicAI] Failed to get chat history:', error);
      return [];
    }
  }
}

export const basicAIService = new BasicAIService();