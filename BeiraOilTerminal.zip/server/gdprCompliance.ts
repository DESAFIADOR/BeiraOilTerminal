// GDPR/LGPD Compliance for Virtual Assistant
import { db } from "./db";
import { chatSessions, chatMessages } from "@shared/schema";
import { eq, lt } from "drizzle-orm";

export class GDPRComplianceService {
  
  // Data retention policy - delete chat data older than 90 days
  async cleanupOldChatData(): Promise<void> {
    const retentionPeriod = new Date();
    retentionPeriod.setDate(retentionPeriod.getDate() - 90);
    
    try {
      // Delete old chat messages
      await db.delete(chatMessages)
        .where(lt(chatMessages.timestamp, retentionPeriod));
      
      // Delete old chat sessions
      await db.delete(chatSessions)
        .where(lt(chatSessions.startTime, retentionPeriod));
      
      console.log(`GDPR Cleanup: Removed chat data older than ${retentionPeriod.toISOString()}`);
    } catch (error) {
      console.error('Error during GDPR cleanup:', error);
    }
  }
  
  // Export user data (GDPR Article 20 - Right to data portability)
  async exportUserData(userId: string): Promise<any> {
    try {
      const sessions = await db.select()
        .from(chatSessions)
        .where(eq(chatSessions.userId, userId));
      
      const messages = await db.select()
        .from(chatMessages)
        .innerJoin(chatSessions, eq(chatMessages.sessionId, chatSessions.id))
        .where(eq(chatSessions.userId, userId));
      
      return {
        exportDate: new Date().toISOString(),
        userId,
        chatSessions: sessions,
        chatMessages: messages.map(m => m.chat_messages),
        dataProcessor: "Beira Oil Terminal Virtual Assistant",
        legalBasis: "Legitimate interest for customer support",
        retentionPeriod: "90 days"
      };
    } catch (error) {
      console.error('Error exporting user data:', error);
      throw error;
    }
  }
  
  // Delete user data (GDPR Article 17 - Right to erasure)
  async deleteUserData(userId: string): Promise<void> {
    try {
      // Get user sessions
      const userSessions = await db.select()
        .from(chatSessions)
        .where(eq(chatSessions.userId, userId));
      
      // Delete messages from user sessions
      for (const session of userSessions) {
        await db.delete(chatMessages)
          .where(eq(chatMessages.sessionId, session.id));
      }
      
      // Delete user sessions
      await db.delete(chatSessions)
        .where(eq(chatSessions.userId, userId));
      
      console.log(`GDPR Erasure: Deleted all data for user ${userId}`);
    } catch (error) {
      console.error('Error deleting user data:', error);
      throw error;
    }
  }
  
  // Anonymize chat data for analytics (pseudo-anonymization)
  async anonymizeChatData(): Promise<void> {
    try {
      // Remove user IDs from old sessions (older than 30 days)
      const anonymizationDate = new Date();
      anonymizationDate.setDate(anonymizationDate.getDate() - 30);
      
      await db.update(chatSessions)
        .set({ userId: null })
        .where(lt(chatSessions.startTime, anonymizationDate));
      
      console.log(`GDPR Anonymization: Anonymized chat data older than ${anonymizationDate.toISOString()}`);
    } catch (error) {
      console.error('Error anonymizing chat data:', error);
    }
  }
  
  // Get data processing consent record
  getDataProcessingInfo(): any {
    return {
      controller: "CFM-EP - Beira Oil Terminal",
      processor: "Virtual Assistant System",
      purpose: "Customer support and operational assistance",
      legalBasis: "Legitimate interest (Article 6(1)(f) GDPR)",
      dataTypes: [
        "Chat messages",
        "User role/permissions",
        "Session metadata",
        "Satisfaction ratings"
      ],
      retentionPeriod: "90 days",
      rights: [
        "Right to access (Article 15)",
        "Right to rectification (Article 16)", 
        "Right to erasure (Article 17)",
        "Right to data portability (Article 20)",
        "Right to object (Article 21)"
      ],
      contact: "dpo@cfm.co.mz"
    };
  }
}

export const gdprComplianceService = new GDPRComplianceService();

// Schedule automatic cleanup (run daily)
setInterval(() => {
  gdprComplianceService.cleanupOldChatData();
  gdprComplianceService.anonymizeChatData();
}, 24 * 60 * 60 * 1000); // 24 hours