// Alternative email service - currently using web report until SendGrid is configured
export class AlternativeEmailService {
  async sendEmail(params: {
    to: string;
    from: string;
    subject: string;
    html: string;
  }): Promise<boolean> {
    console.log(`Alternative email service - report available at: https://beiraoilterminal-vessels-lineup.com/api/system/report-web`);
    console.log(`Recipient: ${params.to}`);
    return true;
  }
}

// Fallback: Generate accessible web report
export function generateWebReport(): string {
  const reportHtml = `
    <!DOCTYPE html>
    <html lang="pt-BR">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Relatório do Sistema - Terminal Petrolífero da Beira</title>
        <style>
            body { font-family: Arial, sans-serif; margin: 0; padding: 20px; background: #f5f5f5; }
            .container { max-width: 800px; margin: 0 auto; background: white; padding: 30px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
            .header { text-align: center; margin-bottom: 30px; border-bottom: 3px solid #1e40af; padding-bottom: 20px; }
            .header h1 { color: #1e40af; margin: 0; font-size: 28px; }
            .header h2 { color: #64748b; margin: 10px 0 0 0; font-size: 18px; }
            .section { background: #eff6ff; padding: 20px; border-radius: 8px; margin: 20px 0; }
            .section h3 { color: #1e40af; margin: 0 0 15px 0; }
            .section h4 { color: #059669; margin-bottom: 10px; }
            ul { line-height: 1.6; color: #374151; margin: 0; padding-left: 20px; }
            .highlight { background: #fef3c7; border-left: 4px solid #f59e0b; }
            .tech-specs { background: #f0fdf4; border-left: 4px solid #22c55e; }
            .access-info { background: #e0f2fe; text-align: center; }
            .footer { text-align: center; color: #9ca3af; font-size: 12px; border-top: 1px solid #e5e7eb; padding-top: 20px; }
        </style>
    </head>
    <body>
        <div class="container">
            <div class="header">
                <h1>⚓ Sistema de Gestão Portuária</h1>
                <h2>Terminal Petrolífero da Beira</h2>
                <p>Relatório Completo de Funcionalidades | Versão 2.0 | beiraoilterminal-vessels-lineup.com</p>
                <p><strong>Data de Geração:</strong> ${new Date().toLocaleString('pt-BR')}</p>
            </div>
            
            <div class="section">
                <h3>📋 Funcionalidades Principais</h3>
                
                <h4>Gestão de Navios</h4>
                <ul>
                    <li>Registro completo de navios com informações detalhadas (nome, contra marca, calado, agentes)</li>
                    <li>Sistema de status em tempo real (esperado, na barra, próximo a atracar, no cais, partido)</li>
                    <li>Controle de tipos de operação (Trânsito e Combinado) com regras de atracação 2:1</li>
                    <li>Sistema de priorização IMOPETRO conforme Decreto 89/2019</li>
                    <li>Gestão de parcelas de carga com volumes e destinatários</li>
                    <li>Rastreamento de progresso de descarga em tempo real</li>
                </ul>
                
                <h4>Sistema de Priorização Inteligente</h4>
                <ul>
                    <li>Prioridade absoluta para navios IMOPETRO (Decreto 89/2019)</li>
                    <li>Regra de atracação 2:1: 2 navios trânsito + 1 navio combinado</li>
                    <li>Ordenação cronológica por data de chegada na barra</li>
                    <li>Badges visuais diferenciando tipos de operação (trânsito verde, combinado roxo)</li>
                    <li>Alertas de prioridade em tempo real</li>
                </ul>
                
                <h4>Controle de Atracação</h4>
                <ul>
                    <li>Registro de tempos de atracação (primeira e última amarra)</li>
                    <li>Verificação automática de condições baseada no calado e maré</li>
                    <li>Sistema de confirmação de instruções de descarga via email</li>
                    <li>Controle de berço com status de manutenção programada</li>
                    <li>Fluxo automatizado de movimentação entre status</li>
                </ul>
                
                <h4>Monitoramento Ambiental</h4>
                <ul>
                    <li>Monitoramento de marés em tempo real para Porto da Beira</li>
                    <li>Previsões de maré com análise harmônica (constituintes M2, S2, N2)</li>
                    <li>Alertas meteorológicos para ventos acima de 25 nós</li>
                    <li>Dados de temperatura, umidade e pressão atmosférica</li>
                    <li>Integração com APIs meteorológicas (OpenWeather e Open-Meteo)</li>
                </ul>
            </div>
            
            <div class="section tech-specs">
                <h3>⚙️ Especificações Técnicas</h3>
                <ul>
                    <li><strong>Frontend:</strong> React 18 com TypeScript, Tailwind CSS, shadcn/ui</li>
                    <li><strong>Backend:</strong> Express.js com TypeScript, Drizzle ORM</li>
                    <li><strong>Banco de Dados:</strong> PostgreSQL (Neon Serverless)</li>
                    <li><strong>Autenticação:</strong> Replit Auth com OpenID Connect</li>
                    <li><strong>Email:</strong> SendGrid para notificações profissionais</li>
                    <li><strong>Relatórios:</strong> Chart.js e Puppeteer para relatórios PDF</li>
                    <li><strong>Clima/Marés:</strong> APIs OpenWeather e Open-Meteo</li>
                    <li><strong>Deployment:</strong> Replit com domínio beiraoilterminal-vessels-lineup.com</li>
                </ul>
            </div>
            
            <div class="section highlight">
                <h3>📈 Benefícios Operacionais</h3>
                <ul>
                    <li>Redução significativa do tempo de coordenação de navios</li>
                    <li>Transparência total no processo de atracação</li>
                    <li>Conformidade regulatória automática (Decreto 89/2019)</li>
                    <li>Otimização da utilização do berço único</li>
                    <li>Rastreamento preciso de operações de descarga</li>
                    <li>Melhoria na comunicação com agentes marítimos</li>
                    <li>Relatórios automáticos para gestão superior</li>
                    <li>Alertas preventivos para condições adversas</li>
                </ul>
            </div>
            
            <div class="section">
                <h3>🎯 Principais Destaques</h3>
                <ul>
                    <li><strong>Sistema de Priorização IMOPETRO:</strong> Conformidade automática com Decreto 89/2019</li>
                    <li><strong>Regras de Atracação 2:1:</strong> Algoritmo inteligente para navios trânsito e combinados</li>
                    <li><strong>Monitoramento Ambiental:</strong> Dados de maré e clima em tempo real</li>
                    <li><strong>Relatórios Automáticos:</strong> Geração e envio mensal de relatórios em PDF</li>
                    <li><strong>Interface Responsiva:</strong> Otimizada para dispositivos móveis e ambiente marítimo</li>
                    <li><strong>Controle de Acesso:</strong> Sistema seguro com permissões granulares</li>
                </ul>
            </div>
            
            <div class="section access-info">
                <h3>🌐 Acesso ao Sistema</h3>
                <p>Sistema disponível em:<br>
                <strong style="color: #1e40af; font-size: 18px;">https://beiraoilterminal-vessels-lineup.com</strong></p>
            </div>
            
            <div class="footer">
                <p>Este relatório foi gerado automaticamente pelo sistema de gestão portuária</p>
                <p>CFM-EP | Terminal Petrolífero da Beira | 2025</p>
                <p>Para suporte técnico, contate o administrador do sistema</p>
            </div>
        </div>
    </body>
    </html>
  `;
  
  return reportHtml;
}