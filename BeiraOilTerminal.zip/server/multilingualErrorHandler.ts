import { Language } from './advancedAIService';

export interface ErrorTranslation {
  title: string;
  message: string;
  suggestions: string[];
  actionText?: string;
}

export interface ErrorContext {
  errorCode: string;
  errorType: 'technical' | 'quota' | 'configuration' | 'network' | 'permission';
  severity: 'low' | 'medium' | 'high' | 'critical';
  userRole: 'visitor' | 'operator' | 'admin';
  context?: any;
}

export class MultilingualErrorHandler {
  
  private errorTranslations = {
    pt: {
      // Technical Errors
      insufficient_quota: {
        title: "Limite de Uso Atingido",
        message: "O serviço de IA atingiu seu limite de uso atual. Ainda posso fornecer informações básicas do terminal e assistência com navegação.",
        suggestions: [
          "Ver status atual dos navios",
          "Consultar operações do terminal", 
          "Contatar administrador para upgrade",
          "Usar funcionalidades básicas"
        ],
        actionText: "Contatar Administrador"
      },
      invalid_api_key: {
        title: "Configuração Necessária",
        message: "O serviço de IA não está configurado adequadamente. É necessário configurar a chave de API do OpenAI para funcionalidade completa.",
        suggestions: [
          "Contatar administrador do sistema",
          "Ver informações básicas do terminal",
          "Navegar pelas funcionalidades disponíveis"
        ],
        actionText: "Configurar Serviço"
      },
      network_error: {
        title: "Problema de Conectividade",
        message: "Detectei uma instabilidade na conexão. Tentarei novamente ou posso ajudar com informações locais do terminal.",
        suggestions: [
          "Tentar novamente em alguns momentos",
          "Ver dados locais do terminal",
          "Verificar status dos navios"
        ],
        actionText: "Tentar Novamente"
      },
      timeout_error: {
        title: "Tempo Limite Excedido",
        message: "O processamento está demorando mais que o esperado. Posso fornecer respostas mais rápidas sobre dados básicos do terminal.",
        suggestions: [
          "Reformular pergunta mais simples",
          "Ver informações rápidas",
          "Consultar dados locais"
        ],
        actionText: "Simplificar Consulta"
      },
      database_error: {
        title: "Erro de Dados",
        message: "Problema temporário no acesso aos dados. Algumas informações podem estar limitadas no momento.",
        suggestions: [
          "Tentar novamente",
          "Usar informações em cache",
          "Reportar problema"
        ],
        actionText: "Reportar Problema"
      },
      permission_denied: {
        title: "Acesso Restrito",
        message: "Você não tem permissão para acessar esta informação. Entre em contato com seu supervisor para solicitar acesso adicional.",
        suggestions: [
          "Solicitar permissões adicionais",
          "Ver informações públicas",
          "Contatar supervisor"
        ],
        actionText: "Solicitar Acesso"
      },
      rate_limit: {
        title: "Muitas Solicitações",
        message: "Você fez muitas perguntas em pouco tempo. Aguarde alguns momentos antes de continuar.",
        suggestions: [
          "Aguardar alguns minutos",
          "Fazer perguntas mais específicas",
          "Usar funcionalidades básicas"
        ],
        actionText: "Aguardar"
      },
      service_unavailable: {
        title: "Serviço Temporariamente Indisponível",
        message: "O serviço de IA está temporariamente fora do ar. Informações básicas do terminal ainda estão disponíveis.",
        suggestions: [
          "Tentar mais tarde",
          "Ver status básico do terminal",
          "Contatar suporte técnico"
        ],
        actionText: "Tentar Mais Tarde"
      },
      generic_error: {
        title: "Erro Técnico",
        message: "Encontrei um problema técnico inesperado. Ainda posso ajudar com informações básicas do terminal.",
        suggestions: [
          "Tentar reformular a pergunta",
          "Ver informações disponíveis",
          "Reportar o problema"
        ],
        actionText: "Tentar Novamente"
      }
    },
    en: {
      // Technical Errors  
      insufficient_quota: {
        title: "Usage Limit Reached",
        message: "The AI service has reached its current usage limit. I can still provide basic terminal information and navigation assistance.",
        suggestions: [
          "View current ships status",
          "Check terminal operations",
          "Contact administrator for upgrade",
          "Use basic functionalities"
        ],
        actionText: "Contact Administrator"
      },
      invalid_api_key: {
        title: "Configuration Required",
        message: "The AI service is not properly configured. OpenAI API key configuration is required for full functionality.",
        suggestions: [
          "Contact system administrator",
          "View basic terminal information",
          "Navigate available features"
        ],
        actionText: "Configure Service"
      },
      network_error: {
        title: "Connectivity Issue",
        message: "I detected a connection instability. I'll try again or can help with local terminal information.",
        suggestions: [
          "Try again in a few moments",
          "View local terminal data", 
          "Check ships status"
        ],
        actionText: "Try Again"
      },
      timeout_error: {
        title: "Timeout Exceeded",
        message: "Processing is taking longer than expected. I can provide faster responses about basic terminal data.",
        suggestions: [
          "Rephrase question more simply",
          "View quick information",
          "Check local data"
        ],
        actionText: "Simplify Query"
      },
      database_error: {
        title: "Data Error",
        message: "Temporary issue accessing data. Some information may be limited at the moment.",
        suggestions: [
          "Try again",
          "Use cached information",
          "Report issue"
        ],
        actionText: "Report Issue"
      },
      permission_denied: {
        title: "Access Restricted",
        message: "You don't have permission to access this information. Contact your supervisor to request additional access.",
        suggestions: [
          "Request additional permissions",
          "View public information", 
          "Contact supervisor"
        ],
        actionText: "Request Access"
      },
      rate_limit: {
        title: "Too Many Requests",
        message: "You've made too many questions in a short time. Please wait a few moments before continuing.",
        suggestions: [
          "Wait a few minutes",
          "Ask more specific questions",
          "Use basic functionalities"
        ],
        actionText: "Wait"
      },
      service_unavailable: {
        title: "Service Temporarily Unavailable", 
        message: "The AI service is temporarily down. Basic terminal information is still available.",
        suggestions: [
          "Try later",
          "View basic terminal status",
          "Contact technical support"
        ],
        actionText: "Try Later"
      },
      generic_error: {
        title: "Technical Error",
        message: "I encountered an unexpected technical issue. I can still help with basic terminal information.",
        suggestions: [
          "Try rephrasing the question",
          "View available information",
          "Report the issue"
        ],
        actionText: "Try Again"
      }
    }
  };

  private roleSpecificMessages = {
    pt: {
      visitor: {
        limitation: "Como visitante, você tem acesso limitado. Para mais funcionalidades, solicite credenciais de operador.",
        contact: "Entre em contato com a administração do terminal para mais informações."
      },
      operator: {
        limitation: "Como operador, você pode acessar informações operacionais. Para dados administrativos, contate um administrador.",
        contact: "Consulte o administrador para questões que requerem privilégios elevados."
      },
      admin: {
        limitation: "Como administrador, você tem acesso completo. Este erro pode indicar um problema do sistema.",
        contact: "Verifique os logs do sistema ou entre em contato com o suporte técnico."
      }
    },
    en: {
      visitor: {
        limitation: "As a visitor, you have limited access. For more functionality, request operator credentials.",
        contact: "Contact terminal administration for more information."
      },
      operator: {
        limitation: "As an operator, you can access operational information. For administrative data, contact an administrator.",
        contact: "Consult administrator for issues requiring elevated privileges."
      },
      admin: {
        limitation: "As an administrator, you have full access. This error may indicate a system issue.",
        contact: "Check system logs or contact technical support."
      }
    }
  };

  translateError(
    errorCode: string,
    language: Language,
    context: ErrorContext
  ): ErrorTranslation {
    const lang = language === 'en' ? 'en' : 'pt';
    const translations = this.errorTranslations[lang];
    
    // Get base translation
    let translation = translations[errorCode] || translations.generic_error;
    
    // Clone to avoid mutating original
    translation = {
      title: translation.title,
      message: translation.message,
      suggestions: [...translation.suggestions],
      actionText: translation.actionText
    };

    // Add role-specific context
    const roleMessages = this.roleSpecificMessages[lang][context.userRole];
    if (roleMessages && context.severity !== 'low') {
      translation.message += ` ${roleMessages.limitation}`;
      
      // Add role-specific suggestion
      if (!translation.suggestions.includes(roleMessages.contact)) {
        translation.suggestions.push(roleMessages.contact);
      }
    }

    // Add severity-specific modifications
    if (context.severity === 'critical') {
      const criticalPrefix = lang === 'pt' ? '🚨 CRÍTICO: ' : '🚨 CRITICAL: ';
      translation.title = criticalPrefix + translation.title;
    } else if (context.severity === 'high') {
      const highPrefix = lang === 'pt' ? '⚠️ IMPORTANTE: ' : '⚠️ IMPORTANT: ';
      translation.title = highPrefix + translation.title;
    }

    return translation;
  }

  getContextualSuggestions(
    errorCode: string,
    language: Language,
    userRole: string,
    terminalContext?: any
  ): string[] {
    const lang = language === 'en' ? 'en' : 'pt';
    const baseSuggestions = this.errorTranslations[lang][errorCode]?.suggestions || [];
    const contextualSuggestions = [];

    // Add terminal-specific suggestions based on current state
    if (terminalContext?.hasActiveShips) {
      contextualSuggestions.push(
        lang === 'pt' ? 'Ver navios ativos no terminal' : 'View active ships at terminal'
      );
    }

    if (terminalContext?.hasPendingOperations) {
      contextualSuggestions.push(
        lang === 'pt' ? 'Verificar operações pendentes' : 'Check pending operations'
      );
    }

    // Add role-specific suggestions
    if (userRole === 'admin') {
      contextualSuggestions.push(
        lang === 'pt' ? 'Verificar logs do sistema' : 'Check system logs'
      );
    } else if (userRole === 'operator') {
      contextualSuggestions.push(
        lang === 'pt' ? 'Consultar supervisor' : 'Consult supervisor'
      );
    }

    return [...baseSuggestions, ...contextualSuggestions];
  }

  formatErrorResponse(
    error: any,
    language: Language,
    userRole: string,
    terminalContext?: any
  ): {
    errorCode: string;
    translation: ErrorTranslation;
    confidence: number;
    requiresEscalation: boolean;
    suggestions: string[];
  } {
    // Determine error code from error object
    let errorCode = 'generic_error';
    let errorType: ErrorContext['errorType'] = 'technical';
    let severity: ErrorContext['severity'] = 'medium';

    if (error?.code) {
      errorCode = error.code;
    } else if (error?.message) {
      const message = error.message.toLowerCase();
      if (message.includes('quota') || message.includes('limit')) {
        errorCode = 'insufficient_quota';
        errorType = 'quota';
        severity = 'high';
      } else if (message.includes('api key') || message.includes('unauthorized')) {
        errorCode = 'invalid_api_key';
        errorType = 'configuration';
        severity = 'high';
      } else if (message.includes('network') || message.includes('connection')) {
        errorCode = 'network_error';
        errorType = 'network';
        severity = 'medium';
      } else if (message.includes('timeout')) {
        errorCode = 'timeout_error';
        errorType = 'technical';
        severity = 'medium';
      } else if (message.includes('permission') || message.includes('access denied')) {
        errorCode = 'permission_denied';
        errorType = 'permission';
        severity = 'high';
      }
    }

    const context: ErrorContext = {
      errorCode,
      errorType,
      severity,
      userRole: userRole as any,
      context: terminalContext
    };

    const translation = this.translateError(errorCode, language, context);
    const suggestions = this.getContextualSuggestions(
      errorCode, 
      language, 
      userRole, 
      terminalContext
    );

    // Determine confidence and escalation based on error type and severity
    let confidence = 0.5;
    let requiresEscalation = false;

    switch (errorType) {
      case 'quota':
        confidence = 0.9;
        requiresEscalation = true;
        break;
      case 'configuration':
        confidence = 0.8;
        requiresEscalation = true;
        break;
      case 'permission':
        confidence = 0.7;
        requiresEscalation = true;
        break;
      case 'network':
        confidence = 0.6;
        requiresEscalation = false;
        break;
      default:
        confidence = 0.4;
        requiresEscalation = severity === 'critical' || severity === 'high';
    }

    return {
      errorCode,
      translation,
      confidence,
      requiresEscalation,
      suggestions
    };
  }

  getLocalizedDateTime(date: Date, language: Language): string {
    const options: Intl.DateTimeFormatOptions = {
      year: 'numeric',
      month: 'long', 
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      timeZone: 'Africa/Maputo'
    };

    const locale = language === 'en' ? 'en-US' : 'pt-MZ';
    return date.toLocaleString(locale, options);
  }

  getLocalizedNumbers(value: number, language: Language): string {
    const locale = language === 'en' ? 'en-US' : 'pt-MZ';
    return value.toLocaleString(locale);
  }
}

export const multilingualErrorHandler = new MultilingualErrorHandler();