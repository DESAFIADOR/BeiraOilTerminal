import { reportService } from './reportService';

class ReportScheduler {
  private intervalId: NodeJS.Timeout | null = null;
  private readonly THIRTY_DAYS = 30 * 24 * 60 * 60 * 1000; // 30 dias em millisegundos

  start(): void {
    console.log('Iniciando agendador de relatórios mensais...');
    
    // Gerar relatório imediatamente na inicialização se for dia 1 do mês
    this.checkAndGenerateReport();
    
    // Agendar para verificar diariamente
    this.intervalId = setInterval(() => {
      this.checkAndGenerateReport();
    }, 24 * 60 * 60 * 1000); // Verificar a cada 24 horas
  }

  stop(): void {
    if (this.intervalId) {
      clearInterval(this.intervalId);
      this.intervalId = null;
      console.log('Agendador de relatórios parado');
    }
  }

  private async checkAndGenerateReport(): Promise<void> {
    const now = new Date();
    const isFirstDayOfMonth = now.getDate() === 1;
    
    if (isFirstDayOfMonth) {
      // Gerar relatório do mês anterior
      const lastMonth = now.getMonth() === 0 ? 12 : now.getMonth();
      const year = now.getMonth() === 0 ? now.getFullYear() - 1 : now.getFullYear();
      
      try {
        console.log(`Gerando relatório automático para ${lastMonth}/${year}`);
        await reportService.scheduleMonthlyReport();
        console.log('Relatório mensal gerado e enviado com sucesso');
      } catch (error) {
        console.error('Erro ao gerar relatório automático:', error);
      }
    }
  }

  // Método para gerar relatório manualmente (para testes ou demanda administrativa)
  async generateReportNow(month?: number, year?: number): Promise<void> {
    try {
      await reportService.generateMonthlyReport(month, year);
      console.log('Relatório gerado manualmente com sucesso');
    } catch (error) {
      console.error('Erro ao gerar relatório manual:', error);
      throw error;
    }
  }
}

export const reportScheduler = new ReportScheduler();