import puppeteer from 'puppeteer';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import path from 'path';
import fs from 'fs';

class SystemCapabilitiesPDF {
  private readonly outputDir = path.join(process.cwd(), 'reports');

  constructor() {
    // Ensure reports directory exists
    if (!fs.existsSync(this.outputDir)) {
      fs.mkdirSync(this.outputDir, { recursive: true });
    }
  }

  async generateSystemCapabilitiesPDF(): Promise<string> {
    const browser = await puppeteer.launch({
      headless: true,
      args: [
        '--no-sandbox',
        '--disable-setuid-sandbox',
        '--disable-dev-shm-usage',
        '--disable-gpu',
        '--disable-web-security',
        '--disable-features=VizDisplayCompositor'
      ]
    });

    try {
      const page = await browser.newPage();
      
      const htmlContent = this.getSystemCapabilitiesHTML();
      await page.setContent(htmlContent, { waitUntil: 'networkidle0' });
      
      const timestamp = format(new Date(), 'yyyy-MM-dd_HHmm', { locale: ptBR });
      const filename = `Sistema_Funcionalidades_${timestamp}.pdf`;
      const filepath = path.join(this.outputDir, filename);
      
      await page.pdf({
        path: filepath,
        format: 'A4',
        printBackground: true,
        margin: {
          top: '20mm',
          bottom: '20mm',
          left: '15mm',
          right: '15mm'
        }
      });

      return filepath;
    } finally {
      await browser.close();
    }
  }

  private getSystemCapabilitiesHTML(): string {
    const currentDate = format(new Date(), "dd 'de' MMMM 'de' yyyy", { locale: ptBR });
    
    return `
    <!DOCTYPE html>
    <html lang="pt-BR">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Sistema de Gestão Portuária - Funcionalidades</title>
        <style>
            * {
                margin: 0;
                padding: 0;
                box-sizing: border-box;
            }
            
            body {
                font-family: 'Arial', sans-serif;
                line-height: 1.6;
                color: #333;
                background: #fff;
            }
            
            .header {
                text-align: center;
                margin-bottom: 40px;
                padding: 30px 0;
                border-bottom: 3px solid #1e40af;
            }
            
            .header h1 {
                color: #1e40af;
                font-size: 28px;
                margin-bottom: 10px;
                font-weight: bold;
            }
            
            .header .subtitle {
                color: #64748b;
                font-size: 16px;
                margin-bottom: 5px;
            }
            
            .header .date {
                color: #64748b;
                font-size: 14px;
            }
            
            .section {
                margin-bottom: 35px;
                page-break-inside: avoid;
            }
            
            .section h2 {
                color: #1e40af;
                font-size: 20px;
                margin-bottom: 15px;
                padding-bottom: 8px;
                border-bottom: 2px solid #e2e8f0;
            }
            
            .section h3 {
                color: #374151;
                font-size: 16px;
                margin-bottom: 10px;
                margin-top: 20px;
            }
            
            .feature-grid {
                display: grid;
                grid-template-columns: repeat(2, 1fr);
                gap: 20px;
                margin-bottom: 20px;
            }
            
            .feature-card {
                background: #f8fafc;
                padding: 20px;
                border-radius: 8px;
                border-left: 4px solid #1e40af;
            }
            
            .feature-card h4 {
                color: #1e40af;
                font-size: 14px;
                font-weight: bold;
                margin-bottom: 8px;
            }
            
            .feature-card p {
                font-size: 13px;
                color: #64748b;
                line-height: 1.5;
            }
            
            .highlight-box {
                background: linear-gradient(135deg, #1e40af 0%, #3b82f6 100%);
                color: white;
                padding: 20px;
                border-radius: 10px;
                margin: 20px 0;
                text-align: center;
            }
            
            .highlight-box h3 {
                color: white;
                margin-bottom: 10px;
            }
            
            .tech-grid {
                display: grid;
                grid-template-columns: repeat(3, 1fr);
                gap: 15px;
                margin: 20px 0;
            }
            
            .tech-item {
                background: #f1f5f9;
                padding: 15px;
                border-radius: 6px;
                text-align: center;
                border: 1px solid #e2e8f0;
            }
            
            .tech-item strong {
                color: #1e40af;
                font-size: 13px;
                display: block;
                margin-bottom: 5px;
            }
            
            .tech-item span {
                font-size: 12px;
                color: #64748b;
            }
            
            ul {
                list-style: none;
                padding-left: 0;
            }
            
            li {
                padding: 8px 0;
                border-bottom: 1px solid #f1f5f9;
                font-size: 14px;
            }
            
            li:before {
                content: "✓";
                color: #10b981;
                font-weight: bold;
                margin-right: 10px;
            }
            
            .stats-grid {
                display: grid;
                grid-template-columns: repeat(4, 1fr);
                gap: 15px;
                margin: 20px 0;
            }
            
            .stat-card {
                background: white;
                border: 2px solid #e2e8f0;
                border-radius: 8px;
                padding: 15px;
                text-align: center;
            }
            
            .stat-number {
                font-size: 24px;
                font-weight: bold;
                color: #1e40af;
                display: block;
            }
            
            .stat-label {
                font-size: 12px;
                color: #64748b;
                margin-top: 5px;
            }
            
            .priority-badge {
                display: inline-block;
                background: #dc2626;
                color: white;
                padding: 4px 8px;
                border-radius: 4px;
                font-size: 11px;
                font-weight: bold;
                margin: 5px 0;
            }
            
            .footer {
                margin-top: 50px;
                text-align: center;
                padding: 20px 0;
                border-top: 2px solid #e2e8f0;
                font-size: 12px;
                color: #64748b;
            }
            
            @media print {
                .section {
                    page-break-inside: avoid;
                }
            }
        </style>
    </head>
    <body>
        <div class="header">
            <h1>Sistema de Gestão Portuária</h1>
            <div class="subtitle">Terminal de Petróleo de Beira - CFM-EP</div>
            <div class="date">Relatório de Funcionalidades - ${currentDate}</div>
        </div>

        <div class="section">
            <h2>🎯 Visão Geral do Sistema</h2>
            <div class="highlight-box">
                <h3>Plataforma Completa de Gestão Marítima</h3>
                <p>Sistema web avançado para controle de operações portuárias, com funcionalidades especializadas para gerenciamento de navios, carga e operações de descarga no Terminal de Petróleo de Beira.</p>
            </div>
            
            <div class="stats-grid">
                <div class="stat-card">
                    <span class="stat-number">100%</span>
                    <div class="stat-label">Funcionalidade Web</div>
                </div>
                <div class="stat-card">
                    <span class="stat-number">2</span>
                    <div class="stat-label">Idiomas Suportados</div>
                </div>
                <div class="stat-card">
                    <span class="stat-number">24/7</span>
                    <div class="stat-label">Monitoramento</div>
                </div>
                <div class="stat-card">
                    <span class="stat-number">Real-time</span>
                    <div class="stat-label">Atualizações</div>
                </div>
            </div>
        </div>

        <div class="section">
            <h2>🚢 Gestão de Navios</h2>
            <div class="feature-grid">
                <div class="feature-card">
                    <h4>Registro Completo</h4>
                    <p>Cadastro detalhado de navios com informações técnicas, agentes, datas de chegada e especificações de carga.</p>
                </div>
                <div class="feature-card">
                    <h4>Controle de Status</h4>
                    <p>Rastreamento em tempo real do progresso: Esperado → Na Barra → Próximo ao Cais → No Cais → Partido.</p>
                </div>
                <div class="feature-card">
                    <h4>Sistema de Prioridades</h4>
                    <p>Priorização automática IMOPETRO conforme Decreto 89/2019 com identificação visual especial.</p>
                    <div class="priority-badge">🚨 PRIORIDADE - Decreto 89/2019</div>
                </div>
                <div class="feature-card">
                    <h4>Regra de Atracação 2:1</h4>
                    <p>Algoritmo inteligente que processa 2 navios de trânsito seguidos de 1 navio combinado, respeitando ordem cronológica.</p>
                </div>
            </div>
        </div>

        <div class="section">
            <h2>⚓ Operações de Atracação</h2>
            <div class="feature-grid">
                <div class="feature-card">
                    <h4>Registro de Atracação</h4>
                    <p>Sistema completo para registrar horários de primeira e última espía, com cálculo automático de tempo de atracação.</p>
                </div>
                <div class="feature-card">
                    <h4>Controle de Manutenção</h4>
                    <p>Gestão de períodos de manutenção do cais com interface administrativa e bloqueio automático de operações.</p>
                </div>
                <div class="feature-card">
                    <h4>Confirmação de Descarga</h4>
                    <p>Sistema bi-modal: confirmação manual instantânea ou envio automático por email com validação por token seguro.</p>
                </div>
                <div class="feature-card">
                    <h4>Monitoramento Ambiental</h4>
                    <p>Integração com APIs meteorológicas e de marés para decisões operacionais baseadas em condições reais.</p>
                </div>
            </div>
        </div>

        <div class="section">
            <h2>📊 Monitoramento e Relatórios</h2>
            <h3>Relatórios Automatizados</h3>
            <ul>
                <li>Geração automática de relatórios mensais em PDF</li>
                <li>Gráficos operacionais com Chart.js e análises estatísticas</li>
                <li>Envio automático por email a cada 30 dias</li>
                <li>Limpeza automática de dados históricos após relatório</li>
                <li>Acesso histórico com log de segurança para administradores</li>
            </ul>
            
            <h3>Dados em Tempo Real</h3>
            <ul>
                <li>Condições meteorológicas atualizadas automaticamente</li>
                <li>Previsões de marés com análise harmônica M2, S2, N2</li>
                <li>Status de descarga com cálculos de volume em tempo real</li>
                <li>Alertas meteorológicos e de segurança</li>
            </ul>
        </div>

        <div class="section">
            <h2>🔧 Arquitetura Técnica</h2>
            <div class="tech-grid">
                <div class="tech-item">
                    <strong>Frontend</strong>
                    <span>React 18 + TypeScript</span>
                </div>
                <div class="tech-item">
                    <strong>Backend</strong>
                    <span>Express.js + Node.js</span>
                </div>
                <div class="tech-item">
                    <strong>Database</strong>
                    <span>PostgreSQL + Drizzle ORM</span>
                </div>
                <div class="tech-item">
                    <strong>UI Framework</strong>
                    <span>Tailwind CSS + shadcn/ui</span>
                </div>
                <div class="tech-item">
                    <strong>Autenticação</strong>
                    <span>Passport.js + Sessions</span>
                </div>
                <div class="tech-item">
                    <strong>Email</strong>
                    <span>SendGrid Integration</span>
                </div>
                <div class="tech-item">
                    <strong>PDF Generation</strong>
                    <span>Puppeteer + Chart.js</span>
                </div>
                <div class="tech-item">
                    <strong>Weather APIs</strong>
                    <span>OpenWeather + Open-Meteo</span>
                </div>
                <div class="tech-item">
                    <strong>Deployment</strong>
                    <span>Replit Autoscale</span>
                </div>
            </div>
        </div>

        <div class="section">
            <h2>🌐 Recursos Multilíngues</h2>
            <div class="feature-grid">
                <div class="feature-card">
                    <h4>Suporte Bilíngue</h4>
                    <p>Interface completa em Português e Inglês com mais de 80 chaves de tradução implementadas.</p>
                </div>
                <div class="feature-card">
                    <h4>Troca Instantânea</h4>
                    <p>Seletor de idioma no header com bandeiras 🇵🇹/🇬🇧 para alteração em tempo real de toda a interface.</p>
                </div>
                <div class="feature-card">
                    <h4>Persistência Local</h4>
                    <p>Preferência de idioma salva automaticamente no navegador usando localStorage.</p>
                </div>
                <div class="feature-card">
                    <h4>Cobertura Completa</h4>
                    <p>Tradução de formulários, botões, mensagens, navegação e todas as seções da plataforma.</p>
                </div>
            </div>
        </div>

        <div class="section">
            <h2>🔐 Segurança e Controle de Acesso</h2>
            <ul>
                <li>Sistema de autenticação baseado em sessões com PostgreSQL</li>
                <li>Controle granular de permissões por usuário</li>
                <li>Workflow de aprovação para operadores com senha administrativa</li>
                <li>Validação por token em confirmações por email</li>
                <li>Logs de acesso para relatórios administrativos</li>
                <li>Proteção contra acesso não autorizado a funcionalidades críticas</li>
            </ul>
        </div>

        <div class="section">
            <h2>📱 Interface e Experiência</h2>
            <div class="feature-grid">
                <div class="feature-card">
                    <h4>Design Responsivo</h4>
                    <p>Interface otimizada para desktop, tablet e mobile com suporte a todos os navegadores modernos.</p>
                </div>
                <div class="feature-card">
                    <h4>Tema Marítimo</h4>
                    <p>Visual especializado para operações portuárias com cores e ícones apropriados ao ambiente marítimo.</p>
                </div>
                <div class="feature-card">
                    <h4>Navegação Intuitiva</h4>
                    <p>Interface limpa e organizada com acesso rápido às funções mais utilizadas pelos operadores.</p>
                </div>
                <div class="feature-card">
                    <h4>Feedback Visual</h4>
                    <p>Indicadores visuais claros para status, progresso e alertas com atualização em tempo real.</p>
                </div>
            </div>
        </div>

        <div class="section">
            <h2>🎯 Benefícios Operacionais</h2>
            <ul>
                <li>Redução significativa do tempo de processamento de navios</li>
                <li>Maior precisão no planejamento de operações portuárias</li>
                <li>Compliance automático com regulamentações IMOPETRO</li>
                <li>Transparência total nas operações para agentes e operadores</li>
                <li>Histórico completo de operações para análises e auditorias</li>
                <li>Integração com dados meteorológicos para decisões seguras</li>
                <li>Automatização de processos manuais repetitivos</li>
                <li>Comunicação eficiente entre todas as partes envolvidas</li>
            </ul>
        </div>

        <div class="section">
            <h2>🔮 Futuras Expansões</h2>
            <div class="feature-grid">
                <div class="feature-card">
                    <h4>Integração API</h4>
                    <p>Conexão com sistemas portuários externos e bases de dados governamentais.</p>
                </div>
                <div class="feature-card">
                    <h4>Analytics Avançados</h4>
                    <p>Dashboard executivo com KPIs e métricas de performance operacional.</p>
                </div>
                <div class="feature-card">
                    <h4>Mobile App</h4>
                    <p>Aplicativo móvel nativo para operadores em campo e agentes marítimos.</p>
                </div>
                <div class="feature-card">
                    <h4>IoT Integration</h4>
                    <p>Conexão com sensores portuários para monitoramento automático de condições.</p>
                </div>
            </div>
        </div>

        <div class="footer">
            <strong>Sistema de Gestão Portuária - Terminal de Petróleo de Beira</strong><br>
            CFM-EP (Portos e Caminhos de Ferro de Moçambique, E.P.)<br>
            Desenvolvido com tecnologias modernas para máxima eficiência operacional<br>
            <em>Documento gerado automaticamente em ${currentDate}</em>
        </div>
    </body>
    </html>
    `;
  }
}

export const systemCapabilitiesPDF = new SystemCapabilitiesPDF();