import OpenAI from 'openai';
import { nanoid } from 'nanoid';
import { db } from './db';

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

export type UserRole = 'visitor' | 'operator' | 'admin';

export interface ChatMessage {
  id: string;
  sessionId: string;
  content: string;
  role: 'user' | 'assistant';
  timestamp: Date;
  confidence?: number;
  requiresEscalation?: boolean;
}

export interface AssistantCapabilities {
  canViewShips: boolean;
  canModifyShips: boolean;
  canViewReports: boolean;
  canAccessSensitiveData: boolean;
}

export class VirtualAssistantService {
  // Get user capabilities based on role
  getUserCapabilities(role: UserRole): AssistantCapabilities {
    switch (role) {
      case 'admin':
        return {
          canViewShips: true,
          canModifyShips: true,
          canViewReports: true,
          canAccessSensitiveData: true,
        };
      case 'operator':
        return {
          canViewShips: true,
          canModifyShips: true,
          canViewReports: true,
          canAccessSensitiveData: false,
        };
      case 'visitor':
      default:
        return {
          canViewShips: true,
          canModifyShips: false,
          canViewReports: false,
          canAccessSensitiveData: false,
        };
    }
  }

  // Get system context based on user role and language
  async getSystemContext(role: UserRole, language: string = 'pt'): Promise<string> {
    const capabilities = this.getUserCapabilities(role);
    const basePrompt = this.getBaseSystemPrompt(language);
    
    try {
      // Get current ships data
      const ships = await db.execute('SELECT * FROM ships ORDER BY arrival_date ASC');
      const shipsContext = this.formatShipsContext(ships.rows || [], capabilities.canAccessSensitiveData, language);
      
      const reportsContext = capabilities.canViewReports ? this.getReportsContext(language) : '';
      
      return `${basePrompt}\n\n${shipsContext}${reportsContext}`;
    } catch (error) {
      console.error('Error getting system context:', error);
      return basePrompt;
    }
  }

  private getBaseSystemPrompt(language: string): string {
    if (language === 'en') {
      return `You are a virtual assistant for the Beira Oil Terminal ship management system. You help users with information about ships, berth operations, and terminal status.

Key capabilities:
- Provide information about ships in queue (expected, at bar, next to berth, at berth, departed)
- Explain berth operations and discharge processes
- Answer questions about terminal weather and tide conditions
- Help with navigation through the system interface

Always respond in a professional, helpful manner. If you don't have specific information, guide users to the appropriate system section or suggest contacting an operator.`;
    }
    
    return `Você é um assistente virtual do sistema de gestão de navios do Terminal Petrolífero da Beira. Você ajuda os usuários com informações sobre navios, operações de atracação e status do terminal.

Principais capacidades:
- Fornecer informações sobre navios na fila (previstos, na barra, próximo ao cais, no cais, partidos)
- Explicar operações de atracação e processos de descarga
- Responder perguntas sobre condições meteorológicas e marés do terminal
- Ajudar na navegação pela interface do sistema

Sempre responda de forma profissional e útil. Se não tiver informações específicas, direcione os usuários para a seção apropriada do sistema ou sugira entrar em contato com um operador.`;
  }

  private formatShipsContext(ships: any[], canViewSensitive: boolean, language: string): string {
    if (!ships || ships.length === 0) {
      return language === 'en' ? 
        "\n\nCurrent Status: No ships in the system." :
        "\n\nStatus Atual: Nenhum navio no sistema.";
    }

    const context = language === 'en' ? "\n\nCurrent Ships:" : "\n\nNavios Atuais:";
    
    return context + ships.map(ship => {
      const basicInfo = `\n- ${ship.name} (${ship.status})`;
      if (canViewSensitive) {
        return basicInfo + ` - Agent: ${ship.ship_agent || 'N/A'}`;
      }
      return basicInfo;
    }).join('');
  }

  private getReportsContext(language: string): string {
    return language === 'en' ? 
      "\n\nYou can help with operational reports, statistics, and ship movement history." :
      "\n\nVocê pode ajudar com relatórios operacionais, estatísticas e histórico de movimentação de navios.";
  }

  // Create new chat session
  async createChatSession(userId: string | null, userRole: UserRole, language: string = 'pt'): Promise<string> {
    const sessionId = nanoid();
    console.log('Creating session with ID:', sessionId);
    
    try {
      await db.execute(`
        INSERT INTO chat_sessions (id, user_id, user_role, language, status)
        VALUES ('${sessionId}', ${userId ? `'${userId}'` : 'NULL'}, '${userRole}', '${language}', 'active')
      `);
      
      console.log('Session inserted successfully');
      return sessionId;
    } catch (error) {
      console.error('Error creating chat session:', error);
      throw new Error(`Failed to create chat session: ${error.message}`);
    }
  }

  // Process chat message
  async processChatMessage(
    sessionId: string, 
    userMessage: string, 
    userRole: UserRole, 
    language: string = 'pt'
  ): Promise<{ response: string; confidence: number; requiresEscalation: boolean }> {
    
    try {
      console.log('Processing message:', { sessionId, userMessage, userRole });

      // Save user message
      const userMessageId = nanoid();
      await db.execute(`
        INSERT INTO chat_messages (id, session_id, content, role)
        VALUES ('${userMessageId}', '${sessionId}', '${userMessage.replace(/'/g, "''")}', 'user')
      `);

      // Get system context
      const systemContext = await this.getSystemContext(userRole, language);

      // Get conversation history
      const previousMessages = await db.execute(`
        SELECT * FROM chat_messages 
        WHERE session_id = '${sessionId}' 
        ORDER BY timestamp DESC 
        LIMIT 10
      `);

      // Prepare messages for OpenAI
      const messages = [
        {
          role: 'system' as const,
          content: systemContext
        }
      ];

      // Add conversation history (reverse to get chronological order)
      if (previousMessages.rows) {
        previousMessages.rows.reverse().slice(0, -1).forEach((msg: any) => {
          messages.push({
            role: msg.role === 'user' ? 'user' : 'assistant',
            content: msg.content
          });
        });
      }

      // Add current user message
      messages.push({ role: 'user', content: userMessage });

      // Get response from OpenAI
      if (!process.env.OPENAI_API_KEY) {
        console.error('OpenAI API key not configured');
        throw new Error("OpenAI API key not configured");
      }
      
      console.log('Calling OpenAI with messages:', messages.length);
      console.log('First system message:', messages[0]?.content?.substring(0, 200));
      
      const completion = await openai.chat.completions.create({
        model: "gpt-4o", // newest OpenAI model released May 13, 2024
        messages,
        max_tokens: 500,
        temperature: 0.7,
      });

      const response = completion.choices[0]?.message?.content || "Desculpe, não consegui processar sua pergunta.";
      const confidence = this.calculateConfidence(response, userMessage);
      const requiresEscalation = confidence < 0.7 || this.shouldEscalate(userMessage, response);

      console.log('OpenAI response received:', response.substring(0, 100));

      // Save assistant response
      const assistantMessageId = nanoid();
      await db.execute(`
        INSERT INTO chat_messages (id, session_id, content, role, confidence, requires_escalation)
        VALUES ('${assistantMessageId}', '${sessionId}', '${response.replace(/'/g, "''")}', 'assistant', ${confidence}, ${requiresEscalation})
      `);

      return {
        response,
        confidence,
        requiresEscalation
      };

    } catch (error) {
      console.error('Error processing chat message:', error);
      
      // Return a fallback response
      return {
        response: language === 'en' ? 
          "I apologize, but I'm experiencing technical difficulties. Please try again or contact support." :
          "Peço desculpas, mas estou enfrentando dificuldades técnicas. Tente novamente ou entre em contato com o suporte.",
        confidence: 0.1,
        requiresEscalation: true
      };
    }
  }

  // Calculate response confidence based on various factors
  private calculateConfidence(response: string, userMessage: string): number {
    let confidence = 0.8; // Base confidence
    
    // Lower confidence for very short responses
    if (response.length < 50) confidence -= 0.2;
    
    // Lower confidence if response contains uncertainty phrases
    const uncertaintyPhrases = [
      'não sei', 'não tenho certeza', 'talvez', 'possivelmente',
      "don't know", "not sure", "maybe", "possibly"
    ];
    
    if (uncertaintyPhrases.some(phrase => response.toLowerCase().includes(phrase))) {
      confidence -= 0.3;
    }
    
    // Higher confidence for specific ship/terminal related queries
    const terminalKeywords = [
      'navio', 'cais', 'atracação', 'descarga', 'beira',
      'ship', 'berth', 'docking', 'discharge', 'terminal'
    ];
    
    if (terminalKeywords.some(keyword => 
      userMessage.toLowerCase().includes(keyword) || 
      response.toLowerCase().includes(keyword)
    )) {
      confidence += 0.1;
    }
    
    return Math.max(0.1, Math.min(1.0, confidence));
  }

  // Determine if response should be escalated to human
  private shouldEscalate(userMessage: string, response: string): boolean {
    const escalationTriggers = [
      'falar com humano', 'operador', 'supervisor', 'gerente',
      'talk to human', 'operator', 'supervisor', 'manager',
      'reclamação', 'problema', 'erro', 'complaint', 'problem', 'error'
    ];
    
    return escalationTriggers.some(trigger => 
      userMessage.toLowerCase().includes(trigger) ||
      response.toLowerCase().includes(trigger)
    );
  }

  // Get chat history for a session
  async getChatHistory(sessionId: string): Promise<ChatMessage[]> {
    try {
      const result = await db.execute(`
        SELECT * FROM chat_messages 
        WHERE session_id = '${sessionId}' 
        ORDER BY timestamp ASC
      `);
      
      return result.rows?.map((row: any) => ({
        id: row.id,
        sessionId: row.session_id,
        content: row.content,
        role: row.role,
        timestamp: new Date(row.timestamp),
        confidence: row.confidence,
        requiresEscalation: row.requires_escalation
      })) || [];
    } catch (error) {
      console.error('Error getting chat history:', error);
      return [];
    }
  }

  // End chat session with satisfaction rating
  async endChatSession(sessionId: string, satisfactionRating?: number, escalationReason?: string): Promise<void> {
    try {
      await db.execute(`
        UPDATE chat_sessions 
        SET status = '${escalationReason ? 'escalated' : 'completed'}', 
            end_time = NOW(), 
            satisfaction_rating = ${satisfactionRating || 'NULL'}, 
            escalation_reason = ${escalationReason ? `'${escalationReason.replace(/'/g, "''")}'` : 'NULL'}
        WHERE id = '${sessionId}'
      `);
    } catch (error) {
      console.error('Error ending chat session:', error);
    }
  }

  // Text-to-speech conversion
  async textToSpeech(text: string, language: string = 'pt'): Promise<string | null> {
    try {
      // For now, return null as we're not implementing TTS
      // This can be expanded later with services like ElevenLabs or Google TTS
      return null;
    } catch (error) {
      console.error('Text-to-speech error:', error);
      return null;
    }
  }

  // Speech-to-text conversion using OpenAI Whisper
  async speechToText(audioBuffer: Buffer, language: string = 'pt'): Promise<string | null> {
    try {
      if (!process.env.OPENAI_API_KEY) {
        console.error('OpenAI API key not configured for speech-to-text');
        return null;
      }

      // Create a temporary file for the audio
      const tempFilePath = `/tmp/audio_${Date.now()}.wav`;
      require('fs').writeFileSync(tempFilePath, audioBuffer);

      const transcription = await openai.audio.transcriptions.create({
        file: require('fs').createReadStream(tempFilePath),
        model: 'whisper-1',
        language: language === 'en' ? 'en' : 'pt',
      });

      // Clean up temporary file
      require('fs').unlinkSync(tempFilePath);

      return transcription.text;
    } catch (error) {
      console.error('Speech-to-text error:', error);
      return null;
    }
  }
}

export const virtualAssistantService = new VirtualAssistantService();