import type { Express } from "express";
import { createServer, type Server } from "http";
import express from "express";
import path from "path";
import { storage } from "./storage";
import { setupAuth, isAuthenticated, isOperator, isAdmin } from "./auth";
import { geminiAIService } from "./geminiAIService";
import { agentService } from "./agentService";
import { insertShipSchema, insertDischargeProgressSchema, updateShipStatusSchema, insertUserPermissionSchema, permissionSchema, insertCargoAgentSchema, registerAgentSchema, approveAgentSchema, insertPredictedArrivalSchema, updateArrivalConfirmationSchema } from "@shared/schema";
import { Permission, UserRole, hasPermission } from "@shared/permissions";
import { getUserPermissions, USER_LEVELS, canAccessLevel } from "@shared/userLevels";
import { z } from "zod";
import bcrypt from "bcrypt";
import { registerCommunicationRoutes } from "./communicationRoutes";
import { communicationService } from "./communicationService";
import { registerAgentRoutes } from "./agentRoutes";

const createShipWithParcelsSchema = z.object({
  ship: z.object({
    name: z.string(),
    countermark: z.string(),
    arrivalDateTime: z.string().transform((str) => new Date(str)),
    draft: z.string(),
    shipAgent: z.string(),
    cargoAgent: z.string(),
    shipowner: z.string(),
    cargoType: z.string(),
    cargoDestination: z.string(),
    status: z.string().default("expected"),
    hasDischargeInstructions: z.boolean().optional().default(false),
    berthingConfirmed: z.boolean().optional().default(false),
    confirmationEmailSentAt: z.date().optional(),
    confirmationReceivedAt: z.date().optional(),
    berthingStartedAt: z.date().optional(),
    departedAt: z.date().optional(),
  }),
  parcels: z.array(z.object({
    parcelNumber: z.string(),
    volume: z.string(),
    receiver: z.string(),
  })),
});

const updateOperationTypeSchema = z.object({
  operationType: z.string().transform((val) => {
    // Normalize values to database format
    const normalized = val.toLowerCase()
      .replace('â', 'a')
      .replace('ã', 'a')
      .replace('ç', 'c');
    
    // Map Portuguese values to database values
    switch (normalized) {
      case 'nacional':
        return 'nacional';
      case 'transito':
        return 'transito';
      case 'combinado':
        return 'combinado';
      case 'lpg':
        return 'lpg';
      default:
        return normalized;
    }
  }),
});

// Middleware hierárquico para verificar permissões específicas
function requirePermission(permission: Permission) {
  return async (req: any, res: any, next: any) => {
    if (!req.user || !req.user.id) {
      return res.status(401).json({ message: "Unauthorized" });
    }

    try {
      const user = await storage.getUser(req.user.id);
      if (!user) {
        return res.status(401).json({ message: "User not found" });
      }

      const userPermissions = await storage.getUserPermissions(user.id);
      
      // Verificar hierarquia: Admin tem todas as permissões
      if (user.role === UserRole.ADMIN) {
        return next();
      }
      
      // Verificar se tem a permissão específica
      const permissionsList = userPermissions.map(p => p.permission);
      const hasSpecificPermission = hasPermission(user.role as UserRole, permissionsList, permission);
      if (!hasSpecificPermission) {
        return res.status(403).json({ 
          message: `Acesso negado. Necessária permissão: ${permission}` 
        });
      }
      
      next();
    } catch (error) {
      console.error("Error checking permission:", error);
      res.status(500).json({ message: "Error checking permissions" });
    }
  };
}

// Middleware para garantir apenas administradores
function requireAdmin(req: any, res: any, next: any) {
  if (!req.user || !req.user.id) {
    return res.status(401).json({ message: "Unauthorized" });
  }

  if (req.user.role !== UserRole.ADMIN) {
    return res.status(403).json({ message: "Acesso restrito a administradores" });
  }

  next();
}

// Middleware para garantir operadores ou administradores
function requireOperatorOrAdmin(req: any, res: any, next: any) {
  if (!req.user || !req.user.id) {
    return res.status(401).json({ message: "Unauthorized" });
  }

  const userRole = req.user.role;
  console.log(`[AUTH CHECK] User role: ${userRole}, checking permissions for ship operations`);
  
  // Aceitar gestores, CTOs, desenvolvedor, agente_navio e também os roles legados
  const allowedRoles = ['gestores', 'ctos', 'desenvolvedor', 'agente_navio', 'operator', 'admin'];
  
  if (!allowedRoles.includes(userRole)) {
    console.log(`[AUTH FAILED] Role ${userRole} not in allowed roles:`, allowedRoles);
    return res.status(403).json({ message: "Acesso restrito a operadores e administradores" });
  }

  console.log(`[AUTH SUCCESS] Role ${userRole} has access to ship operations`);
  next();
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware
  setupAuth(app);

  // Get current user profile
  app.get('/api/user', async (req: any, res) => {
    try {
      console.log('GET /api/user - Auth check:', {
        isAuthenticated: req.isAuthenticated ? req.isAuthenticated() : false,
        hasUser: !!req.user,
        sessionID: req.sessionID
      });
      
      if (!req.isAuthenticated || !req.isAuthenticated()) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      
      if (!req.user) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      
      const user = await storage.getUser(req.user.id);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Remove password from response
      const { password: _, ...userResponse } = user;
      
      console.log('User fetched successfully:', user.username);
      res.json(userResponse);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Logout endpoint for local authentication
  app.post('/api/logout', (req: any, res) => {
    console.log('Logout request received');
    
    // Use passport logout function
    req.logout((err: any) => {
      if (err) {
        console.error('Passport logout error:', err);
        return res.status(500).json({ message: 'Logout failed', error: err.message });
      }
      
      // Destroy session
      req.session.destroy((err: any) => {
        if (err) {
          console.error('Session destroy error:', err);
          return res.status(500).json({ message: 'Session destroy failed', error: err.message });
        }
        
        // Clear session cookie
        res.clearCookie('connect.sid', {
          path: '/',
          httpOnly: true,
          secure: false
        });
        
        console.log('User successfully logged out');
        res.json({ success: true, message: 'Logout successful' });
      });
    });
  });

  // User management routes
  app.get('/api/users/pending', isAuthenticated, isOperator, async (req, res) => {
    try {
      const pendingUsers = await storage.getPendingUsers();
      res.json(pendingUsers);
    } catch (error) {
      console.error("Error fetching pending users:", error);
      res.status(500).json({ message: "Failed to fetch pending users" });
    }
  });

  app.get('/api/users/pending', isAuthenticated, isOperator, async (req, res) => {
    try {
      const pendingUsers = await storage.getPendingUsers();
      res.json(pendingUsers);
    } catch (error) {
      console.error("Error fetching pending users:", error);
      res.status(500).json({ message: "Failed to fetch pending users" });
    }
  });

  app.post('/api/users/approve', isAuthenticated, isOperator, async (req: any, res) => {
    try {
      const { userId, approved, role, adminPassword } = req.body;
      const currentUser = req.user;
      
      console.log('Approval request:', { userId, approved, role, hasPassword: !!adminPassword });
      
      if (!currentUser) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      
      // Validate required fields
      if (!userId || typeof approved !== 'boolean' || !adminPassword) {
        return res.status(400).json({ message: "Missing required fields" });
      }
      
      // Verificar senha de administrador
      const ADMIN_PASSWORD = "BeiraTerm2025!"; // Senha administrativa resetada
      if (adminPassword !== ADMIN_PASSWORD) {
        console.log('Invalid admin password provided');
        return res.status(403).json({ message: "Senha de administrador incorreta" });
      }
      
      const userIdNum = parseInt(userId);
      if (isNaN(userIdNum)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }
      
      if (approved) {
        const finalRole = role || 'user';
        console.log(`Approving user ${userIdNum} with role ${finalRole}`);
        const user = await storage.approveUser(userIdNum, currentUser.id, finalRole);
        res.json(user);
      } else {
        console.log(`Rejecting user ${userIdNum}`);
        const success = await storage.rejectUser(userIdNum);
        res.json({ success });
      }
    } catch (error) {
      console.error("Error approving/rejecting user:", error);
      const errorMessage = error instanceof Error ? error instanceof Error ? error.message : String(error) : 'Unknown error';
      res.status(500).json({ message: "Failed to process user approval", error: errorMessage });
    }
  });

  // Admin password verification route
  app.post('/api/admin/verify-password', isAuthenticated, async (req: any, res) => {
    try {
      const { password } = req.body;
      const ADMIN_PASSWORD = "BeiraTerm2025!";
      
      if (!password) {
        return res.status(400).json({ message: "Senha é obrigatória" });
      }
      
      if (password !== ADMIN_PASSWORD) {
        return res.status(401).json({ message: "Senha administrativa incorreta" });
      }
      
      res.json({ success: true, message: "Senha verificada com sucesso" });
    } catch (error) {
      console.error("Error verifying admin password:", error);
      res.status(500).json({ message: "Erro interno do servidor" });
    }
  });

  // Ship routes
  app.get('/api/ships', async (req, res) => {
    try {
      // Disable caching completely
      res.set({
        'Cache-Control': 'no-cache, no-store, must-revalidate',
        'Pragma': 'no-cache',
        'Expires': '0',
        'ETag': null,
        'Last-Modified': null
      });
      
      const ships = await storage.getShips();
      console.log(`[Ships API] Returning ${ships.length} ships to frontend`);
      res.json(ships);
    } catch (error) {
      console.error("Error fetching ships:", error);
      res.status(500).json({ message: "Failed to fetch ships" });
    }
  });

  app.get('/api/ships/:id', async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      
      // Validate ID is a valid number
      if (isNaN(id) || id <= 0) {
        console.log(`Invalid ship ID received: ${req.params.id}`);
        return res.status(400).json({ message: "Invalid ship ID" });
      }
      
      const ship = await storage.getShipById(id);
      if (!ship) {
        return res.status(404).json({ message: "Ship not found" });
      }
      res.json(ship);
    } catch (error) {
      console.error("Error fetching ship:", error);
      res.status(500).json({ message: "Failed to fetch ship" });
    }
  });

  app.post('/api/ships', isAuthenticated, requireOperatorOrAdmin, async (req: any, res) => {
    try {
      console.log("=== CREATING NEW SHIP ===");
      console.log("Request body:", req.body);
      console.log("User:", req.user ? { id: req.user.id, role: req.user.role } : "NO USER");
      
      const { ship, parcels } = req.body;
      
      if (!ship) {
        return res.status(400).json({ message: "Dados do navio são obrigatórios" });
      }
      
      // Transform the ship data with proper validation
      const transformedShip = {
        ...ship,
        arrivalDateTime: new Date(ship.arrivalDateTime),
        draft: parseFloat(ship.draft) || 0,
        shipAgentEmail: ship.shipAgentEmail || `${ship.shipAgent?.toLowerCase().replace(/\s+/g, '.')}@terminal.com`,
        cargoAgentEmail: ship.cargoAgentEmail || `${ship.cargoAgent?.toLowerCase().replace(/\s+/g, '.')}@terminal.com`,
        operationType: ship.operationType || 'nacional',
        status: 'expected',
        hasDischargeInstructions: false,
        berthingConfirmed: false
      };
      
      console.log("Transformed ship data:", transformedShip);
      
      // Transform parcels data with proper numeric validation
      const transformedParcels = (parcels || []).map((parcel: any) => ({
        parcelNumber: parcel.parcelNumber || '',
        product: parcel.product || '',
        volumeMT: parcel.volumeMT && parcel.volumeMT !== '' ? parseFloat(parcel.volumeMT) : null,
        volumeM3: parcel.volumeM3 && parcel.volumeM3 !== '' ? parseFloat(parcel.volumeM3) : null,
        density15C: parcel.density15C && parcel.density15C !== '' ? parseFloat(parcel.density15C) : null,
        receiver: parcel.receiver || '',
        owner: parcel.owner || ''
      }));
      
      console.log("Transformed parcels data:", transformedParcels);

      const createdShip = await storage.createShip(transformedShip, transformedParcels);
      console.log("Ship created successfully:", createdShip);
      
      res.status(201).json(createdShip);
    } catch (error) {
      console.error("Error creating ship:", error);
      res.status(500).json({ 
        message: "Falha ao criar navio", 
        error: error instanceof Error ? error.message : "Erro desconhecido"
      });
    }
  });

  // Get ship status
  app.get('/api/ships/:id/status', isAuthenticated, async (req: any, res) => {
    try {
      const id = parseInt(req.params.id);
      const ship = await storage.getShip(id);
      
      if (!ship) {
        return res.status(404).json({ message: 'Ship not found' });
      }
      
      res.json({ 
        id: ship.id,
        name: ship.name,
        status: ship.status,
        operationType: ship.operationType,
        hasDischargeInstructions: ship.hasDischargeInstructions,
        berthingConfirmed: ship.berthingConfirmed
      });
    } catch (error) {
      console.error(`[GET SHIP STATUS] Error fetching ship ${req.params.id} status:`, error);
      res.status(500).json({ message: 'Failed to fetch ship status' });
    }
  });

  app.patch('/api/ships/:id/status', isAuthenticated, requirePermission(Permission.MOVE_SHIPS), async (req: any, res) => {
    try {
      console.log(`[SHIP STATUS UPDATE] ID: ${req.params.id}, Body:`, req.body);
      
      const id = parseInt(req.params.id);
      const validatedData = updateShipStatusSchema.parse(req.body);
      
      console.log(`[SHIP STATUS UPDATE] Validated data:`, validatedData);
      
      // REGRA: Berço aceita apenas um navio de cada vez
      if (validatedData.status === 'at_berth') {
        const allShips = await storage.getShips();
        const shipsAtBerth = allShips.filter(ship => ship.status === 'at_berth' && ship.id !== id);
        
        console.log(`[BERTH CHECK] Ships at berth: ${shipsAtBerth.length}`);
        
        if (shipsAtBerth.length > 0) {
          const occupiedBy = shipsAtBerth[0].name;
          console.log(`[BERTH OCCUPIED] Berth occupied by: ${occupiedBy}`);
          return res.status(400).json({ 
            message: `Berço ocupado pelo navio ${occupiedBy}. O cais só aceita um navio de cada vez.`,
            error: "BERTH_OCCUPIED"
          });
        }
      }
      
      const ship = await storage.updateShipStatus(id, validatedData);
      console.log(`[SHIP STATUS UPDATE] Success: Ship ${ship.name} status updated to ${ship.status}`);
      res.json(ship);
    } catch (error) {
      console.error("[SHIP STATUS UPDATE] Error updating ship status:", error);
      if (error instanceof z.ZodError) {
        console.error("[SHIP STATUS UPDATE] Validation errors:", error.errors);
        return res.status(400).json({ message: "Invalid data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to update ship status" });
    }
  });

  // Update ship operation type (for operators only)
  app.patch('/api/ships/:id', isAuthenticated, requirePermission(Permission.MOVE_SHIPS), async (req: any, res) => {
    try {
      const id = parseInt(req.params.id);
      const validatedData = updateOperationTypeSchema.parse(req.body);
      
      // Check if ship exists and is not departed
      const currentShip = await storage.getShipById(id);
      if (!currentShip) {
        return res.status(404).json({ message: "Ship not found" });
      }
      
      if (currentShip.status === 'departed') {
        return res.status(400).json({ message: "Cannot edit information for departed ships" });
      }

      const ship = await storage.updateShipOperationType(id, validatedData.operationType);
      res.json(ship);
    } catch (error) {
      console.error("Error updating ship operation type:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to update ship operation type" });
    }
  });

  // Update complete ship information (for operators only)
  app.put('/api/ships/:id', isAuthenticated, requireOperatorOrAdmin, async (req: any, res) => {
    try {
      console.log("=== SHIP UPDATE REQUEST ===");
      console.log("Ship ID:", req.params.id);
      console.log("Request body:", JSON.stringify(req.body, null, 2));
      console.log("User:", req.user ? { id: req.user.id, role: req.user.role } : "NO USER");
      
      const id = parseInt(req.params.id);
      
      // Check if ship exists and is not departed
      const currentShip = await storage.getShipById(id);
      if (!currentShip) {
        console.log("Ship not found with ID:", id);
        return res.status(404).json({ message: "Ship not found" });
      }
      
      if (currentShip.status === 'departed') {
        console.log("Cannot edit departed ship:", id);
        return res.status(400).json({ message: "Cannot edit information for departed ships" });
      }

      // Normalize operation type
      const normalizeOperationType = (val: string) => {
        const normalized = val.toLowerCase()
          .replace('â', 'a')
          .replace('ã', 'a')
          .replace('ç', 'c');
        
        switch (normalized) {
          case 'nacional':
            return 'nacional';
          case 'transito':
            return 'transito';
          case 'combinado':
            return 'combinado';
          case 'lpg':
            return 'lpg';
          default:
            return normalized;
        }
      };

      const validatedData = {
        name: req.body.name,
        countermark: req.body.countermark,
        draft: req.body.draft,
        shipAgent: req.body.shipAgent,
        cargoAgent: req.body.cargoAgent,
        cargoType: req.body.cargoType,
        operationType: normalizeOperationType(req.body.operationType),
        arrivalDateTime: req.body.arrivalDateTime ? new Date(req.body.arrivalDateTime) : undefined,
        status: req.body.status,
        shipowner: req.body.shipowner,
        cargoDestination: req.body.cargoDestination,
        shipAgentEmail: req.body.shipAgentEmail,
        cargoAgentEmail: req.body.cargoAgentEmail,
      };

      console.log("Validated ship data:", validatedData);

      const parcels = req.body.parcels || [];
      console.log("Parcels to update:", parcels.length, "parcels");

      const ship = await storage.updateCompleteShipInfo(id, validatedData, parcels);
      console.log("Ship updated successfully:", ship.id, ship.name);
      
      res.json(ship);
    } catch (error) {
      console.error("Error updating ship information:", error);
      res.status(500).json({ message: "Failed to update ship information", error: error instanceof Error ? error.message : "Unknown error" });
    }
  });

  // Operational discharge records routes
  app.post('/api/ships/:id/operational-discharge', isAuthenticated, requirePermission(Permission.UPDATE_DISCHARGE), async (req: any, res) => {
    try {
      const shipId = parseInt(req.params.id);
      
      // Clean and validate the data with proper timestamp conversion
      const cleanData = {
        shipId,
        operationType: req.body.operationType,
        parcelId: req.body.parcelId || null,
        pressure: req.body.pressure || null,
        dischargeRate: req.body.dischargeRate || null,
        dischargeStartTime: req.body.dischargeStartTime ? new Date(req.body.dischargeStartTime) : null,
        dischargeEndTime: req.body.dischargeEndTime ? new Date(req.body.dischargeEndTime) : null,
        stopStartTime: req.body.stopStartTime ? new Date(req.body.stopStartTime) : null,
        stopEndTime: req.body.stopEndTime ? new Date(req.body.stopEndTime) : null,
        stopType: req.body.stopType || null,
        stopComment: req.body.stopComment || null,
        resumeComment: req.body.resumeComment || null,
        hasLineDisplacement: req.body.hasLineDisplacement || false,
        lineDisplacementDuration: req.body.lineDisplacementDuration || null,
        recordedBy: req.user.id
      };

      const record = await storage.createOperationalDischargeRecord(cleanData);
      res.status(201).json(record);
    } catch (error) {
      console.error("Error creating operational discharge record:", error);
      res.status(500).json({ message: "Failed to create operational discharge record" });
    }
  });

  app.get('/api/ships/:id/operational-discharge', isAuthenticated, async (req, res) => {
    try {
      const shipId = parseInt(req.params.id);
      const records = await storage.getOperationalDischargeRecords(shipId);
      res.json(records);
    } catch (error) {
      console.error("Error fetching operational discharge records:", error);
      res.status(500).json({ message: "Failed to fetch operational discharge records" });
    }
  });

  // Operational discharge history (for management users)
  app.get("/api/operational-discharge/history", isAuthenticated, requirePermission("view_reports"), async (req, res) => {
    try {
      const { date, ship, operation } = req.query;
      const filters = {
        date: date as string,
        ship: ship as string,
        operation: operation as string
      };
      
      const history = await storage.getOperationalDischargeHistory(filters);
      res.json(history);
    } catch (error) {
      console.error("Error fetching operational discharge history:", error);
      res.status(500).json({ message: "Failed to fetch operational discharge history" });
    }
  });

  // Ships summary (for operational history)
  app.get("/api/ships/summary", isAuthenticated, async (req, res) => {
    try {
      const ships = await storage.getShipsSummary();
      res.json(ships);
    } catch (error) {
      console.error("Error fetching ships summary:", error);
      res.status(500).json({ message: "Failed to fetch ships summary" });
    }
  });

  app.get('/api/ships/:id/latest-operational-discharge', isAuthenticated, async (req, res) => {
    try {
      const shipId = parseInt(req.params.id);
      const operationType = req.query.operationType as string;
      const record = await storage.getLatestOperationalRecord(shipId, operationType);
      res.json(record || null);
    } catch (error) {
      console.error("Error fetching latest operational discharge record:", error);
      res.status(500).json({ message: "Failed to fetch latest operational discharge record" });
    }
  });

  app.put('/api/operational-discharge/:id', isAuthenticated, requirePermission(Permission.UPDATE_DISCHARGE), async (req: any, res) => {
    try {
      const recordId = parseInt(req.params.id);
      const updates = req.body;
      
      const record = await storage.updateOperationalDischargeRecord(recordId, updates);
      res.json(record);
    } catch (error) {
      console.error("Error updating operational discharge record:", error);
      res.status(500).json({ message: "Failed to update operational discharge record" });
    }
  });

  // Get operational discharge progress for a ship
  app.get('/api/ships/:id/operational-progress', isAuthenticated, async (req, res) => {
    try {
      const shipId = parseInt(req.params.id);
      const ships = await storage.getShips();
      const ship = ships.find(s => s.id === shipId);
      
      if (!ship) {
        return res.status(404).json({ message: "Ship not found" });
      }

      // Get latest operational discharge record from the modal system
      const latestRecord = await storage.getLatestOperationalRecord(shipId, 'update');
      
      if (!latestRecord) {
        // If no operational progress, fall back to traditional discharge progress
        const progress = await storage.getLatestDischargeProgress(shipId);
        return res.json({
          percentage: parseFloat(progress?.percentage || '0'),
          source: 'traditional',
          lastUpdated: progress?.recordedAt || null
        });
      }

      // The parcelProgress data is stored in the getLatestOperationalRecord method
      // which retrieves data from the operational modal's localStorage/memory
      const parcelProgress = (latestRecord as any).parcelProgress || {};

      // Calculate total cargo from ship parcels
      const totalCargo = ship.parcels?.reduce((sum, p) => sum + (parseFloat(p.volumeMT) || 0), 0) || 0;
      
      if (totalCargo === 0 || Object.keys(parcelProgress).length === 0) {
        // Fall back to traditional progress if no operational data
        const progress = await storage.getLatestDischargeProgress(shipId);
        return res.json({
          percentage: parseFloat(progress?.percentage || '0'),
          source: 'traditional',
          lastUpdated: progress?.recordedAt || null,
          totalCargo
        });
      }

      const totalDischarged = Object.values(parcelProgress)
        .reduce((sum: number, progress: any) => sum + (parseFloat(progress?.discharged) || 0), 0);
      
      const percentage = Math.min((totalDischarged / totalCargo) * 100, 100);
      
      res.json({
        percentage: Math.round(percentage * 10) / 10, // Round to 1 decimal
        source: 'operational',
        lastUpdated: latestRecord.recordedAt,
        totalCargo,
        totalDischarged
      });
    } catch (error) {
      console.error("Error calculating operational progress:", error);
      // Fallback to traditional progress on any error
      try {
        const progress = await storage.getLatestDischargeProgress(parseInt(req.params.id));
        res.json({
          percentage: parseFloat(progress?.percentage || '0'),
          source: 'traditional',
          lastUpdated: progress?.recordedAt || null
        });
      } catch (fallbackError) {
        res.status(500).json({ message: "Failed to calculate progress" });
      }
    }
  });

  // Discharge progress routes
  app.post('/api/ships/:id/discharge', isAuthenticated, requirePermission(Permission.UPDATE_DISCHARGE), async (req: any, res) => {
    try {
      const shipId = parseInt(req.params.id);
      const discharged = parseFloat(req.body.discharged);
      const remaining = parseFloat(req.body.remaining);
      
      // Calculate percentage and estimated completion
      const total = discharged + remaining;
      const percentage = (discharged / total) * 100;
      
      // Simple estimation based on last hour's progress
      const latestProgress = await storage.getLatestDischargeProgress(shipId);
      let estimatedCompletionHours = null;
      
      if (latestProgress) {
        const lastDischarged = parseFloat(latestProgress.discharged);
        const hourlyRate = discharged - lastDischarged;
        if (hourlyRate > 0) {
          estimatedCompletionHours = remaining / hourlyRate;
        }
      }

      const progressData = {
        shipId,
        discharged: discharged.toString(),
        remaining: remaining.toString(),
        percentage: percentage.toString(),
        estimatedCompletionHours: estimatedCompletionHours?.toString(),
        recordedBy: req.user.id.toString(),
      };

      const progress = await storage.createDischargeProgress(progressData);
      res.status(201).json(progress);
    } catch (error) {
      console.error("Error creating discharge progress:", error);
      res.status(500).json({ message: "Failed to record discharge progress" });
    }
  });

  // Simplified discharge tracking for now - will expand later
  app.get('/api/ships/:id/discharge-status', isAuthenticated, async (req: any, res) => {
    try {
      const shipId = parseInt(req.params.id);
      const ship = await storage.getShipById(shipId);
      
      if (!ship) {
        return res.status(404).json({ message: "Ship not found" });
      }

      // Return basic discharge status for now
      res.json({
        shipId,
        status: 'basic',
        parcels: ship.parcels || [],
        message: 'Advanced discharge tracking will be implemented'
      });
    } catch (error) {
      console.error("Error getting discharge status:", error);
      res.status(500).json({ message: "Failed to get discharge status" });
    }
  });

  // Get parcels for specific ship
  app.get('/api/ships/:id/parcels', isAuthenticated, async (req: any, res) => {
    try {
      const shipId = parseInt(req.params.id);
      const parcels = await storage.getParcelsForShip(shipId);
      res.json(parcels);
    } catch (error) {
      console.error("Error fetching ship parcels:", error);
      res.status(500).json({ message: "Failed to fetch ship parcels" });
    }
  });

  // Get parcels for a specific ship - no auth required for viewing
  app.get('/api/ships/:id/parcels', async (req, res) => {
    try {
      const shipId = parseInt(req.params.id);
      if (!shipId || isNaN(shipId)) {
        return res.status(400).json({ message: 'Invalid ship ID' });
      }
      
      const parcels = await storage.getShipParcels(shipId);
      console.log(`[PARCELS API] Returning ${parcels.length} parcels for ship ${shipId}`);
      console.log(`[PARCELS API] Parcel IDs:`, parcels.map(p => ({ id: p.id, number: p.parcelNumber })));
      res.json(parcels);
    } catch (error) {
      console.error('Error fetching parcels:', error);
      res.status(500).json({ message: 'Failed to fetch parcels' });
    }
  });

  // Add new parcel to existing ship
  app.post('/api/ships/:id/parcels', isAuthenticated, requireOperatorOrAdmin, async (req: any, res) => {
    try {
      console.log("=== ADDING NEW PARCEL ===");
      console.log("Ship ID:", req.params.id);
      console.log("Parcel data:", req.body);
      console.log("User:", req.user ? { id: req.user.id, role: req.user.role } : "NO USER");
      
      const shipId = parseInt(req.params.id);
      const parcelData = req.body;
      
      if (!shipId || isNaN(shipId)) {
        return res.status(400).json({ message: "ID do navio inválido" });
      }
      
      // Validate and transform numeric fields - convert empty strings to null for database
      const transformedParcel = {
        ...parcelData,
        volumeMT: parcelData.volumeMT && parcelData.volumeMT !== '' ? parseFloat(parcelData.volumeMT) : null,
        volumeM3: parcelData.volumeM3 && parcelData.volumeM3 !== '' ? parseFloat(parcelData.volumeM3) : null,
        density15C: parcelData.density15C && parcelData.density15C !== '' ? parseFloat(parcelData.density15C) : null,
        product: parcelData.product || '',
        receiver: parcelData.receiver || '',
        owner: parcelData.owner || ''
      };
      
      console.log("Transformed parcel:", transformedParcel);
      
      // Validate numeric values
      if (transformedParcel.volumeMT !== null && isNaN(transformedParcel.volumeMT)) {
        return res.status(400).json({ message: "Volume MT deve ser um número válido" });
      }
      if (transformedParcel.volumeM3 !== null && isNaN(transformedParcel.volumeM3)) {
        return res.status(400).json({ message: "Volume m³ deve ser um número válido" });
      }
      if (transformedParcel.density15C !== null && isNaN(transformedParcel.density15C)) {
        return res.status(400).json({ message: "Densidade deve ser um número válido" });
      }
      
      const newParcel = await storage.addParcelToShip(shipId, transformedParcel);
      console.log("Parcel created successfully:", newParcel);
      
      res.status(201).json(newParcel);
    } catch (error) {
      console.error("Error adding parcel to ship:", error);
      res.status(500).json({ 
        message: "Falha ao adicionar parcela", 
        error: error instanceof Error ? error.message : "Erro desconhecido"
      });
    }
  });

  // Berthing registration route
  app.post('/api/ships/berthing', isAuthenticated, requirePermission(Permission.CONFIRM_SHIPS), async (req: any, res) => {
    try {
      console.log('=== BERTHING REGISTRATION DEBUG ===');
      console.log('User authenticated:', !!req.user);
      console.log('User details:', req.user ? { id: req.user.id, username: req.user.username, role: req.user.role } : 'NO USER');
      console.log('Request body:', req.body);
      
      const { shipId, firstRopeTime, lastRopeTime } = req.body;
      
      const berthingData = {
        shipId: parseInt(shipId),
        firstRopeTime: new Date(firstRopeTime),
        lastRopeTime: new Date(lastRopeTime),
        createdBy: req.user.id,
      };

      console.log('Creating berthing record with data:', berthingData);
      const berthingRecord = await storage.createBerthingRecord(berthingData);
      console.log('Berthing record created:', berthingRecord);
      
      // If both ropes are confirmed, automatically move ship to berth if berth is empty
      if (firstRopeTime && lastRopeTime) {
        console.log('Both rope times provided, checking berth availability...');
        const ships = await storage.getShips();
        const shipsAtBerth = ships.filter(ship => ship.status === 'at_berth');
        console.log('Ships currently at berth:', shipsAtBerth.length);
        
        // REGRA: Berço aceita apenas um navio de cada vez
        if (shipsAtBerth.length === 0) {
          console.log(`Moving ship ${shipId} to berth...`);
          const updatedShip = await storage.updateShipStatus(parseInt(shipId), { status: 'at_berth' });
          console.log('Ship moved to berth successfully:', updatedShip);
        } else {
          const occupyingShip = shipsAtBerth[0];
          console.log(`Berth occupied by ${occupyingShip.name} (ID: ${occupyingShip.id}) - ship ${shipId} cannot berth automatically`);
          return res.status(409).json({ 
            error: 'BERTH_OCCUPIED',
            message: `Berço ocupado pelo navio ${occupyingShip.name}. O cais só aceita um navio de cada vez.`
          });
        }
      }
      
      res.status(201).json(berthingRecord);
    } catch (error) {
      console.error("Error registering berthing:", error);
      res.status(500).json({ message: "Failed to register berthing" });
    }
  });

  // Get all berthing records
  app.get("/api/berthing-records", isAuthenticated, async (req, res) => {
    try {
      const berthingRecords = await storage.getAllBerthingRecords();
      res.json(berthingRecords);
    } catch (error) {
      console.error("Error fetching berthing records:", error);
      res.status(500).json({ message: "Failed to fetch berthing records" });
    }
  });

  // Get berthing record for a ship
  app.get("/api/ships/:id/berthing", isAuthenticated, async (req, res) => {
    try {
      const shipId = parseInt(req.params.id);
      const berthingRecord = await storage.getBerthingRecord(shipId);
      res.json(berthingRecord);
    } catch (error) {
      console.error("Error fetching berthing record:", error);
      res.status(500).json({ message: "Failed to fetch berthing record" });
    }
  });

  // Update berthing record for a ship
  app.patch("/api/ships/:id/berthing", isAuthenticated, requireOperatorOrAdmin, async (req: any, res) => {
    try {
      const shipId = parseInt(req.params.id);
      const { firstRopeTime, lastRopeTime } = req.body;
      
      console.log("PATCH /api/ships/:id/berthing - Request data:", {
        shipId,
        firstRopeTime,
        lastRopeTime,
        body: req.body
      });
      
      const updatedRecord = await storage.updateBerthingRecord(shipId, {
        firstRopeTime: firstRopeTime,
        lastRopeTime: lastRopeTime,
      });
      
      console.log("PATCH /api/ships/:id/berthing - Updated record:", updatedRecord);
      
      res.json(updatedRecord);
    } catch (error) {
      console.error("Error updating berthing record:", error);
      res.status(500).json({ message: "Failed to update berthing record" });
    }
  });

  // Get undocking record for a ship
  app.get("/api/ships/:id/undocking", isAuthenticated, async (req, res) => {
    try {
      const shipId = parseInt(req.params.id);
      const undockingRecord = await storage.getUndockingRecord(shipId);
      res.json(undockingRecord);
    } catch (error) {
      console.error("Error fetching undocking record:", error);
      res.status(500).json({ message: "Failed to fetch undocking record" });
    }
  });

  // Update undocking record for a ship
  app.put("/api/ships/:id/undocking", isAuthenticated, requireOperatorOrAdmin, async (req: any, res) => {
    try {
      const shipId = parseInt(req.params.id);
      const { firstRopeTime, lastRopeTime } = req.body;
      
      const undockingData = {
        shipId: shipId,
        firstRopeTime: firstRopeTime,
        lastRopeTime: lastRopeTime,
        createdBy: req.user.id,
      };

      const undockingRecord = await storage.createOrUpdateUndockingRecord(undockingData);
      res.json(undockingRecord);
    } catch (error) {
      console.error("Error updating undocking record:", error);
      res.status(500).json({ message: "Failed to update undocking record" });
    }
  });

  // Undocking registration route
  app.post('/api/ships/undocking', isAuthenticated, requirePermission(Permission.REGISTER_UNDOCKING), async (req: any, res) => {
    try {
      const { shipId, firstRopeTime, lastRopeTime } = req.body;
      
      const undockingData = {
        shipId: parseInt(shipId),
        firstRopeTime: new Date(firstRopeTime),
        lastRopeTime: new Date(lastRopeTime),
        createdBy: req.user.id,
      };

      const undockingRecord = await storage.createUndockingRecord(undockingData);
      res.status(201).json(undockingRecord);
    } catch (error) {
      console.error("Error registering undocking:", error);
      res.status(500).json({ message: "Failed to register undocking" });
    }
  });

  // Send discharge instruction email to ship agents
  app.post('/api/ships/:id/send-instruction-email', isAuthenticated, requirePermission(Permission.CONFIRM_SHIPS), async (req: any, res) => {
    try {
      const shipId = parseInt(req.params.id);
      const success = await storage.sendInstructionRequestEmail(shipId);
      
      if (success) {
        res.json({ 
          message: "Email de instrução de descarga enviado com sucesso aos agentes do navio",
          success: true 
        });
      } else {
        res.status(500).json({ 
          message: "Falha ao enviar email de instrução de descarga",
          success: false 
        });
      }
    } catch (error) {
      console.error("Error sending instruction email:", error);
      res.status(500).json({ 
        message: "Erro interno ao enviar email de instrução de descarga",
        success: false 
      });
    }
  });

  // Manual instruction move - update discharge instruction status
  app.patch('/api/ships/:id/instruction', isAuthenticated, requirePermission(Permission.CONFIRM_SHIPS), async (req: any, res) => {
    try {
      const shipId = parseInt(req.params.id);
      const { hasDischargeInstructions } = req.body;
      
      // Get ship first to validate it exists
      const ship = await storage.getShipById(shipId);
      if (!ship) {
        return res.status(404).json({
          message: "Navio não encontrado",
          success: false
        });
      }
      
      // Update ship directly using complete ship info function
      const updatedShip = await storage.updateCompleteShipInfo(shipId, {
        hasDischargeInstructions: hasDischargeInstructions
      });
      
      // Send status change alerts
      await storage.sendShipStatusChangeAlerts(shipId, 'without_instructions', 'with_instructions');
      
      res.json({
        message: "Instrução adicionada com sucesso. Navio aguarda na lista 'Com Instrução' conforme prioridades.",
        ship: updatedShip,
        success: true
      });
    } catch (error) {
      console.error("Error updating instruction status:", error);
      res.status(500).json({ 
        message: "Erro ao atualizar status de instrução de descarga",
        success: false 
      });
    }
  });

  // Rota duplicada removida - usando a implementação completa na linha 730

  // Update specific parcel for a ship
  app.put('/api/ships/:id/parcels/:parcelId', isAuthenticated, requireOperatorOrAdmin, async (req: any, res) => {
    try {
      const parcelId = parseInt(req.params.parcelId);
      const updateData = req.body;
      
      const updatedParcel = await storage.updateParcel(parcelId, updateData);
      res.json(updatedParcel);
    } catch (error) {
      console.error("Error updating parcel:", error);
      res.status(500).json({ message: "Failed to update parcel" });
    }
  });

  // Delete specific parcel for a ship
  app.delete('/api/ships/:id/parcels/:parcelId', isAuthenticated, requireOperatorOrAdmin, async (req: any, res) => {
    try {
      const parcelId = parseInt(req.params.parcelId);
      
      await storage.deleteParcel(parcelId);
      res.json({ message: "Parcel deleted successfully" });
    } catch (error) {
      console.error("Error deleting parcel:", error);
      res.status(500).json({ message: "Failed to delete parcel" });
    }
  });

  // Legacy routes for backwards compatibility
  app.patch('/api/parcels/:id', isAuthenticated, requireOperatorOrAdmin, async (req: any, res) => {
    try {
      const parcelId = parseInt(req.params.id);
      const updateData = req.body;
      
      const updatedParcel = await storage.updateParcel(parcelId, updateData);
      res.json(updatedParcel);
    } catch (error) {
      console.error("Error updating parcel:", error);
      res.status(500).json({ message: "Failed to update parcel" });
    }
  });

  app.delete('/api/parcels/:id', isAuthenticated, requireOperatorOrAdmin, async (req: any, res) => {
    try {
      const parcelId = parseInt(req.params.id);
      
      await storage.deleteParcel(parcelId);
      res.json({ message: "Parcel deleted successfully" });
    } catch (error) {
      console.error("Error deleting parcel:", error);
      res.status(500).json({ message: "Failed to delete parcel" });
    }
  });

  // Cargo agents routes
  app.post('/api/ships/:id/cargo-agents', isAuthenticated, requirePermission(Permission.UPDATE_SHIPS), async (req: any, res) => {
    try {
      const shipId = parseInt(req.params.id);
      const agentData = insertCargoAgentSchema.parse(req.body);
      
      const newAgent = await storage.createCargoAgent(agentData, shipId);
      res.status(201).json(newAgent);
    } catch (error) {
      console.error("Error creating cargo agent:", error);
      res.status(500).json({ message: "Failed to create cargo agent" });
    }
  });

  app.get('/api/ships/:id/cargo-agents', isAuthenticated, async (req, res) => {
    try {
      const shipId = parseInt(req.params.id);
      const agents = await storage.getCargoAgents(shipId);
      res.json(agents);
    } catch (error) {
      console.error("Error fetching cargo agents:", error);
      res.status(500).json({ message: "Failed to fetch cargo agents" });
    }
  });

  app.patch('/api/cargo-agents/:id', isAuthenticated, requirePermission(Permission.UPDATE_SHIPS), async (req: any, res) => {
    try {
      const agentId = parseInt(req.params.id);
      const updates = req.body;
      
      const updatedAgent = await storage.updateCargoAgent(agentId, updates);
      res.json(updatedAgent);
    } catch (error) {
      console.error("Error updating cargo agent:", error);
      res.status(500).json({ message: "Failed to update cargo agent" });
    }
  });

  app.delete('/api/cargo-agents/:id', isAuthenticated, requirePermission(Permission.UPDATE_SHIPS), async (req: any, res) => {
    try {
      const agentId = parseInt(req.params.id);
      const success = await storage.deleteCargoAgent(agentId);
      
      if (success) {
        res.json({ message: "Cargo agent deleted successfully" });
      } else {
        res.status(404).json({ message: "Cargo agent not found" });
      }
    } catch (error) {
      console.error("Error deleting cargo agent:", error);
      res.status(500).json({ message: "Failed to delete cargo agent" });
    }
  });

  // Terminal settings routes
  app.get('/api/terminal/settings', async (req, res) => {
    try {
      const settings = await storage.getTerminalSettings();
      res.json(settings);
    } catch (error) {
      console.error("Error fetching terminal settings:", error);
      res.status(500).json({ message: "Failed to fetch terminal settings" });
    }
  });

  app.patch('/api/terminal/tide', isOperator, async (req: any, res) => {
    try {
      const { tide } = req.body;
      const settings = await storage.updateCurrentTide(parseFloat(tide));
      res.json(settings);
    } catch (error) {
      console.error("Error updating tide:", error);
      res.status(500).json({ message: "Failed to update tide" });
    }
  });

  // Enhanced Tide information endpoints - Validated data for Beira Port
  app.get('/api/tide', async (req, res) => {
    try {
      const { enhancedTideService } = await import('./enhancedTideService');
      const tideData = await enhancedTideService.getCurrentTideData();
      
      // Log data source and reliability for transparency
      console.log(`Tide data source: ${tideData.dataSource} (${tideData.reliability}% reliability)`);
      
      // Include next high tide validation for January 7, 2025 at 8:00 AM
      const jan7_8am = new Date('2025-01-07T08:00:00+02:00'); // Mozambique time
      if (Math.abs(jan7_8am.getTime() - Date.now()) < 7 * 24 * 60 * 60 * 1000) {
        console.log(`Validation: High tide on Jan 7 at 8:00 AM predicted as reference point`);
      }
      
      res.json(tideData);
    } catch (error) {
      console.error("Error fetching enhanced tide data:", error);
      res.status(500).json({ message: "Failed to fetch tide data" });
    }
  });

  app.get('/api/tides/current', async (req, res) => {
    try {
      const { enhancedTideService } = await import('./enhancedTideService');
      const tideData = await enhancedTideService.getCurrentTideData();
      res.json(tideData);
    } catch (error) {
      console.error("Error fetching current enhanced tide data:", error);
      res.status(500).json({ message: "Failed to fetch tide data" });
    }
  });

  app.get('/api/tides/predictions', async (req, res) => {
    try {
      const { enhancedTideService } = await import('./enhancedTideService');
      const { days = 3 } = req.query;
      
      const startDate = new Date();
      const endDate = new Date(startDate.getTime() + parseInt(days as string) * 24 * 60 * 60 * 1000);
      
      // Generate validated predictions
      const tideData = await enhancedTideService.getCurrentTideData();
      const predictions = tideData.prediction24h.filter(pred => 
        pred.time >= startDate && pred.time <= endDate
      );
      
      res.json({
        predictions,
        dataSource: tideData.dataSource,
        reliability: tideData.reliability
      });
    } catch (error) {
      console.error("Error fetching enhanced tide predictions:", error);
      res.status(500).json({ message: "Failed to fetch tide predictions" });
    }
  });

  // Weather monitoring endpoints
  app.get('/api/weather', async (req, res) => {
    try {
      const { weatherService } = await import('./weatherService');
      const weatherData = await weatherService.getCurrentWeatherData();
      res.json(weatherData);
    } catch (error) {
      console.error("Error fetching weather data:", error);
      res.status(500).json({ message: "Failed to fetch weather data" });
    }
  });

  app.get('/api/weather/current', async (req, res) => {
    try {
      const { weatherService } = await import('./weatherService');
      const weatherData = await weatherService.getCurrentWeatherData();
      res.json(weatherData);
    } catch (error) {
      console.error("Error fetching weather data:", error);
      res.status(500).json({ message: "Failed to fetch weather data" });
    }
  });

  app.get('/api/weather/alerts', async (req, res) => {
    try {
      const { weatherService } = await import('./weatherService');
      const alerts = await weatherService.getActiveAlerts();
      res.json(alerts);
    } catch (error) {
      console.error("Error fetching weather alerts:", error);
      res.status(500).json({ message: "Failed to fetch weather alerts" });
    }
  });

  app.get('/api/weather/history', async (req, res) => {
    try {
      const { weatherService } = await import('./weatherService');
      const { hours = 24 } = req.query;
      const history = await weatherService.getWeatherHistory(parseInt(hours as string));
      res.json(history);
    } catch (error) {
      console.error("Error fetching weather history:", error);
      res.status(500).json({ message: "Failed to fetch weather history" });
    }
  });

  // Ship Registry and Reports routes (Admin only)
  app.get("/api/admin/reports", isAuthenticated, async (req: any, res) => {
    try {
      // Verificar se usuário tem permissões de administrador
      const userPermissions = await storage.getUserPermissions(req.user.id);
      const hasAdminPermission = userPermissions.some(p => p.permission === 'admin' || req.user.role === 'admin');
      
      if (!hasAdminPermission) {
        return res.status(403).json({ message: "Acesso negado - apenas administradores" });
      }

      const reports = await storage.getMonthlyReports();
      res.json(reports);
    } catch (error) {
      console.error("Error fetching reports:", error);
      res.status(500).json({ message: "Failed to fetch reports" });
    }
  });

  app.get("/api/admin/reports/:id", isAuthenticated, async (req: any, res) => {
    try {
      const reportId = parseInt(req.params.id);
      const userId = req.user?.id;
      
      if (!userId) {
        return res.status(401).json({ message: "Unauthorized" });
      }

      // Verificar permissões administrativas
      const userPermissions = await storage.getUserPermissions(userId);
      const hasAdminPermission = userPermissions.some(p => p.permission === 'admin' || req.user.role === 'admin');
      
      if (!hasAdminPermission) {
        return res.status(403).json({ message: "Acesso negado - apenas administradores" });
      }

      const report = await storage.getMonthlyReport(reportId);
      if (!report) {
        return res.status(404).json({ message: "Report not found" });
      }

      // Log access for security
      await storage.logReportAccess(reportId, userId, req.ip);

      res.json(report);
    } catch (error) {
      console.error("Error fetching report:", error);
      res.status(500).json({ message: "Failed to fetch report" });
    }
  });

  app.post("/api/admin/reports/generate", isAuthenticated, async (req: any, res) => {
    try {
      const { month, year } = req.body;
      
      // Verificar permissões administrativas
      const userPermissions = await storage.getUserPermissions(req.user.id);
      const hasAdminPermission = userPermissions.some(p => p.permission === 'admin' || req.user.role === 'admin');
      
      if (!hasAdminPermission) {
        return res.status(403).json({ message: "Acesso negado - apenas administradores" });
      }
      
      const { reportService } = await import('./reportService');
      
      const result = await reportService.generateMonthlyReport(month, year);
      
      res.json({ 
        message: "Relatório gerado e enviado para manuel.antonio@cfm.co.mz", 
        reportId: result.reportId 
      });
    } catch (error) {
      console.error("Error generating report:", error);
      res.status(500).json({ message: "Failed to generate report" });
    }
  });

  // Ship reports endpoints  
  app.get('/api/reports/ships/pdf', async (req, res) => {
    try {
      const { reportService } = await import('./reportService');
      const currentDate = new Date();
      const month = currentDate.getMonth() + 1;
      const year = currentDate.getFullYear();
      const result = await reportService.generateReport(month, year);
      const pdfBuffer = result.pdfPath;
      
      res.setHeader('Content-Type', 'application/pdf');
      res.setHeader('Content-Disposition', 'attachment; filename="ships-report.pdf"');
      res.send(pdfBuffer);
    } catch (error) {
      console.error('Error generating ship report PDF:', error);
      res.status(500).json({ message: 'Failed to generate report' });
    }
  });

  // Get agreed discharge rate for a ship
  app.get('/api/ships/:id/agreed-rate', async (req, res) => {
    try {
      const shipId = parseInt(req.params.id);
      const result = await storage.getAgreedDischargeRate(shipId);
      
      // Extract the actual agreed rate value
      let agreedRate = 150; // default
      if (result) {
        if (typeof result === 'object' && result.agreedRate) {
          agreedRate = result.agreedRate;
        } else if (typeof result === 'number') {
          agreedRate = result;
        }
      }
      
      res.json({ agreedRate });
    } catch (error) {
      console.error('Error fetching agreed rate:', error);
      res.status(500).json({ message: 'Failed to fetch agreed rate' });
    }
  });

  // Update agreed discharge rate for a ship
  app.put('/api/ships/:id/agreed-rate', async (req, res) => {
    try {
      const shipId = parseInt(req.params.id);
      const { agreedRate } = req.body;
      
      if (!agreedRate || agreedRate <= 0) {
        return res.status(400).json({ message: 'Invalid agreed rate' });
      }

      await storage.updateAgreedDischargeRate(shipId, agreedRate);
      res.json({ success: true, agreedRate });
    } catch (error) {
      console.error('Error updating agreed rate:', error);
      res.status(500).json({ message: 'Failed to update agreed rate' });
    }
  });

  app.get('/api/reports/ships/data', async (req, res) => {
    try {
      const ships = await storage.getShips();
      
      // Calculate summary statistics
      const totalShips = ships.length;
      const totalParcels = ships.reduce((sum, ship) => sum + (ship.parcels?.length || 0), 0);
      const allReceivers = new Set();
      let totalVolumeNum = 0;

      const shipDetails = ships.map(ship => {
        const parcels = ship.parcels || [];
        const shipVolume = parcels.reduce((sum, p) => sum + (parseFloat(p.volumeMT || '') || 0), 0);
        totalVolumeNum += shipVolume;
        
        const receivers = parcels.map(p => p.receiver).filter(r => r);
        receivers.forEach(r => allReceivers.add(r));

        return {
          name: ship.name,
          countermark: ship.countermark,
          status: ship.status,
          parcels: parcels.length,
          totalVolume: `${shipVolume.toLocaleString()} MT`,
          receivers: receivers,
          operationDuration: ship.status === 'departed' ? 'Concluído' : 'Em andamento'
        };
      });

      const reportData = {
        totalShips,
        totalParcels,
        uniqueReceivers: allReceivers.size,
        totalVolume: `${totalVolumeNum.toLocaleString()} MT`,
        operationsData: {},
        shipDetails
      };

      res.json(reportData);
    } catch (error) {
      console.error('Error generating ship report data:', error);
      res.status(500).json({ message: 'Failed to generate report data' });
    }
  });

  // Berthing eligibility check
  app.post('/api/ships/:id/check-berthing', isOperator, async (req: any, res) => {
    try {
      const shipId = parseInt(req.params.id);
      const ship = await storage.getShipById(shipId);
      
      if (!ship) {
        return res.status(404).json({ message: "Ship not found" });
      }

      const result = await storage.canShipBerth(parseFloat(ship.draft));
      res.json(result);
    } catch (error) {
      console.error("Error checking berthing eligibility:", error);
      res.status(500).json({ message: "Failed to check berthing eligibility" });
    }
  });

  // Email confirmation routes
  app.post('/api/ships/:id/send-confirmation', isAuthenticated, requirePermission(Permission.CONFIRM_SHIPS), async (req: any, res) => {
    try {
      const shipId = parseInt(req.params.id);
      const success = await storage.sendBerthingConfirmationEmail(shipId);
      
      if (success) {
        res.json({ message: "Confirmation email sent successfully" });
      } else {
        res.status(500).json({ message: "Failed to send confirmation email" });
      }
    } catch (error) {
      console.error("Error sending confirmation email:", error);
      res.status(500).json({ message: "Failed to send confirmation email" });
    }
  });

  app.post('/api/ships/:id/confirm-berthing', async (req, res) => {
    try {
      const shipId = parseInt(req.params.id);
      const ship = await storage.updateShipStatus(shipId, { 
        status: "next_to_berth", 
        berthingConfirmed: true 
      });
      res.json(ship);
    } catch (error) {
      console.error("Error confirming berthing:", error);
      res.status(500).json({ message: "Failed to confirm berthing" });
    }
  });

  // Send instruction email endpoint
  app.post('/api/ships/:id/send-instruction-email', isAuthenticated, isOperator, async (req, res) => {
    try {
      const shipId = parseInt(req.params.id);
      const success = await storage.sendInstructionRequestEmail(shipId);
      
      if (success) {
        res.json({ message: "Instruction request email sent successfully" });
      } else {
        res.status(404).json({ message: "Ship not found" });
      }
    } catch (error) {
      console.error("Error sending instruction email:", error);
      res.status(500).json({ message: "Failed to send instruction email" });
    }
  });

  // Agent confirmation endpoint (accessible via email link)
  app.get('/api/ships/:id/confirm/:token', async (req, res) => {
    try {
      const shipId = parseInt(req.params.id);
      const token = req.params.token;
      
      // Simple token validation (in production, use proper JWT or secure tokens)
      const expectedToken = Buffer.from(`ship-${shipId}-confirm`).toString('base64');
      
      if (token !== expectedToken) {
        return res.status(400).json({ message: "Invalid confirmation token" });
      }

      const ship = await storage.updateShipStatus(shipId, { 
        status: "next_to_berth", 
        berthingConfirmed: true,
        confirmationReceivedAt: new Date()
      });
      
      // Return a simple confirmation page
      res.send(`
        <!DOCTYPE html>
        <html>
        <head>
          <title>Confirmação de Atracação - Beira Oil Terminal</title>
          <meta charset="UTF-8">
          <style>
            body { font-family: Arial, sans-serif; max-width: 600px; margin: 50px auto; padding: 20px; }
            .success { background-color: #d4edda; border: 1px solid #c3e6cb; color: #155724; padding: 15px; border-radius: 5px; }
            .info { background-color: #d1ecf1; border: 1px solid #bee5eb; color: #0c5460; padding: 15px; border-radius: 5px; margin-top: 20px; }
          </style>
        </head>
        <body>
          <h1>Beira Oil Terminal - Sistema de Line-Up</h1>
          <div class="success">
            <h2>✓ Confirmação Recebida</h2>
            <p>A atracação do navio <strong>${ship.name}</strong> foi confirmada com sucesso.</p>
            <p>O navio foi movido para a posição "Próximo a Atracar" na fila do terminal.</p>
          </div>
          <div class="info">
            <h3>Detalhes do Navio:</h3>
            <ul>
              <li><strong>Nome:</strong> ${ship.name}</li>
              <li><strong>Contra Marca:</strong> ${ship.countermark}</li>
              <li><strong>Status:</strong> Próximo a Atracar</li>
              <li><strong>Confirmado em:</strong> ${new Date().toLocaleString('pt-BR')}</li>
            </ul>
          </div>
          <p><em>Esta confirmação foi processada automaticamente pelo sistema.</em></p>
        </body>
        </html>
      `);
    } catch (error) {
      console.error("Error confirming berthing via email:", error);
      res.status(500).json({ message: "Failed to confirm berthing" });
    }
  });

  // Agent instruction confirmation endpoint (accessible via email link)
  app.get('/api/ships/:id/confirm-instruction/:token', async (req, res) => {
    try {
      const shipId = parseInt(req.params.id);
      const token = req.params.token;
      
      const result = await storage.confirmDischargeInstruction(shipId, token);
      
      if (!result.success) {
        return res.send(`
          <!DOCTYPE html>
          <html>
          <head>
            <title>Erro na Confirmação - Beira Oil Terminal</title>
            <meta charset="UTF-8">
            <style>
              body { font-family: Arial, sans-serif; max-width: 600px; margin: 50px auto; padding: 20px; }
              .error { background-color: #f8d7da; border: 1px solid #f5c6cb; color: #721c24; padding: 15px; border-radius: 5px; }
              .info { background-color: #d1ecf1; border: 1px solid #bee5eb; color: #0c5460; padding: 15px; border-radius: 5px; margin-top: 20px; }
            </style>
          </head>
          <body>
            <h1>Beira Oil Terminal - Sistema de Line-Up</h1>
            <div class="error">
              <h2>✗ Erro na Confirmação</h2>
              <p>${result.message}</p>
            </div>
            <div class="info">
              <p>Se você acredita que isso é um erro, entre em contato com o terminal.</p>
            </div>
          </body>
          </html>
        `);
      }

      const ship = result.ship!;
      
      // Return success confirmation page
      res.send(`
        <!DOCTYPE html>
        <html>
        <head>
          <title>Confirmação de Instrução de Descarga - Beira Oil Terminal</title>
          <meta charset="UTF-8">
          <style>
            body { font-family: Arial, sans-serif; max-width: 600px; margin: 50px auto; padding: 20px; }
            .success { background-color: #d4edda; border: 1px solid #c3e6cb; color: #155724; padding: 15px; border-radius: 5px; }
            .info { background-color: #d1ecf1; border: 1px solid #bee5eb; color: #0c5460; padding: 15px; border-radius: 5px; margin-top: 20px; }
            .next-steps { background-color: #fff3cd; border: 1px solid #ffeaa7; color: #856404; padding: 15px; border-radius: 5px; margin-top: 20px; }
          </style>
        </head>
        <body>
          <h1>Beira Oil Terminal - Sistema de Line-Up</h1>
          <div class="success">
            <h2>✓ Instrução de Descarga Confirmada</h2>
            <p>A instrução de descarga para o navio <strong>${ship.name}</strong> foi confirmada com sucesso.</p>
            <p>O navio agora possui instrução de descarga e está pronto para operações.</p>
          </div>
          <div class="info">
            <h3>Detalhes do Navio:</h3>
            <ul>
              <li><strong>Nome:</strong> ${ship.name}</li>
              <li><strong>Contra Marca:</strong> ${ship.countermark}</li>
              <li><strong>Status:</strong> Na Barra - Com Instrução de Descarga</li>
              <li><strong>Confirmado em:</strong> ${new Date().toLocaleString('pt-BR')}</li>
            </ul>
          </div>
          <div class="next-steps">
            <h3>Próximos Passos:</h3>
            <p>O navio foi movido para a seção "Com Instrução de Descarga" no sistema de line-up e está aguardando posição para atracação conforme disponibilidade do terminal.</p>
          </div>
          <p><em>Esta confirmação foi processada automaticamente pelo sistema.</em></p>
        </body>
        </html>
      `);
    } catch (error) {
      console.error("Error confirming instruction via email:", error);
      res.status(500).send(`
        <!DOCTYPE html>
        <html>
        <head>
          <title>Erro do Sistema - Beira Oil Terminal</title>
          <meta charset="UTF-8">
          <style>
            body { font-family: Arial, sans-serif; max-width: 600px; margin: 50px auto; padding: 20px; }
            .error { background-color: #f8d7da; border: 1px solid #f5c6cb; color: #721c24; padding: 15px; border-radius: 5px; }
          </style>
        </head>
        <body>
          <h1>Beira Oil Terminal - Sistema de Line-Up</h1>
          <div class="error">
            <h2>✗ Erro do Sistema</h2>
            <p>Ocorreu um erro interno. Tente novamente mais tarde ou entre em contato com o terminal.</p>
          </div>
        </body>
        </html>
      `);
    }
  });

  // Notification subscription management endpoints
  app.get('/api/ships/:id/notifications', isAuthenticated, async (req, res) => {
    try {
      const shipId = parseInt(req.params.id);
      const subscriptions = await storage.getNotificationSubscriptions(shipId);
      res.json(subscriptions);
    } catch (error) {
      console.error("Error fetching notification subscriptions:", error);
      res.status(500).json({ message: "Failed to fetch notification subscriptions" });
    }
  });

  app.post('/api/ships/:id/notifications', isAuthenticated, isOperator, async (req, res) => {
    try {
      const shipId = parseInt(req.params.id);
      const subscriptionData = { ...req.body, shipId };
      const subscription = await storage.createNotificationSubscription(subscriptionData);
      res.json(subscription);
    } catch (error) {
      console.error("Error creating notification subscription:", error);
      res.status(500).json({ message: "Failed to create notification subscription" });
    }
  });

  app.patch('/api/notifications/:id', isAuthenticated, isOperator, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const subscription = await storage.updateNotificationSubscription(id, req.body);
      res.json(subscription);
    } catch (error) {
      console.error("Error updating notification subscription:", error);
      res.status(500).json({ message: "Failed to update notification subscription" });
    }
  });

  app.delete('/api/notifications/:id', isAuthenticated, isOperator, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const success = await storage.deleteNotificationSubscription(id);
      res.json({ success });
    } catch (error) {
      console.error("Error deleting notification subscription:", error);
      res.status(500).json({ message: "Failed to delete notification subscription" });
    }
  });

  // User management routes
  app.get('/api/users', isAuthenticated, isOperator, async (req, res) => {
    try {
      const users = await storage.getAllUsers();
      res.json(users);
    } catch (error) {
      console.error("Error fetching users:", error);
      res.status(500).json({ message: "Failed to fetch users" });
    }
  });

  // Permission management routes
  app.get('/api/users/:id/permissions', isAuthenticated, isOperator, async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      const permissions = await storage.getUserPermissions(userId);
      res.json(permissions);
    } catch (error) {
      console.error("Error fetching user permissions:", error);
      res.status(500).json({ message: "Failed to fetch user permissions" });
    }
  });

  app.post('/api/users/:id/permissions', isAuthenticated, isOperator, async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      const { permission } = req.body;
      
      const validatedPermission = permissionSchema.parse(permission);
      const permissionData = {
        userId,
        permission: validatedPermission,
        grantedBy: (req as any).user?.id
      };
      
      const newPermission = await storage.grantPermission(permissionData);
      res.json(newPermission);
    } catch (error) {
      console.error("Error granting permission:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid permission", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to grant permission" });
    }
  });

  app.delete('/api/users/:id/permissions/:permission', isAuthenticated, isOperator, async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      const permission = permissionSchema.parse(req.params.permission);
      
      const success = await storage.revokePermission(userId, permission);
      res.json({ success });
    } catch (error) {
      console.error("Error revoking permission:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid permission", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to revoke permission" });
    }
  });

  // Check current user permissions
  app.get('/api/user/permissions', isAuthenticated, async (req: any, res) => {
    try {
      const permissions = await storage.getUserPermissions(req.user.id);
      res.json(permissions);
    } catch (error) {
      console.error("Error fetching current user permissions:", error);
      res.status(500).json({ message: "Failed to fetch permissions" });
    }
  });

  // Berth maintenance routes
  app.get('/api/berth/maintenance', isAuthenticated, async (req, res) => {
    try {
      const maintenanceStatus = await storage.getBerthMaintenanceStatus();
      res.json(maintenanceStatus || { isUnderMaintenance: false });
    } catch (error) {
      console.error("Error fetching berth maintenance status:", error);
      res.status(500).json({ message: "Failed to fetch berth maintenance status" });
    }
  });

  app.post('/api/berth/maintenance', isAuthenticated, isOperator, async (req: any, res) => {
    try {
      const { isUnderMaintenance, maintenancePeriod, description } = req.body;
      
      if (typeof isUnderMaintenance !== 'boolean') {
        return res.status(400).json({ message: "isUnderMaintenance must be a boolean" });
      }

      const maintenanceData = {
        isUnderMaintenance,
        maintenancePeriod: maintenancePeriod || null,
        description: description || null,
      };

      const maintenance = await storage.setBerthMaintenance(maintenanceData, req.user.id);
      res.json(maintenance);
    } catch (error) {
      console.error("Error setting berth maintenance:", error);
      res.status(500).json({ message: "Failed to set berth maintenance" });
    }
  });

  app.post('/api/berth/maintenance/end', isAuthenticated, isOperator, async (req: any, res) => {
    try {
      const maintenance = await storage.endBerthMaintenance(req.user.id);
      res.json(maintenance);
    } catch (error) {
      console.error("Error ending berth maintenance:", error);
      res.status(500).json({ message: "Failed to end berth maintenance" });
    }
  });

  // Generate system capabilities HTML for client-side PDF generation
  app.get('/api/system/capabilities-html', isAuthenticated, isOperator, async (req, res) => {
    try {
      const { simplePDFGenerator } = await import('./simplePDFGenerator');
      const htmlContent = simplePDFGenerator.getSystemCapabilitiesHTML();
      
      res.setHeader('Content-Type', 'text/html; charset=utf-8');
      res.send(htmlContent);
    } catch (error) {
      console.error('Error generating system capabilities HTML:', error);
      res.status(500).json({ message: 'Erro ao gerar conteúdo das funcionalidades' });
    }
  });

  // System capabilities report endpoint
  app.post('/api/system/generate-report', isAuthenticated, isOperator, async (req, res) => {
    try {
      const { sendEmail } = await import('./emailService');
      
      const emailHtml = `
        <div style="font-family: Arial, sans-serif; max-width: 800px; margin: 0 auto; padding: 20px;">
            <div style="background: white; padding: 30px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1);">
                <div style="text-align: center; margin-bottom: 30px; border-bottom: 3px solid #1e40af; padding-bottom: 20px;">
                    <h1 style="color: #1e40af; margin: 0; font-size: 28px;">⚓ Sistema de Gestão Portuária</h1>
                    <h2 style="color: #64748b; margin: 10px 0 0 0; font-size: 18px;">Terminal Petrolífero da Beira</h2>
                    <p style="color: #6b7280; margin: 10px 0 0 0;">
                        Relatório Completo de Funcionalidades | Versão 2.0 | beiraoilterminal-vessels-lineup.com
                    </p>
                </div>
                
                <div style="background: #eff6ff; padding: 20px; border-radius: 8px; margin: 20px 0;">
                    <h3 style="color: #1e40af; margin: 0 0 15px 0;">📋 Funcionalidades Principais</h3>
                    
                    <div style="margin: 20px 0;">
                        <h4 style="color: #059669; margin-bottom: 10px;">Gestão de Navios</h4>
                        <ul style="line-height: 1.6; color: #374151; margin: 0; padding-left: 20px;">
                            <li>Registro completo de navios com informações detalhadas (nome, contra marca, calado, agentes)</li>
                            <li>Sistema de status em tempo real (esperado, na barra, próximo a atracar, no cais, partido)</li>
                            <li>Controle de tipos de operação (Trânsito e Combinado) com regras de atracação 2:1</li>
                            <li>Sistema de priorização IMOPETRO conforme Decreto 89/2019</li>
                            <li>Gestão de parcelas de carga com volumes e destinatários</li>
                            <li>Rastreamento de progresso de descarga em tempo real</li>
                        </ul>
                    </div>
                    
                    <div style="margin: 20px 0;">
                        <h4 style="color: #059669; margin-bottom: 10px;">Sistema de Priorização Inteligente</h4>
                        <ul style="line-height: 1.6; color: #374151; margin: 0; padding-left: 20px;">
                            <li>Prioridade absoluta para navios IMOPETRO (Decreto 89/2019)</li>
                            <li>Regra de atracação 2:1: 2 navios trânsito + 1 navio combinado</li>
                            <li>Ordenação cronológica por data de chegada na barra</li>
                            <li>Badges visuais diferenciando tipos de operação (trânsito verde, combinado roxo)</li>
                            <li>Alertas de prioridade em tempo real</li>
                        </ul>
                    </div>
                    
                    <div style="margin: 20px 0;">
                        <h4 style="color: #059669; margin-bottom: 10px;">Controle de Atracação</h4>
                        <ul style="line-height: 1.6; color: #374151; margin: 0; padding-left: 20px;">
                            <li>Registro de tempos de atracação (primeira e última amarra)</li>
                            <li>Verificação automática de condições baseada no calado e maré</li>
                            <li>Sistema de confirmação de instruções de descarga via email</li>
                            <li>Controle de berço com status de manutenção programada</li>
                            <li>Fluxo automatizado de movimentação entre status</li>
                        </ul>
                    </div>
                    
                    <div style="margin: 20px 0;">
                        <h4 style="color: #059669; margin-bottom: 10px;">Monitoramento Ambiental</h4>
                        <ul style="line-height: 1.6; color: #374151; margin: 0; padding-left: 20px;">
                            <li>Monitoramento de marés em tempo real para Porto da Beira</li>
                            <li>Previsões de maré com análise harmônica (constituintes M2, S2, N2)</li>
                            <li>Alertas meteorológicos para ventos acima de 25 nós</li>
                            <li>Dados de temperatura, umidade e pressão atmosférica</li>
                            <li>Integração com APIs meteorológicas (OpenWeather e Open-Meteo)</li>
                        </ul>
                    </div>
                </div>
                
                <div style="background: #f0fdf4; padding: 20px; border-radius: 8px; border-left: 4px solid #22c55e; margin: 20px 0;">
                    <h3 style="color: #15803d; margin: 0 0 15px 0;">⚙️ Especificações Técnicas</h3>
                    <ul style="line-height: 1.6; color: #374151; margin: 0; padding-left: 20px;">
                        <li><strong>Frontend:</strong> React 18 com TypeScript, Tailwind CSS, shadcn/ui</li>
                        <li><strong>Backend:</strong> Express.js com TypeScript, Drizzle ORM</li>
                        <li><strong>Banco de Dados:</strong> PostgreSQL (Neon Serverless)</li>
                        <li><strong>Autenticação:</strong> Replit Auth com OpenID Connect</li>
                        <li><strong>Email:</strong> SendGrid para notificações profissionais</li>
                        <li><strong>Relatórios:</strong> Chart.js e Puppeteer para relatórios PDF</li>
                        <li><strong>Clima/Marés:</strong> APIs OpenWeather e Open-Meteo</li>
                        <li><strong>Deployment:</strong> Replit com domínio beiraoilterminal-vessels-lineup.com</li>
                    </ul>
                </div>
                
                <div style="background: #fef3c7; padding: 20px; border-radius: 8px; border-left: 4px solid #f59e0b; margin: 20px 0;">
                    <h3 style="color: #d97706; margin: 0 0 15px 0;">📈 Benefícios Operacionais</h3>
                    <ul style="line-height: 1.6; color: #374151; margin: 0; padding-left: 20px;">
                        <li>Redução significativa do tempo de coordenação de navios</li>
                        <li>Transparência total no processo de atracação</li>
                        <li>Conformidade regulatória automática (Decreto 89/2019)</li>
                        <li>Otimização da utilização do berço único</li>
                        <li>Rastreamento preciso de operações de descarga</li>
                        <li>Melhoria na comunicação com agentes marítimos</li>
                        <li>Relatórios automáticos para gestão superior</li>
                        <li>Alertas preventivos para condições adversas</li>
                    </ul>
                </div>
                
                <div style="background: #fdf2f8; padding: 20px; border-radius: 8px; border-left: 4px solid #ec4899; margin: 20px 0;">
                    <h3 style="color: #be185d; margin: 0 0 15px 0;">🎯 Principais Destaques</h3>
                    <ul style="line-height: 1.6; color: #374151; margin: 0; padding-left: 20px;">
                        <li><strong>Sistema de Priorização IMOPETRO:</strong> Conformidade automática com Decreto 89/2019</li>
                        <li><strong>Regras de Atracação 2:1:</strong> Algoritmo inteligente para navios trânsito e combinados</li>
                        <li><strong>Monitoramento Ambiental:</strong> Dados de maré e clima em tempo real</li>
                        <li><strong>Relatórios Automáticos:</strong> Geração e envio mensal de relatórios em PDF</li>
                        <li><strong>Interface Responsiva:</strong> Otimizada para dispositivos móveis e ambiente marítimo</li>
                        <li><strong>Controle de Acesso:</strong> Sistema seguro com permissões granulares</li>
                    </ul>
                </div>
                
                <div style="text-align: center; background: #e0f2fe; padding: 20px; border-radius: 8px; margin: 20px 0;">
                    <h3 style="color: #0277bd; margin: 0 0 10px 0;">🌐 Acesso ao Sistema</h3>
                    <p style="color: #374151; margin: 0; font-size: 16px;">
                        Sistema disponível em: <br>
                        <strong style="color: #1e40af; font-size: 18px;">https://beiraoilterminal-vessels-lineup.com</strong>
                    </p>
                </div>
                
                <div style="text-align: center; color: #9ca3af; font-size: 12px; border-top: 1px solid #e5e7eb; padding-top: 20px;">
                    <p style="margin: 0;">Este relatório foi gerado automaticamente pelo sistema de gestão portuária</p>
                    <p style="margin: 5px 0 0 0;">CFM-EP | Terminal Petrolífero da Beira | 2025</p>
                    <p style="margin: 5px 0 0 0;">Para suporte técnico, contate o administrador do sistema</p>
                </div>
            </div>
        </div>
      `;
      
      const success = await sendEmail({
        to: 'manuel.antonio@cfm.co.mz',
        from: 'noreply@beiraoilterminal.com',
        subject: 'Relatório Completo de Funcionalidades - Sistema de Gestão Portuária',
        html: emailHtml
      });
      
      if (success) {
        console.log('Relatório do sistema enviado com sucesso para manuel.antonio@cfm.co.mz');
        res.json({ 
          message: "System capabilities report sent successfully to manuel.antonio@cfm.co.mz"
        });
      } else {
        res.status(500).json({ message: "Failed to send system report" });
      }
    } catch (error) {
      console.error("Error sending system report:", error);
      res.status(500).json({ message: "Failed to send system report" });
    }
  });

  // Alternative report delivery - direct content endpoint
  app.get('/api/system/report-content', async (req, res) => {
    try {
      const reportData = {
        title: "Sistema de Gestão de Navios - Terminal Petrolífero da Beira",
        subtitle: "Relatório Completo de Funcionalidades e Capacidades do Sistema",
        generatedAt: new Date().toLocaleString('pt-BR'),
        version: "2.0",
        url: "https://beiraoilterminal-vessels-lineup.com",
        
        sections: {
          gestaoNavios: {
            title: "Gestão de Navios",
            items: [
              "Registro completo de navios com informações detalhadas (nome, contra marca, calado, agentes)",
              "Sistema de status em tempo real (esperado, na barra, próximo a atracar, no cais, partido)",
              "Controle de tipos de operação (Trânsito e Combinado) com regras de atracação 2:1",
              "Sistema de priorização IMOPETRO conforme Decreto 89/2019",
              "Gestão de parcelas de carga com volumes e destinatários",
              "Rastreamento de progresso de descarga em tempo real"
            ]
          },
          priorizacao: {
            title: "Sistema de Priorização Inteligente",
            items: [
              "Prioridade absoluta para navios IMOPETRO (Decreto 89/2019)",
              "Regra de atracação 2:1: 2 navios trânsito + 1 navio combinado",
              "Ordenação cronológica por data de chegada na barra",
              "Badges visuais diferenciando tipos de operação (trânsito verde, combinado roxo)",
              "Alertas de prioridade em tempo real"
            ]
          },
          atracacao: {
            title: "Controle de Atracação",
            items: [
              "Registro de tempos de atracação (primeira e última amarra)",
              "Verificação automática de condições baseada no calado e maré",
              "Sistema de confirmação de instruções de descarga via email",
              "Controle de berço com status de manutenção programada",
              "Fluxo automatizado de movimentação entre status"
            ]
          },
          monitoramento: {
            title: "Monitoramento Ambiental",
            items: [
              "Monitoramento de marés em tempo real para Porto da Beira",
              "Previsões de maré com análise harmônica (constituintes M2, S2, N2)",
              "Alertas meteorológicos para ventos acima de 25 nós",
              "Dados de temperatura, umidade e pressão atmosférica",
              "Integração com APIs meteorológicas (OpenWeather e Open-Meteo)"
            ]
          },
          especificacoes: {
            title: "Especificações Técnicas",
            items: [
              "Frontend: React 18 com TypeScript, Tailwind CSS, shadcn/ui",
              "Backend: Express.js com TypeScript, Drizzle ORM",
              "Banco de Dados: PostgreSQL (Neon Serverless)",
              "Autenticação: Replit Auth com OpenID Connect",
              "Email: SendGrid para notificações profissionais",
              "Relatórios: Chart.js e Puppeteer para relatórios PDF",
              "Clima/Marés: APIs OpenWeather e Open-Meteo",
              "Deployment: Replit com domínio beiraoilterminal-vessels-lineup.com"
            ]
          },
          beneficios: {
            title: "Benefícios Operacionais",
            items: [
              "Redução significativa do tempo de coordenação de navios",
              "Transparência total no processo de atracação",
              "Conformidade regulatória automática (Decreto 89/2019)",
              "Otimização da utilização do berço único",
              "Rastreamento preciso de operações de descarga",
              "Melhoria na comunicação com agentes marítimos",
              "Relatórios automáticos para gestão superior",
              "Alertas preventivos para condições adversas"
            ]
          },
          destaques: {
            title: "Principais Destaques",
            items: [
              "Sistema de Priorização IMOPETRO: Conformidade automática com Decreto 89/2019",
              "Regras de Atracação 2:1: Algoritmo inteligente para navios trânsito e combinados",
              "Monitoramento Ambiental: Dados de maré e clima em tempo real",
              "Relatórios Automáticos: Geração e envio mensal de relatórios em PDF",
              "Interface Responsiva: Otimizada para dispositivos móveis e ambiente marítimo",
              "Controle de Acesso: Sistema seguro com permissões granulares"
            ]
          }
        }
      };
      
      res.json(reportData);
    } catch (error) {
      console.error("Error generating report content:", error);
      res.status(500).json({ message: "Failed to generate report content" });
    }
  });

  // Admin user management routes
  app.get('/api/admin/users', isAuthenticated, isAdmin, async (req, res) => {
    try {
      const users = await storage.getAllUsers();
      res.json(users);
    } catch (error) {
      console.error("Error fetching users:", error);
      res.status(500).json({ message: "Failed to fetch users" });
    }
  });

  app.put('/api/admin/users/:id', isAuthenticated, isAdmin, async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      const updateData = req.body;
      
      const updatedUser = await storage.updateUser(userId, updateData);
      res.json(updatedUser);
    } catch (error) {
      console.error("Error updating user:", error);
      res.status(500).json({ message: "Failed to update user" });
    }
  });

  app.delete('/api/admin/users/:id', isAuthenticated, isAdmin, async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      
      await storage.deleteUser(userId);
      res.json({ message: "User deleted successfully" });
    } catch (error) {
      console.error("Error deleting user:", error);
      res.status(500).json({ message: "Failed to delete user" });
    }
  });

  // User approval system routes
  // Get all users - for admin interface
  app.get('/api/users', isAuthenticated, async (req: any, res) => {
    try {
      const user = req.user;
      if (!user) {
        return res.status(401).json({ message: "Unauthorized" });
      }

      const currentUser = await storage.getUser(user.id);
      if (!currentUser) {
        return res.status(401).json({ message: "User not found" });
      }

      // Only admin and developer can view all users
      if (!['admin', 'desenvolvedor'].includes(currentUser.role)) {
        return res.status(403).json({ message: "Access denied" });
      }

      const allUsers = await storage.getAllUsers();
      res.json(allUsers);
    } catch (error) {
      console.error("Error fetching users:", error);
      res.status(500).json({ message: "Failed to fetch users" });
    }
  });

  app.get('/api/admin/pending-registrations', isAuthenticated, async (req: any, res) => {
    try {
      // Check if user can approve registrations
      const user = req.user;
      if (!user) {
        return res.status(401).json({ message: "Unauthorized" });
      }

      const currentUser = await storage.getUser(user.id);
      if (!currentUser) {
        return res.status(401).json({ message: "User not found" });
      }

      // Get pending users based on role permissions
      const pendingUsers = await storage.getUsersByStatus('pending');
      
      // Filter based on approval hierarchy
      let filteredUsers = [];
      if (currentUser.role === 'desenvolvedor') {
        // Developers can approve admins and all other types
        filteredUsers = pendingUsers.filter(u => 
          u.role === 'admin' || 
          u.role === 'gestores' || 
          u.role === 'ctos' || 
          u.role === 'line_up' || 
          u.role === 'agente_navio'
        );
      } else if (currentUser.role === 'admin') {
        // Admins can approve all except developers and other admins
        filteredUsers = pendingUsers.filter(u => 
          u.role !== 'desenvolvedor' && 
          u.role !== 'admin'
        );
      }

      res.json(filteredUsers);
    } catch (error) {
      console.error("Error fetching pending registrations:", error);
      res.status(500).json({ message: "Failed to fetch pending registrations" });
    }
  });

  // User approval routes - both PATCH and POST for compatibility
  app.patch('/api/users/:id/approve', isAuthenticated, async (req: any, res) => {
    try {
      const userId = parseInt(req.params.id);
      const { adminPassword } = req.body;
      const currentUser = req.user;

      if (!currentUser) {
        return res.status(401).json({ message: "Unauthorized" });
      }

      // Verify admin password
      const correctPassword = 'BeiraTerm2025!';
      if (adminPassword !== correctPassword) {
        return res.status(403).json({ message: "Senha administrativa incorreta" });
      }

      // Get the pending user
      const pendingUser = await storage.getUser(userId);
      if (!pendingUser || pendingUser.status !== 'pending') {
        return res.status(404).json({ message: "Usuário pendente não encontrado" });
      }

      // Check if current user can approve this role
      const authorizer = await storage.getUser(currentUser.id);
      if (!authorizer) {
        return res.status(401).json({ message: "Autorizador não encontrado" });
      }

      let canApprove = false;
      if (authorizer.role === 'desenvolvedor') {
        canApprove = true; // Developer can approve all
      } else if (authorizer.role === 'admin') {
        canApprove = !['desenvolvedor', 'admin'].includes(pendingUser.role);
      }

      if (!canApprove) {
        return res.status(403).json({ message: "Sem permissão para aprovar esta função" });
      }

      // Approve the user
      await storage.approveUser(userId);
      
      res.json({ message: "Usuário aprovado com sucesso" });
    } catch (error) {
      console.error("Error approving user:", error);
      res.status(500).json({ message: "Erro ao aprovar usuário" });
    }
  });

  // PATCH route for user approval
  app.patch('/api/users/:id/approve', isAuthenticated, async (req: any, res) => {
    try {
      const userId = parseInt(req.params.id);
      const { adminPassword } = req.body;
      const currentUser = req.user;

      if (!currentUser) {
        return res.status(401).json({ message: "Unauthorized" });
      }

      // Verify admin password
      const correctPassword = 'BeiraTerm2025!';
      if (adminPassword !== correctPassword) {
        return res.status(403).json({ message: "Senha administrativa incorreta" });
      }

      // Get the pending user
      const pendingUser = await storage.getUser(userId);
      if (!pendingUser || pendingUser.status !== 'pending') {
        return res.status(404).json({ message: "Usuário pendente não encontrado" });
      }

      // Check if current user can approve this role
      const authorizer = await storage.getUser(currentUser.id);
      if (!authorizer) {
        return res.status(401).json({ message: "Autorizador não encontrado" });
      }

      let canApprove = false;
      if (authorizer.role === 'desenvolvedor') {
        canApprove = true; // Developer can approve all
      } else if (authorizer.role === 'admin') {
        canApprove = !['desenvolvedor', 'admin'].includes(pendingUser.role);
      }

      if (!canApprove) {
        return res.status(403).json({ message: "Sem permissão para aprovar esta função" });
      }

      // Approve the user
      await storage.approveUser(userId);
      
      res.json({ message: "Usuário aprovado com sucesso" });
    } catch (error) {
      console.error("Error approving user:", error);
      res.status(500).json({ message: "Erro ao aprovar usuário" });
    }
  });

  app.post('/api/admin/users/:id/approve', isAuthenticated, async (req: any, res) => {
    try {
      const userId = parseInt(req.params.id);
      const { adminPassword } = req.body;
      const currentUser = req.user;

      if (!currentUser) {
        return res.status(401).json({ message: "Unauthorized" });
      }

      // Verify admin password
      const correctPassword = 'BeiraTerm2025!';
      if (adminPassword !== correctPassword) {
        return res.status(403).json({ message: "Senha administrativa incorreta" });
      }

      // Get the pending user
      const pendingUser = await storage.getUser(userId);
      if (!pendingUser || pendingUser.status !== 'pending') {
        return res.status(404).json({ message: "Usuário pendente não encontrado" });
      }

      // Check if current user can approve this role
      const authorizer = await storage.getUser(currentUser.id);
      if (!authorizer) {
        return res.status(401).json({ message: "Autorizador não encontrado" });
      }

      let canApprove = false;
      if (authorizer.role === 'desenvolvedor') {
        canApprove = ['admin', 'gestores', 'ctos', 'line_up', 'agente_navio'].includes(pendingUser.role);
      } else if (authorizer.role === 'admin') {
        canApprove = !['desenvolvedor', 'admin'].includes(pendingUser.role);
      }

      if (!canApprove) {
        return res.status(403).json({ message: "Sem permissão para aprovar este tipo de usuário" });
      }

      // Approve user and assign permissions
      const userPermissions = getUserPermissions(pendingUser.role as any);
      
      await storage.updateUser(userId, { 
        status: 'active',
        permissions: userPermissions
      });

      res.json({ message: "Usuário aprovado com sucesso" });
    } catch (error) {
      console.error("Error approving user:", error);
      res.status(500).json({ message: "Failed to approve user" });
    }
  });

  // User rejection routes - both PATCH and POST for compatibility
  app.patch('/api/users/:id/reject', isAuthenticated, async (req: any, res) => {
    try {
      const userId = parseInt(req.params.id);
      const { adminPassword } = req.body;
      const currentUser = req.user;

      if (!currentUser) {
        return res.status(401).json({ message: "Unauthorized" });
      }

      // Verify admin password
      const correctPassword = 'BeiraTerm2025!';
      if (adminPassword !== correctPassword) {
        return res.status(403).json({ message: "Senha administrativa incorreta" });
      }

      // Get the pending user
      const pendingUser = await storage.getUser(userId);
      if (!pendingUser || pendingUser.status !== 'pending') {
        return res.status(404).json({ message: "Usuário pendente não encontrado" });
      }

      // Check if current user can reject this role
      const authorizer = await storage.getUser(currentUser.id);
      if (!authorizer) {
        return res.status(401).json({ message: "Autorizador não encontrado" });
      }

      let canReject = false;
      if (authorizer.role === 'desenvolvedor') {
        canReject = true; // Developer can reject all
      } else if (authorizer.role === 'admin') {
        canReject = !['desenvolvedor', 'admin'].includes(pendingUser.role);
      }

      if (!canReject) {
        return res.status(403).json({ message: "Sem permissão para rejeitar esta função" });
      }

      // Reject the user
      await storage.rejectUser(userId);
      
      res.json({ message: "Usuário rejeitado com sucesso" });
    } catch (error) {
      console.error("Error rejecting user:", error);
      res.status(500).json({ message: "Erro ao rejeitar usuário" });
    }
  });

  // PATCH route for user rejection
  app.patch('/api/users/:id/reject', isAuthenticated, async (req: any, res) => {
    try {
      const userId = parseInt(req.params.id);
      const { adminPassword } = req.body;
      const currentUser = req.user;

      if (!currentUser) {
        return res.status(401).json({ message: "Unauthorized" });
      }

      // Verify admin password
      const correctPassword = 'BeiraTerm2025!';
      if (adminPassword !== correctPassword) {
        return res.status(403).json({ message: "Senha administrativa incorreta" });
      }

      // Get the pending user
      const pendingUser = await storage.getUser(userId);
      if (!pendingUser || pendingUser.status !== 'pending') {
        return res.status(404).json({ message: "Usuário pendente não encontrado" });
      }

      // Check if current user can reject this role
      const authorizer = await storage.getUser(currentUser.id);
      if (!authorizer) {
        return res.status(401).json({ message: "Autorizador não encontrado" });
      }

      let canReject = false;
      if (authorizer.role === 'desenvolvedor') {
        canReject = true; // Developer can reject all
      } else if (authorizer.role === 'admin') {
        canReject = !['desenvolvedor', 'admin'].includes(pendingUser.role);
      }

      if (!canReject) {
        return res.status(403).json({ message: "Sem permissão para rejeitar esta função" });
      }

      // Reject the user
      await storage.rejectUser(userId);
      
      res.json({ message: "Usuário rejeitado com sucesso" });
    } catch (error) {
      console.error("Error rejecting user:", error);
      res.status(500).json({ message: "Erro ao rejeitar usuário" });
    }
  });

  app.post('/api/admin/users/:id/reject', isAuthenticated, async (req: any, res) => {
    try {
      const userId = parseInt(req.params.id);
      const { adminPassword } = req.body;
      const currentUser = req.user;

      if (!currentUser) {
        return res.status(401).json({ message: "Unauthorized" });
      }

      // Verify admin password
      const correctPassword = 'BeiraTerm2025!';
      if (adminPassword !== correctPassword) {
        return res.status(403).json({ message: "Senha administrativa incorreta" });
      }

      // Get the pending user
      const pendingUser = await storage.getUser(userId);
      if (!pendingUser || pendingUser.status !== 'pending') {
        return res.status(404).json({ message: "Usuário pendente não encontrado" });
      }

      // Check if current user can reject this role
      const authorizer = await storage.getUser(currentUser.id);
      if (!authorizer) {
        return res.status(401).json({ message: "Autorizador não encontrado" });
      }

      let canReject = false;
      if (authorizer.role === 'desenvolvedor') {
        canReject = ['admin', 'gestores', 'ctos', 'line_up', 'agente_navio'].includes(pendingUser.role);
      } else if (authorizer.role === 'admin') {
        canReject = !['desenvolvedor', 'admin'].includes(pendingUser.role);
      }

      if (!canReject) {
        return res.status(403).json({ message: "Sem permissão para rejeitar este tipo de usuário" });
      }

      // Reject user
      await storage.updateUser(userId, { status: 'rejected' });

      res.json({ message: "Usuário rejeitado com sucesso" });
    } catch (error) {
      console.error("Error rejecting user:", error);
      res.status(500).json({ message: "Failed to reject user" });
    }
  });

  // Advanced Discharge Control System Routes
  
  // Create discharge record for a parcel
  app.post('/api/ships/:id/discharge-records', isAuthenticated, requirePermission(Permission.UPDATE_DISCHARGE), async (req: any, res) => {
    try {
      const shipId = parseInt(req.params.id);
      const userId = req.user?.id;
      const recordData = { ...req.body, shipId, recordedBy: userId };
      
      const record = await storage.createDischargeRecord(recordData);
      res.status(201).json(record);
    } catch (error) {
      console.error("Error creating discharge record:", error);
      res.status(500).json({ message: "Failed to create discharge record" });
    }
  });

  // Update discharge record (rate, volumes, etc.)
  app.patch('/api/discharge-records/:id', isAuthenticated, requirePermission(Permission.UPDATE_DISCHARGE), async (req: any, res) => {
    try {
      const recordId = parseInt(req.params.id);
      const updates = req.body;
      
      const record = await storage.updateDischargeRecord(recordId, updates);
      res.json(record);
    } catch (error) {
      console.error("Error updating discharge record:", error);
      res.status(500).json({ message: "Failed to update discharge record" });
    }
  });

  // Add stop to discharge record (line displacement, parcel change, completion)
  app.post('/api/discharge-records/:id/stops', isAuthenticated, requirePermission(Permission.UPDATE_DISCHARGE), async (req: any, res) => {
    try {
      const recordId = parseInt(req.params.id);
      const { stopType, timestamp } = req.body;
      
      const record = await storage.addDischargeStop(recordId, stopType, timestamp);
      res.json(record);
    } catch (error) {
      console.error("Error adding discharge stop:", error);
      res.status(500).json({ message: "Failed to add discharge stop" });
    }
  });

  // Get discharge records for a ship
  app.get('/api/ships/:id/discharge-records', isAuthenticated, async (req, res) => {
    try {
      const shipId = parseInt(req.params.id);
      const records = await storage.getDischargeRecords(shipId);
      res.json(records);
    } catch (error) {
      console.error("Error fetching discharge records:", error);
      res.status(500).json({ message: "Failed to fetch discharge records" });
    }
  });

  // Discharge Planning API
  app.get("/api/discharge-plan", isAuthenticated, async (req, res) => {
    try {
      const { dischargePlanningService } = await import("./dischargePlanningService");
      const plan = await dischargePlanningService.generateDischargePlan();
      res.json(plan);
    } catch (error) {
      console.error("Error generating discharge plan:", error);
      res.status(500).json({ message: "Falha ao gerar plano de descarga" });
    }
  });

  // Comprehensive discharge planning with intelligent ordering
  app.get('/api/discharge-planning/generate', isAuthenticated, async (req, res) => {
    try {
      const ships = await storage.getShips();
      const shipsWithInstructions = ships.filter(ship => 
        ['at_bar', 'next_to_berth'].includes(ship.status) && 
        ship.hasDischargeInstructions
      );
      
      // Apply priority ordering using discharge planning service
      const { dischargePlanningService } = await import("./dischargePlanningService");
      const prioritizedShips = dischargePlanningService.applyPriorityOrdering(shipsWithInstructions);
      
      // Calculate discharge estimates for each ship
      const planningResults = [];
      let currentTime = new Date();
      let totalDuration = 0;
      
      for (let i = 0; i < Math.min(prioritizedShips.length, 5); i++) {
        const ship = prioritizedShips[i];
        const parcels = await storage.getCargoParcelsByShip(ship.id);
        
        // Calculate total volume and estimated duration
        let totalVolume = 0;
        const parcelPlans = parcels.map((parcel: any) => {
          const volume = parseFloat(parcel.volumeMT || '0');
          totalVolume += volume;
          
          // Get discharge rate based on product type
          const rate = dischargePlanningService.getDischargeRate(parcel.product);
          const duration = volume / rate; // hours
          
          return {
            product: parcel.product,
            volumeMT: parcel.volumeMT,
            estimatedDuration: duration
          };
        });
        
        const shipDuration = Math.max(24, parcelPlans.reduce((sum: number, p: any) => sum + p.estimatedDuration, 0)); // minimum 24h
        
        // Determine priority information
        let priority = {
          level: ship.operationType || 'Trânsito',
          reason: 'Sequência normal',
          badge: ship.operationType || 'Trânsito'
        };
        
        if (ship.operationType === 'Nacional') {
          priority = {
            level: 'Nacional',
            reason: 'Operação Nacional - Prioridade 1',
            badge: 'Nacional - Prioridade 1'
          };
        } else if (ship.operationType === 'LPG' || parcels.some((p: any) => p.product === 'LPG')) {
          priority = {
            level: 'LPG',
            reason: 'Produto LPG - Prioridade 2',
            badge: 'LPG - Prioridade 2'
          };
        } else if (ship.operationType === 'Combinada') {
          priority = {
            level: 'Combinada',
            reason: 'Operação Combinada - Regra 2:1',
            badge: 'Combinada'
          };
        }
        
        const estimatedBerthingTime = new Date(currentTime.getTime() + (totalDuration * 60 * 60 * 1000));
        const estimatedCompletionTime = new Date(estimatedBerthingTime.getTime() + (shipDuration * 60 * 60 * 1000));
        
        planningResults.push({
          id: ship.id,
          name: ship.name,
          operationType: ship.operationType || 'Trânsito',
          position: i + 1,
          estimatedBerthingTime: estimatedBerthingTime.toISOString(),
          estimatedCompletionTime: estimatedCompletionTime.toISOString(),
          totalDuration: shipDuration,
          parcels: parcelPlans,
          priority: priority
        });
        
        totalDuration += shipDuration;
        currentTime = estimatedCompletionTime;
      }
      
      // Generate recommendations
      const recommendations = [];
      
      if (prioritizedShips.length > 5) {
        recommendations.push(`Existem ${prioritizedShips.length - 5} navios adicionais aguardando na fila além dos próximos 5.`);
      }
      
      const nacionalCount = prioritizedShips.filter(s => s.operationType === 'Nacional').length;
      const lpgCount = prioritizedShips.filter(s => s.operationType === 'LPG' || 
        (s.parcels && s.parcels.some((p: any) => p.product === 'LPG'))).length;
      
      if (nacionalCount > 2) {
        recommendations.push(`Atenção: ${nacionalCount} operações Nacionais na fila. Considere otimizar recursos para atender prioridade.`);
      }
      
      if (lpgCount > 1) {
        recommendations.push(`${lpgCount} navios com LPG na fila. Verificar disponibilidade de equipamentos especializados.`);
      }
      
      if (totalDuration > 120) { // more than 5 days
        recommendations.push('Fila extensa detectada. Considere acelerar operações ou comunicar atrasos aos agentes.');
      }
      
      const dischargePlan = {
        nextFiveShips: planningResults,
        totalEstimatedDays: totalDuration / 24,
        averageDischargeDays: planningResults.length > 0 ? (totalDuration / 24) / planningResults.length : 0,
        recommendations: recommendations
      };
      
      res.json(dischargePlan);
    } catch (error) {
      console.error("Error generating discharge plan:", error);
      res.status(500).json({ message: "Failed to generate discharge plan" });
    }
  });

  app.post("/api/discharge-plan/update-rate", isAuthenticated, async (req, res) => {
    try {
      const { shipId, parcelId, actualRate } = req.body;
      const { dischargePlanningService } = await import("./dischargePlanningService");
      await dischargePlanningService.updateActualRates(shipId, parcelId, actualRate);
      res.json({ success: true });
    } catch (error) {
      console.error("Error updating discharge rate:", error);
      res.status(500).json({ message: "Falha ao atualizar rate de descarga" });
    }
  });

  // Custom rates API
  app.get("/api/custom-rates", isAuthenticated, async (req, res) => {
    try {
      const rates = await storage.getCustomDischargeRates();
      res.json(rates);
    } catch (error) {
      console.error("Error fetching custom rates:", error);
      res.status(500).json({ message: "Falha ao buscar rates customizados" });
    }
  });

  app.post("/api/custom-rates", isAuthenticated, async (req, res) => {
    try {
      const userId = (req.user as any)?.id;
      if (!userId) {
        return res.status(401).json({ message: "User not authenticated" });
      }

      const rateData = {
        ...req.body,
        createdBy: parseInt(userId)
      };

      const rate = await storage.createCustomDischargeRate(rateData);
      res.json(rate);
    } catch (error) {
      console.error("Error creating custom rate:", error);
      res.status(500).json({ message: "Falha ao criar rate customizado" });
    }
  });

  app.get("/api/custom-rates/ship/:shipId", isAuthenticated, async (req, res) => {
    try {
      const shipId = parseInt(req.params.shipId);
      const rates = await storage.getCustomRatesForShip(shipId);
      res.json(rates);
    } catch (error) {
      console.error("Error fetching ship custom rates:", error);
      res.status(500).json({ message: "Falha ao buscar rates do navio" });
    }
  });

  app.delete("/api/custom-rates/:id", isAuthenticated, async (req, res) => {
    try {
      const rateId = parseInt(req.params.id);
      const success = await storage.deleteCustomDischargeRate(rateId);
      
      if (success) {
        res.json({ success: true });
      } else {
        res.status(404).json({ message: "Rate não encontrado" });
      }
    } catch (error) {
      console.error("Error deleting custom rate:", error);
      res.status(500).json({ message: "Falha ao deletar rate customizado" });
    }
  });

  // SWAP Operations Routes
  app.get("/api/swap-operations", async (req, res) => {
    try {
      const swapOps = await storage.getSwapOperations();
      res.json(swapOps);
    } catch (error) {
      console.error("Error fetching swap operations:", error);
      res.status(500).json({ message: "Failed to fetch swap operations" });
    }
  });

  app.post("/api/swap-operations", requireOperatorOrAdmin, async (req, res) => {
    try {
      const swapOp = await storage.createSwapOperation(req.body);
      res.status(201).json(swapOp);
    } catch (error) {
      console.error("Error creating swap operation:", error);
      res.status(500).json({ message: "Failed to create swap operation" });
    }
  });

  app.patch("/api/swap-operations/:id", requireOperatorOrAdmin, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const swapOp = await storage.updateSwapOperation(id, req.body);
      res.json(swapOp);
    } catch (error) {
      console.error("Error updating swap operation:", error);
      res.status(500).json({ message: "Failed to update swap operation" });
    }
  });

  app.delete("/api/swap-operations/:id", requireOperatorOrAdmin, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      await storage.deleteSwapOperation(id);
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting swap operation:", error);
      res.status(500).json({ message: "Failed to delete swap operation" });
    }
  });

  // Operational Statistics routes
  app.get('/api/operational-stats/:shipId', isAuthenticated, async (req, res) => {
    try {
      const shipId = parseInt(req.params.shipId);
      const stats = await storage.getOperationalStats(shipId);
      res.json(stats);
    } catch (error) {
      console.error('Error fetching operational stats:', error);
      res.status(500).json({ message: 'Failed to fetch operational stats' });
    }
  });

  app.post('/api/operational-stats', requireOperatorOrAdmin, async (req, res) => {
    try {
      console.log('Creating operational stats with data:', req.body);
      const stats = await storage.createOperationalStats(req.body);
      console.log('Operational stats created successfully:', stats);
      res.status(201).json(stats);
    } catch (error) {
      console.error('Error creating operational stats:', error);
      res.status(500).json({ message: 'Failed to create operational stats', error: error instanceof Error ? error instanceof Error ? error.message : String(error) : String(error) });
    }
  });

  app.get('/api/hourly-discharge/:shipId', isAuthenticated, async (req, res) => {
    try {
      const shipId = parseInt(req.params.shipId);
      const data = await storage.getHourlyDischarge(shipId);
      res.json(data);
    } catch (error) {
      console.error('Error fetching hourly discharge:', error);
      res.status(500).json({ message: 'Failed to fetch hourly discharge' });
    }
  });

  app.post('/api/hourly-discharge', requireOperatorOrAdmin, async (req, res) => {
    try {
      const { shipId, parcelId, pressure, rate } = req.body;
      
      const parcel = await storage.getParcelById(parcelId);
      if (!parcel) {
        return res.status(404).json({ message: 'Parcel not found' });
      }

      // Get previous records for this parcel to calculate totals
      const previousRecords = await storage.getHourlyDischarge(shipId);
      const parcelRecords = previousRecords.filter(r => r.parcelId === parcelId);
      const totalDischarged = parcelRecords.reduce((sum, r) => sum + parseFloat(r.volumeHour.toString()), 0) + rate;
      const remaining = Math.max(0, parseFloat(parcel.volumeMT.toString()) - totalDischarged);
      const estimatedHours = rate > 0 ? remaining / rate : null;

      const dischargeData = {
        shipId,
        parcelId,
        pressure,
        rate,
        volumeHour: rate.toString(),
        totalDischarged: totalDischarged.toString(),
        remaining: remaining.toString(),
        estimatedHours: estimatedHours?.toString() || null
      };

      const record = await storage.createHourlyDischarge(dischargeData);
      res.status(201).json(record);
    } catch (error) {
      console.error('Error creating hourly discharge:', error);
      res.status(500).json({ message: 'Failed to create hourly discharge record' });
    }
  });

  // ADVANCED AI ASSISTANT API - Following specified requirements
  app.post('/api/advanced-ai/session', async (req, res) => {
    try {
      const { userRole = 'visitor', language = 'pt' } = req.body;
      const userId = req.user?.id?.toString() || null;
      
      console.log('[AdvancedAI] Creating session for user:', { userRole, language, userId });

      const { advancedAIService } = await import('./advancedAIService');
      const sessionId = await advancedAIService.createSession(userId, userRole, language);
      
      res.json({ 
        sessionId,
        capabilities: advancedAIService.getUserCapabilities(userRole),
        status: 'active'
      });
    } catch (error) {
      console.error('[AdvancedAI] Session creation error:', error);
      res.status(500).json({ 
        error: 'Failed to create session',
        details: error instanceof Error ? error.message : String(error) 
      });
    }
  });

  app.post('/api/advanced-ai/chat', async (req, res) => {
    try {
      const { sessionId, message, userRole = 'visitor', language = 'pt' } = req.body;
      
      if (!sessionId || !message) {
        return res.status(400).json({ error: 'Session ID and message required' });
      }

      console.log('[AdvancedAI] Processing message:', { 
        sessionId: sessionId.substring(0, 8) + '...', 
        messageLength: message.length, 
        userRole 
      });

      const { advancedAIService } = await import('./advancedAIService');
      const response = await advancedAIService.processMessage(sessionId, message, userRole, language);
      
      res.json(response);
    } catch (error) {
      console.error('[AdvancedAI] Message processing error:', error);
      res.status(500).json({ 
        error: 'Failed to process message',
        details: error instanceof Error ? error.message : String(error) 
      });
    }
  });

  app.post('/api/advanced-ai/speech-to-text', async (req, res) => {
    try {
      const { audioData, language = 'pt' } = req.body;
      
      if (!audioData) {
        return res.status(400).json({ error: 'Audio data required' });
      }

      const { advancedAIService } = await import('./advancedAIService');
      const transcription = await advancedAIService.speechToText(audioData, language);
      
      res.json({ transcription, language });
    } catch (error) {
      console.error('[AdvancedAI] Speech processing error:', error);
      res.status(500).json({ 
        error: 'Failed to process speech',
        details: error instanceof Error ? error.message : String(error) 
      });
    }
  });

  app.post('/api/advanced-ai/text-to-speech', async (req, res) => {
    try {
      const { text, language = 'pt' } = req.body;
      
      if (!text) {
        return res.status(400).json({ error: 'Text required' });
      }

      const { advancedAIService } = await import('./advancedAIService');
      const audioUrl = await advancedAIService.textToSpeech(text, language);
      
      res.json({ audioUrl, language });
    } catch (error) {
      console.error('[AdvancedAI] TTS error:', error);
      res.status(500).json({ 
        error: 'Failed to generate speech',
        details: error instanceof Error ? error.message : String(error) 
      });
    }
  });

  app.get('/api/advanced-ai/session/:sessionId/history', async (req, res) => {
    try {
      const { sessionId } = req.params;
      
      const { advancedAIService } = await import('./advancedAIService');
      const history = await advancedAIService.getChatHistory(sessionId);
      
      res.json({ history, count: history.length });
    } catch (error) {
      console.error('[AdvancedAI] History retrieval error:', error);
      res.status(500).json({ 
        error: 'Failed to get chat history',
        details: error instanceof Error ? error.message : String(error) 
      });
    }
  });

  app.post('/api/advanced-ai/session/:sessionId/end', async (req, res) => {
    try {
      const { sessionId } = req.params;
      const { satisfactionRating, escalationReason } = req.body;
      
      const { advancedAIService } = await import('./advancedAIService');
      await advancedAIService.endSession(sessionId, satisfactionRating, escalationReason);
      
      res.json({ success: true, message: 'Session ended successfully' });
    } catch (error) {
      console.error('[AdvancedAI] Session end error:', error);
      res.status(500).json({ 
        error: 'Failed to end session',
        details: error instanceof Error ? error.message : String(error) 
      });
    }
  });

  // BASIC AI ASSISTANT API - Simple interaction system
  app.post('/api/basic-ai/session', async (req, res) => {
    try {
      const { userRole = 'visitor', language = 'pt' } = req.body;
      const userId = req.user?.id?.toString() || null;
      
      console.log('[BasicAI] Creating session for user:', { userRole, language, userId });

      const { basicAIService } = await import('./basicAIService');
      const sessionId = await basicAIService.createSession(userId, userRole, language);
      
      res.json({ 
        sessionId,
        status: 'active',
        message: language === 'en' ? 
          'Basic AI assistant ready to help!' :
          'Assistente IA básico pronto para ajudar!'
      });
    } catch (error) {
      console.error('[BasicAI] Session creation error:', error);
      res.status(500).json({ 
        error: 'Failed to create session',
        details: error instanceof Error ? error.message : String(error) 
      });
    }
  });

  app.post('/api/basic-ai/chat', async (req, res) => {
    try {
      const { sessionId, message, userRole = 'visitor', language = 'pt' } = req.body;
      
      if (!sessionId || !message) {
        return res.status(400).json({ error: 'Session ID and message required' });
      }

      console.log('[BasicAI] Processing message:', { 
        sessionId: sessionId.substring(0, 8) + '...', 
        messageLength: message.length, 
        userRole 
      });

      const { basicAIService } = await import('./basicAIService');
      const response = await basicAIService.processMessage(sessionId, message, userRole, language);
      
      res.json(response);
    } catch (error) {
      console.error('[BasicAI] Message processing error:', error);
      res.status(500).json({ 
        error: 'Failed to process message',
        details: error instanceof Error ? error.message : String(error) 
      });
    }
  });

  app.get('/api/basic-ai/session/:sessionId/history', async (req, res) => {
    try {
      const { sessionId } = req.params;
      
      const { basicAIService } = await import('./basicAIService');
      const history = await basicAIService.getChatHistory(sessionId);
      
      res.json({ history, count: history.length });
    } catch (error) {
      console.error('[BasicAI] History retrieval error:', error);
      res.status(500).json({ 
        error: 'Failed to get chat history',
        details: error instanceof Error ? error.message : String(error) 
      });
    }
  });

  app.post('/api/assistant/session/end', async (req, res) => {
    try {
      const { sessionId, satisfactionRating, escalationReason } = req.body;
      
      const { virtualAssistantService } = await import('./assistantService');
      await virtualAssistantService.endChatSession(sessionId, satisfactionRating, escalationReason);
      
      res.json({ success: true });
    } catch (error) {
      console.error('Error ending chat session:', error);
      res.status(500).json({ message: 'Failed to end session' });
    }
  });

  app.get('/api/assistant/history/:sessionId', async (req, res) => {
    try {
      const { sessionId } = req.params;
      
      const { virtualAssistantService } = await import('./assistantService');
      const history = await virtualAssistantService.getChatHistory(sessionId);
      
      res.json(history);
    } catch (error) {
      console.error('Error fetching chat history:', error);
      res.status(500).json({ message: 'Failed to fetch chat history' });
    }
  });

  // Voice processing routes
  app.post('/api/assistant/speech-to-text', async (req, res) => {
    try {
      const { audioData, language } = req.body;
      
      if (!audioData) {
        return res.status(400).json({ message: 'Audio data required' });
      }

      // Convert base64 audio to buffer
      const audioBuffer = Buffer.from(audioData, 'base64');
      
      const { virtualAssistantService } = await import('./assistantService');
      const transcription = await virtualAssistantService.speechToText(audioBuffer, language);
      
      res.json({ transcription });
    } catch (error) {
      console.error('Error processing speech-to-text:', error);
      res.status(500).json({ message: 'Failed to process speech' });
    }
  });

  app.post('/api/assistant/text-to-speech', async (req, res) => {
    try {
      const { text, language } = req.body;
      
      if (!text) {
        return res.status(400).json({ message: 'Text required' });
      }

      const { virtualAssistantService } = await import('./assistantService');
      const audioUrl = await virtualAssistantService.textToSpeech(text, language);
      
      res.json({ audioUrl });
    } catch (error) {
      console.error('Error processing text-to-speech:', error);
      res.status(500).json({ message: 'Failed to generate speech' });
    }
  });

  // Serve temporary audio files
  app.use('/temp-audio', express.static(path.join(process.cwd(), 'temp-audio')));

  // Gemini AI Routes
  app.post('/api/gemini-ai/session', async (req, res) => {
    try {
      const { userRole, language } = req.body;
      const userId = req.user?.id || null;
      
      const sessionId = await geminiAIService.createSession(userId?.toString() || null, userRole, language);
      res.json({ sessionId });
    } catch (error) {
      console.error('Gemini AI session creation error:', error);
      res.status(500).json({ message: 'Failed to create Gemini AI session' });
    }
  });

  app.post('/api/gemini-ai/message', async (req, res) => {
    try {
      const { sessionId, message, userRole, language } = req.body;
      
      if (!sessionId || !message) {
        return res.status(400).json({ message: 'SessionId and message are required' });
      }

      const response = await geminiAIService.processMessage(sessionId, message, userRole, language);
      res.json(response);
    } catch (error) {
      console.error('Gemini AI message processing error:', error);
      res.status(500).json({ message: 'Failed to process message' });
    }
  });

  app.delete('/api/gemini-ai/session/:sessionId', async (req, res) => {
    try {
      const { sessionId } = req.params;
      await geminiAIService.endSession(sessionId);
      res.json({ success: true });
    } catch (error) {
      console.error('Gemini AI session end error:', error);
      res.status(500).json({ message: 'Failed to end session' });
    }
  });

  app.get('/api/gemini-ai/history/:sessionId', async (req, res) => {
    try {
      const { sessionId } = req.params;
      const history = await geminiAIService.getChatHistory(sessionId);
      res.json(history);
    } catch (error) {
      console.error('Gemini AI history error:', error);
      res.status(500).json({ message: 'Failed to get chat history' });
    }
  });

  // Speech-to-Text endpoint
  app.post('/api/gemini-ai/speech-to-text', async (req, res) => {
    try {
      const { audioData, language } = req.body;
      
      if (!audioData) {
        return res.status(400).json({ message: 'Audio data is required' });
      }

      const text = await geminiAIService.speechToText(audioData, language || 'pt');
      res.json({ text });
    } catch (error) {
      console.error('Speech-to-text error:', error);
      res.status(500).json({ message: 'Failed to process speech' });
    }
  });

  // Text-to-Speech endpoint
  app.post('/api/gemini-ai/text-to-speech', async (req, res) => {
    try {
      const { text, language } = req.body;
      
      if (!text) {
        return res.status(400).json({ message: 'Text is required' });
      }

      const audioUrl = await geminiAIService.textToSpeech(text, language || 'pt');
      res.json({ audioUrl });
    } catch (error) {
      console.error('Text-to-speech error:', error);
      res.status(500).json({ message: 'Failed to generate speech' });
    }
  });

  // Emergency berthing interface when main UI fails
  app.get('/emergency-berth', (req, res) => {
    res.send(`
      <!DOCTYPE html>
      <html>
      <head>
          <title>Atracação de Emergência - Beira Oil Terminal</title>
          <meta charset="UTF-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <style>
              body {
                  font-family: Arial, sans-serif;
                  background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
                  color: white;
                  padding: 20px;
                  margin: 0;
                  min-height: 100vh;
              }
              .container {
                  max-width: 900px;
                  margin: 0 auto;
                  background: rgba(255,255,255,0.1);
                  padding: 30px;
                  border-radius: 15px;
                  backdrop-filter: blur(10px);
                  box-shadow: 0 8px 32px rgba(0,0,0,0.3);
              }
              h1 {
                  text-align: center;
                  margin-bottom: 30px;
                  font-size: 28px;
              }
              .emergency-notice {
                  background: rgba(255,193,7,0.2);
                  border: 2px solid #ffc107;
                  border-radius: 8px;
                  padding: 15px;
                  margin-bottom: 30px;
                  text-align: center;
              }
              .ship-card {
                  background: rgba(255,255,255,0.15);
                  margin: 20px 0;
                  padding: 25px;
                  border-radius: 12px;
                  border: 1px solid rgba(255,255,255,0.2);
              }
              .ship-name {
                  font-size: 24px;
                  font-weight: bold;
                  margin-bottom: 10px;
                  color: #ffd700;
              }
              .ship-info {
                  margin-bottom: 15px;
                  opacity: 0.9;
              }
              .action-btn {
                  background: #28a745;
                  color: white;
                  border: none;
                  padding: 12px 24px;
                  border-radius: 8px;
                  cursor: pointer;
                  font-size: 16px;
                  margin: 5px;
                  transition: all 0.3s;
                  font-weight: bold;
              }
              .action-btn:hover {
                  background: #218838;
                  transform: translateY(-2px);
                  box-shadow: 0 4px 8px rgba(0,0,0,0.2);
              }
              .berth-form {
                  background: rgba(0,0,0,0.3);
                  padding: 25px;
                  border-radius: 10px;
                  margin-top: 20px;
                  border: 1px solid rgba(255,255,255,0.1);
              }
              .form-group {
                  margin: 15px 0;
              }
              label {
                  display: block;
                  margin-bottom: 8px;
                  font-weight: bold;
                  font-size: 14px;
              }
              input[type="datetime-local"] {
                  width: 100%;
                  padding: 12px;
                  border: 1px solid #ddd;
                  border-radius: 6px;
                  background: rgba(255,255,255,0.95);
                  color: #333;
                  font-size: 16px;
                  box-sizing: border-box;
              }
              .btn-success { background: #28a745; }
              .btn-danger { background: #dc3545; }
              .btn-secondary { background: #6c757d; }
              .btn-success:hover { background: #218838; }
              .btn-danger:hover { background: #c82333; }
              .btn-secondary:hover { background: #5a6268; }
              
              .message {
                  padding: 15px;
                  border-radius: 8px;
                  margin: 20px 0;
                  font-weight: bold;
                  text-align: center;
              }
              .message.success {
                  background: rgba(40,167,69,0.2);
                  border: 1px solid #28a745;
                  color: #d4edda;
              }
              .message.error {
                  background: rgba(220,53,69,0.2);
                  border: 1px solid #dc3545;
                  color: #f8d7da;
              }
              
              .return-btn {
                  text-align: center;
                  margin-top: 40px;
              }
          </style>
      </head>
      <body>
          <div class="container">
              <h1>⚓ Interface de Emergência - Atracação de Navios</h1>
              
              <div class="emergency-notice">
                  <strong>⚠️ SISTEMA DE EMERGÊNCIA ATIVO</strong><br>
                  Interface alternativa para registro de atracação quando o sistema principal não responde aos cliques.
              </div>
              
              <div id="ships-container">
                  <!-- Ships will be loaded dynamically -->
              </div>
              
              <div id="message-container"></div>
              
              <div class="return-btn">
                  <button class="action-btn btn-secondary" onclick="returnToMain()">
                      🔄 Voltar ao Sistema Principal
                  </button>
              </div>
          </div>

          <script>
              async function loadShips() {
                  try {
                      const response = await fetch('/api/ships');
                      const ships = await response.json();
                      
                      // Filter ships that can be berthed
                      const availableShips = ships.filter(ship => 
                          (ship.status === 'at_bar' && ship.hasDischargeInstructions) || 
                          ship.status === 'next_to_berth'
                      );
                      
                      const container = document.getElementById('ships-container');
                      
                      if (availableShips.length === 0) {
                          container.innerHTML = '<div class="ship-card"><div class="ship-name">Nenhum navio disponível para atracação</div></div>';
                          return;
                      }
                      
                      container.innerHTML = availableShips.map(ship => \`
                          <div class="ship-card">
                              <div class="ship-name">\${ship.name}</div>
                              <div class="ship-info">
                                  <strong>Status:</strong> \${getStatusLabel(ship.status)}<br>
                                  <strong>Contramark:</strong> \${ship.countermark || 'N/A'}<br>
                                  <strong>Operação:</strong> \${ship.operationType || 'N/A'}
                              </div>
                              
                              <button class="action-btn" onclick="toggleBerthingForm('\${ship.name}', \${ship.id})">
                                  ⚓ Registrar Atracação
                              </button>
                              
                              <div id="berth-form-\${ship.name}" class="berth-form" style="display:none;">
                                  <h3>📋 Registro de Atracação - \${ship.name}</h3>
                                  <div class="form-group">
                                      <label>🕐 Data/Hora do Primeiro Cabo:</label>
                                      <input type="datetime-local" id="first-rope-\${ship.name}">
                                  </div>
                                  <div class="form-group">
                                      <label>🕐 Data/Hora do Último Cabo:</label>
                                      <input type="datetime-local" id="last-rope-\${ship.name}">
                                  </div>
                                  <button class="action-btn btn-success" onclick="confirmBerthing('\${ship.name}', \${ship.id})">
                                      ✅ Confirmar Atracação
                                  </button>
                                  <button class="action-btn btn-danger" onclick="hideBerthingForm('\${ship.name}')">
                                      ❌ Cancelar
                                  </button>
                              </div>
                          </div>
                      \`).join('');
                      
                  } catch (error) {
                      console.error('Error loading ships:', error);
                      showMessage('❌ Erro ao carregar navios: ' + error instanceof Error ? error.message : String(error), 'error');
                  }
              }
              
              function getStatusLabel(status) {
                  switch(status) {
                      case 'at_bar': return 'Na Barra';
                      case 'next_to_berth': return 'Próximo a Atracar';
                      case 'at_berth': return 'Atracado';
                      case 'departed': return 'Partiu';
                      default: return status;
                  }
              }
              
              function toggleBerthingForm(shipName, shipId) {
                  const form = document.getElementById('berth-form-' + shipName);
                  
                  if (form.style.display === 'none') {
                      // Hide all other forms
                      document.querySelectorAll('[id^="berth-form-"]').forEach(f => f.style.display = 'none');
                      
                      // Show this form
                      form.style.display = 'block';
                      
                      // Set current date/time
                      const now = new Date();
                      now.setMinutes(now.getMinutes() - now.getTimezoneOffset());
                      const localDateTime = now.toISOString().slice(0, 16);
                      
                      document.getElementById('first-rope-' + shipName).value = localDateTime;
                      document.getElementById('last-rope-' + shipName).value = localDateTime;
                  } else {
                      form.style.display = 'none';
                  }
              }
              
              function hideBerthingForm(shipName) {
                  document.getElementById('berth-form-' + shipName).style.display = 'none';
              }
              
              async function confirmBerthing(shipName, shipId) {
                  const firstRope = document.getElementById('first-rope-' + shipName).value;
                  const lastRope = document.getElementById('last-rope-' + shipName).value;
                  
                  if (!firstRope || !lastRope) {
                      showMessage('❌ Por favor, preencha ambas as datas/horas.', 'error');
                      return;
                  }
                  
                  try {
                      showMessage('⏳ Processando atracação...', 'success');
                      
                      // Register berthing data
                      const berthingResponse = await fetch('/api/berthing', {
                          method: 'POST',
                          headers: { 'Content-Type': 'application/json' },
                          body: JSON.stringify({
                              shipId: shipId,
                              firstRopeTime: firstRope,
                              lastRopeTime: lastRope
                          })
                      });
                      
                      if (!berthingResponse.ok) {
                          throw new Error('Erro ao registrar atracação');
                      }
                      
                      // Update ship status
                      const statusResponse = await fetch(\`/api/ships/\${shipId}\`, {
                          method: 'PATCH',
                          headers: { 'Content-Type': 'application/json' },
                          body: JSON.stringify({ status: 'at_berth' })
                      });
                      
                      if (!statusResponse.ok) {
                          throw new Error('Erro ao atualizar status do navio');
                      }
                      
                      showMessage(\`✅ Atracação de \${shipName} registrada com sucesso! Recarregando em 3 segundos...\`, 'success');
                      hideBerthingForm(shipName);
                      
                      // Reload page in 3 seconds
                      setTimeout(() => {
                          location.reload();
                      }, 3000);
                      
                  } catch (error) {
                      showMessage(\`❌ Erro: \${error instanceof Error ? error.message : String(error)}\`, 'error');
                  }
              }
              
              function showMessage(text, type) {
                  const container = document.getElementById('message-container');
                  container.innerHTML = \`<div class="message \${type}">\${text}</div>\`;
                  
                  if (type === 'success') {
                      setTimeout(() => {
                          container.innerHTML = '';
                      }, 8000);
                  }
              }
              
              function returnToMain() {
                  window.location.href = '/';
              }
              
              // Load ships on page load
              loadShips();
          </script>
      </body>
      </html>
    `);
  });

  // User authentication endpoint for frontend
  app.get('/api/user', isAuthenticated, async (req: any, res) => {
    try {
      const user = await storage.getUserById(req.user.id);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Get user permissions
      const permissions = await storage.getUserPermissions(user.id);
      
      res.json({
        id: user.id,
        username: user.username,
        role: user.role,
        email: user.email,
        firstName: user.firstName,
        lastName: user.lastName,
        permissions: permissions.map(p => p.permission)
      });
    } catch (error) {
      console.error("Error fetching current user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Register communication routes
  registerCommunicationRoutes(app);

  // Agent Registration and Authentication Routes
  app.post('/api/agents/register', async (req, res) => {
    try {
      const agentData = registerAgentSchema.parse(req.body);
      const { confirmPassword, ...insertData } = agentData;
      
      // Hash password
      const hashedPassword = await bcrypt.hash(insertData.password, 10);
      const finalData = { ...insertData, password: hashedPassword };
      
      const agent = await storage.createAgent(finalData);
      res.status(201).json({ 
        message: "Registro enviado para aprovação",
        agentId: agent.id 
      });
    } catch (error) {
      console.error("Error registering agent:", error);
      res.status(500).json({ message: "Falha no registro" });
    }
  });

  app.post('/api/agents/login', async (req, res) => {
    try {
      const { username, password } = req.body;
      const agent = await storage.getAgentByUsername(username);
      
      if (!agent || !await bcrypt.compare(password, agent.password)) {
        return res.status(401).json({ message: "Credenciais inválidas" });
      }
      
      if (agent.status !== 'approved') {
        return res.status(403).json({ 
          message: agent.status === 'pending' 
            ? "Conta pendente de aprovação" 
            : "Conta rejeitada" 
        });
      }

      // Update last login
      await storage.updateAgent(agent.id, { lastLogin: new Date() });
      
      // Store agent session (simplified)
      (req.session as any).agentId = agent.id;
      
      res.json({ message: "Login realizado com sucesso", agent });
    } catch (error) {
      console.error("Error in agent login:", error);
      res.status(500).json({ message: "Erro no login" });
    }
  });

  // Rota adicional para compatibilidade com o frontend
  app.post('/api/auth/agent-login', async (req, res) => {
    try {
      const { username, password } = req.body;
      
      // Verificar se existe agente com esse username
      const agent = await storage.getAgentByUsername(username);
      
      if (!agent) {
        return res.status(401).json({ message: "Credenciais inválidas" });
      }
      
      // Verificar senha
      const isValidPassword = await bcrypt.compare(password, agent.password);
      if (!isValidPassword) {
        return res.status(401).json({ message: "Credenciais inválidas" });
      }
      
      // Verificar status de aprovação
      if (agent.status !== 'approved') {
        return res.status(403).json({ 
          message: agent.status === 'pending' 
            ? "Conta pendente de aprovação" 
            : "Conta rejeitada" 
        });
      }

      // Atualizar último login
      await storage.updateAgent(agent.id, { lastLogin: new Date() });
      
      // Criar sessão do agente compatível com isAuthenticated
      (req.session as any).agentId = agent.id;
      (req.session as any).agentRole = 'agente_navio';
      (req.session as any).userId = agent.id; // Para compatibilidade com isAuthenticated
      (req.session as any).user = { 
        id: agent.id, 
        role: 'agente_navio',
        username: agent.username
      };
      
      res.json({ 
        message: "Login realizado com sucesso", 
        agent: {
          id: agent.id,
          username: agent.username,
          companyName: agent.firstName || agent.username,
          contactName: agent.email,
          role: 'agente_navio'
        }
      });
    } catch (error) {
      console.error("Error in agent auth login:", error);
      res.status(500).json({ message: "Erro interno do servidor" });
    }
  });

  app.post('/api/agents/logout', async (req, res) => {
    try {
      req.session.destroy((err) => {
        if (err) {
          return res.status(500).json({ message: "Erro no logout" });
        }
        res.json({ message: "Logout realizado" });
      });
    } catch (error) {
      console.error("Error in agent logout:", error);
      res.status(500).json({ message: "Erro no logout" });
    }
  });

  // Agent middleware
  const requireAgent = async (req: any, res: any, next: any) => {
    if (!req.session.agentId) {
      return res.status(401).json({ message: "Agent authentication required" });
    }
    
    const agent = await storage.getAgentById(req.session.agentId);
    if (!agent || agent.status !== 'approved') {
      return res.status(403).json({ message: "Agent not approved" });
    }
    
    req.agent = agent;
    next();
  };

  // Agent Info Routes
  app.get('/api/agents/current', requireAgent, (req: any, res) => {
    res.json(req.agent);
  });

  // Rota específica para navios do agente (compatível com dashboard)
  app.get('/api/agent/ships', async (req: any, res) => {
    try {
      const ships = await storage.getShips();
      res.json(ships);
    } catch (error) {
      console.error("Error fetching ships for agent:", error);
      res.status(500).json({ message: "Failed to fetch ships" });
    }
  });

  // Rota para navios ordenados (dashboard do agente)
  app.get('/api/agent/ships/ordered', async (req: any, res) => {
    try {
      const ships = await storage.getShips();
      // Aplicar ordenação por prioridade conforme regras do sistema
      const orderedShips = ships.sort((a, b) => {
        // IMOPETRO priority
        if (a.cargoAgent?.includes('IMOPETRO') && !b.cargoAgent?.includes('IMOPETRO')) return -1;
        if (!a.cargoAgent?.includes('IMOPETRO') && b.cargoAgent?.includes('IMOPETRO')) return 1;
        
        // Nacional priority
        if (a.operationType === 'nacional' && b.operationType !== 'nacional') return -1;
        if (a.operationType !== 'nacional' && b.operationType === 'nacional') return 1;
        
        // Then by arrival date
        return new Date(a.arrivalDateTime).getTime() - new Date(b.arrivalDateTime).getTime();
      });
      
      res.json(orderedShips);
    } catch (error) {
      console.error("Error fetching ordered ships:", error);
      res.status(500).json({ message: "Failed to fetch ordered ships" });
    }
  });

  // Middleware to check if user is Agent do Navio
  const requireAgentRole = (req: any, res: any, next: any) => {
    // Verificar sessão de agente ou usuário com role agente_navio
    const isAgent = (req.session?.agentRole === 'agente_navio') || 
                   (req.user?.role === 'agente_navio') ||
                   (req.session?.user?.role === 'agente_navio');
    
    if (!isAgent) {
      return res.status(403).json({ message: "Acesso restrito a Agentes do Navio" });
    }
    next();
  };

  // Routes para Agente do Navio
  
  // Middleware específico para autenticação de agente
  const authenticateAgent = (req: any, res: any, next: any) => {
    console.log("Agent auth check - Session:", req.session);
    console.log("Agent auth check - Headers:", req.headers.cookie);
    
    const agentId = req.session?.agentId;
    const agentRole = req.session?.agentRole;
    
    console.log("Agent auth - agentId:", agentId, "agentRole:", agentRole);
    
    if (!agentId || agentRole !== 'agente_navio') {
      console.log("Agent auth failed - unauthorized");
      return res.status(401).json({ message: "Unauthorized" });
    }
    
    // Definir req.user para compatibilidade
    req.user = { 
      id: agentId, 
      role: 'agente_navio',
      username: req.session.user?.username
    };
    
    console.log("Agent auth success - user:", req.user);
    next();
  };

  // 1. Adicionar navio aos Previstos a Chegar
  app.post('/api/agent/ships/add', authenticateAgent, async (req: any, res) => {
    try {
      const shipData = req.body;
      console.log("Agent adding ship:", shipData);
      
      const newShip = await storage.createShip({
        name: shipData.name,
        countermark: shipData.countermark,
        arrivalDateTime: new Date(shipData.expectedArrivalDate),
        draft: shipData.draft.toString(),
        shipAgent: shipData.shipAgent || "Agente Marítimo",
        shipAgentEmail: shipData.shipAgentEmail,
        cargoAgent: shipData.cargoAgent || "Agente de Carga", 
        cargoAgentEmail: shipData.cargoAgentEmail,
        shipowner: shipData.armador,
        cargoType: shipData.cargoType,
        cargoDestination: shipData.destinoCarga,
        operationType: shipData.operationType,
        status: "expected",
        hasDischargeInstructions: false,
        berthingConfirmed: false
      });

      res.status(201).json({ 
        message: "Navio adicionado com sucesso aos Previstos a Chegar",
        ship: newShip 
      });
    } catch (error) {
      console.error("Error adding ship by agent:", error);
      res.status(500).json({ message: "Falha ao adicionar navio" });
    }
  });

  // 2. Confirmar chegada do navio na barra
  app.post('/api/agent/ships/:id/confirm-arrival', isAuthenticated, requireAgentRole, async (req: any, res) => {
    try {
      const shipId = parseInt(req.params.id);
      const { arrivalDateTime } = req.body;
      
      console.log("Agent confirming ship arrival:", { shipId, arrivalDateTime });
      
      const updatedShip = await storage.updateShipStatus(shipId, {
        status: "at_bar",
        berthingConfirmed: true
      });

      res.json({ 
        message: "Chegada confirmada - navio movido para Sem Instrução",
        ship: updatedShip 
      });
    } catch (error) {
      console.error("Error confirming ship arrival:", error);
      res.status(500).json({ message: "Falha ao confirmar chegada" });
    }
  });

  // 3. Confirmar instruções de descarga (manual ou com anexo)
  app.post('/api/agent/ships/:id/confirm-instructions', isAuthenticated, requireAgentRole, async (req: any, res) => {
    try {
      const shipId = parseInt(req.params.id);
      const { confirmationType, attachmentData, confirmationNotes } = req.body;
      
      console.log("Agent confirming instructions:", { shipId, confirmationType });
      
      // Verificar se navio está no status correto
      const ship = await storage.getShipById(shipId);
      if (!ship || ship.status !== "at_bar") {
        return res.status(400).json({ message: "Navio deve estar na barra para confirmar instruções" });
      }

      // Atualizar navio para ter instruções
      const updatedShip = await storage.updateShipStatus(shipId, {
        hasDischargeInstructions: true
      });

      // Enviar email automático para doptp03@gmail.com
      const emailData = {
        to: "doptp03@gmail.com",
        from: "noreply@beiraoilterminal.com", 
        subject: `Confirmação de Instruções - ${ship.name}`,
        html: `
          <h2>Confirmação de Instruções de Descarga</h2>
          <h3>Navio: ${ship.name} (${ship.countermark})</h3>
          <p><strong>Tipo de Operação:</strong> ${ship.operationType}</p>
          <p><strong>Armador:</strong> ${ship.shipowner}</p>
          <p><strong>Confirmado em:</strong> ${new Date().toLocaleString('pt-BR', { timeZone: 'Africa/Maputo' })}</p>
          ${confirmationNotes ? `<p><strong>Observações:</strong> ${confirmationNotes}</p>` : ''}
          <p><em>Confirmação enviada automaticamente pelo sistema.</em></p>
        `,
        text: `Confirmação de Instruções - ${ship.name}\nConfirmado em: ${new Date().toLocaleString('pt-BR', { timeZone: 'Africa/Maputo' })}`
      };

      // Usar o serviço de comunicação existente
      try {
        const emailSent = await communicationService.sendEmail(emailData);
        console.log("Instruction email sent:", emailSent);
      } catch (emailError) {
        console.warn("Failed to send email:", emailError);
      }

      res.json({ 
        message: "Instruções confirmadas - navio movido para Com Instrução e email enviado",
        ship: updatedShip 
      });
    } catch (error) {
      console.error("Error confirming instructions:", error);
      res.status(500).json({ message: "Falha ao confirmar instruções" });
    }
  });

  // 4. Listar navios do agente
  app.get('/api/agent/ships', isAuthenticated, requireAgentRole, async (req: any, res) => {
    try {
      // Por enquanto retorna todos os navios - pode ser filtrado por agente futuramente
      const ships = await storage.getShips();
      
      res.json({
        ships: ships,
        message: "Lista de navios carregada"
      });
    } catch (error) {
      console.error("Error getting agent ships:", error);
      res.status(500).json({ message: "Falha ao carregar navios" });
    }
  });

  // 5. Obter navios ordenados com regra 2:1 (Nacional/LPG prioritário)
  app.get('/api/agent/ships/ordered', isAuthenticated, async (req: any, res) => {
    try {
      const ships = await storage.getShips();
      
      // Filtrar navios com instruções
      const shipsWithInstructions = ships.filter(ship => 
        ship.status === "at_bar" && ship.hasDischargeInstructions
      );

      // Separar por tipo de operação
      const nacionalShips = shipsWithInstructions.filter(ship => 
        ship.operationType?.toLowerCase() === 'nacional'
      );
      const lgpShips = shipsWithInstructions.filter(ship => 
        ship.operationType?.toLowerCase() === 'lgp'
      );
      const transitoShips = shipsWithInstructions.filter(ship => 
        ship.operationType?.toLowerCase() === 'trânsito' || ship.operationType?.toLowerCase() === 'transito'
      );
      const combinadaShips = shipsWithInstructions.filter(ship => 
        ship.operationType?.toLowerCase() === 'combinada'
      );

      // Aplicar regras de priorização
      const orderedShips = [];

      // 1. Nacional e LPG primeiro (prioridade imediata)
      orderedShips.push(...nacionalShips.sort((a, b) => 
        new Date(a.arrivalDateTime).getTime() - new Date(b.arrivalDateTime).getTime()
      ));
      
      orderedShips.push(...lgpShips.sort((a, b) => 
        new Date(a.arrivalDateTime).getTime() - new Date(b.arrivalDateTime).getTime()
      ));

      // 2. Aplicar regra 2:1 para Trânsito e Combinada
      const transitoSorted = transitoShips.sort((a, b) => 
        new Date(a.arrivalDateTime).getTime() - new Date(b.arrivalDateTime).getTime()
      );
      const combinadaSorted = combinadaShips.sort((a, b) => 
        new Date(a.arrivalDateTime).getTime() - new Date(b.arrivalDateTime).getTime()
      );

      let transitoIndex = 0;
      let combinadaIndex = 0;
      let transitoCount = 0;

      while (transitoIndex < transitoSorted.length || combinadaIndex < combinadaSorted.length) {
        // Adicionar até 2 navios de trânsito
        if (transitoIndex < transitoSorted.length && transitoCount < 2) {
          orderedShips.push(transitoSorted[transitoIndex]);
          transitoIndex++;
          transitoCount++;
        }
        
        // Se já adicionamos 2 trânsitos ou não há mais trânsitos, adicionar 1 combinada
        if ((transitoCount === 2 || transitoIndex >= transitoSorted.length) && combinadaIndex < combinadaSorted.length) {
          orderedShips.push(combinadaSorted[combinadaIndex]);
          combinadaIndex++;
          transitoCount = 0; // Reset contador
        }
        
        // Se não há mais combinadas mas ainda há trânsitos, continuar adicionando trânsitos
        if (combinadaIndex >= combinadaSorted.length && transitoIndex < transitoSorted.length) {
          orderedShips.push(transitoSorted[transitoIndex]);
          transitoIndex++;
        }
      }

      res.json({
        orderedShips: orderedShips,
        summary: {
          total: orderedShips.length,
          nacional: nacionalShips.length,
          lgp: lgpShips.length,
          transito: transitoShips.length,
          combinada: combinadaShips.length
        }
      });
    } catch (error) {
      console.error("Error getting ordered ships:", error);
      res.status(500).json({ message: "Falha ao obter navios ordenados" });
    }
  });

  // Predicted Arrivals Routes
  app.post('/api/agents/predictions', requireAgent, async (req: any, res) => {
    try {
      if (req.agent.permissionLevel !== 'ship_management') {
        return res.status(403).json({ message: "Permissão insuficiente" });
      }

      const predictionData = { ...req.body, agentId: req.agent.id };
      const prediction = await storage.createPredictedArrival(predictionData);
      
      res.status(201).json(prediction);
    } catch (error) {
      console.error("Error creating prediction:", error);
      res.status(500).json({ message: "Falha ao criar previsão" });
    }
  });

  app.get('/api/agents/predictions', requireAgent, async (req: any, res) => {
    try {
      const predictions = await storage.getPredictedArrivals(req.agent.id);
      res.json(predictions);
    } catch (error) {
      console.error("Error fetching predictions:", error);
      res.status(500).json({ message: "Falha ao buscar previsões" });
    }
  });

  app.put('/api/agents/predictions/:id/confirm', requireAgent, async (req: any, res) => {
    try {
      if (req.agent.permissionLevel !== 'ship_management') {
        return res.status(403).json({ message: "Permissão insuficiente" });
      }

      const predictionId = parseInt(req.params.id);
      const { arrivalDateTime, countermark } = req.body;
      
      // Confirm arrival
      const prediction = await storage.confirmPredictedArrival(
        predictionId, 
        new Date(arrivalDateTime), 
        countermark
      );
      
      // Convert to ship in main system
      const ship = await storage.convertPredictionToShip(predictionId);
      
      res.json({ prediction, ship });
    } catch (error) {
      console.error("Error confirming arrival:", error);
      res.status(500).json({ message: "Falha ao confirmar chegada" });
    }
  });

  // Admin routes for agent management
  app.get('/api/admin/agents', isAuthenticated, isAdmin, async (req, res) => {
    try {
      const agents = await storage.getAllAgents();
      res.json(agents);
    } catch (error) {
      console.error("Error fetching agents:", error);
      res.status(500).json({ message: "Falha ao buscar agentes" });
    }
  });

  app.put('/api/admin/agents/:id/approve', isAuthenticated, isAdmin, async (req, res) => {
    try {
      const agentId = parseInt(req.params.id);
      const { permissionLevel } = req.body;
      const adminId = (req.user as any).id;
      
      const agent = await storage.approveAgent(agentId, adminId, permissionLevel);
      res.json(agent);
    } catch (error) {
      console.error("Error approving agent:", error);
      res.status(500).json({ message: "Falha ao aprovar agente" });
    }
  });

  app.put('/api/admin/agents/:id/reject', isAuthenticated, isAdmin, async (req, res) => {
    try {
      const agentId = parseInt(req.params.id);
      const { reason } = req.body;
      const adminId = (req.user as any).id;
      
      const agent = await storage.rejectAgent(agentId, adminId, reason);
      res.json(agent);
    } catch (error) {
      console.error("Error rejecting agent:", error);
      res.status(500).json({ message: "Falha ao rejeitar agente" });
    }
  });

  // ============= DISCHARGE CONTROL SYSTEM ROUTES =============
  
  // Discharge Events Management
  app.post('/api/ships/:id/discharge-events', isAuthenticated, requireOperatorOrAdmin, async (req: any, res) => {
    try {
      const shipId = parseInt(req.params.id);
      const eventData = {
        shipId,
        recordedBy: req.user.id,
        ...req.body
      };
      
      const event = await storage.createDischargeEvent(eventData);
      res.status(201).json(event);
    } catch (error) {
      console.error("Error creating discharge event:", error);
      res.status(500).json({ message: "Falha ao criar evento de descarga" });
    }
  });

  app.get('/api/ships/:id/discharge-events', isAuthenticated, async (req, res) => {
    try {
      const shipId = parseInt(req.params.id);
      const events = await storage.getDischargeEvents(shipId);
      res.json(events);
    } catch (error) {
      console.error("Error fetching discharge events:", error);
      res.status(500).json({ message: "Falha ao buscar eventos de descarga" });
    }
  });

  app.patch('/api/discharge-events/:id', isAuthenticated, requireOperatorOrAdmin, async (req: any, res) => {
    try {
      const eventId = parseInt(req.params.id);
      const updates = req.body;
      
      const event = await storage.updateDischargeEvent(eventId, updates);
      res.json(event);
    } catch (error) {
      console.error("Error updating discharge event:", error);
      res.status(500).json({ message: "Falha ao atualizar evento de descarga" });
    }
  });

  // Parcel Discharge Control
  app.post('/api/ships/:id/parcel-discharge-control', isAuthenticated, requireOperatorOrAdmin, async (req: any, res) => {
    try {
      const shipId = parseInt(req.params.id);
      const controlData = {
        shipId,
        ...req.body
      };
      
      const control = await storage.createParcelDischargeControl(controlData);
      res.status(201).json(control);
    } catch (error) {
      console.error("Error creating parcel discharge control:", error);
      res.status(500).json({ message: "Falha ao criar controlo de descarga da parcela" });
    }
  });

  app.get('/api/ships/:id/parcel-discharge-control', isAuthenticated, async (req, res) => {
    try {
      const shipId = parseInt(req.params.id);
      const controls = await storage.getParcelDischargeControls(shipId);
      res.json(controls);
    } catch (error) {
      console.error("Error fetching parcel discharge controls:", error);
      res.status(500).json({ message: "Falha ao buscar controlos de descarga das parcelas" });
    }
  });

  // Hourly Discharge Records
  app.post('/api/ships/:id/hourly-discharge', isAuthenticated, requireOperatorOrAdmin, async (req: any, res) => {
    try {
      const shipId = parseInt(req.params.id);
      const recordData = {
        shipId,
        recordedBy: req.user.id,
        ...req.body,
        recordTime: new Date(req.body.recordTime)
      };
      
      const record = await storage.createHourlyDischargeRecord(recordData);
      res.status(201).json(record);
    } catch (error) {
      console.error("Error creating hourly discharge record:", error);
      res.status(500).json({ message: "Falha ao criar registro horário de descarga" });
    }
  });

  app.get('/api/ships/:id/hourly-discharge', isAuthenticated, async (req, res) => {
    try {
      const shipId = parseInt(req.params.id);
      const records = await storage.getHourlyDischargeRecords(shipId);
      res.json(records);
    } catch (error) {
      console.error("Error fetching hourly discharge records:", error);
      res.status(500).json({ message: "Falha ao buscar registros horários de descarga" });
    }
  });

  // Discharge Stoppages
  app.post('/api/ships/:id/discharge-stoppages', isAuthenticated, requireOperatorOrAdmin, async (req: any, res) => {
    try {
      const shipId = parseInt(req.params.id);
      const stoppageData = {
        shipId,
        recordedBy: req.user.id,
        ...req.body,
        startTime: new Date(req.body.startTime),
        endTime: req.body.endTime ? new Date(req.body.endTime) : null
      };
      
      const stoppage = await storage.createDischargeStoppage(stoppageData);
      res.status(201).json(stoppage);
    } catch (error) {
      console.error("Error creating discharge stoppage:", error);
      res.status(500).json({ message: "Falha ao criar parada de descarga" });
    }
  });

  app.get('/api/ships/:id/discharge-stoppages', isAuthenticated, async (req, res) => {
    try {
      const shipId = parseInt(req.params.id);
      const stoppages = await storage.getDischargeStoppages(shipId);
      res.json(stoppages);
    } catch (error) {
      console.error("Error fetching discharge stoppages:", error);
      res.status(500).json({ message: "Falha ao buscar paradas de descarga" });
    }
  });

  // Waiting Times
  app.post('/api/ships/:id/waiting-times', isAuthenticated, requireOperatorOrAdmin, async (req: any, res) => {
    try {
      const shipId = parseInt(req.params.id);
      const waitingData = {
        shipId,
        recordedBy: req.user.id,
        ...req.body
      };
      
      const waitingTime = await storage.createWaitingTime(waitingData);
      res.status(201).json(waitingTime);
    } catch (error) {
      console.error("Error creating waiting time:", error);
      res.status(500).json({ message: "Falha ao criar tempo de espera" });
    }
  });

  app.get('/api/ships/:id/waiting-times', isAuthenticated, async (req, res) => {
    try {
      const shipId = parseInt(req.params.id);
      const waitingTimes = await storage.getWaitingTimes(shipId);
      res.json(waitingTimes);
    } catch (error) {
      console.error("Error fetching waiting times:", error);
      res.status(500).json({ message: "Falha ao buscar tempos de espera" });
    }
  });

  // Comprehensive Discharge Report
  app.get('/api/ships/:id/discharge-report', isAuthenticated, async (req, res) => {
    try {
      const shipId = parseInt(req.params.id);
      const ship = await storage.getShip(shipId);
      
      if (!ship) {
        return res.status(404).json({ message: "Navio não encontrado" });
      }

      const events = await storage.getDischargeEvents(shipId);
      const parcelControls = await storage.getParcelDischargeControls(shipId);
      const hourlyRecords = await storage.getHourlyDischargeRecords(shipId);
      const stoppages = await storage.getDischargeStoppages(shipId);
      const waitingTimes = await storage.getWaitingTimes(shipId);
      const parcels = await storage.getCargoParcelsByShip(shipId);
      
      // Calculate operational statistics
      const totalStoppageTime = stoppages.reduce((total, stoppage) => 
        total + (stoppage.duration || 0), 0);
      
      const berthWaitingTime = waitingTimes
        .filter(wt => wt.waitingType === 'berth')
        .reduce((total, wt) => total + (wt.duration || 0), 0);
      
      const unberthWaitingTime = waitingTimes
        .filter(wt => wt.waitingType === 'unberth')
        .reduce((total, wt) => total + (wt.duration || 0), 0);
      
      const pilotWaitingTime = waitingTimes
        .filter(wt => wt.waitingType === 'pilot')
        .reduce((total, wt) => total + (wt.duration || 0), 0);

      const report = {
        ship: {
          name: ship.name,
          imo: ship.countermark,
          dwt: ship.cargoType,
          loa: ship.draft,
          agent: ship.shipAgent
        },
        products: parcels.map((parcel: any) => ({
          product: parcel.product,
          volume: parcel.volumeMT,
          density: parcel.density15C,
          receiver: parcel.receiver,
          owner: parcel.parcelOwner
        })),
        events: events.map(event => ({
          type: event.eventType,
          date: event.eventDate,
          commenceTime: event.commenceTime,
          completeTime: event.completeTime,
          notes: event.notes,
          pob: event.pob,
          status: event.status
        })),
        operationalTimes: {
          totalStoppageTime: `${Math.floor(totalStoppageTime / 60)}h ${totalStoppageTime % 60}m`,
          awaitingTimeToBerth: `${Math.floor(berthWaitingTime / 60)}h ${berthWaitingTime % 60}m`,
          awaitingTimeToUnberth: `${Math.floor(unberthWaitingTime / 60)}h ${unberthWaitingTime % 60}m`,
          awaitingPilot: `${Math.floor(pilotWaitingTime / 60)}h ${pilotWaitingTime % 60}m`
        },
        stoppagesByReason: {
          lineDisplacement: stoppages.filter(s => s.stoppageType === 'line_displacement').length,
          parcelChange: stoppages.filter(s => s.stoppageType === 'parcel_change').length,
          maintenance: stoppages.filter(s => s.stoppageType === 'maintenance').length,
          weather: stoppages.filter(s => s.stoppageType === 'weather').length,
          other: stoppages.filter(s => s.stoppageType === 'other').length
        },
        productivity: {
          averageRate: hourlyRecords.length > 0 
            ? hourlyRecords.reduce((sum, record) => sum + parseFloat(record.rate), 0) / hourlyRecords.length
            : 0,
          totalDischarged: hourlyRecords.length > 0
            ? Math.max(...hourlyRecords.map(record => parseFloat(record.totalDischarged)))
            : 0
        }
      };

      res.json(report);
    } catch (error) {
      console.error("Error generating discharge report:", error);
      res.status(500).json({ message: "Falha ao gerar relatório de descarga" });
    }
  });

  // ========== COMPREHENSIVE DISCHARGE CONTROL SYSTEM API ==========
  
  // Discharge Events API
  app.get('/api/ships/:id/discharge-events', isAuthenticated, async (req, res) => {
    try {
      const shipId = parseInt(req.params.id);
      const events = await storage.getDischargeEvents(shipId);
      res.json(events);
    } catch (error) {
      console.error('Error fetching discharge events:', error);
      res.status(500).json({ message: 'Failed to fetch discharge events' });
    }
  });

  app.post('/api/ships/:id/discharge-events', requireOperatorOrAdmin, async (req, res) => {
    try {
      const shipId = parseInt(req.params.id);
      const eventData = { ...req.body, shipId };
      const event = await storage.createDischargeEvent(eventData);
      res.status(201).json(event);
    } catch (error) {
      console.error('Error creating discharge event:', error);
      res.status(500).json({ message: 'Failed to create discharge event' });
    }
  });

  // Parcel Discharge Control API
  app.get('/api/ships/:id/parcel-discharge-control', isAuthenticated, async (req, res) => {
    try {
      const shipId = parseInt(req.params.id);
      const controls = await storage.getParcelDischargeControls(shipId);
      res.json(controls);
    } catch (error) {
      console.error('Error fetching parcel discharge control:', error);
      res.status(500).json({ message: 'Failed to fetch parcel discharge control' });
    }
  });

  app.post('/api/ships/:id/parcel-discharge-control', requireOperatorOrAdmin, async (req, res) => {
    try {
      const shipId = parseInt(req.params.id);
      const controlData = { ...req.body, shipId };
      const control = await storage.createParcelDischargeControl(controlData);
      res.status(201).json(control);
    } catch (error) {
      console.error('Error creating parcel discharge control:', error);
      res.status(500).json({ message: 'Failed to create parcel discharge control' });
    }
  });

  // Hourly Discharge Records API
  app.get('/api/ships/:id/hourly-discharge', isAuthenticated, async (req, res) => {
    try {
      const shipId = parseInt(req.params.id);
      const records = await storage.getHourlyDischargeRecords(shipId);
      res.json(records);
    } catch (error) {
      console.error('Error fetching hourly discharge records:', error);
      res.status(500).json({ message: 'Failed to fetch hourly discharge records' });
    }
  });

  app.post('/api/ships/:id/hourly-discharge', requireOperatorOrAdmin, async (req, res) => {
    try {
      const shipId = parseInt(req.params.id);
      const recordData = { ...req.body, shipId };
      const record = await storage.createHourlyDischargeRecord(recordData);
      res.status(201).json(record);
    } catch (error) {
      console.error('Error creating hourly discharge record:', error);
      res.status(500).json({ message: 'Failed to create hourly discharge record' });
    }
  });

  // Discharge Stoppages API
  app.get('/api/ships/:id/discharge-stoppages', isAuthenticated, async (req, res) => {
    try {
      const shipId = parseInt(req.params.id);
      const stoppages = await storage.getDischargeStoppages(shipId);
      res.json(stoppages);
    } catch (error) {
      console.error('Error fetching discharge stoppages:', error);
      res.status(500).json({ message: 'Failed to fetch discharge stoppages' });
    }
  });

  app.post('/api/ships/:id/discharge-stoppages', requireOperatorOrAdmin, async (req, res) => {
    try {
      const shipId = parseInt(req.params.id);
      const stoppageData = { ...req.body, shipId };
      const stoppage = await storage.createDischargeStoppage(stoppageData);
      res.status(201).json(stoppage);
    } catch (error) {
      console.error('Error creating discharge stoppage:', error);
      res.status(500).json({ message: 'Failed to create discharge stoppage' });
    }
  });

  // Waiting Times API
  app.get('/api/ships/:id/waiting-times', isAuthenticated, async (req, res) => {
    try {
      const shipId = parseInt(req.params.id);
      const waitingTimes = await storage.getWaitingTimes(shipId);
      res.json(waitingTimes);
    } catch (error) {
      console.error('Error fetching waiting times:', error);
      res.status(500).json({ message: 'Failed to fetch waiting times' });
    }
  });

  app.post('/api/ships/:id/waiting-times', requireOperatorOrAdmin, async (req, res) => {
    try {
      const shipId = parseInt(req.params.id);
      const waitingData = { ...req.body, shipId };
      const waitingTime = await storage.createWaitingTime(waitingData);
      res.status(201).json(waitingTime);
    } catch (error) {
      console.error('Error creating waiting time:', error);
      res.status(500).json({ message: 'Failed to create waiting time' });
    }
  });

  // Comprehensive Discharge Report API
  app.get('/api/ships/:id/discharge-report', isAuthenticated, async (req, res) => {
    try {
      const shipId = parseInt(req.params.id);
      
      // Get ship details
      const ship = await storage.getShip(shipId);
      if (!ship) {
        return res.status(404).json({ message: 'Ship not found' });
      }

      // Get all discharge-related data
      const [events, parcels, stoppages, waitingTimes] = await Promise.all([
        storage.getDischargeEvents(shipId),
        storage.getCargoParcelsByShip(shipId),
        storage.getDischargeStoppages(shipId),
        storage.getWaitingTimes(shipId)
      ]);

      // Calculate operational times
      const totalStoppageTime = stoppages.reduce((total: number, stoppage: any) => {
        if (stoppage.startTime && stoppage.endTime) {
          const duration = new Date(stoppage.endTime).getTime() - new Date(stoppage.startTime).getTime();
          return total + (duration / (1000 * 60 * 60)); // Convert to hours
        }
        return total;
      }, 0);

      const awaitingTimeToBerth = waitingTimes
        .filter((wt: any) => wt.waitingType === 'berth')
        .reduce((total: number, wt: any) => total + (wt.duration || 0), 0);

      const awaitingTimeToUnberth = waitingTimes
        .filter((wt: any) => wt.waitingType === 'unberth')
        .reduce((total: number, wt: any) => total + (wt.duration || 0), 0);

      const awaitingPilot = waitingTimes
        .filter((wt: any) => wt.waitingType === 'pilot')
        .reduce((total: number, wt: any) => total + (wt.duration || 0), 0);

      // Calculate productivity
      const totalDischarged = parcels.reduce((total: number, parcel: any) => {
        return total + parseFloat(parcel.volumeMT || '0');
      }, 0);

      const cargoCommenceEvent = events.find((e: any) => e.eventType === 'cargo_commence');
      const cargoCompleteEvent = events.find((e: any) => e.eventType === 'cargo_complete');
      
      let averageRate = 0;
      if (cargoCommenceEvent && cargoCompleteEvent) {
        const startTime = new Date(`${cargoCommenceEvent.eventDate}T${cargoCommenceEvent.commenceTime}`);
        const endTime = new Date(`${cargoCompleteEvent.eventDate}T${cargoCompleteEvent.completeTime}`);
        const hours = (endTime.getTime() - startTime.getTime()) / (1000 * 60 * 60);
        if (hours > 0) {
          averageRate = totalDischarged / hours;
        }
      }

      const report = {
        ship: {
          name: ship.name,
          imo: ship.countermark,
          dwt: ship.draft,
          loa: ship.draft, // Using draft as placeholder for LOA
          agent: ship.shipAgent
        },
        products: parcels.map((parcel: any) => ({
          product: parcel.product,
          volume: parcel.volumeMT,
          density: parcel.density15C,
          receiver: parcel.receiver,
          owner: parcel.owner
        })),
        operationalTimes: {
          totalStoppageTime: `${totalStoppageTime.toFixed(1)} horas`,
          awaitingTimeToBerth: `${awaitingTimeToBerth.toFixed(1)} horas`,
          awaitingTimeToUnberth: `${awaitingTimeToUnberth.toFixed(1)} horas`,
          awaitingPilot: `${awaitingPilot.toFixed(1)} horas`
        },
        productivity: {
          averageRate,
          totalDischarged
        },
        events,
        stoppages,
        waitingTimes
      };

      res.json(report);
    } catch (error) {
      console.error('Error generating discharge report:', error);
      res.status(500).json({ message: 'Failed to generate discharge report' });
    }
  });

  // Agreed Discharge Rate Management Routes
  app.get('/api/ships/:id/agreed-rate', isAuthenticated, async (req, res) => {
    try {
      const shipId = parseInt(req.params.id);
      const rate = await storage.getAgreedDischargeRate(shipId);
      res.json(rate || { agreedRate: 300, currentRate: 300 });
    } catch (error) {
      console.error("Error fetching agreed rate:", error);
      res.status(500).json({ message: "Failed to fetch agreed rate" });
    }
  });

  app.post('/api/ships/:id/agreed-rate', isAuthenticated, requireOperatorOrAdmin, async (req, res) => {
    try {
      const shipId = parseInt(req.params.id);
      const { agreedRate } = req.body;
      const userId = req.user?.id;

      if (!agreedRate || agreedRate <= 0) {
        return res.status(400).json({ message: "Invalid agreed rate" });
      }

      const rateData = {
        shipId,
        agreedRate,
        updatedBy: userId,
        updatedAt: new Date()
      };

      const rate = await storage.setAgreedDischargeRate(rateData);
      res.json(rate);
    } catch (error) {
      console.error("Error setting agreed rate:", error);
      res.status(500).json({ message: "Failed to set agreed rate" });
    }
  });

  app.put('/api/ships/:id/agreed-rate', isAuthenticated, requireOperatorOrAdmin, async (req, res) => {
    try {
      const shipId = parseInt(req.params.id);
      const { agreedRate, updatedBy, updatedAt } = req.body;
      const userId = req.user?.id;

      if (!agreedRate || agreedRate <= 0) {
        return res.status(400).json({ message: "Invalid agreed rate" });
      }

      const rateData = {
        shipId,
        agreedRate,
        updatedBy: updatedBy || userId,
        updatedAt: updatedAt ? new Date(updatedAt) : new Date()
      };

      const rate = await storage.setAgreedDischargeRate(rateData);
      res.json(rate);
    } catch (error) {
      console.error("Error updating agreed rate:", error);
      res.status(500).json({ message: "Failed to update agreed rate" });
    }
  });

  // Ship Report Operations
  app.get('/api/ships/:id/report', isAuthenticated, async (req, res) => {
    try {
      const shipId = parseInt(req.params.id);
      const reportData = await storage.getShipReport(shipId);
      res.json(reportData);
    } catch (error) {
      console.error('Error fetching ship report:', error);
      res.status(500).json({ message: 'Failed to fetch ship report' });
    }
  });

  app.post('/api/ships/:id/report', isAuthenticated, requireOperatorOrAdmin, async (req, res) => {
    try {
      const shipId = parseInt(req.params.id);
      const { reportData, updatedAt } = req.body;
      
      const savedReport = await storage.saveShipReport({
        shipId,
        reportData,
        updatedAt
      });
      
      res.json(savedReport);
    } catch (error) {
      console.error('Error saving ship report:', error);
      res.status(500).json({ message: 'Failed to save ship report' });
    }
  });

  app.get('/api/ships/:id/hourly-records', isAuthenticated, async (req, res) => {
    try {
      const shipId = parseInt(req.params.id);
      const records = await storage.getHourlyDischargeRecords(shipId);
      res.json(records);
    } catch (error) {
      console.error("Error fetching hourly records:", error);
      res.status(500).json({ message: "Failed to fetch hourly records" });
    }
  });

  // OPERATIONAL STATUS AND REAL-TIME DATA APIs
  app.get('/api/ships/:id/operational-status', isAuthenticated, async (req, res) => {
    try {
      const shipId = parseInt(req.params.id);
      
      // Get operational data from storage
      const operationalData = await storage.getOperationalStatusForShip(shipId);
      
      res.json(operationalData);
    } catch (error) {
      console.error('Error fetching operational status:', error);
      res.status(500).json({ message: 'Failed to fetch operational status' });
    }
  });

  // Get operational history for a ship
  app.get('/api/ships/:id/operational-history', isAuthenticated, async (req, res) => {
    try {
      const shipId = parseInt(req.params.id);
      
      const history = await storage.getOperationalHistoryForShip(shipId);
      
      res.json(history);
    } catch (error) {
      console.error('Error fetching operational history:', error);
      res.status(500).json({ message: 'Failed to fetch operational history' });
    }
  });

  // Update operational status with real-time data
  app.post('/api/ships/:id/operational-update', requireOperatorOrAdmin, async (req, res) => {
    try {
      const shipId = parseInt(req.params.id);
      const { pressure, dischargeRate, operationType = 'normal' } = req.body;
      
      const result = await storage.addOperationalRecord(shipId, {
        pressure,
        dischargeRate,
        operationType,
        recordedBy: req.user?.id || 1
      });

      res.json(result);
    } catch (error) {
      console.error('Error updating operational status:', error);
      res.status(500).json({ message: 'Failed to update operational status' });
    }
  });

  // Register agent routes
  registerAgentRoutes(app);

  const httpServer = createServer(app);
  return httpServer;
}
