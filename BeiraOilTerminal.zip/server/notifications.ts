import { Ship } from "../shared/schema";

export interface NotificationService {
  sendEmail(to: string, subject: string, html: string): Promise<boolean>;
  sendSMS(to: string, message: string): Promise<boolean>;
}

export interface NotificationTemplate {
  subject: string;
  emailHtml: string;
  smsMessage: string;
}

export class NotificationManager {
  private emailService: NotificationService;
  private smsService: NotificationService;

  constructor(emailService: NotificationService, smsService: NotificationService) {
    this.emailService = emailService;
    this.smsService = smsService;
  }

  async sendShipStatusAlert(
    ship: Ship,
    oldStatus: string,
    newStatus: string,
    recipients: { email?: string; phone?: string }[]
  ): Promise<void> {
    const template = this.getStatusChangeTemplate(ship, oldStatus, newStatus);
    
    const emailPromises = recipients
      .filter(r => r.email)
      .map(r => this.emailService.sendEmail(r.email!, template.subject, template.emailHtml));
    
    const smsPromises = recipients
      .filter(r => r.phone)
      .map(r => this.smsService.sendSMS(r.phone!, template.smsMessage));

    await Promise.all([...emailPromises, ...smsPromises]);
  }

  private getStatusChangeTemplate(ship: Ship, oldStatus: string, newStatus: string): NotificationTemplate {
    const statusLabels: Record<string, string> = {
      expected: "Esperado",
      at_bar: "Na Barra",
      next_to_berth: "Próximo a Atracar",
      at_berth: "No Cais",
      departed: "Partiu"
    };

    const subject = `Atualização de Status - ${ship.name}`;
    const statusChange = `${statusLabels[oldStatus]} → ${statusLabels[newStatus]}`;

    const emailHtml = `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="UTF-8">
        <style>
          body { font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; }
          .header { background-color: #0ea5e9; color: white; padding: 20px; border-radius: 8px 8px 0 0; }
          .content { background-color: #f8fafc; padding: 20px; border: 1px solid #e2e8f0; }
          .status-change { background-color: #dbeafe; border: 1px solid #93c5fd; padding: 15px; border-radius: 5px; margin: 15px 0; }
          .ship-details { background-color: white; padding: 15px; border-radius: 5px; margin: 15px 0; }
          .footer { background-color: #64748b; color: white; padding: 15px; border-radius: 0 0 8px 8px; text-align: center; }
        </style>
      </head>
      <body>
        <div class="header">
          <h1>Beira Oil Terminal - Alerta de Status</h1>
        </div>
        <div class="content">
          <div class="status-change">
            <h2>Mudança de Status</h2>
            <p><strong>${statusChange}</strong></p>
            <p>Atualizado em: ${new Date().toLocaleString('pt-BR')}</p>
          </div>
          <div class="ship-details">
            <h3>Detalhes do Navio</h3>
            <ul>
              <li><strong>Nome:</strong> ${ship.name}</li>
              <li><strong>Contra Marca:</strong> ${ship.countermark}</li>
              <li><strong>Calado:</strong> ${ship.draft}m</li>
              <li><strong>Agente do Navio:</strong> ${ship.shipAgent}</li>
              <li><strong>Tipo de Carga:</strong> ${ship.cargoType}</li>
              <li><strong>Status Atual:</strong> ${statusLabels[newStatus]}</li>
            </ul>
          </div>
        </div>
        <div class="footer">
          <p>Sistema de Line-Up - Beira Oil Terminal (CFM-EP)</p>
        </div>
      </body>
      </html>
    `;

    const smsMessage = `ALERTA BOT: ${ship.name} (${ship.countermark}) - Status: ${statusChange}. Atualizado: ${new Date().toLocaleString('pt-BR')}`;

    return { subject, emailHtml, smsMessage };
  }
}

// Email Service using SendGrid
export class SendGridEmailService implements NotificationService {
  private apiKey: string;

  constructor() {
    this.apiKey = process.env.SENDGRID_API_KEY || '';
  }

  async sendEmail(to: string, subject: string, html: string): Promise<boolean> {
    if (!this.apiKey || !this.apiKey.startsWith('SG.')) {
      console.log(`[EMAIL MOCK] To: ${to}, Subject: ${subject}`);
      console.log(`[EMAIL MOCK] Missing or invalid SendGrid API key`);
      return true;
    }

    try {
      // In production, use actual SendGrid implementation
      const sgMail = require('@sendgrid/mail');
      sgMail.setApiKey(this.apiKey);

      const msg = {
        to,
        from: process.env.FROM_EMAIL || 'alerts@beiraoilterminal.co.mz',
        subject,
        html,
      };

      await sgMail.send(msg);
      console.log(`Email sent successfully to ${to}`);
      return true;
    } catch (error) {
      console.error('Error sending email:', error);
      return false;
    }
  }

  async sendSMS(to: string, message: string): Promise<boolean> {
    // SMS not implemented for email service
    return false;
  }
}

// SMS Service using Twilio or similar
export class TwilioSMSService implements NotificationService {
  private accountSid: string;
  private authToken: string;
  private fromPhone: string;

  constructor() {
    this.accountSid = process.env.TWILIO_ACCOUNT_SID || '';
    this.authToken = process.env.TWILIO_AUTH_TOKEN || '';
    this.fromPhone = process.env.TWILIO_PHONE_NUMBER || '';
  }

  async sendSMS(to: string, message: string): Promise<boolean> {
    if (!this.accountSid || !this.authToken || !this.fromPhone) {
      console.log(`[SMS MOCK] To: ${to}, Message: ${message}`);
      return true;
    }

    try {
      // In production, use actual Twilio implementation
      const twilio = require('twilio');
      const client = twilio(this.accountSid, this.authToken);

      await client.messages.create({
        body: message,
        from: this.fromPhone,
        to: to
      });

      console.log(`SMS sent successfully to ${to}`);
      return true;
    } catch (error) {
      console.error('Error sending SMS:', error);
      return false;
    }
  }

  async sendEmail(to: string, subject: string, html: string): Promise<boolean> {
    // Email not implemented for SMS service
    return false;
  }
}

// Combined notification service
export class CombinedNotificationService implements NotificationService {
  private emailService: SendGridEmailService;
  private smsService: TwilioSMSService;

  constructor() {
    this.emailService = new SendGridEmailService();
    this.smsService = new TwilioSMSService();
  }

  async sendEmail(to: string, subject: string, html: string): Promise<boolean> {
    return this.emailService.sendEmail(to, subject, html);
  }

  async sendSMS(to: string, message: string): Promise<boolean> {
    return this.smsService.sendSMS(to, message);
  }
}

// Export singleton instance
export const notificationService = new CombinedNotificationService();
export const notificationManager = new NotificationManager(notificationService, notificationService);