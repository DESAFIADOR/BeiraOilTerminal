import OpenAI from "openai";
import fs from "fs";
import path from "path";
import { nanoid } from "nanoid";

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

export class VoiceService {
  private readonly tempDir = path.join(process.cwd(), 'temp-audio');

  constructor() {
    // Ensure temp directory exists
    if (!fs.existsSync(this.tempDir)) {
      fs.mkdirSync(this.tempDir, { recursive: true });
    }
  }

  // Speech-to-text using OpenAI Whisper
  async speechToText(audioBuffer: Buffer, language: string = 'pt'): Promise<string | null> {
    try {
      if (!process.env.OPENAI_API_KEY) {
        throw new Error("OpenAI API key not configured");
      }

      // Save audio buffer to temporary file
      const tempFileName = `${nanoid()}.wav`;
      const tempFilePath = path.join(this.tempDir, tempFileName);
      fs.writeFileSync(tempFilePath, audioBuffer);

      // Create readable stream for OpenAI API
      const audioReadStream = fs.createReadStream(tempFilePath);

      // Transcribe audio
      const transcription = await openai.audio.transcriptions.create({
        file: audioReadStream,
        model: "whisper-1",
        language: language === 'pt' ? 'pt' : 'en',
        response_format: 'text',
      });

      // Cleanup temp file
      fs.unlinkSync(tempFilePath);

      return typeof transcription === 'string' ? transcription : transcription.text || null;
    } catch (error) {
      console.error('Error in speech-to-text:', error);
      return null;
    }
  }

  // Text-to-speech using OpenAI TTS
  async textToSpeech(text: string, language: string = 'pt'): Promise<string | null> {
    try {
      if (!process.env.OPENAI_API_KEY) {
        throw new Error("OpenAI API key not configured");
      }

      // Generate speech
      const mp3 = await openai.audio.speech.create({
        model: "tts-1",
        voice: "nova", // Natural voice that works well for both PT and EN
        input: text,
        speed: 1.0,
      });

      // Save to temporary file and return path
      const tempFileName = `${nanoid()}.mp3`;
      const tempFilePath = path.join(this.tempDir, tempFileName);
      
      const buffer = Buffer.from(await mp3.arrayBuffer());
      fs.writeFileSync(tempFilePath, buffer);

      // Return relative path for serving
      return `/temp-audio/${tempFileName}`;
    } catch (error) {
      console.error('Error in text-to-speech:', error);
      return null;
    }
  }

  // Cleanup old audio files (run periodically)
  async cleanupOldFiles(): Promise<void> {
    try {
      const files = fs.readdirSync(this.tempDir);
      const now = Date.now();
      const maxAge = 60 * 60 * 1000; // 1 hour

      for (const file of files) {
        const filePath = path.join(this.tempDir, file);
        const stats = fs.statSync(filePath);
        
        if (now - stats.mtime.getTime() > maxAge) {
          fs.unlinkSync(filePath);
        }
      }
    } catch (error) {
      console.error('Error cleaning up audio files:', error);
    }
  }
}

export const voiceService = new VoiceService();

// Schedule cleanup every hour
setInterval(() => {
  voiceService.cleanupOldFiles();
}, 60 * 60 * 1000);