import { sendEmail } from './emailService.js';

async function sendReport() {
  const reportData = {
    title: "Sistema de Gestão de Navios - Terminal Petrolífero da Beira",
    subtitle: "Relatório Completo de Funcionalidades e Capacidades",
    generatedAt: new Date(),
    version: "2.0",
    
    mainFeatures: [
      {
        category: "Gestão de Navios",
        features: [
          "Registro completo de navios com informações detalhadas",
          "Sistema de status em tempo real",
          "Controle de tipos de operação (Trânsito e Combinado)",
          "Sistema de priorização IMOPETRO conforme Decreto 89/2019",
          "Gestão de parcelas de carga com volumes",
          "Rastreamento de progresso de descarga em tempo real"
        ]
      },
      {
        category: "Sistema de Priorização Inteligente",
        features: [
          "Prioridade absoluta para navios IMOPETRO",
          "Regra de atracação 2:1 (2 trânsitos + 1 combinado)",
          "Ordenação cronológica por data de chegada",
          "Badges visuais diferenciando tipos de operação"
        ]
      },
      {
        category: "Monitoramento Ambiental",
        features: [
          "Monitoramento de marés em tempo real",
          "Alertas meteorológicos para ventos acima de 25 nós",
          "Dados de temperatura, umidade e pressão",
          "Integração com APIs meteorológicas"
        ]
      }
    ],
    
    technicalSpecs: {
      frontend: "React 18 com TypeScript, Tailwind CSS",
      backend: "Express.js com TypeScript, Drizzle ORM",
      database: "PostgreSQL (Neon Serverless)",
      email: "SendGrid para notificações profissionais",
      deployment: "Replit com domínio beiraoilterminal-vessels-lineup.com"
    },
    
    operationalBenefits: [
      "Redução do tempo de coordenação de navios",
      "Conformidade regulatória automática",
      "Otimização da utilização do berço único",
      "Transparência total no processo de atracação"
    ]
  };

  const emailHtml = `
    <div style="font-family: Arial, sans-serif; max-width: 800px; margin: 0 auto; padding: 20px;">
        <div style="background: white; padding: 30px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1);">
            <div style="text-align: center; margin-bottom: 30px; border-bottom: 3px solid #1e40af; padding-bottom: 20px;">
                <h1 style="color: #1e40af; margin: 0; font-size: 28px;">⚓ Sistema de Gestão Portuária</h1>
                <h2 style="color: #64748b; margin: 10px 0 0 0; font-size: 18px;">Terminal Petrolífero da Beira</h2>
                <p style="color: #6b7280; margin: 10px 0 0 0;">
                    Relatório Completo de Funcionalidades | Versão 2.0 | beiraoilterminal-vessels-lineup.com
                </p>
            </div>
            
            <div style="background: #eff6ff; padding: 20px; border-radius: 8px; margin: 20px 0;">
                <h3 style="color: #1e40af; margin: 0 0 10px 0;">📋 Funcionalidades Principais</h3>
                
                <div style="margin: 20px 0;">
                    <h4 style="color: #059669;">Gestão de Navios</h4>
                    <ul style="line-height: 1.6; color: #374151;">
                        <li>Registro completo de navios com informações detalhadas</li>
                        <li>Sistema de status em tempo real</li>
                        <li>Controle de tipos de operação (Trânsito e Combinado)</li>
                        <li>Sistema de priorização IMOPETRO conforme Decreto 89/2019</li>
                        <li>Gestão de parcelas de carga com volumes</li>
                        <li>Rastreamento de progresso de descarga em tempo real</li>
                    </ul>
                </div>
                
                <div style="margin: 20px 0;">
                    <h4 style="color: #059669;">Sistema de Priorização Inteligente</h4>
                    <ul style="line-height: 1.6; color: #374151;">
                        <li>Prioridade absoluta para navios IMOPETRO</li>
                        <li>Regra de atracação 2:1 (2 trânsitos + 1 combinado)</li>
                        <li>Ordenação cronológica por data de chegada</li>
                        <li>Badges visuais diferenciando tipos de operação</li>
                    </ul>
                </div>
                
                <div style="margin: 20px 0;">
                    <h4 style="color: #059669;">Monitoramento Ambiental</h4>
                    <ul style="line-height: 1.6; color: #374151;">
                        <li>Monitoramento de marés em tempo real</li>
                        <li>Alertas meteorológicos para ventos acima de 25 nós</li>
                        <li>Dados de temperatura, umidade e pressão</li>
                        <li>Integração com APIs meteorológicas</li>
                    </ul>
                </div>
            </div>
            
            <div style="background: #f0fdf4; padding: 20px; border-radius: 8px; margin: 20px 0;">
                <h3 style="color: #15803d;">⚙️ Especificações Técnicas</h3>
                <ul style="line-height: 1.6; color: #374151;">
                    <li><strong>Frontend:</strong> React 18 com TypeScript, Tailwind CSS</li>
                    <li><strong>Backend:</strong> Express.js com TypeScript, Drizzle ORM</li>
                    <li><strong>Banco de Dados:</strong> PostgreSQL (Neon Serverless)</li>
                    <li><strong>Email:</strong> SendGrid para notificações profissionais</li>
                    <li><strong>Deployment:</strong> Replit com domínio beiraoilterminal-vessels-lineup.com</li>
                </ul>
            </div>
            
            <div style="background: #fef3c7; padding: 20px; border-radius: 8px; margin: 20px 0;">
                <h3 style="color: #d97706;">📈 Benefícios Operacionais</h3>
                <ul style="line-height: 1.6; color: #374151;">
                    <li>Redução do tempo de coordenação de navios</li>
                    <li>Conformidade regulatória automática</li>
                    <li>Otimização da utilização do berço único</li>
                    <li>Transparência total no processo de atracação</li>
                </ul>
            </div>
            
            <div style="text-align: center; background: #e0f2fe; padding: 20px; border-radius: 8px; margin: 20px 0;">
                <h3 style="color: #0277bd;">🌐 Acesso ao Sistema</h3>
                <p style="color: #374151; font-size: 16px;">
                    <strong style="color: #1e40af; font-size: 18px;">https://beiraoilterminal-vessels-lineup.com</strong>
                </p>
            </div>
            
            <div style="text-align: center; color: #9ca3af; font-size: 12px; border-top: 1px solid #e5e7eb; padding-top: 20px;">
                <p>CFM-EP | Terminal Petrolífero da Beira | Relatório gerado automaticamente</p>
            </div>
        </div>
    </div>
  `;

  try {
    const result = await sendEmail({
      to: 'manuel.antonio@cfm.co.mz',
      from: 'noreply@beiraoilterminal.com',
      subject: 'Relatório Completo de Funcionalidades - Sistema de Gestão Portuária',
      html: emailHtml
    });
    
    console.log('Email enviado com sucesso:', result);
    return result;
  } catch (error) {
    console.error('Erro ao enviar email:', error);
    return false;
  }
}

sendReport().then(result => {
  console.log('Resultado:', result);
  process.exit(result ? 0 : 1);
}).catch(error => {
  console.error('Erro:', error);
  process.exit(1);
});