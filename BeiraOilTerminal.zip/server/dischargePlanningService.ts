import { db } from "./db";
import { ships, cargoParcels } from "@shared/schema";
import { eq, and, inArray } from "drizzle-orm";
import type { 
  DischargeParcelPlan, 
  ShipDischargePlan, 
  TideWindow, 
  DischargePlanningResult 
} from "@shared/discharge-plan-types";

export class DischargePlanningService {
  
  // Default rates by product type (m³/h)
  private readonly defaultRates = {
    'Gasolina': 400,
    'Diesel': 350,
    'Jet A1': 300,
    'LPG': 250,
    'Gasóleo': 350,
    'Fuel Oil': 200,
    'default': 300
  };

  // Get discharge rate for a specific product
  public getDischargeRate(product: string): number {
    return this.defaultRates[product as keyof typeof this.defaultRates] || this.defaultRates.default;
  }

  // Priority system for ship operations
  public applyPriorityOrdering(ships: any[]): any[] {
    if (!ships || ships.length === 0) return [];
    
    // Separate ships by priority levels
    const nacionalShips = ships.filter(ship => ship.operationType === 'Nacional');
    const lpgShips = ships.filter(ship => 
      ship.operationType === 'LPG' || 
      (ship.parcels && ship.parcels.some((p: any) => p.product === 'LPG'))
    );
    const transitoShips = ships.filter(ship => ship.operationType === 'Trânsito');
    const combinadaShips = ships.filter(ship => ship.operationType === 'Combinada');
    
    // Apply 2:1 rule to Trânsito and Combinada ships while preserving arrival order
    const orderedGeneralShips = this.apply2to1Rule(transitoShips, combinadaShips);
    
    // Helper function to safely sort by arrival time
    const sortByArrival = (a: any, b: any) => {
      const dateA = new Date(a.arrivalAtBar || a.arrivalDateTime || a.createdAt);
      const dateB = new Date(b.arrivalAtBar || b.arrivalDateTime || b.createdAt);
      return dateA.getTime() - dateB.getTime();
    };
    
    // Final priority order: Nacional → LPG → 2:1 Rule (Trânsito/Combinada)
    return [
      ...nacionalShips.sort(sortByArrival),
      ...lpgShips.sort(sortByArrival),
      ...orderedGeneralShips
    ];
  }

  // Apply 2 Trânsito : 1 Combinada rule while preserving chronological order
  private apply2to1Rule(transitoShips: any[], combinadaShips: any[]): any[] {
    // Sort by arrival time
    const sortedTransito = [...transitoShips].sort((a, b) => 
      new Date(a.arrivalAtBar).getTime() - new Date(b.arrivalAtBar).getTime());
    const sortedCombinada = [...combinadaShips].sort((a, b) => 
      new Date(a.arrivalAtBar).getTime() - new Date(b.arrivalAtBar).getTime());
    
    const result = [];
    let transitoIndex = 0;
    let combinadaIndex = 0;
    let transitoCount = 0;
    
    while (transitoIndex < sortedTransito.length || combinadaIndex < sortedCombinada.length) {
      // Add 2 Trânsito ships
      while (transitoCount < 2 && transitoIndex < sortedTransito.length) {
        result.push(sortedTransito[transitoIndex]);
        transitoIndex++;
        transitoCount++;
      }
      
      // Add 1 Combinada ship
      if (combinadaIndex < sortedCombinada.length) {
        result.push(sortedCombinada[combinadaIndex]);
        combinadaIndex++;
        transitoCount = 0; // Reset counter for next cycle
      } else if (transitoIndex < sortedTransito.length) {
        // If no more Combinada ships, continue with remaining Trânsito
        result.push(sortedTransito[transitoIndex]);
        transitoIndex++;
      }
    }
    
    return result;
  }

  // Generate tide predictions for the next 30 days
  private generateTidePredictions(startDate: Date): TideWindow[] {
    const tideWindows: TideWindow[] = [];
    const currentDate = new Date(startDate);
    
    // Beira has semi-diurnal tides (2 high tides and 2 low tides per day)
    // Average period between high tides: ~12.42 hours
    for (let day = 0; day < 30; day++) {
      const baseDate = new Date(currentDate);
      baseDate.setDate(baseDate.getDate() + day);
      
      // First high tide of the day (around 6:00 AM + tidal variation)
      const firstHighTide = new Date(baseDate);
      firstHighTide.setHours(6 + Math.sin(day * 0.5) * 2, Math.random() * 60, 0, 0);
      
      // Second high tide (12.42 hours later)
      const secondHighTide = new Date(firstHighTide);
      secondHighTide.setHours(secondHighTide.getHours() + 12, secondHighTide.getMinutes() + 25, 0, 0);
      
      // Low tides (approximately 6.2 hours after high tides)
      const firstLowTide = new Date(firstHighTide);
      firstLowTide.setHours(firstLowTide.getHours() + 6, firstLowTide.getMinutes() + 12, 0, 0);
      
      const secondLowTide = new Date(secondHighTide);
      secondLowTide.setHours(secondLowTide.getHours() + 6, secondLowTide.getMinutes() + 12, 0, 0);
      
      // Create tide windows
      tideWindows.push({
        highTide: firstHighTide,
        lowTide: firstLowTide,
        unberthingWindow: new Date(firstHighTide.getTime() - 2 * 60 * 60 * 1000), // 2h before high tide
        berthingWindow: new Date(firstHighTide.getTime() + 2 * 60 * 60 * 1000)     // 2h after high tide
      });
      
      tideWindows.push({
        highTide: secondHighTide,
        lowTide: secondLowTide,
        unberthingWindow: new Date(secondHighTide.getTime() - 2 * 60 * 60 * 1000),
        berthingWindow: new Date(secondHighTide.getTime() + 2 * 60 * 60 * 1000)
      });
    }
    
    return tideWindows.sort((a, b) => a.highTide.getTime() - b.highTide.getTime());
  }

  // Get next available berthing window after given time
  private getNextBerthingWindow(afterTime: Date, tideWindows: TideWindow[]): TideWindow | null {
    return tideWindows.find(window => window.berthingWindow > afterTime) || null;
  }

  // Get next unberthing window before given time or closest available
  private getUnberthingWindow(beforeTime: Date, tideWindows: TideWindow[]): TideWindow | null {
    // Find window where unberthing time is before the target time
    const suitableWindows = tideWindows.filter(window => window.unberthingWindow <= beforeTime);
    return suitableWindows[suitableWindows.length - 1] || tideWindows[0];
  }

  // Calculate discharge plan for a single parcel
  private calculateParcelPlan(parcel: any, startTime: Date): DischargeParcelPlan {
    const expectedRate = this.defaultRates[parcel.product as keyof typeof this.defaultRates] || this.defaultRates.default;
    const estimatedDuration = parcel.volumeM3 / expectedRate;
    const endTime = new Date(startTime.getTime() + estimatedDuration * 60 * 60 * 1000);
    
    return {
      parcelId: parcel.id,
      product: parcel.product,
      volumeM3: parcel.volumeM3,
      expectedRate,
      estimatedDuration,
      startTime,
      endTime
    };
  }

  // Main planning function
  async generateDischargePlan(): Promise<DischargePlanningResult> {
    try {
      // Get all ships ready to berth (at_bar with instructions or next_to_berth)
      const candidateShips = await db
        .select()
        .from(ships)
        .where(
          and(
            inArray(ships.status, ['at_bar', 'next_to_berth']),
            eq(ships.hasDischargeInstructions, true)
          )
        )
        .orderBy(ships.createdAt);

      // Apply priority ordering system
      const prioritizedShips = this.applyPriorityOrdering(candidateShips);
      
      // Take only next 5 ships after priority ordering
      const nextShips = prioritizedShips.slice(0, 5);

      if (nextShips.length === 0) {
        return {
          ships: [],
          tideWindows: [],
          totalPlanningPeriod: 0,
          warnings: ['Nenhum navio encontrado para planejamento'],
          recommendations: []
        };
      }

      // Get cargo parcels for all ships
      const shipIds = nextShips.map(ship => ship.id);
      const allParcels = await db
        .select()
        .from(cargoParcels)
        .where(inArray(cargoParcels.shipId, shipIds));

      // Generate tide predictions
      const planningStartTime = new Date();
      const tideWindows = this.generateTidePredictions(planningStartTime);

      const shipPlans: ShipDischargePlan[] = [];
      const warnings: string[] = [];
      const recommendations: string[] = [];
      
      let currentPlanningTime = new Date(planningStartTime);

      // Plan each ship sequentially
      for (const ship of nextShips) {
        const shipParcels = allParcels.filter(p => p.shipId === ship.id);
        
        if (shipParcels.length === 0) {
          warnings.push(`Navio ${ship.name} não possui parcelas de carga`);
          continue;
        }

        // Find next available berthing window
        const berthingWindow = this.getNextBerthingWindow(currentPlanningTime, tideWindows);
        if (!berthingWindow) {
          warnings.push(`Não foi possível encontrar janela de atracação para ${ship.name}`);
          continue;
        }

        const berthingTime = berthingWindow.berthingWindow;
        
        // Discharge starts max 6 hours after last rope (berthing)
        const dischargeStartTime = new Date(berthingTime.getTime() + 6 * 60 * 60 * 1000);
        
        // Calculate parcel discharge plans
        const parcelPlans: DischargeParcelPlan[] = [];
        let currentParcelStartTime = new Date(dischargeStartTime);
        
        for (let i = 0; i < shipParcels.length; i++) {
          const parcel = shipParcels[i];
          const parcelPlan = this.calculateParcelPlan(parcel, currentParcelStartTime);
          parcelPlans.push(parcelPlan);
          
          // Add 1 hour break between parcels (except for last parcel)
          if (i < shipParcels.length - 1) {
            currentParcelStartTime = new Date(parcelPlan.endTime.getTime() + 60 * 60 * 1000);
          } else {
            currentParcelStartTime = parcelPlan.endTime;
          }
        }

        const totalDischargeTime = (currentParcelStartTime.getTime() - dischargeStartTime.getTime()) / (1000 * 60 * 60);
        const dischargeEndTime = currentParcelStartTime;
        
        // Find unberthing window (2 hours before high tide, after discharge end)
        const unberthingWindow = this.getNextBerthingWindow(dischargeEndTime, tideWindows);
        const unberthingTime = unberthingWindow ? 
          new Date(unberthingWindow.highTide.getTime() - 2 * 60 * 60 * 1000) : 
          new Date(dischargeEndTime.getTime() + 2 * 60 * 60 * 1000);

        // If unberthing is before discharge end, adjust to next tide
        if (unberthingTime < dischargeEndTime) {
          const nextWindow = this.getNextBerthingWindow(dischargeEndTime, tideWindows);
          if (nextWindow) {
            const adjustedUnberthingTime = new Date(nextWindow.highTide.getTime() - 2 * 60 * 60 * 1000);
            warnings.push(`Navio ${ship.name}: Desatracação adiada para próxima maré devido ao término da descarga`);
          }
        }

        const shipPlan: ShipDischargePlan = {
          shipId: ship.id,
          shipName: ship.name,
          operationType: ship.operationType || 'transito',
          berthingTime,
          dischargeStartTime,
          parcels: parcelPlans,
          totalDischargeTime,
          dischargeEndTime,
          unberthingTime
        };

        shipPlans.push(shipPlan);
        
        // Next ship planning starts after current ship unberthing
        currentPlanningTime = new Date(unberthingTime.getTime() + 30 * 60 * 1000); // 30 min buffer
        
        // Add recommendations
        if (totalDischargeTime > 48) {
          recommendations.push(`${ship.name}: Descarga longa (${totalDischargeTime.toFixed(1)}h) - considere otimizar rates`);
        }
        
        if (parcelPlans.length > 3) {
          recommendations.push(`${ship.name}: Múltiplas parcelas (${parcelPlans.length}) - coordenar mudanças de linha`);
        }
      }

      // Set next ship berthing times
      for (let i = 0; i < shipPlans.length - 1; i++) {
        shipPlans[i].nextShipBerthingTime = shipPlans[i + 1].berthingTime;
      }

      const totalPlanningPeriod = shipPlans.length > 0 ? 
        (shipPlans[shipPlans.length - 1].unberthingTime.getTime() - planningStartTime.getTime()) / (1000 * 60 * 60 * 24) : 0;

      return {
        ships: shipPlans,
        tideWindows: tideWindows.slice(0, 20), // Return first 20 tide windows
        totalPlanningPeriod,
        warnings,
        recommendations
      };

    } catch (error) {
      console.error('Error generating discharge plan:', error);
      throw new Error('Falha ao gerar plano de descarga');
    }
  }

  // Update discharge rates based on actual performance
  async updateActualRates(shipId: number, parcelId: number, actualRate: number): Promise<void> {
    // This could be stored in a separate table for learning and improving predictions
    console.log(`Updating actual rate for ship ${shipId}, parcel ${parcelId}: ${actualRate} m³/h`);
  }
}

export const dischargePlanningService = new DischargePlanningService();