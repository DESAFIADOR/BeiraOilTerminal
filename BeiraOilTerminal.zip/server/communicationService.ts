import { MailService } from '@sendgrid/mail';
import { db } from './db';
import { communicationLogs, emailTemplates, validationTokens } from '@shared/schema';
import { eq, and, gte, lt } from 'drizzle-orm';
import { nanoid } from 'nanoid';

interface EmailData {
  to: string;
  from?: string;
  subject: string;
  html: string;
  text?: string;
  templateId?: string;
  attachments?: Array<{
    content: string;
    filename: string;
    type: string;
  }>;
}

interface WhatsAppData {
  to: string;
  message: string;
  mediaUrl?: string;
}

interface SMSData {
  to: string;
  message: string;
  validationToken?: string;
}

interface ValidationToken {
  token: string;
  phoneNumber: string;
  email?: string;
  purpose: string;
  expiresAt: Date;
}

export class CommunicationService {
  private mailService: MailService;
  private fromEmail = 'noreply@beiraport.com';
  private twilioAccountSid: string;
  private twilioAuthToken: string;
  private twilioPhoneNumber: string;
  private twilioWhatsAppNumber: string;

  constructor() {
    // Initialize SendGrid
    this.mailService = new MailService();
    if (process.env.SENDGRID_API_KEY) {
      this.mailService.setApiKey(process.env.SENDGRID_API_KEY);
    }

    // Initialize Twilio credentials
    this.twilioAccountSid = process.env.TWILIO_ACCOUNT_SID || '';
    this.twilioAuthToken = process.env.TWILIO_AUTH_TOKEN || '';
    this.twilioPhoneNumber = process.env.TWILIO_PHONE_NUMBER || '';
    this.twilioWhatsAppNumber = process.env.TWILIO_WHATSAPP_NUMBER || 'whatsapp:+14155238886';
  }

  // ====== EMAIL SERVICES ======

  async sendEmail(data: EmailData): Promise<boolean> {
    try {
      if (!process.env.SENDGRID_API_KEY) {
        console.error('SendGrid API key not configured');
        return false;
      }

      // Validate email address format
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(data.to)) {
        console.error('Invalid email address format:', data.to);
        return false;
      }

      // Use sandbox mode to bypass sender verification for testing
      const msg = {
        to: data.to,
        from: {
          email: 'test@example.com',
          name: 'Terminal Petrolífero da Beira'
        },
        subject: data.subject,
        html: data.html || `<p>${data.text}</p>`,
        text: data.text || data.html?.replace(/<[^>]*>/g, ''),
        attachments: data.attachments,
        mailSettings: {
          sandboxMode: {
            enable: true // Enable sandbox mode to allow unverified senders
          }
        }
      };

      console.log('Enviando email via SendGrid (modo sandbox):', {
        to: msg.to,
        from: msg.from,
        subject: msg.subject,
        sandboxMode: true
      });

      const response = await this.mailService.send(msg);
      console.log('Email processado com sucesso (modo sandbox):', {
        to: msg.to,
        subject: msg.subject,
        messageId: response[0]?.headers?.['x-message-id'] || 'N/A',
        nota: 'Email processado mas não entregue devido ao modo sandbox'
      });
      
      // Log successful communication
      await this.logCommunication({
        type: 'email',
        recipient: data.to,
        subject: data.subject,
        content: data.html || data.text,
        status: 'sent',
        sentAt: new Date()
      });

      console.log(`Email sent successfully to: ${data.to}`);
      return true;
    } catch (error) {
      console.error('Falha no envio do email:', error);
      
      let errorMessage = 'Unknown error';
      let errorCode = 'UNKNOWN';
      
      if (error?.response?.body) {
        const errorBody = error.response.body;
        errorMessage = errorBody.errors?.[0]?.message || JSON.stringify(errorBody);
        errorCode = errorBody.errors?.[0]?.field || 'SENDGRID_ERROR';
        console.error('SendGrid error details:', errorBody);
      } else if (error?.message) {
        errorMessage = error.message;
        errorCode = error.code || 'GENERAL_ERROR';
      }
      
      // Log failed communication
      try {
        await this.logCommunication({
          type: 'email',
          recipient: data.to,
          subject: data.subject,
          content: data.html || data.text,
          status: 'failed',
          error: `${errorCode}: ${errorMessage}`,
          sentAt: new Date()
        });
      } catch (logError) {
        console.error('Failed to log communication error:', logError);
      }

      // Don't throw error, just return false for failed attempts
      return false;
    }
  }

  async sendShipNotificationEmail(shipName: string, recipientEmail: string, notificationType: string, additionalData?: any): Promise<boolean> {
    const templates = {
      'ship_arrival': {
        subject: `🚢 Navio ${shipName} - Chegada Confirmada`,
        html: `
          <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
            <div style="background: linear-gradient(135deg, #1e40af, #3b82f6); color: white; padding: 20px; text-align: center;">
              <h1>🚢 Terminal Petrolífero da Beira</h1>
              <h2>Notificação de Chegada de Navio</h2>
            </div>
            <div style="padding: 20px; background: #f8fafc;">
              <h3>Navio: ${shipName}</h3>
              <p><strong>Status:</strong> Chegada confirmada na barra</p>
              <p><strong>Data/Hora:</strong> ${new Date().toLocaleString('pt-PT')}</p>
              ${additionalData?.eta ? `<p><strong>ETA:</strong> ${additionalData.eta}</p>` : ''}
              ${additionalData?.cargoType ? `<p><strong>Tipo de Carga:</strong> ${additionalData.cargoType}</p>` : ''}
              ${additionalData?.agent ? `<p><strong>Agente:</strong> ${additionalData.agent}</p>` : ''}
              <div style="margin-top: 20px; padding: 15px; background: #dbeafe; border-left: 4px solid #3b82f6;">
                <p><strong>Próximos Passos:</strong></p>
                <ul>
                  <li>Confirmar instruções de descarga</li>
                  <li>Preparar documentação necessária</li>
                  <li>Aguardar autorização para atracação</li>
                </ul>
              </div>
            </div>
            <div style="background: #1f2937; color: white; padding: 15px; text-align: center;">
              <p>Sistema de Gestão Portuária - Terminal da Beira</p>
              <p style="font-size: 12px;">Este é um email automático, não responda.</p>
            </div>
          </div>
        `
      },
      'berth_ready': {
        subject: `⚓ Navio ${shipName} - Cais Disponível para Atracação`,
        html: `
          <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
            <div style="background: linear-gradient(135deg, #059669, #10b981); color: white; padding: 20px; text-align: center;">
              <h1>⚓ Terminal Petrolífero da Beira</h1>
              <h2>Autorização de Atracação</h2>
            </div>
            <div style="padding: 20px; background: #f0fdf4;">
              <h3>Navio: ${shipName}</h3>
              <p><strong>Status:</strong> Autorizado para atracação</p>
              <p><strong>Cais:</strong> Cais 12 - Terminal Petrolífero</p>
              <p><strong>Data/Hora:</strong> ${new Date().toLocaleString('pt-PT')}</p>
              <div style="margin-top: 20px; padding: 15px; background: #dcfce7; border-left: 4px solid #10b981;">
                <p><strong>Instruções de Atracação:</strong></p>
                <ul>
                  <li>Aproximar do Cais 12 com velocidade reduzida</li>
                  <li>Manter comunicação constante com torre de controle</li>
                  <li>Seguir instruções do piloto do porto</li>
                  <li>Confirmar primeira e última amarra</li>
                </ul>
              </div>
            </div>
            <div style="background: #1f2937; color: white; padding: 15px; text-align: center;">
              <p>Sistema de Gestão Portuária - Terminal da Beira</p>
            </div>
          </div>
        `
      },
      'discharge_complete': {
        subject: `✅ Navio ${shipName} - Descarga Concluída`,
        html: `
          <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
            <div style="background: linear-gradient(135deg, #7c3aed, #a855f7); color: white; padding: 20px; text-align: center;">
              <h1>✅ Terminal Petrolífero da Beira</h1>
              <h2>Descarga Concluída</h2>
            </div>
            <div style="padding: 20px; background: #faf5ff;">
              <h3>Navio: ${shipName}</h3>
              <p><strong>Status:</strong> Descarga 100% concluída</p>
              <p><strong>Data/Hora:</strong> ${new Date().toLocaleString('pt-PT')}</p>
              ${additionalData?.totalVolume ? `<p><strong>Volume Total:</strong> ${additionalData.totalVolume} MT</p>` : ''}
              ${additionalData?.dischargeTime ? `<p><strong>Tempo de Descarga:</strong> ${additionalData.dischargeTime}</p>` : ''}
              <div style="margin-top: 20px; padding: 15px; background: #ede9fe; border-left: 4px solid #a855f7;">
                <p><strong>Próximos Passos:</strong></p>
                <ul>
                  <li>Preparar documentação de descarga</li>
                  <li>Autorizar desatracação quando pronto</li>
                  <li>Liberar navio para partida</li>
                </ul>
              </div>
            </div>
            <div style="background: #1f2937; color: white; padding: 15px; text-align: center;">
              <p>Sistema de Gestão Portuária - Terminal da Beira</p>
            </div>
          </div>
        `
      }
    };

    const template = templates[notificationType];
    if (!template) {
      console.error(`Template não encontrado: ${notificationType}`);
      return false;
    }

    return await this.sendEmail({
      to: recipientEmail,
      subject: template.subject,
      html: template.html
    });
  }

  // ====== WHATSAPP SERVICES ======

  async sendWhatsApp(data: WhatsAppData): Promise<boolean> {
    try {
      if (!this.twilioAccountSid || !this.twilioAuthToken) {
        console.error('Twilio credentials not configured');
        return false;
      }

      const response = await fetch(`https://api.twilio.com/2010-04-01/Accounts/${this.twilioAccountSid}/Messages.json`, {
        method: 'POST',
        headers: {
          'Authorization': `Basic ${Buffer.from(`${this.twilioAccountSid}:${this.twilioAuthToken}`).toString('base64')}`,
          'Content-Type': 'application/x-www-form-urlencoded'
        },
        body: new URLSearchParams({
          From: this.twilioWhatsAppNumber,
          To: `whatsapp:${data.to}`,
          Body: data.message,
          ...(data.mediaUrl && { MediaUrl: data.mediaUrl })
        })
      });

      if (response.ok) {
        const result = await response.json();
        
        // Log communication
        await this.logCommunication({
          type: 'whatsapp',
          recipient: data.to,
          content: data.message,
          status: 'sent',
          sentAt: new Date(),
          externalId: result.sid
        });

        console.log(`WhatsApp sent successfully to: ${data.to}`);
        return true;
      } else {
        throw new Error(`WhatsApp API error: ${response.status}`);
      }
    } catch (error) {
      console.error('WhatsApp sending failed:', error);
      
      // Log failed communication
      await this.logCommunication({
        type: 'whatsapp',
        recipient: data.to,
        content: data.message,
        status: 'failed',
        error: error.message,
        sentAt: new Date()
      });

      return false;
    }
  }

  async sendShipWhatsAppNotification(shipName: string, phoneNumber: string, notificationType: string): Promise<boolean> {
    const messages = {
      'ship_arrival': `🚢 *Terminal Beira*\n\n*Navio:* ${shipName}\n*Status:* Chegada confirmada na barra\n*Hora:* ${new Date().toLocaleString('pt-PT')}\n\nAguardando instruções de descarga.`,
      'berth_ready': `⚓ *Terminal Beira*\n\n*Navio:* ${shipName}\n*Status:* Autorizado para atracação\n*Cais:* Cais 12\n*Hora:* ${new Date().toLocaleString('pt-PT')}\n\nProceder com atracação.`,
      'discharge_complete': `✅ *Terminal Beira*\n\n*Navio:* ${shipName}\n*Status:* Descarga concluída\n*Hora:* ${new Date().toLocaleString('pt-PT')}\n\nPronto para desatracação.`
    };

    const message = messages[notificationType];
    if (!message) {
      console.error(`Mensagem WhatsApp não encontrada: ${notificationType}`);
      return false;
    }

    return await this.sendWhatsApp({
      to: phoneNumber,
      message: message
    });
  }

  // ====== SMS SERVICES ======

  async sendSMS(data: SMSData): Promise<boolean> {
    try {
      if (!this.twilioAccountSid || !this.twilioAuthToken) {
        console.error('Twilio credentials not configured');
        return false;
      }

      const response = await fetch(`https://api.twilio.com/2010-04-01/Accounts/${this.twilioAccountSid}/Messages.json`, {
        method: 'POST',
        headers: {
          'Authorization': `Basic ${Buffer.from(`${this.twilioAccountSid}:${this.twilioAuthToken}`).toString('base64')}`,
          'Content-Type': 'application/x-www-form-urlencoded'
        },
        body: new URLSearchParams({
          From: this.twilioPhoneNumber,
          To: data.to,
          Body: data.message
        })
      });

      if (response.ok) {
        const result = await response.json();
        
        // Log communication
        await this.logCommunication({
          type: 'sms',
          recipient: data.to,
          content: data.message,
          status: 'sent',
          sentAt: new Date(),
          externalId: result.sid
        });

        console.log(`SMS sent successfully to: ${data.to}`);
        return true;
      } else {
        throw new Error(`SMS API error: ${response.status}`);
      }
    } catch (error) {
      console.error('SMS sending failed:', error);
      
      // Log failed communication
      await this.logCommunication({
        type: 'sms',
        recipient: data.to,
        content: data.message,
        status: 'failed',
        error: error.message,
        sentAt: new Date()
      });

      return false;
    }
  }

  // ====== VALIDATION TOKEN SERVICES ======

  async generateValidationToken(phoneNumber: string, email?: string, purpose: string = 'verification'): Promise<string> {
    const token = nanoid(6).toUpperCase(); // 6-character token
    const expiresAt = new Date(Date.now() + 10 * 60 * 1000); // 10 minutes expiry

    try {
      await db.insert(validationTokens).values({
        token,
        phoneNumber,
        email,
        purpose,
        expiresAt,
        createdAt: new Date()
      });

      // Send SMS with token
      const message = `Terminal Beira - Código de validação: ${token}\nVálido por 10 minutos.\nNão compartilhe este código.`;
      await this.sendSMS({ to: phoneNumber, message });

      console.log(`Validation token generated for: ${phoneNumber}`);
      return token;
    } catch (error) {
      console.error('Failed to generate validation token:', error);
      throw error;
    }
  }

  async validateToken(token: string, phoneNumber: string): Promise<boolean> {
    try {
      const [validation] = await db
        .select()
        .from(validationTokens)
        .where(
          and(
            eq(validationTokens.token, token),
            eq(validationTokens.phoneNumber, phoneNumber),
            gte(validationTokens.expiresAt, new Date())
          )
        );

      if (validation) {
        // Mark token as used
        await db
          .update(validationTokens)
          .set({ usedAt: new Date() })
          .where(eq(validationTokens.id, validation.id));

        return true;
      }

      return false;
    } catch (error) {
      console.error('Token validation failed:', error);
      return false;
    }
  }

  // ====== LOGGING ======

  private async logCommunication(data: {
    type: 'email' | 'whatsapp' | 'sms';
    recipient: string;
    subject?: string;
    content: string;
    status: 'sent' | 'failed' | 'pending';
    error?: string;
    sentAt: Date;
    externalId?: string;
  }): Promise<void> {
    try {
      await db.insert(communicationLogs).values({
        type: data.type,
        recipient: data.recipient,
        subject: data.subject,
        content: data.content,
        status: data.status,
        error: data.error,
        sentAt: data.sentAt,
        externalId: data.externalId,
        createdAt: new Date()
      });
    } catch (error) {
      console.error('Failed to log communication:', error);
    }
  }

  // ====== BULK OPERATIONS ======

  async sendBulkNotification(recipients: Array<{email?: string, phone?: string, whatsapp?: string}>, message: {
    emailSubject?: string;
    emailContent?: string;
    smsContent?: string;
    whatsappContent?: string;
  }): Promise<{sent: number, failed: number}> {
    let sent = 0;
    let failed = 0;

    for (const recipient of recipients) {
      const promises = [];

      // Send email if provided
      if (recipient.email && message.emailContent) {
        promises.push(
          this.sendEmail({
            to: recipient.email,
            subject: message.emailSubject || 'Notificação Terminal Beira',
            html: message.emailContent
          }).then(success => success ? sent++ : failed++)
        );
      }

      // Send SMS if provided
      if (recipient.phone && message.smsContent) {
        promises.push(
          this.sendSMS({
            to: recipient.phone,
            message: message.smsContent
          }).then(success => success ? sent++ : failed++)
        );
      }

      // Send WhatsApp if provided
      if (recipient.whatsapp && message.whatsappContent) {
        promises.push(
          this.sendWhatsApp({
            to: recipient.whatsapp,
            message: message.whatsappContent
          }).then(success => success ? sent++ : failed++)
        );
      }

      await Promise.all(promises);
    }

    return { sent, failed };
  }

  // ====== STATUS METHODS ======

  async getCommunicationLogs(limit: number = 50): Promise<any[]> {
    return await db
      .select()
      .from(communicationLogs)
      .orderBy(communicationLogs.sentAt)
      .limit(limit);
  }

  getServiceStatus(): {email: boolean, sms: boolean, whatsapp: boolean} {
    return {
      email: !!process.env.SENDGRID_API_KEY,
      sms: !!(this.twilioAccountSid && this.twilioAuthToken && this.twilioPhoneNumber),
      whatsapp: !!(this.twilioAccountSid && this.twilioAuthToken && this.twilioWhatsAppNumber)
    };
  }
}

export const communicationService = new CommunicationService();