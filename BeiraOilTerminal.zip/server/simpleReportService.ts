import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { sendEmail } from './emailService';

class SimpleReportService {
  async sendSystemCapabilitiesReport(): Promise<boolean> {
    console.log('Enviando relatório de capacidades do sistema por email...');
    
    const reportData = this.getSystemCapabilities();
    const success = await this.sendReportEmail(reportData);
    
    return success;
  }

  private getSystemCapabilities() {
    return {
      title: "Sistema de Gestão de Navios - Terminal Petrolífero da Beira",
      subtitle: "Relatório Completo de Funcionalidades e Capacidades",
      generatedAt: new Date(),
      version: "2.0",
      
      mainFeatures: [
        {
          category: "Gestão de Navios",
          features: [
            "Registro completo de navios com informações detalhadas (nome, contra marca, calado, agentes)",
            "Sistema de status em tempo real (esperado, na barra, próximo a atracar, no cais, partido)",
            "Controle de tipos de operação (Trânsito e Combinado) com regras de atracação 2:1",
            "Sistema de priorização IMOPETRO conforme Decreto 89/2019",
            "Gestão de parcelas de carga com volumes e destinatários",
            "Rastreamento de progresso de descarga em tempo real"
          ]
        },
        {
          category: "Controle de Atracação",
          features: [
            "Registro de tempos de atracação (primeira e última amarra)",
            "Verificação automática de condições de atracação baseada no calado e maré",
            "Sistema de confirmação de instruções de descarga via email",
            "Controle de berço com status de manutenção programada",
            "Fluxo automatizado de movimentação entre status"
          ]
        },
        {
          category: "Sistema de Priorização Inteligente",
          features: [
            "Prioridade absoluta para navios IMOPETRO (Decreto 89/2019)",
            "Regra de atracação 2:1: 2 navios trânsito + 1 navio combinado",
            "Ordenação cronológica por data de chegada na barra",
            "Badges visuais diferenciando tipos de operação",
            "Alertas de prioridade em tempo real"
          ]
        },
        {
          category: "Monitoramento Ambiental",
          features: [
            "Monitoramento de marés em tempo real para Porto da Beira",
            "Previsões de maré com análise harmônica (constituintes M2, S2, N2)",
            "Alertas meteorológicos para ventos acima de 25 nós",
            "Dados de temperatura, umidade e pressão atmosférica",
            "Integração com APIs meteorológicas (OpenWeather e Open-Meteo)"
          ]
        },
        {
          category: "Sistema de Notificações",
          features: [
            "Emails automáticos de confirmação de atracação",
            "Notificações de mudança de status via SendGrid",
            "Sistema de tokens seguros para confirmação de instruções",
            "Alertas personalizáveis por navio",
            "Notificações para agentes de navios e carga"
          ]
        },
        {
          category: "Relatórios e Analytics",
          features: [
            "Relatórios mensais automáticos em PDF",
            "Gráficos de operações com Chart.js",
            "Análise de volumes por destinatário",
            "Estatísticas de tempos de operação",
            "Limpeza automática de dados após 30 dias",
            "Log de acesso a relatórios para auditoria"
          ]
        },
        {
          category: "Controle de Acesso",
          features: [
            "Sistema de autenticação com Replit Auth",
            "Controle de permissões granular (update_discharge, confirm_ship, move_ship, manage_maintenance)",
            "Aprovação administrativa para operadores",
            "Acesso público para visualização de status",
            "Senha administrativa para ações sensíveis"
          ]
        },
        {
          category: "Interface e Usabilidade",
          features: [
            "Interface responsiva para dispositivos móveis",
            "Design otimizado para ambiente marítimo",
            "Visualização em tempo real da fila de navios",
            "Modais informativos com abas organizadas",
            "Suporte a português brasileiro",
            "Temas claro/escuro automáticos"
          ]
        }
      ],
      
      technicalSpecs: {
        frontend: "React 18 com TypeScript, Tailwind CSS, shadcn/ui",
        backend: "Express.js com TypeScript, Drizzle ORM",
        database: "PostgreSQL (Neon Serverless)",
        authentication: "Replit Auth com OpenID Connect",
        email: "SendGrid para notificações profissionais",
        charts: "Chart.js e Puppeteer para relatórios PDF",
        weather: "APIs OpenWeather e Open-Meteo",
        deployment: "Replit com domínio personalizado beiraoilterminal-vessels-lineup.com"
      },
      
      operationalBenefits: [
        "Redução significativa do tempo de coordenação de navios",
        "Transparência total no processo de atracação",
        "Conformidade regulatória automática (Decreto 89/2019)",
        "Otimização da utilização do berço único",
        "Rastreamento preciso de operações de descarga",
        "Melhoria na comunicação com agentes marítimos",
        "Relatórios automáticos para gestão superior",
        "Alertas preventivos para condições adversas"
      ]
    };
  }

  private async sendReportEmail(data: any): Promise<boolean> {
    const emailData = {
      to: 'manuel.antonio@cfm.co.mz',
      from: 'noreply@beiraoilterminal.com',
      subject: 'Relatório Completo de Funcionalidades - Sistema de Gestão Portuária',
      html: this.getEmailTemplate(data)
    };

    const success = await sendEmail(emailData);
    
    if (success) {
      console.log('Relatório do sistema enviado com sucesso para manuel.antonio@cfm.co.mz');
    } else {
      console.log('Erro ao enviar relatório do sistema');
    }
    
    return success;
  }

  private getEmailTemplate(data: any): string {
    return `
    <div style="font-family: Arial, sans-serif; max-width: 800px; margin: 0 auto; padding: 20px; background-color: #f9fafb;">
        <div style="background: white; padding: 30px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1);">
            <div style="text-align: center; margin-bottom: 30px; border-bottom: 3px solid #1e40af; padding-bottom: 20px;">
                <h1 style="color: #1e40af; margin: 0; font-size: 28px;">⚓ Sistema de Gestão Portuária</h1>
                <h2 style="color: #64748b; margin: 10px 0 0 0; font-size: 18px; font-weight: normal;">Terminal Petrolífero da Beira</h2>
                <p style="color: #6b7280; margin: 10px 0 0 0; font-size: 14px;">
                    <strong>Data:</strong> ${format(data.generatedAt, "dd 'de' MMMM 'de' yyyy 'às' HH:mm", { locale: ptBR })} |
                    <strong>Versão:</strong> ${data.version} |
                    <strong>Domínio:</strong> beiraoilterminal-vessels-lineup.com
                </p>
            </div>
            
            <div style="background: #eff6ff; padding: 20px; border-radius: 8px; border-left: 4px solid #1e40af; margin: 20px 0;">
                <h3 style="color: #1e40af; margin: 0 0 10px 0;">📋 Relatório de Funcionalidades Completas</h3>
                <p style="margin: 0; color: #374151;">
                    Este relatório apresenta todas as funcionalidades e capacidades do sistema de gestão de navios 
                    desenvolvido para o Terminal Petrolífero da Beira (CFM-EP).
                </p>
            </div>
            
            ${data.mainFeatures.map((category: any) => `
                <div style="margin: 25px 0; background: #f9fafb; padding: 20px; border-radius: 10px; border: 1px solid #e5e7eb;">
                    <h3 style="color: #059669; margin: 0 0 15px 0; font-size: 18px;">${category.category}</h3>
                    <ul style="margin: 0; padding-left: 20px; line-height: 1.8; color: #374151;">
                        ${category.features.map((feature: string) => `<li style="margin: 8px 0;">${feature}</li>`).join('')}
                    </ul>
                </div>
            `).join('')}
            
            <div style="margin: 30px 0; background: #f0fdf4; padding: 20px; border-radius: 8px; border-left: 4px solid #22c55e;">
                <h3 style="color: #15803d; margin: 0 0 15px 0;">⚙️ Especificações Técnicas</h3>
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 15px;">
                    <div><strong style="color: #1d4ed8;">Frontend:</strong> ${data.technicalSpecs.frontend}</div>
                    <div><strong style="color: #1d4ed8;">Backend:</strong> ${data.technicalSpecs.backend}</div>
                    <div><strong style="color: #1d4ed8;">Banco de Dados:</strong> ${data.technicalSpecs.database}</div>
                    <div><strong style="color: #1d4ed8;">Autenticação:</strong> ${data.technicalSpecs.authentication}</div>
                    <div><strong style="color: #1d4ed8;">Notificações:</strong> ${data.technicalSpecs.email}</div>
                    <div><strong style="color: #1d4ed8;">Relatórios:</strong> ${data.technicalSpecs.charts}</div>
                    <div><strong style="color: #1d4ed8;">Clima/Marés:</strong> ${data.technicalSpecs.weather}</div>
                    <div><strong style="color: #1d4ed8;">Deployment:</strong> ${data.technicalSpecs.deployment}</div>
                </div>
            </div>
            
            <div style="margin: 30px 0; background: #fef3c7; padding: 20px; border-radius: 8px; border-left: 4px solid #f59e0b;">
                <h3 style="color: #d97706; margin: 0 0 15px 0;">📈 Benefícios Operacionais</h3>
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 10px;">
                    ${data.operationalBenefits.map((benefit: string) => `
                        <div style="background: #fffbeb; padding: 12px; border-radius: 6px; border-left: 4px solid #f59e0b; font-size: 14px;">${benefit}</div>
                    `).join('')}
                </div>
            </div>
            
            <div style="margin: 30px 0; background: #fdf2f8; padding: 20px; border-radius: 8px; border-left: 4px solid #ec4899;">
                <h3 style="color: #be185d; margin: 0 0 15px 0;">🎯 Principais Destaques</h3>
                <ul style="margin: 10px 0; color: #374151; line-height: 1.8; padding-left: 20px;">
                    <li><strong>Sistema de Priorização IMOPETRO:</strong> Conformidade automática com Decreto 89/2019</li>
                    <li><strong>Regras de Atracação 2:1:</strong> Algoritmo inteligente para navios trânsito e combinados</li>
                    <li><strong>Monitoramento Ambiental:</strong> Dados de maré e clima em tempo real</li>
                    <li><strong>Relatórios Automáticos:</strong> Geração e envio mensal de relatórios em PDF</li>
                    <li><strong>Interface Responsiva:</strong> Otimizada para dispositivos móveis e ambiente marítimo</li>
                    <li><strong>Controle de Acesso:</strong> Sistema seguro com permissões granulares</li>
                </ul>
            </div>
            
            <div style="margin: 30px 0; text-align: center; background: #e0f2fe; padding: 20px; border-radius: 8px;">
                <h3 style="color: #0277bd; margin: 0 0 10px 0;">🌐 Acesso ao Sistema</h3>
                <p style="color: #374151; margin: 0; font-size: 16px;">
                    Sistema disponível em: <br>
                    <strong style="color: #1e40af; font-size: 18px;">https://beiraoilterminal-vessels-lineup.com</strong>
                </p>
            </div>
            
            <div style="border-top: 1px solid #e5e7eb; padding-top: 20px; text-align: center; color: #9ca3af; font-size: 12px;">
                <p style="margin: 0;">Este relatório foi gerado automaticamente pelo sistema de gestão portuária</p>
                <p style="margin: 5px 0 0 0;">CFM-EP | Terminal Petrolífero da Beira | ${format(data.generatedAt, 'yyyy')}</p>
                <p style="margin: 5px 0 0 0;">Para suporte técnico, contate o administrador do sistema</p>
            </div>
        </div>
    </div>
    `;
  }
}

export const simpleReportService = new SimpleReportService();