import { GoogleGenAI } from "@google/genai";
import { db } from "./db";
import { nanoid } from "nanoid";
import * as schema from "@shared/schema";
import { eq, sql } from "drizzle-orm";

export type UserRole = 'visitor' | 'publico' | 'line_up' | 'gestores' | 'ctos' | 'desenvolvedor' | 'agente_navio' | 'operator' | 'admin';
export type Language = 'pt' | 'en';

export interface GeminiChatMessage {
  id: string;
  sessionId: string;
  content: string;
  role: 'user' | 'assistant';
  timestamp: Date;
  confidence?: number;
  requiresEscalation?: boolean;
  responseTimeMs?: number;
}

export interface GeminiAIResponse {
  response: string;
  confidence: number;
  requiresEscalation: boolean;
  sessionId: string;
  responseTimeMs: number;
  suggestions?: string[];
}

export interface GeminiCapabilities {
  canViewShips: boolean;
  canModifyShips: boolean;
  canViewReports: boolean;
  canAccessSensitiveData: boolean;
  canEscalateToHuman: boolean;
  maxSessionDuration: number; // minutes
}

export class GeminiAIService {
  private ai: GoogleGenAI;
  private model: string = "gemini-2.5-flash";

  constructor() {
    this.ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });
    this.initializeTables();
  }

  private async initializeTables(): Promise<void> {
    try {
      await db.execute(`
        CREATE TABLE IF NOT EXISTS gemini_ai_sessions (
          id VARCHAR PRIMARY KEY,
          user_id VARCHAR,
          user_role VARCHAR NOT NULL,
          language VARCHAR NOT NULL DEFAULT 'pt',
          created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
          last_activity TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
          status VARCHAR DEFAULT 'active'
        )
      `);

      await db.execute(`
        CREATE TABLE IF NOT EXISTS gemini_ai_messages (
          id VARCHAR PRIMARY KEY,
          session_id VARCHAR NOT NULL,
          content TEXT NOT NULL,
          role VARCHAR NOT NULL,
          timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
          confidence DECIMAL(3,2),
          requires_escalation BOOLEAN DEFAULT FALSE,
          response_time_ms INTEGER
        )
      `);

      console.log('[GeminiAI] Database tables initialized');
    } catch (error) {
      console.error('[GeminiAI] Database initialization error:', error);
    }
  }

  getUserCapabilities(role: UserRole): GeminiCapabilities {
    switch (role) {
      case 'admin':
      case 'desenvolvedor':
        return {
          canViewShips: true,
          canModifyShips: true,
          canViewReports: true,
          canAccessSensitiveData: true,
          canEscalateToHuman: true,
          maxSessionDuration: 120
        };
      case 'operator':
      case 'ctos':
        return {
          canViewShips: true,
          canModifyShips: true,
          canViewReports: true,
          canAccessSensitiveData: true,
          canEscalateToHuman: true,
          maxSessionDuration: 90
        };
      case 'gestores':
        return {
          canViewShips: true,
          canModifyShips: false,
          canViewReports: true,
          canAccessSensitiveData: true,
          canEscalateToHuman: true,
          maxSessionDuration: 60
        };
      case 'agente_navio':
        return {
          canViewShips: true,
          canModifyShips: false,
          canViewReports: false,
          canAccessSensitiveData: false,
          canEscalateToHuman: true,
          maxSessionDuration: 45
        };
      case 'line_up':
        return {
          canViewShips: true,
          canModifyShips: false,
          canViewReports: false,
          canAccessSensitiveData: false,
          canEscalateToHuman: true,
          maxSessionDuration: 30
        };
      case 'publico':
      case 'visitor':
      default:
        return {
          canViewShips: true,
          canModifyShips: false,
          canViewReports: false,
          canAccessSensitiveData: false,
          canEscalateToHuman: false,
          maxSessionDuration: 30
        };
    }
  }

  private getRoleDisplayName(role: UserRole, language: Language): string {
    const isPortuguese = language === 'pt';
    
    const roleNames = {
      pt: {
        'admin': 'Administrador',
        'desenvolvedor': 'Desenvolvedor',
        'ctos': 'CTO',
        'gestores': 'Gestor',
        'operator': 'Operador',
        'agente_navio': 'Agente do Navio',
        'line_up': 'Line Up',
        'publico': 'Público',
        'visitor': 'Visitante'
      },
      en: {
        'admin': 'Administrator',
        'desenvolvedor': 'Developer',
        'ctos': 'CTO',
        'gestores': 'Manager',
        'operator': 'Operator',
        'agente_navio': 'Ship Agent',
        'line_up': 'Line Up',
        'publico': 'Public',
        'visitor': 'Visitor'
      }
    };

    return roleNames[isPortuguese ? 'pt' : 'en'][role] || role.toUpperCase();
  }

  async createSession(userId: string | null, userRole: UserRole, language: Language): Promise<string> {
    const sessionId = nanoid();
    
    try {
      await db.execute(`
        INSERT INTO gemini_ai_sessions (id, user_id, user_role, language, created_at, last_activity, status)
        VALUES ('${sessionId}', ${userId ? `'${userId}'` : 'NULL'}, '${userRole}', '${language}', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, 'active')
      `);

      console.log(`[GeminiAI] Session created: ${sessionId}`);
      return sessionId;
    } catch (error) {
      console.error('[GeminiAI] Session creation error:', error);
      throw new Error('Failed to create Gemini AI session');
    }
  }

  async processMessage(
    sessionId: string,
    message: string,
    userRole: UserRole, 
    language: Language
  ): Promise<GeminiAIResponse> {
    const startTime = Date.now();
    
    try {
      console.log(`[GeminiAI] Processing message: { sessionId: '${sessionId.substring(0, 10)}...', messageLength: ${message.length}, userRole: '${userRole}' }`);

      // Validate Gemini API key
      if (!process.env.GEMINI_API_KEY) {
        throw new Error('GEMINI_API_KEY not configured');
      }

      // Get real-time system context with live data
      const systemContext = await this.getSystemContextWithLiveData(userRole, language);
      
      // Store user message
      const userMessageId = nanoid();
      await db.execute(`
        INSERT INTO gemini_ai_messages (id, session_id, content, role, timestamp)
        VALUES ('${userMessageId}', '${sessionId}', '${message.replace(/'/g, "''")}', 'user', CURRENT_TIMESTAMP)
      `);

      console.log(`[GeminiAI] Calling Gemini API with model: ${this.model}`);

      // Generate AI response
      const response = await this.ai.models.generateContent({
        model: this.model,
        contents: [{
          role: "user",
          parts: [{
            text: `${systemContext}\n\nUser Question: ${message}\n\nPlease provide a helpful response in ${language === 'pt' ? 'Portuguese' : 'English'}.`
          }]
        }],
        config: {
          temperature: 0.7,
          maxOutputTokens: 1000,
        }
      });

      console.log(`[GeminiAI] Gemini API response received:`, { 
        hasResponse: !!response, 
        textLength: response?.text?.length || 0 
      });

      const responseText = response.text || "Desculpe, não consegui processar sua solicitação.";
      const responseTimeMs = Date.now() - startTime;
      
      // Calculate confidence and escalation
      const confidence = this.calculateConfidence(responseText, message);
      const requiresEscalation = this.shouldEscalate(message, responseText, userRole);

      // Store assistant response
      const assistantMessageId = nanoid();
      await db.execute(`
        INSERT INTO gemini_ai_messages (id, session_id, content, role, timestamp, confidence, requires_escalation, response_time_ms)
        VALUES ('${assistantMessageId}', '${sessionId}', '${responseText.replace(/'/g, "''")}', 'assistant', CURRENT_TIMESTAMP, ${confidence}, ${requiresEscalation}, ${responseTimeMs})
      `);

      // Update session activity
      await db.execute(`
        UPDATE gemini_ai_sessions 
        SET last_activity = CURRENT_TIMESTAMP 
        WHERE id = '${sessionId}'
      `);

      // Generate suggestions
      const suggestions = await this.generateSuggestions(message, userRole, language);

      return {
        response: responseText,
        confidence,
        requiresEscalation,
        sessionId,
        responseTimeMs,
        suggestions
      };

    } catch (error) {
      console.error('[GeminiAI] Message processing error:', error);
      const responseTimeMs = Date.now() - startTime;
      
      const fallbackResponse = language === 'pt' ? 
        'Desculpe, ocorreu um erro ao processar sua mensagem. Tente novamente em alguns instantes.' :
        'Sorry, an error occurred while processing your message. Please try again in a moment.';

      return {
        response: fallbackResponse,
        confidence: 0.1,
        requiresEscalation: true,
        sessionId,
        responseTimeMs,
        suggestions: []
      };
    }
  }

  private async getSystemContextWithLiveData(userRole: UserRole, language: Language): Promise<string> {
    const capabilities = this.getUserCapabilities(userRole);
    
    try {
      // Get real-time ships data
      const shipsData = await this.getLiveShipsData(capabilities.canAccessSensitiveData, language);
      
      // Get current weather and tide conditions
      const environmentalData = await this.getLiveEnvironmentalData(language);
      
      // Get berth status and operational info
      const operationalData = await this.getLiveOperationalData(userRole, language);
      
      const isPortuguese = language === 'pt';
      
      const systemPrompt = isPortuguese ? `
Você é o Assistente IA Gemini para o Terminal Petrolífero da Beira (CFM-EP). Especialista em operações portuárias e marítimas com acesso a dados em tempo real.

CONTEXTO DO SISTEMA:
- Terminal: Beira Oil Terminal, Cais 12
- Operador: CFM-EP (Portos e Caminhos de Ferro de Moçambique)
- Função: Assistente virtual com dados em tempo real

PERFIL DO USUÁRIO ATUAL:
- Nível de acesso: ${this.getRoleDisplayName(userRole, language)}
- Permissões: ${capabilities.canViewShips ? 'Ver navios' : 'Limitado'}, ${capabilities.canModifyShips ? 'Modificar dados' : 'Somente leitura'}, ${capabilities.canAccessSensitiveData ? 'Dados sensíveis' : 'Dados públicos'}
- Duração máxima de sessão: ${capabilities.maxSessionDuration} minutos

DADOS ATUAIS DO TERMINAL (TEMPO REAL):
${shipsData}

CONDIÇÕES AMBIENTAIS ATUAIS:
${environmentalData}

STATUS OPERACIONAL:
${operationalData}

INSTRUÇÕES:
1. Forneça respostas baseadas em dados reais e atualizados
2. Use terminologia marítima profissional
3. Seja específico com números e status quando disponível
4. Respeite as permissões do usuário
5. Ofereça informações úteis e contextuais
` : `
You are the Gemini AI Assistant for Beira Oil Terminal (CFM-EP). Maritime operations specialist with real-time data access.

SYSTEM CONTEXT:
- Terminal: Beira Oil Terminal, Berth 12
- Operator: CFM-EP (Mozambique Ports and Railways)
- Function: Virtual assistant with live data

CURRENT USER PROFILE:
- Access level: ${userRole.toUpperCase()}
- Permissions: ${capabilities.canViewShips ? 'View ships' : 'Limited'}, ${capabilities.canModifyShips ? 'Modify data' : 'Read-only'}, ${capabilities.canAccessSensitiveData ? 'Sensitive data' : 'Public data'}

CURRENT TERMINAL DATA (REAL-TIME):
${shipsData}

CURRENT ENVIRONMENTAL CONDITIONS:
${environmentalData}

OPERATIONAL STATUS:
${operationalData}

INSTRUCTIONS:
1. Provide responses based on real, updated data
2. Use professional maritime terminology
3. Be specific with numbers and status when available
4. Respect user permissions
5. Offer useful and contextual information
`;

      return systemPrompt;
    } catch (error) {
      console.error('[GeminiAI] Error getting live system context:', error);
      return this.getFallbackSystemContext(userRole, language);
    }
  }

  private async getLiveShipsData(canAccessSensitive: boolean, language: Language): Promise<string> {
    try {
      const ships = await db.select().from(schema.ships);
      
      if (!ships || ships.length === 0) {
        return language === 'pt' ? 'Nenhum navio registrado no sistema atualmente.' : 'No ships currently registered in the system.';
      }

      const isPortuguese = language === 'pt';
      let shipsContext = isPortuguese ? 
        `NAVIOS NO TERMINAL (${ships.length} navios registrados):\n` :
        `SHIPS AT TERMINAL (${ships.length} ships registered):\n`;

      // Group ships by status
      const shipsByStatus = {
        expected: ships.filter(s => s.status === 'expected'),
        at_bar: ships.filter(s => s.status === 'at_bar'),
        next_to_berth: ships.filter(s => s.status === 'next_to_berth'),
        at_berth: ships.filter(s => s.status === 'at_berth'),
        departed: ships.filter(s => s.status === 'departed')
      };

      // Add status-specific information
      if (shipsByStatus.expected.length > 0) {
        shipsContext += isPortuguese ? 
          `\n📋 PREVISTOS A CHEGAR (${shipsByStatus.expected.length}):\n` :
          `\n📋 EXPECTED TO ARRIVE (${shipsByStatus.expected.length}):\n`;
        
        shipsByStatus.expected.forEach((ship, index) => {
          shipsContext += `${index + 1}. ${ship.name}`;
          if (canAccessSensitive) {
            shipsContext += ` - ${ship.operationType || 'N/A'}, ${ship.cargoType || 'N/A'}`;
            if (ship.arrivalDateTime) {
              shipsContext += `, ETA: ${new Date(ship.arrivalDateTime).toLocaleDateString('pt-BR')}`;
            }
          }
          shipsContext += '\n';
        });
      }

      if (shipsByStatus.at_bar.length > 0) {
        const withInstructions = shipsByStatus.at_bar.filter(s => s.hasDischargeInstructions);
        const withoutInstructions = shipsByStatus.at_bar.filter(s => !s.hasDischargeInstructions);
        
        if (withoutInstructions.length > 0) {
          shipsContext += isPortuguese ? 
            `\n⚓ NAVIOS NA BARRA SEM INSTRUÇÃO (${withoutInstructions.length}):\n` :
            `\n⚓ SHIPS AT BAR WITHOUT INSTRUCTIONS (${withoutInstructions.length}):\n`;
          
          withoutInstructions.forEach((ship, index) => {
            shipsContext += `${index + 1}. ${ship.name}`;
            if (canAccessSensitive) {
              shipsContext += ` - ${ship.operationType || 'N/A'}, ${ship.cargoType || 'N/A'}`;
            }
            shipsContext += '\n';
          });
        }

        if (withInstructions.length > 0) {
          shipsContext += isPortuguese ? 
            `\n📝 NAVIOS NA BARRA COM INSTRUÇÃO (${withInstructions.length}):\n` :
            `\n📝 SHIPS AT BAR WITH INSTRUCTIONS (${withInstructions.length}):\n`;
          
          withInstructions.forEach((ship, index) => {
            shipsContext += `${index + 1}. ${ship.name}`;
            if (canAccessSensitive) {
              shipsContext += ` - ${ship.operationType || 'N/A'}, ${ship.cargoType || 'N/A'}`;
            }
            shipsContext += '\n';
          });
        }
      }

      if (shipsByStatus.next_to_berth.length > 0) {
        shipsContext += isPortuguese ? 
          `\n🚢 PRÓXIMOS A ATRACAR (${shipsByStatus.next_to_berth.length}):\n` :
          `\n🚢 NEXT TO BERTH (${shipsByStatus.next_to_berth.length}):\n`;
        
        shipsByStatus.next_to_berth.forEach((ship, index) => {
          shipsContext += `${index + 1}. ${ship.name}`;
          if (canAccessSensitive) {
            shipsContext += ` - ${ship.operationType || 'N/A'}, ${ship.cargoType || 'N/A'}`;
          }
          shipsContext += '\n';
        });
      }

      if (shipsByStatus.at_berth.length > 0) {
        shipsContext += isPortuguese ? 
          `\n🏗️ ATRACADO NO CAIS 12 (${shipsByStatus.at_berth.length}):\n` :
          `\n🏗️ BERTHED AT BERTH 12 (${shipsByStatus.at_berth.length}):\n`;
        
        shipsByStatus.at_berth.forEach((ship, index) => {
          shipsContext += `${index + 1}. ${ship.name}`;
          if (canAccessSensitive) {
            shipsContext += ` - ${ship.operationType || 'N/A'}, ${ship.cargoType || 'N/A'}`;
            
            // Get discharge progress if available
            db.select().from(schema.dischargeProgress)
              .where(eq(schema.dischargeProgress.shipId, ship.id))
              .then(progress => {
                if (progress.length > 0) {
                  const totalProgress = progress.reduce((sum, p) => sum + parseFloat(p.percentage || '0'), 0) / progress.length;
                  shipsContext += `, Descarga: ${totalProgress.toFixed(1)}%`;
                }
              });
          }
          shipsContext += '\n';
        });
      }

      if (shipsByStatus.departed.length > 0 && canAccessSensitive) {
        const recentDepartures = shipsByStatus.departed
          .filter(s => s.updatedAt && new Date(s.updatedAt) > new Date(Date.now() - 24 * 60 * 60 * 1000))
          .slice(0, 3);
        
        if (recentDepartures.length > 0) {
          shipsContext += isPortuguese ? 
            `\n✅ PARTIDOS RECENTEMENTE (últimas 24h):\n` :
            `\n✅ RECENTLY DEPARTED (last 24h):\n`;
          
          recentDepartures.forEach((ship, index) => {
            shipsContext += `${index + 1}. ${ship.name} - ${ship.operationType || 'N/A'}\n`;
          });
        }
      }

      return shipsContext;
    } catch (error) {
      console.error('[GeminiAI] Error getting live ships data:', error);
      return language === 'pt' ? 
        'Erro ao obter dados de navios em tempo real.' : 
        'Error retrieving real-time ships data.';
    }
  }

  private async getLiveEnvironmentalData(language: Language): Promise<string> {
    try {
      // Get weather and tide data using direct fetch calls
      const weatherResponse = await fetch('http://localhost:5000/api/weather');
      const tideResponse = await fetch('http://localhost:5000/api/tide');
      
      const weatherData = weatherResponse.ok ? await weatherResponse.json() : null;
      const tideData = tideResponse.ok ? await tideResponse.json() : null;

      const isPortuguese = language === 'pt';
      let environmentalContext = '';

      if (weatherData) {
        environmentalContext += isPortuguese ? 
          `🌤️ CONDIÇÕES METEOROLÓGICAS:\n` +
          `- Temperatura: ${weatherData.temperature}°C\n` +
          `- Humidade: ${weatherData.humidity}%\n` +
          `- Pressão: ${weatherData.pressure} hPa\n` +
          `- Vento: ${weatherData.windSpeed} m/s\n` :
          `🌤️ WEATHER CONDITIONS:\n` +
          `- Temperature: ${weatherData.temperature}°C\n` +
          `- Humidity: ${weatherData.humidity}%\n` +
          `- Pressure: ${weatherData.pressure} hPa\n` +
          `- Wind: ${weatherData.windSpeed} m/s\n`;
      }

      if (tideData) {
        environmentalContext += isPortuguese ?
          `\n🌊 CONDIÇÕES DE MARÉ:\n` +
          `- Altura atual: ${tideData.currentTide?.toFixed(2)}m\n` +
          `- Próxima maré alta: ${tideData.nextHigh || 'N/A'}\n` +
          `- Próxima maré baixa: ${tideData.nextLow || 'N/A'}\n` :
          `\n🌊 TIDE CONDITIONS:\n` +
          `- Current height: ${tideData.currentTide?.toFixed(2)}m\n` +
          `- Next high tide: ${tideData.nextHigh || 'N/A'}\n` +
          `- Next low tide: ${tideData.nextLow || 'N/A'}\n`;
      }

      return environmentalContext || (isPortuguese ? 
        'Dados ambientais não disponíveis.' : 
        'Environmental data not available.');
    } catch (error) {
      console.error('[GeminiAI] Error getting environmental data:', error);
      return language === 'pt' ? 
        'Erro ao obter dados ambientais.' : 
        'Error retrieving environmental data.';
    }
  }

  private async getLiveOperationalData(userRole: UserRole, language: Language): Promise<string> {
    try {
      const capabilities = this.getUserCapabilities(userRole);
      const isPortuguese = language === 'pt';
      let operationalContext = '';

      // Get berth status
      const berthStatus = await this.getBerthStatus(language);
      operationalContext += berthStatus;

      // Get maintenance status if user has access
      if (capabilities.canViewReports) {
        try {
          const maintenance = await db.select().from(schema.berthMaintenance)
            .where(eq(schema.berthMaintenance.isUnderMaintenance, true));
          
          if (maintenance.length > 0) {
            operationalContext += isPortuguese ?
              `\n🔧 STATUS DE MANUTENÇÃO:\n` +
              `- Cais em manutenção\n` +
              `- Período: ${maintenance[0].maintenancePeriod || 'N/A'}\n` :
              `\n🔧 MAINTENANCE STATUS:\n` +
              `- Berth under maintenance\n` +
              `- Period: ${maintenance[0].maintenancePeriod || 'N/A'}\n`;
          }
        } catch (error) {
          console.error('[GeminiAI] Error getting maintenance status:', error);
        }
      }

      // Get operational statistics
      if (capabilities.canAccessSensitiveData) {
        const stats = await this.getOperationalStatistics(userRole, language);
        operationalContext += `\n${stats}`;
      }

      return operationalContext;
    } catch (error) {
      console.error('[GeminiAI] Error getting operational data:', error);
      return language === 'pt' ? 
        'Erro ao obter dados operacionais.' : 
        'Error retrieving operational data.';
    }
  }

  private async getBerthStatus(language: Language): Promise<string> {
    try {
      const berthShips = await db.select().from(schema.ships)
        .where(eq(schema.ships.status, 'at_berth'));
      
      const isPortuguese = language === 'pt';
      
      if (berthShips.length === 0) {
        return isPortuguese ? 
          '🏗️ STATUS DO CAIS: Livre (sem navios atracados)\n' :
          '🏗️ BERTH STATUS: Free (no ships berthed)\n';
      } else {
        const ship = berthShips[0];
        return isPortuguese ?
          `🏗️ STATUS DO CAIS: Ocupado pelo navio ${ship.name}\n` :
          `🏗️ BERTH STATUS: Occupied by vessel ${ship.name}\n`;
      }
    } catch (error) {
      console.error('[GeminiAI] Error getting berth status:', error);
      return language === 'pt' ? 
        'Status do cais não disponível.' : 
        'Berth status not available.';
    }
  }



  private getFallbackSystemContext(userRole: UserRole, language: Language): string {
    const capabilities = this.getUserCapabilities(userRole);
    const isPortuguese = language === 'pt';
    
    return isPortuguese ?
      `Você é o Assistente IA Gemini para o Terminal Petrolífero da Beira (CFM-EP).
      
PERFIL DO USUÁRIO: ${userRole.toUpperCase()}
PERMISSÕES: ${capabilities.canViewShips ? 'Ver navios' : 'Limitado'}

Atualmente não é possível acessar dados em tempo real. Forneça informações gerais sobre operações portuárias.` :
      `You are the Gemini AI Assistant for Beira Oil Terminal (CFM-EP).
      
USER PROFILE: ${userRole.toUpperCase()}
PERMISSIONS: ${capabilities.canViewShips ? 'View ships' : 'Limited'}

Real-time data access currently unavailable. Provide general port operations information.`;
  }

  private async getSystemContext(userRole: UserRole, language: Language): Promise<string> {
    const capabilities = this.getUserCapabilities(userRole);
    
    try {
      // Get current ships data based on permissions
      const shipsData = await this.getShipsContext(capabilities.canAccessSensitiveData, language);
      
      // Get terminal status
      const terminalStatus = await this.getTerminalStatus(language);
      
      // Get weather and tide info
      const environmentalData = await this.getEnvironmentalContext(language);

      // Get real-time operational statistics
      const operationalStats = await this.getOperationalStatistics(userRole, language);

      const systemPrompt = language === 'pt' ? `
Você é o Assistente IA Gemini para o Terminal Petrolífero da Beira (CFM-EP). Você é um assistente especializado em operações portuárias e marítimas.

CONTEXTO DO SISTEMA:
- Terminal: Beira Oil Terminal, Cais 12
- Operador: CFM-EP (Portos e Caminhos de Ferro de Moçambique)
- Função: Assistente virtual para informações e suporte operacional

PERFIL DO USUÁRIO ATUAL:
- Nível de acesso: ${userRole.toUpperCase()}
- Permissões de visualização de navios: ${capabilities.canViewShips ? 'AUTORIZADO' : 'RESTRITO'}
- Permissões de modificação: ${capabilities.canModifyShips ? 'AUTORIZADO' : 'RESTRITO'}
- Acesso a dados sensíveis: ${capabilities.canAccessSensitiveData ? 'AUTORIZADO' : 'RESTRITO'}
- Acesso a relatórios: ${capabilities.canViewReports ? 'AUTORIZADO' : 'RESTRITO'}
- Modificar dados: ${capabilities.canModifyShips ? 'Sim' : 'Não'}  
- Ver relatórios: ${capabilities.canViewReports ? 'Sim' : 'Não'}
- Dados sensíveis: ${capabilities.canAccessSensitiveData ? 'Sim' : 'Não'}

DADOS ATUAIS DO TERMINAL:
${shipsData}

STATUS OPERACIONAL:
${terminalStatus}

CONDIÇÕES AMBIENTAIS:
${environmentalData}

INSTRUÇÕES:
1. Forneça respostas precisas baseadas nos dados reais do sistema
2. Mantenha tom profissional e informativo
3. Respeite as permissões do usuário
4. Use terminologia marítima apropriada
5. Seja específico com dados quando disponível
6. Ofereça sugestões úteis relacionadas ao contexto
` : `
You are the Gemini AI Assistant for Beira Oil Terminal (CFM-EP). You are a specialized assistant for port and maritime operations.

SYSTEM CONTEXT:
- Terminal: Beira Oil Terminal, Berth 12
- Operator: CFM-EP (Mozambique Ports and Railways)
- Function: Virtual assistant for information and operational support

USER PERMISSIONS (${userRole}):
- View ships: ${capabilities.canViewShips ? 'Yes' : 'No'}
- Modify data: ${capabilities.canModifyShips ? 'Yes' : 'No'}
- View reports: ${capabilities.canViewReports ? 'Yes' : 'No'}
- Sensitive data: ${capabilities.canAccessSensitiveData ? 'Yes' : 'No'}

CURRENT TERMINAL DATA:
${shipsData}

OPERATIONAL STATUS:
${terminalStatus}

ENVIRONMENTAL CONDITIONS:
${environmentalData}

INSTRUCTIONS:
1. Provide accurate responses based on real system data
2. Maintain professional and informative tone
3. Respect user permissions
4. Use appropriate maritime terminology
5. Be specific with data when available
6. Offer useful suggestions related to context
`;

      return systemPrompt;
    } catch (error) {
      console.error('[GeminiAI] System context error:', error);
      return language === 'pt' ? 
        'Sistema de assistente IA para Terminal Petrolífero da Beira.' :
        'AI assistant system for Beira Oil Terminal.';
    }
  }

  private async getOperationalStatistics(userRole: UserRole, language: Language): Promise<string> {
    try {
      const capabilities = this.getUserCapabilities(userRole);
      
      if (!capabilities.canViewShips) {
        return language === 'pt' ? 
          'Estatísticas não disponíveis para seu nível de acesso.' :
          'Statistics not available for your access level.';
      }

      // Get ship counts by status using Drizzle ORM
      const statusCounts = await db.select({
        status: schema.ships.status,
        count: sql<number>`cast(count(*) as int)`
      })
      .from(schema.ships)
      .groupBy(schema.ships.status);

      // Get total cargo volume if user has permission
      let cargoInfo = '';
      if (capabilities.canAccessSensitiveData) {
        const totalVolumeResult = await db.select({
          totalVolume: sql<number>`cast(sum(cast(volume_mt as decimal)) as decimal)`
        })
        .from(schema.cargoParcels);
        
        const totalVolume = totalVolumeResult[0]?.totalVolume || 0;
        cargoInfo = language === 'pt' ? 
          `\nVolume total de carga no sistema: ${totalVolume} MT` :
          `\nTotal cargo volume in system: ${totalVolume} MT`;
      }

      const stats = statusCounts.map((row) => {
        const status = this.translateStatus(row.status, language);
        return `${status}: ${row.count}`;
      }).join('\n');

      return language === 'pt' ? 
        `Navios por status:\n${stats}${cargoInfo}` :
        `Ships by status:\n${stats}${cargoInfo}`;

    } catch (error) {
      console.error('[GeminiAI] Operational statistics error:', error);
      return language === 'pt' ? 
        'Estatísticas operacionais não disponíveis' :
        'Operational statistics unavailable';
    }
  }

  private async getShipsContext(canViewSensitive: boolean, language: Language): Promise<string> {
    try {
      // Get ships with detailed information using Drizzle ORM
      const ships = await db.select({
        id: schema.ships.id,
        name: schema.ships.name,
        countermark: schema.ships.countermark,
        status: schema.ships.status,
        arrivalDateTime: schema.ships.arrivalDateTime,
        shipAgent: schema.ships.shipAgent,
        cargoAgent: schema.ships.cargoAgent,
        hasDischargeInstructions: schema.ships.hasDischargeInstructions
      }).from(schema.ships)
        .orderBy(schema.ships.arrivalDateTime);

      if (!ships || ships.length === 0) {
        return language === 'pt' ? 'Nenhum navio registrado no sistema atualmente.' : 'No ships currently registered in the system.';
      }

      // Get comprehensive data for each ship
      const shipsWithData = await Promise.all(ships.map(async (ship) => {
        // Get cargo parcels
        const parcels = await db.select({
          id: schema.cargoParcels.id,
          volumeMT: schema.cargoParcels.volumeMT,
          receiver: schema.cargoParcels.receiver,
          status: schema.cargoParcels.status,
          product: schema.cargoParcels.product
        }).from(schema.cargoParcels)
          .where(eq(schema.cargoParcels.shipId, ship.id));

        // Get berthing information
        const berthing = await db.select({
          firstRopeTime: schema.berthingRecords.firstRopeTime,
          lastRopeTime: schema.berthingRecords.lastRopeTime
        }).from(schema.berthingRecords)
          .where(eq(schema.berthingRecords.shipId, ship.id))
          .limit(1);

        // Get discharge progress
        const dischargeProgress = await Promise.all(parcels.map(async (parcel) => {
          const progress = await db.select({
            percentage: schema.dischargeProgress.percentage,
            recordedAt: schema.dischargeProgress.recordedAt
          }).from(schema.dischargeProgress)
            .where(eq(schema.dischargeProgress.shipId, ship.id))
            .orderBy(schema.dischargeProgress.recordedAt)
            .limit(1);
          
          return {
            parcelId: parcel.id,
            progress: progress[0]?.percentage || 0
          };
        }));

        const totalVolume = parcels.reduce((sum, parcel) => sum + parseFloat(parcel.volumeMT || '0'), 0);
        const avgProgress = dischargeProgress.length > 0 ? 
          dischargeProgress.reduce((sum, p) => sum + (parseFloat(p.progress?.toString() || '0')), 0) / dischargeProgress.length : 0;

        return {
          ...ship,
          parcels,
          berthing: berthing[0] || null,
          totalVolume,
          avgProgress
        };
      }));

      let context = language === 'pt' ? 'NAVIOS NO SISTEMA (dados em tempo real):\n' : 'SHIPS IN SYSTEM (real-time data):\n';
      
      shipsWithData.forEach((ship, index) => {
        const status = this.translateStatus(ship.status, language);
        const arrivalDate = new Date(ship.arrivalDateTime).toLocaleDateString('pt-BR', {
          day: '2-digit',
          month: '2-digit', 
          year: 'numeric',
          hour: '2-digit',
          minute: '2-digit'
        });
        
        context += `\n${index + 1}. NAVIO: ${ship.name}`;
        if (ship.countermark) context += ` (Contramarcha: ${ship.countermark})`;
        
        context += `\n   📊 Status atual: ${status}`;
        context += `\n   📅 Chegada na barra: ${arrivalDate}`;
        context += `\n   🚢 Volume total: ${ship.totalVolume.toFixed(1)} MT`;
        
        if (ship.avgProgress > 0) {
          context += `\n   ⚡ Progresso descarga: ${ship.avgProgress.toFixed(1)}%`;
        }
        
        if (canViewSensitive) {
          if (ship.shipAgent) context += `\n   🏢 Agente do navio: ${ship.shipAgent}`;
          if (ship.cargoAgent) context += `\n   📦 Agente da carga: ${ship.cargoAgent}`;
          
          if (ship.berthing?.lastRopeTime) {
            const berthingDate = new Date(ship.berthing.lastRopeTime).toLocaleDateString('pt-BR', {
              day: '2-digit',
              month: '2-digit', 
              year: 'numeric',
              hour: '2-digit',
              minute: '2-digit'
            });
            context += `\n   ⚓ Atracação: ${berthingDate}`;
          }
          
          if (ship.hasDischargeInstructions) {
            const instrStatus = ship.hasDischargeInstructions ? 
              '✅ Com instrução confirmada' : '⏳ Aguardando instrução';
            context += `\n   📋 Instrução descarga: ${instrStatus}`;
          }
          
          if (ship.parcels && ship.parcels.length > 0) {
            const receivers = Array.from(new Set(ship.parcels.map(p => p.receiver).filter(Boolean)));
            if (receivers.length > 0) {
              context += `\n   🏭 Recebedores: ${receivers.join(', ')}`;
            }
            
            const products = Array.from(new Set(ship.parcels.map(p => p.product).filter(Boolean)));
            if (products.length > 0) {
              context += `\n   🛢️ Produtos: ${products.join(', ')}`;
            }
            
            const completedParcels = ship.parcels.filter(p => p.status === 'completed').length;
            const inProgressParcels = ship.parcels.filter(p => p.status === 'in_progress').length;
            const pendingParcels = ship.parcels.filter(p => p.status === 'pending').length;
            
            context += `\n   📦 Parcelas: ${completedParcels} concluídas, ${inProgressParcels} em progresso, ${pendingParcels} pendentes`;
          }
        }
      });

      return context;
    } catch (error) {
      console.error('[GeminiAI] Ships context error:', error);
      return language === 'pt' ? 
        'Erro ao acessar dados dos navios. Sistema temporariamente indisponível.' : 
        'Error accessing ship data. System temporarily unavailable.';
    }
  }

  private async getTerminalStatus(language: Language): Promise<string> {
    try {
      // Check berth maintenance
      const maintenanceResult = await db.execute(`
        SELECT * FROM berth_maintenance 
        WHERE status = 'active' 
        ORDER BY created_at DESC 
        LIMIT 1
      `);

      if (maintenanceResult.rows && maintenanceResult.rows.length > 0) {
        const maintenance = maintenanceResult.rows[0] as any;
        return language === 'pt' ? 
          `Cais em manutenção: ${maintenance.description || 'Manutenção programada'}` :
          `Berth under maintenance: ${maintenance.description || 'Scheduled maintenance'}`;
      }

      return language === 'pt' ? 'Cais operacional e disponível' : 'Berth operational and available';
    } catch (error) {
      console.error('[GeminiAI] Terminal status error:', error);
      return language === 'pt' ? 'Status do terminal não disponível' : 'Terminal status unavailable';
    }
  }

  private async getEnvironmentalContext(language: Language): Promise<string> {
    try {
      // This would call the weather and tide APIs
      return language === 'pt' ? 
        'Condições meteorológicas e de maré atualizadas automaticamente' :
        'Weather and tide conditions updated automatically';
    } catch (error) {
      return language === 'pt' ? 
        'Dados ambientais não disponíveis' :
        'Environmental data unavailable';
    }
  }

  private translateStatus(status: string, language: Language): string {
    const translations: Record<string, Record<string, string>> = {
      'expected': { pt: 'Esperado', en: 'Expected' },
      'at_bar': { pt: 'Na Barra', en: 'At Bar' },
      'next_to_berth': { pt: 'Próximo ao Cais', en: 'Next to Berth' },
      'at_berth': { pt: 'Atracado', en: 'At Berth' },
      'departed': { pt: 'Partiu', en: 'Departed' }
    };

    return translations[status]?.[language] || status;
  }

  private calculateConfidence(response: string, userMessage: string): number {
    // Simple confidence calculation based on response length and content
    let confidence = 0.8;

    if (response.length < 20) confidence -= 0.3;
    if (response.includes('desculpe') || response.includes('sorry')) confidence -= 0.2;
    if (response.includes('erro') || response.includes('error')) confidence -= 0.4;
    if (userMessage.length > 100) confidence += 0.1; // Detailed questions usually get better responses

    return Math.max(0.1, Math.min(1.0, confidence));
  }

  private shouldEscalate(userMessage: string, response: string, userRole: UserRole): boolean {
    const escalationKeywords = [
      'emergency', 'urgent', 'problema grave', 'serious problem',
      'accident', 'acidente', 'help', 'ajuda imediata'
    ];

    const hasEscalationKeyword = escalationKeywords.some(keyword => 
      userMessage.toLowerCase().includes(keyword) || response.toLowerCase().includes(keyword)
    );

    const isShortResponse = response.length < 30;
    const hasErrorIndicator = response.includes('erro') || response.includes('error');

    return hasEscalationKeyword || (isShortResponse && hasErrorIndicator) || userRole === 'visitor';
  }

  private async generateSuggestions(message: string, userRole: UserRole, language: Language): Promise<string[]> {
    const capabilities = this.getUserCapabilities(userRole);
    
    const suggestions: string[] = [];

    if (language === 'pt') {
      if (capabilities.canViewShips) {
        suggestions.push('Mostrar navios atuais');
        suggestions.push('Status de descarga');
      }
      if (capabilities.canViewReports) {
        suggestions.push('Relatórios operacionais');
      }
      suggestions.push('Condições meteorológicas');
      suggestions.push('Informações de maré');
    } else {
      if (capabilities.canViewShips) {
        suggestions.push('Show current ships');
        suggestions.push('Discharge status');
      }
      if (capabilities.canViewReports) {
        suggestions.push('Operational reports');
      }
      suggestions.push('Weather conditions');
      suggestions.push('Tide information');
    }

    return suggestions.slice(0, 3); // Limit to 3 suggestions
  }

  async getChatHistory(sessionId: string): Promise<GeminiChatMessage[]> {
    try {
      const result = await db.execute(`
        SELECT id, session_id, content, role, timestamp, confidence, requires_escalation, response_time_ms
        FROM gemini_ai_messages 
        WHERE session_id = '${sessionId}' 
        ORDER BY timestamp ASC
      `);
      
      return (result.rows || []).map((row: any) => ({
        id: row.id,
        sessionId: row.session_id,
        content: row.content,
        role: row.role,
        timestamp: new Date(row.timestamp),
        confidence: row.confidence,
        requiresEscalation: row.requires_escalation,
        responseTimeMs: row.response_time_ms
      }));
    } catch (error) {
      console.error('[GeminiAI] Failed to get chat history:', error);
      return [];
    }
  }

  async endSession(sessionId: string, satisfactionRating?: number, escalationReason?: string): Promise<void> {
    try {
      await db.execute(`
        UPDATE gemini_ai_sessions 
        SET status = 'ended', last_activity = CURRENT_TIMESTAMP 
        WHERE id = '${sessionId}'
      `);

      console.log(`[GeminiAI] Session ended: ${sessionId}`);
    } catch (error) {
      console.error('[GeminiAI] Session end error:', error);
    }
  }

  private async getWeatherData(): Promise<any> {
    try {
      const response = await fetch('http://localhost:5000/api/weather');
      return response.ok ? await response.json() : null;
    } catch (error) {
      console.error('[GeminiAI] Error getting weather data:', error);
      return null;
    }
  }

  private async getTideData(): Promise<any> {
    try {
      const response = await fetch('http://localhost:5000/api/tide');
      return response.ok ? await response.json() : null;
    } catch (error) {
      console.error('[GeminiAI] Error getting tide data:', error);
      return null;
    }
  }

  async speechToText(audioData: string, language: Language): Promise<string | null> {
    try {
      console.log('[GeminiAI] Starting speech-to-text transcription...');
      
      if (!process.env.OPENAI_API_KEY) {
        console.error('[GeminiAI] OpenAI API key not available for speech-to-text');
        return null;
      }

      const OpenAI = (await import('openai')).default;
      const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

      // Convert base64 audio to buffer
      const audioBuffer = Buffer.from(audioData, 'base64');
      console.log('[GeminiAI] Audio buffer size:', audioBuffer.length, 'bytes');
      
      if (audioBuffer.length === 0) {
        console.error('[GeminiAI] Empty audio buffer received');
        return null;
      }

      // Create temporary file path  
      const fs = await import('fs');
      const path = await import('path');
      
      // Ensure temp directory exists
      const tempDir = '/tmp';
      if (!fs.existsSync(tempDir)) {
        fs.mkdirSync(tempDir, { recursive: true });
      }
      
      // Determine file extension based on audio data
      const isWebM = audioData.startsWith('GkXfowEAAAAAAAAfQoaBAUL') || audioBuffer[0] === 0x1A && audioBuffer[1] === 0x45;
      const extension = isWebM ? 'webm' : 'wav';
      const tempFilePath = path.join(tempDir, `audio_${Date.now()}.${extension}`);
      
      console.log('[GeminiAI] Writing audio to temp file:', tempFilePath);
      
      // Write audio buffer to temporary file
      fs.writeFileSync(tempFilePath, audioBuffer);

      console.log('[GeminiAI] Calling OpenAI Whisper API...');

      // Call OpenAI Whisper API with better error handling
      const transcription = await openai.audio.transcriptions.create({
        file: fs.createReadStream(tempFilePath),
        model: 'whisper-1',
        language: language === 'pt' ? 'pt' : 'en',
        response_format: 'text',
        temperature: 0.2,
        prompt: language === 'pt' ? 
          'Terminal portuário, navios, operações marítimas, descarga, atracação' : 
          'Port terminal, ships, maritime operations, discharge, berthing'
      });

      // Clean up temporary file
      fs.unlinkSync(tempFilePath);
      
      console.log('[GeminiAI] Transcription result:', { 
        hasText: !!transcription, 
        textLength: transcription?.length || 0,
        preview: transcription?.substring(0, 50) 
      });

      return transcription && transcription.trim() ? transcription.trim() : null;
    } catch (error) {
      console.error('[GeminiAI] Speech-to-text error:', error);
      return null;
    }
  }

  async textToSpeech(text: string, language: Language): Promise<string | null> {
    try {
      if (!process.env.OPENAI_API_KEY) {
        console.log('[GeminiAI] OpenAI API key not available for text-to-speech');
        return null;
      }

      const OpenAI = (await import('openai')).default;
      const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

      // Call OpenAI TTS API
      const speech = await openai.audio.speech.create({
        model: 'tts-1',
        voice: 'alloy',
        input: text
      });

      // Convert response to base64
      const audioData = await speech.arrayBuffer();
      const base64Audio = Buffer.from(audioData).toString('base64');
      
      // Return data URL for audio playback
      const audioUrl = `data:audio/mp3;base64,${base64Audio}`;
      
      return audioUrl;
    } catch (error) {
      console.error('[GeminiAI] Text-to-speech error:', error);
      return null;
    }
  }
}

export const geminiAIService = new GeminiAIService();