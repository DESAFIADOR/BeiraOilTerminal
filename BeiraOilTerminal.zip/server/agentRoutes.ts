import type { Express } from "express";
import { storage } from "./storage";
import { agentService } from "./agentService";

// Middleware para verificar se o usuário é agente
function requireAgentRole(req: any, res: any, next: any) {
  if (!req.user) {
    return res.status(401).json({ message: "Unauthorized" });
  }

  const userRole = req.user.role;
  if (userRole !== 'agente_navio') {
    return res.status(403).json({ message: "Access denied. Agent role required." });
  }

  next();
}

export function registerAgentRoutes(app: Express) {
  
  // Buscar navios para agente (simplificado para demonstração)
  app.get('/api/agent/ships', async (req: any, res) => {
    try {
      const ships = await storage.getShips();
      res.json(ships);
    } catch (error) {
      console.error("Error fetching agent ships:", error);
      res.status(500).json({ message: "Failed to fetch ships" });
    }
  });

  // Adicionar navio às previsões
  app.post('/api/agent/ships', requireAgentRole, async (req: any, res) => {
    try {
      const agentId = req.user.id;
      const shipData = req.body;
      
      const newShip = await agentService.addShipToExpected(agentId, shipData);
      res.json(newShip);
    } catch (error) {
      console.error("Error adding ship:", error);
      res.status(500).json({ message: "Failed to add ship" });
    }
  });

  // Confirmar chegada de navio
  app.post('/api/agent/ships/:shipId/confirm-arrival', requireAgentRole, async (req: any, res) => {
    try {
      const agentId = req.user.id;
      const shipId = parseInt(req.params.shipId);
      const { arrivalDateTime } = req.body;
      
      const updatedShip = await agentService.confirmShipArrival(agentId, shipId, new Date(arrivalDateTime));
      res.json(updatedShip);
    } catch (error) {
      console.error("Error confirming arrival:", error);
      res.status(500).json({ message: "Failed to confirm arrival" });
    }
  });

  // Confirmar instruções de descarga
  app.post('/api/agent/ships/:shipId/confirm-instructions', requireAgentRole, async (req: any, res) => {
    try {
      const agentId = req.user.id;
      const shipId = parseInt(req.params.shipId);
      const confirmationData = req.body;
      
      const result = await agentService.confirmInstructions(agentId, {
        shipId,
        ...confirmationData
      });
      
      res.json(result);
    } catch (error) {
      console.error("Error confirming instructions:", error);
      res.status(500).json({ message: "Failed to confirm instructions" });
    }
  });

  // Buscar confirmações de instruções
  app.get('/api/agent/instruction-confirmations', requireAgentRole, async (req: any, res) => {
    try {
      const agentId = req.user.id;
      const confirmations = await agentService.getInstructionConfirmationsByAgent(agentId);
      res.json(confirmations);
    } catch (error) {
      console.error("Error fetching confirmations:", error);
      res.status(500).json({ message: "Failed to fetch confirmations" });
    }
  });

  // Buscar navios com instruções ordenados
  app.get('/api/agent/ships-with-instructions', requireAgentRole, async (req: any, res) => {
    try {
      const orderedShips = await agentService.getOrderedShipsWithInstructions();
      res.json(orderedShips);
    } catch (error) {
      console.error("Error fetching ordered ships:", error);
      res.status(500).json({ message: "Failed to fetch ordered ships" });
    }
  });
}