# Análise de Dados Faltantes - BerthShipInfoModal

## Status Atual
O modal `BerthShipInfoModal` está funcional mas alguns dados estão sendo simulados ou estão indisponíveis.

## Dados Disponíveis ✅
- ✅ Informações básicas do navio (nome, contramarcha, calado)
- ✅ Agentes (navio e carga) com emails
- ✅ Taxa acordada de descarga (editável)
- ✅ Volume total das parcelas
- ✅ Produtos das parcelas
- ✅ Progresso geral de descarga
- ✅ Cálculo de ETC (Estimated Time of Completion)
- ✅ Tipo de operação (Nacional, Trânsito, Combinado, LPG)

## Dados Faltando/Simulados ⚠️

### 1. **Taxa de Performance Atual** 
**Problema:** Hardcoded como 150 MT/h
```javascript
const currentRate = 150; // Simulated current rate
```
**Solução:** Buscar da tabela `operational_discharge_records` ou calcular baseado no progresso real

### 2. **Progresso Real de Descarga**
**Problema:** Usando `ship.dischargeProgress` que pode estar desatualizado
**Solução:** Integrar com sistema de controlo operacional ativo

### 3. **Dados de Atracação/Berthing**
**Faltando:**
- Data/hora de atracação real
- Primeiro e último cabo (berthing records)
- Confirmação oficial de atracação
- Status de ocupação do cais

### 4. **Histórico Operacional**
**Faltando:**
- Eventos de descarga por parcela
- Registros de paradas (stoppages)
- Tempos de espera (waiting times)
- Manutenção durante operação

### 5. **Status Operacional Detalhado**
**Faltando:**
- Status atual da operação (ativo, pausado, concluído)
- Última atividade registrada
- Operador responsável atual
- Turnos operacionais

## Implementações Necessárias

### A. APIs Backend Faltando
```
GET /api/ships/:id/operational-status
GET /api/ships/:id/berthing-data  
GET /api/ships/:id/current-performance
GET /api/ships/:id/operational-history
```

### B. Dados de Banco Necessários
```sql
-- Já existem mas podem precisar de dados:
- berthing_records
- operational_discharge_records  
- discharge_events
- stoppage_records
- waiting_times

-- Pode faltar:
- operational_status table
- performance_tracking table
```

### C. Integrações
- Conectar com sistema de controlo operacional ativo
- Sincronizar dados em tempo real
- Validação de dados de sensores/equipamento

## Próximos Passos Recomendados
1. Verificar quais dados estão disponíveis nas tabelas existentes
2. Implementar APIs para dados operacionais em tempo real
3. Adicionar abas ao modal para organizar informações
4. Conectar com fonte de dados real de performance
5. Implementar notificações de mudança de status