const { scrypt } = require('crypto');
const { promisify } = require('util');

const scryptAsync = promisify(scrypt);

async function createAdminHash() {
  const password = 'BeiraTerm2025!';
  const salt = 'admin-salt-2025';
  
  try {
    const hash = await scryptAsync(password, salt, 32);
    const hashString = `$scrypt$${salt}$${hash.toString('base64')}`;
    console.log('Admin password hash:', hashString);
  } catch (error) {
    console.error('Error creating hash:', error);
  }
}

createAdminHash();