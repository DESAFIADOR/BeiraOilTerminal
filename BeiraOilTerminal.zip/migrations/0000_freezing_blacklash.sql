CREATE TABLE "berth_maintenance" (
	"id" serial PRIMARY KEY NOT NULL,
	"is_under_maintenance" boolean DEFAULT false NOT NULL,
	"maintenance_period" varchar(255),
	"started_at" timestamp,
	"ended_at" timestamp,
	"description" text,
	"created_by" integer,
	"created_at" timestamp DEFAULT now(),
	"updated_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "berthing_records" (
	"id" serial PRIMARY KEY NOT NULL,
	"ship_id" integer NOT NULL,
	"first_rope_time" timestamp NOT NULL,
	"last_rope_time" timestamp NOT NULL,
	"created_at" timestamp DEFAULT now(),
	"created_by" integer
);
--> statement-breakpoint
CREATE TABLE "cargo_agents" (
	"id" serial PRIMARY KEY NOT NULL,
	"ship_id" integer NOT NULL,
	"name" varchar NOT NULL,
	"email" varchar,
	"phone" varchar,
	"company" varchar,
	"is_primary" boolean DEFAULT false,
	"created_at" timestamp DEFAULT now(),
	"updated_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "cargo_parcels" (
	"id" serial PRIMARY KEY NOT NULL,
	"ship_id" integer NOT NULL,
	"parcel_number" varchar NOT NULL,
	"product" varchar NOT NULL,
	"volume_mt" numeric(10, 2) NOT NULL,
	"volume_m3" numeric(10, 2) NOT NULL,
	"density_15c" numeric(6, 3) NOT NULL,
	"receiver" varchar NOT NULL,
	"owner" varchar DEFAULT 'N/A' NOT NULL,
	"status" varchar DEFAULT 'pending' NOT NULL,
	"created_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "custom_discharge_rates" (
	"id" serial PRIMARY KEY NOT NULL,
	"ship_id" integer NOT NULL,
	"parcel_id" integer NOT NULL,
	"product" varchar(100) NOT NULL,
	"receiver" varchar(255) NOT NULL,
	"custom_rate" numeric(8, 2) NOT NULL,
	"estimated_duration" numeric(6, 2),
	"notes" text,
	"created_by" integer NOT NULL,
	"created_at" timestamp DEFAULT now(),
	"updated_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "discharge_progress" (
	"id" serial PRIMARY KEY NOT NULL,
	"ship_id" integer NOT NULL,
	"discharged" numeric(10, 2) NOT NULL,
	"remaining" numeric(10, 2) NOT NULL,
	"percentage" numeric(5, 2) NOT NULL,
	"estimated_completion_hours" numeric(5, 2),
	"recorded_at" timestamp DEFAULT now(),
	"recorded_by" integer
);
--> statement-breakpoint
CREATE TABLE "discharge_records" (
	"id" serial PRIMARY KEY NOT NULL,
	"ship_id" integer NOT NULL,
	"parcel_id" integer NOT NULL,
	"discharge_start_time" timestamp,
	"discharge_end_time" timestamp,
	"line_displacement_stops" text[] DEFAULT '{}',
	"parcel_change_stops" text[] DEFAULT '{}',
	"completion_stops" text[] DEFAULT '{}',
	"current_rate" numeric(8, 2),
	"total_discharged_this_hour" numeric(10, 2),
	"remaining_this_parcel" numeric(10, 2),
	"estimated_completion_time" timestamp,
	"average_rate" numeric(8, 2),
	"created_at" timestamp DEFAULT now(),
	"updated_at" timestamp DEFAULT now(),
	"recorded_by" integer
);
--> statement-breakpoint
CREATE TABLE "hourly_discharge" (
	"id" serial PRIMARY KEY NOT NULL,
	"ship_id" integer NOT NULL,
	"parcel_id" integer NOT NULL,
	"record_time" timestamp DEFAULT now(),
	"pressure" numeric(5, 2) NOT NULL,
	"rate" numeric(8, 2) NOT NULL,
	"volume_hour" numeric(10, 2) NOT NULL,
	"total_discharged" numeric(10, 2) NOT NULL,
	"remaining" numeric(10, 2) NOT NULL,
	"estimated_hours" numeric(6, 2),
	"created_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "monthly_reports" (
	"id" serial PRIMARY KEY NOT NULL,
	"report_month" integer NOT NULL,
	"report_year" integer NOT NULL,
	"total_ships" integer NOT NULL,
	"total_parcels" integer NOT NULL,
	"unique_receivers" integer NOT NULL,
	"total_volume" varchar NOT NULL,
	"operations_data" jsonb NOT NULL,
	"generated_at" timestamp DEFAULT now(),
	"generated_by" integer
);
--> statement-breakpoint
CREATE TABLE "notification_subscriptions" (
	"id" serial PRIMARY KEY NOT NULL,
	"ship_id" integer NOT NULL,
	"contact_type" varchar(10) NOT NULL,
	"contact_value" varchar(255) NOT NULL,
	"contact_name" varchar(255) NOT NULL,
	"role" varchar(50) NOT NULL,
	"statuses_to_notify" text[] NOT NULL,
	"is_active" boolean DEFAULT true,
	"created_at" timestamp DEFAULT now(),
	"updated_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "operational_discharge_records" (
	"id" serial PRIMARY KEY NOT NULL,
	"ship_id" integer NOT NULL,
	"parcel_id" integer,
	"pressure" numeric(6, 2),
	"discharge_rate" numeric(8, 2),
	"discharge_start_time" timestamp,
	"discharge_end_time" timestamp,
	"stop_start_time" timestamp,
	"stop_end_time" timestamp,
	"stop_type" varchar(50),
	"stop_comment" text,
	"resume_comment" text,
	"has_line_displacement" boolean DEFAULT false,
	"line_displacement_duration" numeric(4, 2),
	"recorded_at" timestamp DEFAULT now(),
	"recorded_by" integer,
	"operation_type" varchar(30) NOT NULL
);
--> statement-breakpoint
CREATE TABLE "operational_stats" (
	"id" serial PRIMARY KEY NOT NULL,
	"ship_id" integer NOT NULL,
	"operation" varchar(100) NOT NULL,
	"operation_date" varchar(10) NOT NULL,
	"time_commenced" varchar(5),
	"time_completed" varchar(5),
	"notes" text,
	"pob" integer,
	"created_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "report_access_logs" (
	"id" serial PRIMARY KEY NOT NULL,
	"report_id" integer NOT NULL,
	"accessed_by" integer NOT NULL,
	"accessed_at" timestamp DEFAULT now(),
	"ip_address" varchar
);
--> statement-breakpoint
CREATE TABLE "sessions" (
	"sid" varchar PRIMARY KEY NOT NULL,
	"sess" jsonb NOT NULL,
	"expire" timestamp NOT NULL
);
--> statement-breakpoint
CREATE TABLE "ship_registry" (
	"id" serial PRIMARY KEY NOT NULL,
	"ship_id" integer NOT NULL,
	"registry_date" timestamp DEFAULT now(),
	"total_parcels" integer NOT NULL,
	"total_volume" varchar NOT NULL,
	"receivers" text[] NOT NULL,
	"operation_start_date" timestamp,
	"operation_end_date" timestamp,
	"status" varchar DEFAULT 'active' NOT NULL,
	"registered_by" integer NOT NULL,
	"created_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "ships" (
	"id" serial PRIMARY KEY NOT NULL,
	"name" varchar NOT NULL,
	"countermark" varchar NOT NULL,
	"arrival_date_time" timestamp NOT NULL,
	"draft" numeric(4, 2) NOT NULL,
	"ship_agent" varchar NOT NULL,
	"ship_agent_email" varchar NOT NULL,
	"cargo_agent" varchar NOT NULL,
	"cargo_agent_email" varchar,
	"shipowner" varchar NOT NULL,
	"cargo_type" varchar NOT NULL,
	"cargo_destination" varchar NOT NULL,
	"operation_type" varchar DEFAULT 'transito' NOT NULL,
	"status" varchar DEFAULT 'expected' NOT NULL,
	"has_discharge_instructions" boolean DEFAULT false,
	"berthing_confirmed" boolean DEFAULT false,
	"confirmation_email_sent_at" timestamp,
	"confirmation_received_at" timestamp,
	"berthing_started_at" timestamp,
	"departed_at" timestamp,
	"created_at" timestamp DEFAULT now(),
	"updated_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "swap_operations" (
	"id" serial PRIMARY KEY NOT NULL,
	"ship_id" integer NOT NULL,
	"swap_type" varchar(50) NOT NULL,
	"original_value" text NOT NULL,
	"new_value" text NOT NULL,
	"reason" text NOT NULL,
	"authorized_by" varchar(100) NOT NULL,
	"status" varchar(20) DEFAULT 'pending' NOT NULL,
	"created_at" timestamp DEFAULT now(),
	"completed_at" timestamp
);
--> statement-breakpoint
CREATE TABLE "terminal_settings" (
	"id" serial PRIMARY KEY NOT NULL,
	"channel_depth" numeric(4, 2) DEFAULT '8.0' NOT NULL,
	"tolerance" numeric(4, 2) DEFAULT '1.2' NOT NULL,
	"current_tide" numeric(4, 2) DEFAULT '8.5' NOT NULL,
	"updated_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "undocking_records" (
	"id" serial PRIMARY KEY NOT NULL,
	"ship_id" integer NOT NULL,
	"first_rope_time" timestamp NOT NULL,
	"last_rope_time" timestamp NOT NULL,
	"created_at" timestamp DEFAULT now(),
	"created_by" integer
);
--> statement-breakpoint
CREATE TABLE "user_permissions" (
	"id" serial PRIMARY KEY NOT NULL,
	"user_id" integer NOT NULL,
	"permission" varchar NOT NULL,
	"granted_at" timestamp DEFAULT now(),
	"granted_by" integer
);
--> statement-breakpoint
CREATE TABLE "users" (
	"id" serial PRIMARY KEY NOT NULL,
	"username" varchar NOT NULL,
	"password" varchar NOT NULL,
	"email" varchar,
	"first_name" varchar,
	"last_name" varchar,
	"role" varchar DEFAULT 'public' NOT NULL,
	"status" varchar DEFAULT 'active' NOT NULL,
	"requested_role" varchar,
	"approved_by" integer,
	"approved_at" timestamp,
	"permissions" jsonb DEFAULT '[]' NOT NULL,
	"is_active" boolean DEFAULT true NOT NULL,
	"last_login" timestamp,
	"created_at" timestamp DEFAULT now(),
	"updated_at" timestamp DEFAULT now(),
	CONSTRAINT "users_username_unique" UNIQUE("username")
);
--> statement-breakpoint
CREATE TABLE "weather_alerts" (
	"id" serial PRIMARY KEY NOT NULL,
	"alert_type" text NOT NULL,
	"severity" text NOT NULL,
	"title" text NOT NULL,
	"description" text NOT NULL,
	"wind_speed" numeric(5, 2),
	"is_active" boolean DEFAULT true NOT NULL,
	"triggered_at" timestamp DEFAULT now() NOT NULL,
	"resolved_at" timestamp,
	"created_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "weather_data" (
	"id" serial PRIMARY KEY NOT NULL,
	"timestamp" timestamp DEFAULT now() NOT NULL,
	"wind_speed" numeric(5, 2),
	"wind_direction" integer,
	"wind_gust" numeric(5, 2),
	"temperature" numeric(4, 1),
	"humidity" integer,
	"pressure" numeric(6, 2),
	"visibility" numeric(4, 1),
	"weather_condition" text,
	"precipitation" numeric(4, 1),
	"sea_state" integer,
	"wave_height" numeric(4, 2),
	"source" text DEFAULT 'openweather' NOT NULL,
	"created_at" timestamp DEFAULT now()
);
--> statement-breakpoint
ALTER TABLE "berth_maintenance" ADD CONSTRAINT "berth_maintenance_created_by_users_id_fk" FOREIGN KEY ("created_by") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "berthing_records" ADD CONSTRAINT "berthing_records_ship_id_ships_id_fk" FOREIGN KEY ("ship_id") REFERENCES "public"."ships"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "berthing_records" ADD CONSTRAINT "berthing_records_created_by_users_id_fk" FOREIGN KEY ("created_by") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "cargo_agents" ADD CONSTRAINT "cargo_agents_ship_id_ships_id_fk" FOREIGN KEY ("ship_id") REFERENCES "public"."ships"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "cargo_parcels" ADD CONSTRAINT "cargo_parcels_ship_id_ships_id_fk" FOREIGN KEY ("ship_id") REFERENCES "public"."ships"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "custom_discharge_rates" ADD CONSTRAINT "custom_discharge_rates_ship_id_ships_id_fk" FOREIGN KEY ("ship_id") REFERENCES "public"."ships"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "custom_discharge_rates" ADD CONSTRAINT "custom_discharge_rates_parcel_id_cargo_parcels_id_fk" FOREIGN KEY ("parcel_id") REFERENCES "public"."cargo_parcels"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "custom_discharge_rates" ADD CONSTRAINT "custom_discharge_rates_created_by_users_id_fk" FOREIGN KEY ("created_by") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "discharge_progress" ADD CONSTRAINT "discharge_progress_ship_id_ships_id_fk" FOREIGN KEY ("ship_id") REFERENCES "public"."ships"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "discharge_progress" ADD CONSTRAINT "discharge_progress_recorded_by_users_id_fk" FOREIGN KEY ("recorded_by") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "discharge_records" ADD CONSTRAINT "discharge_records_ship_id_ships_id_fk" FOREIGN KEY ("ship_id") REFERENCES "public"."ships"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "discharge_records" ADD CONSTRAINT "discharge_records_parcel_id_cargo_parcels_id_fk" FOREIGN KEY ("parcel_id") REFERENCES "public"."cargo_parcels"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "discharge_records" ADD CONSTRAINT "discharge_records_recorded_by_users_id_fk" FOREIGN KEY ("recorded_by") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "hourly_discharge" ADD CONSTRAINT "hourly_discharge_ship_id_ships_id_fk" FOREIGN KEY ("ship_id") REFERENCES "public"."ships"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "hourly_discharge" ADD CONSTRAINT "hourly_discharge_parcel_id_cargo_parcels_id_fk" FOREIGN KEY ("parcel_id") REFERENCES "public"."cargo_parcels"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "monthly_reports" ADD CONSTRAINT "monthly_reports_generated_by_users_id_fk" FOREIGN KEY ("generated_by") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "notification_subscriptions" ADD CONSTRAINT "notification_subscriptions_ship_id_ships_id_fk" FOREIGN KEY ("ship_id") REFERENCES "public"."ships"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "operational_discharge_records" ADD CONSTRAINT "operational_discharge_records_ship_id_ships_id_fk" FOREIGN KEY ("ship_id") REFERENCES "public"."ships"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "operational_discharge_records" ADD CONSTRAINT "operational_discharge_records_parcel_id_cargo_parcels_id_fk" FOREIGN KEY ("parcel_id") REFERENCES "public"."cargo_parcels"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "operational_discharge_records" ADD CONSTRAINT "operational_discharge_records_recorded_by_users_id_fk" FOREIGN KEY ("recorded_by") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "operational_stats" ADD CONSTRAINT "operational_stats_ship_id_ships_id_fk" FOREIGN KEY ("ship_id") REFERENCES "public"."ships"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "report_access_logs" ADD CONSTRAINT "report_access_logs_report_id_monthly_reports_id_fk" FOREIGN KEY ("report_id") REFERENCES "public"."monthly_reports"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "report_access_logs" ADD CONSTRAINT "report_access_logs_accessed_by_users_id_fk" FOREIGN KEY ("accessed_by") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "ship_registry" ADD CONSTRAINT "ship_registry_ship_id_ships_id_fk" FOREIGN KEY ("ship_id") REFERENCES "public"."ships"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "ship_registry" ADD CONSTRAINT "ship_registry_registered_by_users_id_fk" FOREIGN KEY ("registered_by") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "swap_operations" ADD CONSTRAINT "swap_operations_ship_id_ships_id_fk" FOREIGN KEY ("ship_id") REFERENCES "public"."ships"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "undocking_records" ADD CONSTRAINT "undocking_records_ship_id_ships_id_fk" FOREIGN KEY ("ship_id") REFERENCES "public"."ships"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "undocking_records" ADD CONSTRAINT "undocking_records_created_by_users_id_fk" FOREIGN KEY ("created_by") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "user_permissions" ADD CONSTRAINT "user_permissions_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "user_permissions" ADD CONSTRAINT "user_permissions_granted_by_users_id_fk" FOREIGN KEY ("granted_by") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "users" ADD CONSTRAINT "users_approved_by_users_id_fk" FOREIGN KEY ("approved_by") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
CREATE INDEX "IDX_session_expire" ON "sessions" USING btree ("expire");