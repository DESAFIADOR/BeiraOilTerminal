import { tideService } from './server/tideService.js';

async function showTideInfo() {
  try {
    console.log('=== INFORMAÇÕES DA MARÉ - TERMINAL DA BEIRA ===\n');
    
    const tideData = await tideService.getCurrentTideData();
    
    console.log('📊 SITUAÇÃO ATUAL DA MARÉ:');
    console.log(`   Altura atual: ${tideData.currentTide.toFixed(2)} metros`);
    console.log(`   Horário: ${tideData.tideTime.toLocaleString('pt-BR', { timeZone: 'Africa/Maputo' })}`);
    console.log(`   Status: ${tideData.tideStatus === 'rising' ? 'Enchente (Subindo)' : 'Vazante (Descendo)'}\n`);
    
    console.log('🌊 PRÓXIMAS PREVISÕES:');
    console.log(`   Próxima PREAMAR: ${tideData.nextHighTide.height.toFixed(2)}m às ${tideData.nextHighTide.time.toLocaleString('pt-BR', { timeZone: 'Africa/Maputo' })}`);
    console.log(`   Próxima BAIXAMAR: ${tideData.nextLowTide.height.toFixed(2)}m às ${tideData.nextLowTide.time.toLocaleString('pt-BR', { timeZone: 'Africa/Maputo' })}\n`);
    
    console.log('📈 PREVISÃO PRÓXIMAS 24 HORAS:');
    tideData.prediction24h.forEach((prediction, index) => {
      if (index < 8) { // Mostrar apenas próximas 8 previsões
        const typeDesc = prediction.type === 'high' ? 'PREAMAR' : 'BAIXAMAR';
        console.log(`   ${typeDesc}: ${prediction.height.toFixed(2)}m às ${prediction.time.toLocaleString('pt-BR', { timeZone: 'Africa/Maputo' })}`);
      }
    });
    
    console.log('\n💡 INFORMAÇÕES OPERACIONAIS:');
    if (tideData.currentTide >= 3.5) {
      console.log('   ✅ Condições favoráveis para atracação de navios de grande calado');
    } else if (tideData.currentTide >= 2.5) {
      console.log('   ⚠️  Condições moderadas - verificar calado dos navios');
    } else {
      console.log('   ❌ Maré baixa - restringir operações de navios de grande calado');
    }
    
    console.log('\n📍 Local: Terminal da Beira (-19.8242°, 34.8383°)');
    console.log('⏰ Dados calculados com análise harmônica M2, S2, N2');
    
  } catch (error) {
    console.error('Erro ao obter informações da maré:', error.message);
  }
}

showTideInfo();