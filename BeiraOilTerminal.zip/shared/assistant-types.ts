export type UserRole = 'visitor' | 'user' | 'operator' | 'admin';

export interface ChatMessage {
  id: string;
  content: string;
  role: 'user' | 'assistant';
  timestamp: Date;
  userId?: string;
  audioUrl?: string;
}

export interface ChatSession {
  id: string;
  userId?: string;
  userRole: UserRole;
  messages: ChatMessage[];
  language: string;
  startTime: Date;
  endTime?: Date;
  status: 'active' | 'completed' | 'escalated';
  satisfactionRating?: number;
  escalationReason?: string;
}

export interface AssistantCapabilities {
  canViewShips: boolean;
  canViewReports: boolean;
  canModifyData: boolean;
  canViewSensitiveInfo: boolean;
  canAccessAdminFunctions: boolean;
}

export interface VoiceMessage {
  audioBlob: Blob;
  transcription?: string;
  language?: string;
}

export interface AssistantResponse {
  text: string;
  audioUrl?: string;
  requiresEscalation?: boolean;
  confidence: number;
  sources?: string[];
}