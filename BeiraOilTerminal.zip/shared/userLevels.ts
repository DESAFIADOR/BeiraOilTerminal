export type UserRole = 'publico' | 'line_up' | 'gestores' | 'ctos' | 'admin' | 'desenvolvedor';

export interface UserLevel {
  id: UserRole;
  name: string;
  description: string;
  permissions: string[];
  hierarchyLevel: number;
}

export const USER_LEVELS: Record<UserRole, UserLevel> = {
  publico: {
    id: 'publico',
    name: 'Público',
    description: 'Acesso público para visualização limitada sem necessidade de aprovação',
    hierarchyLevel: 0,
    permissions: [
      'view_ships_public',          // Visualização básica de navios sem detalhes
      'view_discharge_percentage',  // Ver progresso em % e ETC
      'view_ship_count',           // Ver número de navios na barra/cais
      'view_weather_tide'          // Ver condições meteorológicas
    ]
  },
  line_up: {
    id: 'line_up', 
    name: 'Line Up',
    description: 'Operador de line-up - cadastra navios e edita parcelas antes da atracação',
    hierarchyLevel: 1,
    permissions: [
      'view_ships',                // Visualização completa de navios
      'create_ships',              // Cadastrar navios previstos e chegados na barra
      'update_ships_basic',        // Edição básica de dados do navio
      'manage_parcels_pre_berth',  // Adicionar/editar parcelas antes da atracação
      'view_discharge_percentage', // Ver progresso de descarga
      'view_ship_details'          // Ver detalhes de navios
    ]
  },
  gestores: {
    id: 'gestores',
    name: 'Gestores', 
    description: 'Gestores com acesso a estatísticas e acompanhamento de operações',
    hierarchyLevel: 2,
    permissions: [
      'view_ships',                // Visualização completa
      'view_ship_details',         // Ver informações detalhadas
      'view_parcel_details',       // Ver informações sobre parcelas
      'view_statistics',           // Dados estatísticos do terminal
      'view_live_operations',      // Acompanhar operações em tempo real
      'view_discharge_details',    // Ver detalhes completos de descarga
      'view_reports',              // Relatórios gerenciais
      'view_analytics'             // Analytics do sistema
    ]
  },
  ctos: {
    id: 'ctos',
    name: 'CTOs',
    description: 'Executivos com controle operacional completo durante atracação',
    hierarchyLevel: 3,
    permissions: [
      'view_ships',                // Visualização completa
      'view_ship_details',         // Ver detalhes completos
      'view_parcel_details',       // Ver parcelas detalhadamente
      'manage_parcels_full',       // Adicionar/editar parcelas sem restrições
      'update_discharge_progress', // Registrar eventos durante operação
      'berth_unberth_ships',       // Atracar e desatracar navios
      'operational_control',       // Controle operacional durante atracação
      'view_statistics',           // Estatísticas completas
      'view_live_operations',      // Operações em tempo real
      'view_reports',              // Relatórios executivos
      'export_data'                // Exportar dados
    ]
  },
  admin: {
    id: 'admin',
    name: 'Administrador',
    description: 'Administrador geral - gerencia toda página exceto parte técnica',
    hierarchyLevel: 4,
    permissions: [
      'view_ships',                // Visualização completa
      'create_ships',              // Criar navios
      'update_ships',              // Editar navios
      'delete_ships',              // Deletar navios
      'move_ships',                // Mover navios
      'confirm_ships',             // Confirmar navios
      'update_discharge',          // Atualizar descarga
      'register_undocking',        // Registrar desatracação
      'view_ship_details',         // Ver detalhes de navios
      'view_parcel_details',       // Ver detalhes de parcelas
      'manage_parcels_full',       // Gerenciar parcelas completamente
      'berth_unberth_ships',       // Atracar/desatracar navios
      'operational_control',       // Controle operacional
      'view_statistics',           // Estatísticas
      'view_live_operations',      // Operações ao vivo
      'view_reports',              // Relatórios
      'create_reports',            // Criar relatórios
      'approve_operations',        // Aprovar operações
      'manage_users_full',         // Gerenciar usuários (exceto desenvolvedores)
      'approve_users',             // Aprovar cadastros de usuários
      'view_analytics',            // Analytics
      'export_data',               // Exportar dados
      'system_configuration_basic' // Configuração básica do sistema
    ]
  },
  desenvolvedor: {
    id: 'desenvolvedor',
    name: 'Desenvolvedor',
    description: 'Acesso técnico completo e aprovação de administradores',
    hierarchyLevel: 5,
    permissions: [
      'view_ships',
      'create_ships',
      'update_ships',
      'delete_ships',
      'move_ships',
      'confirm_ships',
      'update_discharge',
      'register_undocking',
      'view_reports',
      'create_reports',
      'approve_operations',
      'manage_users_advanced',
      'approve_admins',            // Aprovar cadastro de administradores
      'view_analytics',
      'view_financial_data',
      'export_data',
      'system_configuration_basic',
      'system_configuration_advanced',
      'database_access',
      'api_access',
      'debug_mode',
      'manage_integrations',
      'system_maintenance'
    ]
  }
};

export function getUserPermissions(role: UserRole): string[] {
  return USER_LEVELS[role]?.permissions || [];
}

export function hasPermission(userRole: UserRole, permission: string): boolean {
  return getUserPermissions(userRole).includes(permission);
}

export function canAccessLevel(userRole: UserRole, targetRole: UserRole): boolean {
  const userLevel = USER_LEVELS[userRole]?.hierarchyLevel || 0;
  const targetLevel = USER_LEVELS[targetRole]?.hierarchyLevel || 0;
  return userLevel >= targetLevel;
}

export function getRoleDisplayName(role: UserRole): string {
  return USER_LEVELS[role]?.name || role;
}

export function getRoleDescription(role: UserRole): string {
  return USER_LEVELS[role]?.description || '';
}