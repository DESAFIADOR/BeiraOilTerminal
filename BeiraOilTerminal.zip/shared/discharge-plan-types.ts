export interface DischargeParcelPlan {
  parcelId: number;
  product: string;
  volumeM3: number;
  expectedRate: number; // m³/h
  estimatedDuration: number; // hours
  startTime: Date;
  endTime: Date;
}

export interface ShipDischargePlan {
  shipId: number;
  shipName: string;
  operationType: string;
  berthingTime: Date;
  dischargeStartTime: Date;
  parcels: DischargeParcelPlan[];
  totalDischargeTime: number; // hours
  dischargeEndTime: Date;
  unberthingTime: Date;
  nextShipBerthingTime?: Date;
}

export interface TideWindow {
  highTide: Date;
  lowTide: Date;
  unberthingWindow: Date; // 2 hours before high tide
  berthingWindow: Date; // 2 hours after high tide
}

export interface DischargePlanningResult {
  ships: ShipDischargePlan[];
  tideWindows: TideWindow[];
  totalPlanningPeriod: number; // days
  warnings: string[];
  recommendations: string[];
}