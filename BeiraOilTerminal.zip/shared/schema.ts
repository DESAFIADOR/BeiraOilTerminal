import {
  pgTable,
  text,
  varchar,
  timestamp,
  jsonb,
  index,
  serial,
  decimal,
  integer,
  boolean,
  date,
  time,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";



// Session storage table.
// (IMPORTANT) This table is mandatory for Replit Auth, don't drop it.
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// User storage table for password authentication
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: varchar("username").unique().notNull(),
  password: varchar("password").notNull(),
  email: varchar("email"),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  role: varchar("role").notNull().default("publico"), // 'publico', 'line_up', 'gestores', 'ctos', 'desenvolvedor', 'agente_navio'
  status: varchar("status").notNull().default("active"), // 'active', 'pending', 'rejected'
  requestedRole: varchar("requested_role"), // role requested during registration
  approvedBy: integer("approved_by").references((): any => users.id),
  approvedAt: timestamp("approved_at"),
  permissions: jsonb("permissions").default("[]").notNull(), // array of permission strings
  isActive: boolean("is_active").notNull().default(true),
  lastLogin: timestamp("last_login"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Agent accounts for ship management
export const agents = pgTable("agents", {
  id: serial("id").primaryKey(),
  username: varchar("username").unique().notNull(),
  password: varchar("password").notNull(),
  email: varchar("email").notNull(),
  companyName: varchar("company_name").notNull(),
  firstName: varchar("first_name").notNull(),
  lastName: varchar("last_name").notNull(),
  phoneNumber: varchar("phone_number"),
  agentType: varchar("agent_type").notNull(), // 'ship_agent' or 'cargo_agent'
  permissionLevel: varchar("permission_level").notNull().default("view_only"), // 'view_only' or 'ship_management'
  status: varchar("status").notNull().default("pending"), // 'pending', 'approved', 'rejected'
  approvedBy: integer("approved_by").references((): any => users.id),
  approvedAt: timestamp("approved_at"),
  rejectedAt: timestamp("rejected_at"),
  rejectionReason: text("rejection_reason"),
  isActive: boolean("is_active").notNull().default(true),
  lastLogin: timestamp("last_login"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Predicted ship arrivals by agents
export const predictedArrivals = pgTable("predicted_arrivals", {
  id: serial("id").primaryKey(),
  agentId: integer("agent_id").references(() => agents.id).notNull(),
  shipName: varchar("ship_name").notNull(),
  voyNumber: varchar("voy_number"),
  arrivalDraft: varchar("arrival_draft"), // calado de chegada
  imoNumber: varchar("imo_number"),
  portOfRegistry: varchar("port_of_registry"),
  summerDWT: varchar("summer_dwt"),
  registeredGRT: varchar("registered_grt"),
  product: varchar("product").notNull(),
  lastPortQuantity: varchar("last_port_quantity"), // quantidade last pot
  portOfLoading: varchar("port_of_loading"),
  arrivalNoticeFile: varchar("arrival_notice_file"), // file path for arrival notice
  arrivalDateTime: timestamp("arrival_date_time"), // when actually arrived
  countermark: varchar("countermark"), // added when ship arrives
  status: varchar("status").notNull().default("predicted"), // 'predicted', 'arrived', 'confirmed'
  isConfirmed: boolean("is_confirmed").notNull().default(false),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// User permissions table for granular access control
export const userPermissions = pgTable("user_permissions", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).notNull(),
  permission: varchar("permission").notNull(), // 'update_discharge', 'confirm_ship', 'move_ship', 'manage_maintenance'
  grantedAt: timestamp("granted_at").defaultNow(),
  grantedBy: integer("granted_by").references(() => users.id),
});

// Relations
export const usersRelations = relations(users, ({ many }) => ({
  permissions: many(userPermissions),
}));

export const userPermissionsRelations = relations(userPermissions, ({ one }) => ({
  user: one(users, {
    fields: [userPermissions.userId],
    references: [users.id],
  }),
  grantedByUser: one(users, {
    fields: [userPermissions.grantedBy],
    references: [users.id],
  }),
}));

export const ships = pgTable("ships", {
  id: serial("id").primaryKey(),
  name: varchar("name").notNull(),
  countermark: varchar("countermark").notNull(),
  arrivalDateTime: timestamp("arrival_date_time").notNull(),
  draft: decimal("draft", { precision: 4, scale: 2 }).notNull(),
  shipAgent: varchar("ship_agent").notNull(),
  shipAgentEmail: varchar("ship_agent_email").notNull(),
  cargoAgent: varchar("cargo_agent").notNull(),
  cargoAgentEmail: varchar("cargo_agent_email"),
  shipowner: varchar("shipowner").notNull(),
  cargoType: varchar("cargo_type").notNull(),
  cargoDestination: varchar("cargo_destination").notNull(),
  operationType: varchar("operation_type").notNull().default("transito"), // 'Nacional', 'Trânsito', 'Combinada', 'LPG'
  status: varchar("status").notNull().default("expected"), // 'expected', 'at_bar', 'at_berth', 'next_to_berth', 'departed'
  hasDischargeInstructions: boolean("has_discharge_instructions").default(false),
  berthingConfirmed: boolean("berthing_confirmed").default(false),
  confirmationEmailSentAt: timestamp("confirmation_email_sent_at"),
  confirmationReceivedAt: timestamp("confirmation_received_at"),
  berthingStartedAt: timestamp("berthing_started_at"),
  departedAt: timestamp("departed_at"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const cargoParcels = pgTable("cargo_parcels", {
  id: serial("id").primaryKey(),
  shipId: integer("ship_id").references(() => ships.id).notNull(),
  parcelNumber: varchar("parcel_number").notNull(),
  product: varchar("product").notNull(), // Produto
  volumeMT: decimal("volume_mt", { precision: 10, scale: 2 }), // Volume em MT - agora permite NULL
  volumeM3: decimal("volume_m3", { precision: 10, scale: 2 }), // Volume em m³ - agora permite NULL
  density15C: decimal("density_15c", { precision: 6, scale: 3 }), // Densidade a 15°C - agora permite NULL
  receiver: varchar("receiver").default(""), // Recebedor - permite vazio
  owner: varchar("owner").default(""), // Dono da parcela - permite vazio
  status: varchar("status").notNull().default("pending"), // 'pending', 'in_progress', 'completed'
  createdAt: timestamp("created_at").defaultNow(),
});

export const dischargeProgress = pgTable("discharge_progress", {
  id: serial("id").primaryKey(),
  shipId: integer("ship_id").references(() => ships.id).notNull(),
  discharged: decimal("discharged", { precision: 10, scale: 2 }).notNull(),
  remaining: decimal("remaining", { precision: 10, scale: 2 }).notNull(),
  percentage: decimal("percentage", { precision: 5, scale: 2 }).notNull(),
  estimatedCompletionHours: decimal("estimated_completion_hours", { precision: 5, scale: 2 }),
  recordedAt: timestamp("recorded_at").defaultNow(),
  recordedBy: integer("recorded_by").references(() => users.id),
});

// Nova tabela para registros detalhados de descarga por parcela
export const dischargeRecords = pgTable("discharge_records", {
  id: serial("id").primaryKey(),
  shipId: integer("ship_id").references(() => ships.id).notNull(),
  parcelId: integer("parcel_id").references(() => cargoParcels.id).notNull(),
  dischargeStartTime: timestamp("discharge_start_time"),
  dischargeEndTime: timestamp("discharge_end_time"),
  // Paradas operacionais
  lineDisplacementStops: text("line_displacement_stops").array().default([]), // Array de timestamps
  parcelChangeStops: text("parcel_change_stops").array().default([]), // Array de timestamps
  completionStops: text("completion_stops").array().default([]), // Array de timestamps
  // Dados de taxa e volumes
  currentRate: decimal("current_rate", { precision: 8, scale: 2 }), // m³/h
  totalDischargedThisHour: decimal("total_discharged_this_hour", { precision: 10, scale: 2 }), // m³
  remainingThisParcel: decimal("remaining_this_parcel", { precision: 10, scale: 2 }), // m³
  estimatedCompletionTime: timestamp("estimated_completion_time"),
  averageRate: decimal("average_rate", { precision: 8, scale: 2 }), // m³/h calculado
  // Metadados
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
  recordedBy: integer("recorded_by").references(() => users.id),
});

// Nova tabela para registros operacionais detalhados de descarga
export const operationalDischargeRecords = pgTable("operational_discharge_records", {
  id: serial("id").primaryKey(),
  shipId: integer("ship_id").references(() => ships.id).notNull(),
  parcelId: integer("parcel_id").references(() => cargoParcels.id),
  // Dados operacionais básicos
  pressure: decimal("pressure", { precision: 6, scale: 2 }), // Pressão em bar
  dischargeRate: decimal("discharge_rate", { precision: 8, scale: 2 }), // Taxa em m³/h
  dischargeStartTime: timestamp("discharge_start_time"),
  dischargeEndTime: timestamp("discharge_end_time"),
  // Controle de paradas
  stopStartTime: timestamp("stop_start_time"),
  stopEndTime: timestamp("stop_end_time"),
  stopType: varchar("stop_type", { length: 50 }), // 'line_displacement', 'parcel_change', 'maintenance', 'other'
  stopComment: text("stop_comment"),
  resumeComment: text("resume_comment"),
  // Line displacement planejado
  hasLineDisplacement: boolean("has_line_displacement").default(false),
  lineDisplacementDuration: decimal("line_displacement_duration", { precision: 4, scale: 2 }), // horas
  // Metadados
  recordedAt: timestamp("recorded_at").defaultNow(),
  recordedBy: integer("recorded_by").references(() => users.id),
  operationType: varchar("operation_type", { length: 30 }).notNull(), // 'start', 'stop', 'resume', 'end', 'hourly_update'
});

export const insertOperationalDischargeRecordSchema = createInsertSchema(operationalDischargeRecords).omit({
  id: true,
  recordedAt: true,
});

export type OperationalDischargeRecord = typeof operationalDischargeRecords.$inferSelect;
export type InsertOperationalDischargeRecord = z.infer<typeof insertOperationalDischargeRecordSchema>;

export const terminalSettings = pgTable("terminal_settings", {
  id: serial("id").primaryKey(),
  channelDepth: decimal("channel_depth", { precision: 4, scale: 2 }).notNull().default("8.0"),
  tolerance: decimal("tolerance", { precision: 4, scale: 2 }).notNull().default("1.2"),
  currentTide: decimal("current_tide", { precision: 4, scale: 2 }).notNull().default("8.5"),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const notificationSubscriptions = pgTable("notification_subscriptions", {
  id: serial("id").primaryKey(),
  shipId: integer("ship_id").references(() => ships.id).notNull(),
  contactType: varchar("contact_type", { length: 10 }).notNull(), // 'email' or 'sms'
  contactValue: varchar("contact_value", { length: 255 }).notNull(), // email address or phone number
  contactName: varchar("contact_name", { length: 255 }).notNull(),
  role: varchar("role", { length: 50 }).notNull(), // 'ship_agent', 'cargo_agent', 'terminal_operator'
  statusesToNotify: text("statuses_to_notify").array().notNull(), // array of status changes to notify about
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Tabela para confirmações de instruções com anexos (Agente do Navio)
export const instructionConfirmations = pgTable("instruction_confirmations", {
  id: serial("id").primaryKey(),
  shipId: integer("ship_id").references(() => ships.id).notNull(),
  agentId: integer("agent_id").references(() => users.id).notNull(),
  confirmationType: varchar("confirmation_type", { length: 20 }).notNull().default("manual"), // 'manual' or 'email'
  attachmentFileName: varchar("attachment_file_name", { length: 255 }),
  attachmentUrl: text("attachment_url"),
  attachmentMimeType: varchar("attachment_mime_type", { length: 100 }),
  confirmationNotes: text("confirmation_notes"),
  emailSentToDoptp: boolean("email_sent_to_doptp").default(false),
  emailSentAt: timestamp("email_sent_at"),
  confirmedAt: timestamp("confirmed_at").defaultNow(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertInstructionConfirmationSchema = createInsertSchema(instructionConfirmations).omit({
  id: true,
  confirmedAt: true,
  createdAt: true,
});

export type InstructionConfirmation = typeof instructionConfirmations.$inferSelect;
export type InsertInstructionConfirmation = z.infer<typeof insertInstructionConfirmationSchema>;

export const berthingRecords = pgTable("berthing_records", {
  id: serial("id").primaryKey(),
  shipId: integer("ship_id").references(() => ships.id).notNull(),
  firstRopeTime: timestamp("first_rope_time").notNull(),
  lastRopeTime: timestamp("last_rope_time").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
  createdBy: integer("created_by").references(() => users.id),
});

export const undockingRecords = pgTable("undocking_records", {
  id: serial("id").primaryKey(),
  shipId: integer("ship_id").references(() => ships.id).notNull(),
  firstRopeTime: timestamp("first_rope_time").notNull(),
  lastRopeTime: timestamp("last_rope_time").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
  createdBy: integer("created_by").references(() => users.id),
});

export const cargoAgents = pgTable("cargo_agents", {
  id: serial("id").primaryKey(),
  shipId: integer("ship_id").references(() => ships.id).notNull(),
  name: varchar("name").notNull(),
  email: varchar("email"),
  phone: varchar("phone"),
  company: varchar("company"),
  isPrimary: boolean("is_primary").default(false),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const berthMaintenance = pgTable("berth_maintenance", {
  id: serial("id").primaryKey(),
  isUnderMaintenance: boolean("is_under_maintenance").notNull().default(false),
  maintenancePeriod: varchar("maintenance_period", { length: 255 }),
  startedAt: timestamp("started_at"),
  endedAt: timestamp("ended_at"),
  description: text("description"),
  createdBy: integer("created_by").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const weatherData = pgTable("weather_data", {
  id: serial("id").primaryKey(),
  timestamp: timestamp("timestamp").notNull().defaultNow(),
  windSpeed: decimal("wind_speed", { precision: 5, scale: 2 }),
  windDirection: integer("wind_direction"),
  windGust: decimal("wind_gust", { precision: 5, scale: 2 }),
  temperature: decimal("temperature", { precision: 4, scale: 1 }),
  humidity: integer("humidity"),
  pressure: decimal("pressure", { precision: 6, scale: 2 }),
  visibility: decimal("visibility", { precision: 4, scale: 1 }),
  weatherCondition: text("weather_condition"),
  precipitation: decimal("precipitation", { precision: 4, scale: 1 }),
  seaState: integer("sea_state"),
  waveHeight: decimal("wave_height", { precision: 4, scale: 2 }),
  source: text("source").notNull().default('openweather'),
  createdAt: timestamp("created_at").defaultNow(),
});

export const weatherAlerts = pgTable("weather_alerts", {
  id: serial("id").primaryKey(),
  alertType: text("alert_type").notNull(), // 'high_wind', 'storm', 'visibility'
  severity: text("severity").notNull(), // 'low', 'medium', 'high', 'critical'
  title: text("title").notNull(),
  description: text("description").notNull(),
  windSpeed: decimal("wind_speed", { precision: 5, scale: 2 }),
  isActive: boolean("is_active").notNull().default(true),
  triggeredAt: timestamp("triggered_at").notNull().defaultNow(),
  resolvedAt: timestamp("resolved_at"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Ship Registry for comprehensive tracking
export const shipRegistry = pgTable("ship_registry", {
  id: serial("id").primaryKey(),
  shipId: integer("ship_id").references(() => ships.id).notNull(),
  registryDate: timestamp("registry_date").defaultNow(),
  totalParcels: integer("total_parcels").notNull(),
  totalVolume: varchar("total_volume").notNull(),
  receivers: text("receivers").array().notNull(),
  operationStartDate: timestamp("operation_start_date"),
  operationEndDate: timestamp("operation_end_date"),
  status: varchar("status").notNull().default("active"), // active, completed, cancelled
  registeredBy: integer("registered_by").references(() => users.id).notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

// Monthly reports for administrative overview
export const monthlyReports = pgTable("monthly_reports", {
  id: serial("id").primaryKey(),
  reportMonth: integer("report_month").notNull(), // 1-12
  reportYear: integer("report_year").notNull(),
  totalShips: integer("total_ships").notNull(),
  totalParcels: integer("total_parcels").notNull(),
  uniqueReceivers: integer("unique_receivers").notNull(),
  totalVolume: varchar("total_volume").notNull(),
  operationsData: jsonb("operations_data").notNull(), // Chart data
  generatedAt: timestamp("generated_at").defaultNow(),
  generatedBy: integer("generated_by").references(() => users.id),
});

// Report access logs for security
export const reportAccessLogs = pgTable("report_access_logs", {
  id: serial("id").primaryKey(),
  reportId: integer("report_id").references(() => monthlyReports.id).notNull(),
  accessedBy: integer("accessed_by").references(() => users.id).notNull(),
  accessedAt: timestamp("accessed_at").defaultNow(),
  ipAddress: varchar("ip_address"),
});

// SWAP Operations for ship management
export const swapOperations = pgTable("swap_operations", {
  id: serial("id").primaryKey(),
  shipId: integer("ship_id").references(() => ships.id, { onDelete: "cascade" }).notNull(),
  swapType: varchar("swap_type", { length: 50 }).notNull(), // 'cargo_swap', 'berth_swap', 'schedule_swap'
  originalValue: text("original_value").notNull(),
  newValue: text("new_value").notNull(),
  reason: text("reason").notNull(),
  authorizedBy: varchar("authorized_by", { length: 100 }).notNull(),
  status: varchar("status", { length: 20 }).default("pending").notNull(), // 'pending', 'approved', 'completed', 'cancelled'
  createdAt: timestamp("created_at").defaultNow(),
  completedAt: timestamp("completed_at"),
});

// Relations
export const shipsRelations = relations(ships, ({ many }) => ({
  parcels: many(cargoParcels),
  dischargeProgress: many(dischargeProgress),
  cargoAgents: many(cargoAgents),
  swapOperations: many(swapOperations),
}));

export const cargoParcelsRelations = relations(cargoParcels, ({ one }) => ({
  ship: one(ships, {
    fields: [cargoParcels.shipId],
    references: [ships.id],
  }),
}));

export const dischargeProgressRelations = relations(dischargeProgress, ({ one }) => ({
  ship: one(ships, {
    fields: [dischargeProgress.shipId],
    references: [ships.id],
  }),
  recordedBy: one(users, {
    fields: [dischargeProgress.recordedBy],
    references: [users.id],
  }),
}));

export const notificationSubscriptionsRelations = relations(notificationSubscriptions, ({ one }) => ({
  ship: one(ships, {
    fields: [notificationSubscriptions.shipId],
    references: [ships.id],
  }),
}));

export const shipRegistryRelations = relations(shipRegistry, ({ one }) => ({
  ship: one(ships, {
    fields: [shipRegistry.shipId],
    references: [ships.id],
  }),
  registeredBy: one(users, {
    fields: [shipRegistry.registeredBy],
    references: [users.id],
  }),
}));

export const monthlyReportsRelations = relations(monthlyReports, ({ one }) => ({
  generatedBy: one(users, {
    fields: [monthlyReports.generatedBy],
    references: [users.id],
  }),
}));

export const reportAccessLogsRelations = relations(reportAccessLogs, ({ one }) => ({
  report: one(monthlyReports, {
    fields: [reportAccessLogs.reportId],
    references: [monthlyReports.id],
  }),
  accessedBy: one(users, {
    fields: [reportAccessLogs.accessedBy],
    references: [users.id],
  }),
}));

export const cargoAgentsRelations = relations(cargoAgents, ({ one }) => ({
  ship: one(ships, {
    fields: [cargoAgents.shipId],
    references: [ships.id],
  }),
}));

export const swapOperationsRelations = relations(swapOperations, ({ one }) => ({
  ship: one(ships, {
    fields: [swapOperations.shipId],
    references: [ships.id],
  }),
}));

// Schemas
export const insertShipSchema = createInsertSchema(ships).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
}).extend({
  arrivalDateTime: z.string().transform((str) => new Date(str)),
  draft: z.string().transform((str) => str),
});

export const insertCargoParcelSchema = createInsertSchema(cargoParcels).omit({
  id: true,
  createdAt: true,
  shipId: true,
}).extend({
  volume: z.string().transform((str) => str),
});

export const insertDischargeProgressSchema = createInsertSchema(dischargeProgress).omit({
  id: true,
  recordedAt: true,
});

export const updateShipStatusSchema = z.object({
  status: z.enum(["expected", "at_bar", "at_berth", "next_to_berth", "departed"]).optional(),
  hasDischargeInstructions: z.boolean().optional(),
  berthingConfirmed: z.boolean().optional(),
  confirmationReceivedAt: z.date().optional(),
  berthingStartedAt: z.date().optional(),
});

export const insertNotificationSubscriptionSchema = createInsertSchema(notificationSubscriptions).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertCargoAgentSchema = createInsertSchema(cargoAgents).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
  shipId: true,
});

export const insertSwapOperationSchema = createInsertSchema(swapOperations).omit({
  id: true,
  createdAt: true,
  completedAt: true,
});

export type SwapOperation = typeof swapOperations.$inferSelect;
export type InsertSwapOperation = typeof swapOperations.$inferInsert;

// Discharge Control System - Enhanced implementation based on technical document
export const dischargeEvents = pgTable("discharge_events", {
  id: serial("id").primaryKey(),
  shipId: integer("ship_id").notNull().references(() => ships.id, { onDelete: "cascade" }),
  eventType: varchar("event_type", { length: 100 }).notNull(), // 'first_line_all_fast', 'gangway_down', etc.
  eventDate: date("event_date").notNull(),
  commenceTime: time("commence_time"),
  completeTime: time("complete_time"),
  notes: text("notes"),
  pob: integer("pob"), // People on Board
  recordedBy: integer("recorded_by").notNull().references(() => users.id),
  status: varchar("status", { length: 50 }).notNull().default("pending"), // pending, in_progress, completed
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const parcelDischargeControl = pgTable("parcel_discharge_control", {
  id: serial("id").primaryKey(),
  shipId: integer("ship_id").notNull().references(() => ships.id, { onDelete: "cascade" }),
  parcelId: integer("parcel_id").notNull().references(() => cargoParcels.id, { onDelete: "cascade" }),
  volumeM3: decimal("volume_m3", { precision: 10, scale: 2 }).notNull(),
  density: decimal("density", { precision: 6, scale: 4 }).notNull(),
  volumeMT: decimal("volume_mt", { precision: 10, scale: 2 }).notNull(),
  hourlyRate: decimal("hourly_rate", { precision: 8, scale: 2 }).notNull(), // m³/h
  dischargedVolume: decimal("discharged_volume", { precision: 10, scale: 2 }).notNull().default("0"),
  remainingVolume: decimal("remaining_volume", { precision: 10, scale: 2 }).notNull(),
  estimatedCompletion: timestamp("estimated_completion"),
  status: varchar("status", { length: 50 }).notNull().default("pending"), // pending, in_progress, completed
  startedAt: timestamp("started_at"),
  completedAt: timestamp("completed_at"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const hourlyDischargeRecords = pgTable("hourly_discharge_records", {
  id: serial("id").primaryKey(),
  shipId: integer("ship_id").notNull().references(() => ships.id, { onDelete: "cascade" }),
  parcelId: integer("parcel_id").notNull().references(() => cargoParcels.id, { onDelete: "cascade" }),
  recordTime: timestamp("record_time").notNull(),
  pressure: decimal("pressure", { precision: 5, scale: 2 }).notNull(), // bar
  rate: decimal("rate", { precision: 8, scale: 2 }).notNull(), // m³/h
  volumeDischargedHour: decimal("volume_discharged_hour", { precision: 10, scale: 2 }).notNull(), // m³ this hour
  totalDischarged: decimal("total_discharged", { precision: 10, scale: 2 }).notNull(), // m³ total
  remainingVolume: decimal("remaining_volume", { precision: 10, scale: 2 }).notNull(), // m³ remaining
  estimatedHoursRemaining: decimal("estimated_hours_remaining", { precision: 6, scale: 2 }),
  productivity: decimal("productivity", { precision: 5, scale: 2 }), // %
  recordedBy: integer("recorded_by").notNull().references(() => users.id),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const dischargeStoppages = pgTable("discharge_stoppages", {
  id: serial("id").primaryKey(),
  shipId: integer("ship_id").notNull().references(() => ships.id, { onDelete: "cascade" }),
  parcelId: integer("parcel_id").references(() => cargoParcels.id, { onDelete: "cascade" }),
  stoppageType: varchar("stoppage_type", { length: 100 }).notNull(), // 'line_displacement', 'parcel_change', 'maintenance', 'weather', 'other'
  reason: text("reason").notNull(),
  startTime: timestamp("start_time").notNull(),
  endTime: timestamp("end_time"),
  duration: integer("duration"), // minutes
  responsibility: varchar("responsibility", { length: 100 }), // 'terminal', 'ship', 'receiver', 'port_authority'
  recordedBy: integer("recorded_by").notNull().references(() => users.id),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const waitingTimes = pgTable("waiting_times", {
  id: serial("id").primaryKey(),
  shipId: integer("ship_id").notNull().references(() => ships.id, { onDelete: "cascade" }),
  waitingType: varchar("waiting_type", { length: 100 }).notNull(), // 'berth', 'unberth', 'pilot'
  startTime: timestamp("start_time").notNull(),
  endTime: timestamp("end_time"),
  duration: integer("duration"), // minutes
  reason: text("reason"),
  recordedBy: integer("recorded_by").notNull().references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
});

// Types for discharge control system
export type DischargeEvent = typeof dischargeEvents.$inferSelect;
export type InsertDischargeEvent = typeof dischargeEvents.$inferInsert;

export type ParcelDischargeControl = typeof parcelDischargeControl.$inferSelect;
export type InsertParcelDischargeControl = typeof parcelDischargeControl.$inferInsert;

export type HourlyDischargeRecord = typeof hourlyDischargeRecords.$inferSelect;
export type InsertHourlyDischargeRecord = typeof hourlyDischargeRecords.$inferInsert;

export type DischargeStoppage = typeof dischargeStoppages.$inferSelect;
export type InsertDischargeStoppage = typeof dischargeStoppages.$inferInsert;

export type WaitingTime = typeof waitingTimes.$inferSelect;
export type InsertWaitingTime = typeof waitingTimes.$inferInsert;

// Discharge Control Schemas
export const insertDischargeEventSchema = createInsertSchema(dischargeEvents).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertParcelDischargeControlSchema = createInsertSchema(parcelDischargeControl).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertHourlyDischargeRecordSchema = createInsertSchema(hourlyDischargeRecords).omit({
  id: true,
  createdAt: true,
});

export const insertDischargeStoppageSchema = createInsertSchema(dischargeStoppages).omit({
  id: true,
  createdAt: true,
});

export const insertWaitingTimeSchema = createInsertSchema(waitingTimes).omit({
  id: true,
  createdAt: true,
});

export const insertBerthingRecordSchema = createInsertSchema(berthingRecords).omit({
  id: true,
  createdAt: true,
});

export const insertUndockingRecordSchema = createInsertSchema(undockingRecords).omit({
  id: true,
  createdAt: true,
});

// Communication and messaging tables
export const communicationLogs = pgTable("communication_logs", {
  id: serial("id").primaryKey(),
  type: varchar("type", { length: 50 }).notNull(), // email, sms, whatsapp
  recipient: varchar("recipient", { length: 255 }).notNull(),
  subject: varchar("subject", { length: 500 }),
  content: text("content").notNull(),
  status: varchar("status", { length: 50 }).notNull(), // sent, failed, pending
  error: text("error"),
  sentAt: timestamp("sent_at").notNull(),
  externalId: varchar("external_id", { length: 255 }), // Twilio SID, SendGrid ID, etc.
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const emailTemplates = pgTable("email_templates", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 100 }).notNull().unique(),
  subject: varchar("subject", { length: 500 }).notNull(),
  htmlContent: text("html_content").notNull(),
  textContent: text("text_content"),
  variables: jsonb("variables"), // Template variables
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const validationTokens = pgTable("validation_tokens", {
  id: serial("id").primaryKey(),
  token: varchar("token", { length: 10 }).notNull(),
  phoneNumber: varchar("phone_number", { length: 20 }).notNull(),
  email: varchar("email", { length: 255 }),
  purpose: varchar("purpose", { length: 100 }).notNull(),
  expiresAt: timestamp("expires_at").notNull(),
  usedAt: timestamp("used_at"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const notificationSettings = pgTable("notification_settings", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  shipId: integer("ship_id").references(() => ships.id),
  notificationType: varchar("notification_type", { length: 100 }).notNull(), // ship_arrival, berth_ready, etc.
  emailEnabled: boolean("email_enabled").default(true),
  smsEnabled: boolean("sms_enabled").default(false),
  whatsappEnabled: boolean("whatsapp_enabled").default(false),
  email: varchar("email", { length: 255 }),
  phoneNumber: varchar("phone_number", { length: 20 }),
  whatsappNumber: varchar("whatsapp_number", { length: 20 }),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const insertBerthMaintenanceSchema = createInsertSchema(berthMaintenance).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const updateBerthMaintenanceSchema = z.object({
  isUnderMaintenance: z.boolean(),
  maintenancePeriod: z.string().optional(),
  description: z.string().optional(),
});

export const insertWeatherDataSchema = createInsertSchema(weatherData).omit({
  id: true,
  createdAt: true,
});

export const insertWeatherAlertSchema = createInsertSchema(weatherAlerts).omit({
  id: true,
  createdAt: true,
  triggeredAt: true,
});

export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
  approvedBy: true,
  approvedAt: true,
});

// Schema for user registration with role request
export const registerUserSchema = insertUserSchema.extend({
  requestedRole: z.enum(['user', 'operator']).default('user'),
  confirmPassword: z.string(),
}).refine((data) => data.password === data.confirmPassword, {
  message: "Senhas não coincidem",
  path: ["confirmPassword"],
});

// Schema for user approval by admin
export const approveUserSchema = z.object({
  userId: z.number(),
  approved: z.boolean(),
  role: z.enum(['user', 'operator']),
});

export const insertUserPermissionSchema = createInsertSchema(userPermissions).omit({
  id: true,
  grantedAt: true,
});

// Permission validation schema
export const permissionSchema = z.enum([
  'view_ships', 'create_ships', 'update_ships', 'delete_ships', 'move_ships',
  'confirm_ships', 'update_discharge', 'view_reports', 'create_reports',
  'access_admin', 'manage_users', 'manage_permissions', 'berth_management',
  'weather_monitoring', 'email_notifications', 'system_config'
]);

// Types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type RegisterUser = z.infer<typeof registerUserSchema>;
export type ApproveUser = z.infer<typeof approveUserSchema>;
export type User = typeof users.$inferSelect;

// Agent schemas
export const insertAgentSchema = createInsertSchema(agents).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
  approvedBy: true,
  approvedAt: true,
  rejectedAt: true,
});

export const registerAgentSchema = insertAgentSchema.extend({
  confirmPassword: z.string(),
}).refine((data) => data.password === data.confirmPassword, {
  message: "Senhas não coincidem",
  path: ["confirmPassword"],
});

export const approveAgentSchema = z.object({
  agentId: z.number(),
  approved: z.boolean(),
  permissionLevel: z.enum(['view_only', 'ship_management']),
  rejectionReason: z.string().optional(),
});

// Predicted arrival schemas
export const insertPredictedArrivalSchema = createInsertSchema(predictedArrivals).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const updateArrivalConfirmationSchema = z.object({
  arrivalDateTime: z.string().transform((str) => new Date(str)),
  countermark: z.string(),
  status: z.enum(['predicted', 'arrived', 'confirmed']).default('arrived'),
  isConfirmed: z.boolean().default(true),
});

// Types
export type Agent = typeof agents.$inferSelect;
export type InsertAgent = z.infer<typeof insertAgentSchema>;
export type RegisterAgent = z.infer<typeof registerAgentSchema>;
export type ApproveAgent = z.infer<typeof approveAgentSchema>;
export type PredictedArrival = typeof predictedArrivals.$inferSelect;
export type InsertPredictedArrival = z.infer<typeof insertPredictedArrivalSchema>;
export type UpdateArrivalConfirmation = z.infer<typeof updateArrivalConfirmationSchema>;

// Chat sessions for virtual assistant
export const chatSessions = pgTable("chat_sessions", {
  id: varchar("id").primaryKey().notNull(),
  userId: varchar("user_id"),
  userRole: varchar("user_role").notNull(),
  language: varchar("language").default("pt").notNull(),
  startTime: timestamp("start_time").defaultNow().notNull(),
  endTime: timestamp("end_time"),
  status: varchar("status").default("active").notNull(), // active, completed, escalated
  satisfactionRating: integer("satisfaction_rating"),
  escalationReason: text("escalation_reason"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Chat messages for virtual assistant
export const chatMessages = pgTable("chat_messages", {
  id: varchar("id").primaryKey().notNull(),
  sessionId: varchar("session_id").references(() => chatSessions.id, { onDelete: "cascade" }).notNull(),
  content: text("content").notNull(),
  role: varchar("role").notNull(), // user, assistant
  timestamp: timestamp("timestamp").defaultNow().notNull(),
  audioUrl: varchar("audio_url"),
  confidence: decimal("confidence", { precision: 3, scale: 2 }),
  sources: text("sources"), // JSON array of sources
});

export type ChatSession = typeof chatSessions.$inferSelect;
export type InsertChatSession = typeof chatSessions.$inferInsert;
export type ChatMessage = typeof chatMessages.$inferSelect;
export type InsertChatMessage = typeof chatMessages.$inferInsert;
export type UserPermission = typeof userPermissions.$inferSelect;
export type InsertUserPermission = z.infer<typeof insertUserPermissionSchema>;

export type Ship = typeof ships.$inferSelect;
export type InsertShip = z.infer<typeof insertShipSchema>;
export type CargoParcel = typeof cargoParcels.$inferSelect;
export type InsertCargoParcel = z.infer<typeof insertCargoParcelSchema>;
export type DischargeProgress = typeof dischargeProgress.$inferSelect;
export type InsertDischargeProgress = z.infer<typeof insertDischargeProgressSchema>;
export type TerminalSettings = typeof terminalSettings.$inferSelect;
export type UpdateShipStatus = z.infer<typeof updateShipStatusSchema>;
export type NotificationSubscription = typeof notificationSubscriptions.$inferSelect;
export type InsertNotificationSubscription = z.infer<typeof insertNotificationSubscriptionSchema>;
export type BerthingRecord = typeof berthingRecords.$inferSelect;
export type InsertBerthingRecord = z.infer<typeof insertBerthingRecordSchema>;
export type UndockingRecord = typeof undockingRecords.$inferSelect;
export type InsertUndockingRecord = z.infer<typeof insertUndockingRecordSchema>;
export type BerthMaintenance = typeof berthMaintenance.$inferSelect;
export type InsertBerthMaintenance = z.infer<typeof insertBerthMaintenanceSchema>;
export type UpdateBerthMaintenance = z.infer<typeof updateBerthMaintenanceSchema>;
export type CargoAgent = typeof cargoAgents.$inferSelect;
export type InsertCargoAgent = z.infer<typeof insertCargoAgentSchema>;
export type WeatherData = typeof weatherData.$inferSelect;
export type InsertWeatherData = z.infer<typeof insertWeatherDataSchema>;
export type WeatherAlert = typeof weatherAlerts.$inferSelect;
export type InsertWeatherAlert = z.infer<typeof insertWeatherAlertSchema>;

// Ship Registry and Reports schemas
export const insertShipRegistrySchema = createInsertSchema(shipRegistry).omit({
  id: true,
  registryDate: true,
  createdAt: true,
});

export const insertMonthlyReportSchema = createInsertSchema(monthlyReports).omit({
  id: true,
  generatedAt: true,
});

export const insertReportAccessLogSchema = createInsertSchema(reportAccessLogs).omit({
  id: true,
  accessedAt: true,
});

// Types for Ship Registry and Reports
export type ShipRegistry = typeof shipRegistry.$inferSelect;
export type InsertShipRegistry = z.infer<typeof insertShipRegistrySchema>;
export type MonthlyReport = typeof monthlyReports.$inferSelect;
export type InsertMonthlyReport = z.infer<typeof insertMonthlyReportSchema>;
export type ReportAccessLog = typeof reportAccessLogs.$inferSelect;
export type InsertReportAccessLog = z.infer<typeof insertReportAccessLogSchema>;

// Custom discharge rates table
export const customDischargeRates = pgTable("custom_discharge_rates", {
  id: serial("id").primaryKey(),
  shipId: integer("ship_id").notNull().references(() => ships.id, { onDelete: "cascade" }),
  parcelId: integer("parcel_id").notNull().references(() => cargoParcels.id, { onDelete: "cascade" }),
  product: varchar("product", { length: 100 }).notNull(),
  receiver: varchar("receiver", { length: 255 }).notNull(),
  customRate: decimal("custom_rate", { precision: 8, scale: 2 }).notNull(), // m³/h
  estimatedDuration: decimal("estimated_duration", { precision: 6, scale: 2 }), // hours
  notes: text("notes"),
  createdBy: integer("created_by").notNull().references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertCustomDischargeRateSchema = createInsertSchema(customDischargeRates).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type CustomDischargeRate = typeof customDischargeRates.$inferSelect;
export type InsertCustomDischargeRate = z.infer<typeof insertCustomDischargeRateSchema>;
