export interface CustomDischargeRate {
  id?: number;
  shipId: number;
  parcelId: number;
  product: string;
  receiver: string;
  customRate: number; // m³/h
  estimatedDuration?: number; // hours
  notes?: string;
  createdBy: number;
  createdAt?: Date;
  updatedAt?: Date;
}

export interface RateConfiguration {
  shipId: number;
  shipName: string;
  parcels: ParcelRateConfig[];
}

export interface ParcelRateConfig {
  parcelId: number;
  product: string;
  receiver: string;
  volumeM3: number;
  defaultRate: number;
  customRate?: number;
  estimatedDuration: number;
  notes?: string;
}

export type InsertCustomDischargeRate = Omit<CustomDischargeRate, 'id' | 'createdAt' | 'updatedAt'>;