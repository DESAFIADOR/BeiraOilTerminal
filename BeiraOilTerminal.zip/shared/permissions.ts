// Sistema hierárquico de usuários para Beira Oil Terminal
// Três níveis: Público (visualização), Operador (permissões autorizadas), Administrador (plenos poderes)

export const UserRole = {
  PUBLIC: "public",      // Somente visualização
  OPERATOR: "operator",  // Permissões autorizadas pelo administrador
  ADMIN: "admin"         // Plenos poderes sobre o sistema
} as const;

export type UserRole = typeof UserRole[keyof typeof UserRole];

export const Permission = {
  // Operações de navios
  VIEW_SHIPS: "view_ships",
  CREATE_SHIPS: "create_ships",
  UPDATE_SHIPS: "update_ships",
  DELETE_SHIPS: "delete_ships",
  MOVE_SHIPS: "move_ships",
  CONFIRM_SHIPS: "confirm_ships",
  
  // Operações de descarga
  UPDATE_DISCHARGE: "update_discharge",
  CONFIRM_DISCHARGE: "confirm_discharge",
  
  // Operações de atracação
  REGISTER_BERTHING: "register_berthing",
  REGISTER_UNDOCKING: "register_undocking",
  
  // Manutenção do cais
  MANAGE_MAINTENANCE: "manage_maintenance",
  
  // Gestão de usuários
  MANAGE_USERS: "manage_users",
  APPROVE_USERS: "approve_users",
  ASSIGN_PERMISSIONS: "assign_permissions",
  
  // Administração do sistema
  VIEW_REPORTS: "view_reports",
  CREATE_REPORTS: "create_reports",
  GENERATE_REPORTS: "generate_reports",
  SYSTEM_CONFIG: "system_config",
  ACCESS_ADMIN: "access_admin",
  
  // Notificações
  EMAIL_NOTIFICATIONS: "email_notifications",
  
  // Monitoramento
  WEATHER_MONITORING: "weather_monitoring",
  
  // Gestão adicional
  MANAGE_PERMISSIONS: "manage_permissions",
  BERTH_MANAGEMENT: "berth_management"
} as const;

export type Permission = typeof Permission[keyof typeof Permission];

// Permissões padrão para cada tipo de usuário
export const DEFAULT_PERMISSIONS = {
  [UserRole.PUBLIC]: [
    Permission.VIEW_SHIPS
  ],
  [UserRole.OPERATOR]: [
    Permission.VIEW_SHIPS,
    Permission.CREATE_SHIPS,
    Permission.UPDATE_SHIPS,
    Permission.MOVE_SHIPS,
    Permission.CONFIRM_SHIPS,
    Permission.UPDATE_DISCHARGE,
    Permission.CONFIRM_DISCHARGE,
    Permission.REGISTER_BERTHING,
    Permission.REGISTER_UNDOCKING,
    Permission.VIEW_REPORTS
  ],
  [UserRole.ADMIN]: [
    Permission.VIEW_SHIPS,
    Permission.CREATE_SHIPS,
    Permission.UPDATE_SHIPS,
    Permission.DELETE_SHIPS,
    Permission.MOVE_SHIPS,
    Permission.CONFIRM_SHIPS,
    Permission.UPDATE_DISCHARGE,
    Permission.CONFIRM_DISCHARGE,
    Permission.REGISTER_BERTHING,
    Permission.REGISTER_UNDOCKING,
    Permission.MANAGE_MAINTENANCE,
    Permission.MANAGE_USERS,
    Permission.APPROVE_USERS,
    Permission.ASSIGN_PERMISSIONS,
    Permission.VIEW_REPORTS,
    Permission.GENERATE_REPORTS,
    Permission.SYSTEM_CONFIG
  ]
} as const;

// Função para verificar se um usuário tem permissão específica
export function hasPermission(userRole: UserRole, userPermissions: string[], requiredPermission: Permission): boolean {
  // Administrador tem acesso total
  if (userRole === UserRole.ADMIN) {
    return true;
  }
  
  // Verificar se a permissão está na lista do usuário
  return userPermissions.includes(requiredPermission);
}

// Função para obter permissões padrão por role
export function getDefaultPermissions(role: UserRole): Permission[] {
  const permissions = DEFAULT_PERMISSIONS[role];
  return permissions ? [...permissions] : [];
}

// Função para verificar hierarquia de usuários
export function canManageUser(currentUserRole: UserRole, targetUserRole: UserRole): boolean {
  const roleHierarchy = {
    [UserRole.ADMIN]: 3,
    [UserRole.OPERATOR]: 2,
    [UserRole.PUBLIC]: 1
  };
  
  return roleHierarchy[currentUserRole] > roleHierarchy[targetUserRole];
}

// Descrições das permissões em português
export const PERMISSION_DESCRIPTIONS = {
  [Permission.VIEW_SHIPS]: "Visualizar navios e informações do terminal",
  [Permission.CREATE_SHIPS]: "Registrar novos navios no sistema",
  [Permission.UPDATE_SHIPS]: "Editar informações de navios",
  [Permission.DELETE_SHIPS]: "Remover navios do sistema",
  [Permission.MOVE_SHIPS]: "Mover navios entre status/filas",
  [Permission.CONFIRM_SHIPS]: "Confirmar atracação e operações",
  [Permission.UPDATE_DISCHARGE]: "Atualizar progresso de descarga",
  [Permission.CONFIRM_DISCHARGE]: "Confirmar conclusão de descarga",
  [Permission.REGISTER_BERTHING]: "Registrar atracação de navios",
  [Permission.REGISTER_UNDOCKING]: "Registrar desatracação de navios",
  [Permission.MANAGE_MAINTENANCE]: "Gerenciar manutenção do cais",
  [Permission.MANAGE_USERS]: "Gerenciar usuários do sistema",
  [Permission.APPROVE_USERS]: "Aprovar novos usuários",
  [Permission.ASSIGN_PERMISSIONS]: "Atribuir permissões a usuários",
  [Permission.VIEW_REPORTS]: "Visualizar relatórios",
  [Permission.GENERATE_REPORTS]: "Gerar relatórios do sistema",
  [Permission.SYSTEM_CONFIG]: "Configurar parâmetros do sistema"
} as const;

// Descrições dos roles em português
export const ROLE_DESCRIPTIONS = {
  [UserRole.PUBLIC]: "Usuário Público - Somente visualização",
  [UserRole.OPERATOR]: "Operador - Permissões autorizadas pelo administrador",
  [UserRole.ADMIN]: "Administrador - Plenos poderes sobre o sistema"
} as const;