import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Ship, Anchor, BarChart3 } from "lucide-react";

export default function Landing() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-blue-100">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-4">
              <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center">
                <Ship className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-gray-900">Beira Oil Terminal</h1>
                <p className="text-sm text-gray-600">Sistema de Line-Up</p>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            Sistema de Gestão de Line-Up de Navios
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Plataforma profissional para gestão do line-up (fila de atracação) de navios 
            que escalam o Beira Oil Terminal – CFM-EP, com visualização em tempo real.
          </p>
        </div>

        {/* Features Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
          <Card className="text-center">
            <CardHeader>
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mx-auto mb-4">
                <Anchor className="w-6 h-6 text-blue-600" />
              </div>
              <CardTitle>Gestão de Navios</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600">
                Cadastro completo de navios com informações de calado, agentes, 
                carga e parcelas de descarga.
              </p>
            </CardContent>
          </Card>

          <Card className="text-center">
            <CardHeader>
              <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mx-auto mb-4">
                <BarChart3 className="w-6 h-6 text-green-600" />
              </div>
              <CardTitle>Acompanhamento em Tempo Real</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600">
                Visualização em tempo real do status de atracação, descarga 
                e fila de navios no terminal.
              </p>
            </CardContent>
          </Card>

          <Card className="text-center">
            <CardHeader>
              <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center mx-auto mb-4">
                <Ship className="w-6 h-6 text-orange-600" />
              </div>
              <CardTitle>Cálculo Automático</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600">
                Cálculo automático de compatibilidade de calado com a maré 
                e previsões de término de descarga.
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Login Section */}
        <div className="max-w-md mx-auto">
          <Card>
            <CardHeader className="text-center">
              <CardTitle className="text-2xl">Acessar Sistema</CardTitle>
              <p className="text-gray-600">
                Faça login para acessar o painel de controle do terminal
              </p>
            </CardHeader>
            <CardContent className="space-y-4">
              <Button 
                onClick={() => window.location.href = '/api/login'}
                className="w-full bg-blue-600 hover:bg-blue-700"
                size="lg"
              >
                Entrar no Sistema
              </Button>
              <p className="text-sm text-gray-500 text-center">
                Sistema integrado com autenticação segura
              </p>
            </CardContent>
          </Card>
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-white border-t mt-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="text-center text-gray-600">
            <p>&copy; 2024 Beira Oil Terminal - CFM-EP. Sistema de Line-Up de Navios.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
