import { useState, useEffect } from "react";
import { useQuery, useQueryClient, useMutation } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { useClock, formatDate, formatTime } from "@/hooks/use-clock";
import { apiRequest } from "@/lib/queryClient";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Ship, Clock, Plus, LogOut, Menu, Anchor, Edit, Mail, Shield, Waves, Settings, AlertTriangle, Check, FileText, List, CheckCircle, ArrowUp, Info } from "lucide-react";
import { ShipRegistrationModal } from "@/components/ship-registration-modal";
import { DischargeUpdateModal } from "@/components/discharge-update-modal";
import { BerthingRegistrationModal } from "@/components/berthing-registration-modal";
import { PermissionsModal } from "@/components/permissions-modal";
import { BerthMaintenanceModal } from "@/components/berth-maintenance-modal";
import { InstructionModal } from "@/components/instruction-modal";
import { ShipInfoModal } from "@/components/ship-info-modal";
import { LanguageSelector } from "@/components/language-selector";
import { UserManagement } from "@/components/user-management";
import { isUnauthorizedError } from "@/lib/authUtils";
import { useToast } from "@/hooks/use-toast";
import { useTranslation } from "@/contexts/LanguageContext";

interface CargoParcel {
  id: number;
  shipId: number;
  parcelNumber: string;
  product: string;
  volumeMT: string;
  volumeM3: string;
  density: string;
  receiver: string;
  owner: string;
  status: string;
}

interface DischargeProgress {
  id: number;
  shipId: number;
  percentage: number;
  notes: string;
  recordedAt: Date;
}

interface TerminalSettings {
  id: number;
  channelDepth: string;
  tolerance: string;
  currentTide: string;
}

interface BerthMaintenance {
  id: number;
  isUnderMaintenance: boolean;
  maintenancePeriod: string;
  description: string;
}

export default function Dashboard() {
  const { user, isLoading } = useAuth();
  const currentTime = useClock();
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const { t } = useTranslation();

  const [userMode, setUserMode] = useState<"operator" | "public">("public");
  const [showMobileMenu, setShowMobileMenu] = useState(false);
  const [showRegisterModal, setShowRegisterModal] = useState(false);
  const [showDischargeUpdate, setShowDischargeUpdate] = useState(false);
  const [showBerthingRegistration, setShowBerthingRegistration] = useState(false);
  const [showPermissionsModal, setShowPermissionsModal] = useState(false);
  const [showMaintenanceModal, setShowMaintenanceModal] = useState(false);
  const [showInstructionModal, setShowInstructionModal] = useState(false);
  const [showUserManagement, setShowUserManagement] = useState(false);
  const [selectedShip, setSelectedShip] = useState<any>(null);
  const [showShipInfo, setShowShipInfo] = useState(false);

  type ShipWithDetails = {
    id: number;
    name: string;
    countermark: string;
    draft: string;
    arrivalDateTime: string | Date;
    shipAgent: string;
    cargoAgent: string;
    operationType: string;
    status: string;
    hasDischargeInstructions: boolean | null;
    departedAt?: string | Date | null;
    parcels: CargoParcel[];
    latestProgress?: DischargeProgress;
  };

  const { data: ships = [], isLoading: shipsLoading, refetch: refetchShips } = useQuery<ShipWithDetails[]>({
    queryKey: ["/api/ships"],
    refetchInterval: 2000,
    staleTime: 0,
  });

  const { data: terminalSettings } = useQuery<TerminalSettings>({
    queryKey: ["/api/terminal/settings"],
    refetchInterval: 60000,
  });

  const { data: berthMaintenanceStatus } = useQuery<BerthMaintenance>({
    queryKey: ["/api/berth/maintenance"],
    refetchInterval: 30000,
  });

  useEffect(() => {
    if (user?.role === "operator") {
      setUserMode("operator");
    } else {
      setUserMode("public");
    }
  }, [user]);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <Ship className="w-12 h-12 mx-auto mb-4 text-blue-600 animate-bounce" />
          <p className="text-gray-600">Carregando sistema...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <Card className="w-96">
          <CardHeader>
            <CardTitle>Acesso Requerido</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="mb-4">Você precisa fazer login para acessar o sistema.</p>
            <Button onClick={() => window.location.href = "/api/login"} className="w-full">
              Fazer Login
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const shipsAtBerth = ships.filter(ship => ship.status === "at_berth").length;
  const shipsInQueue = ships.filter(ship => ship.status === "at_bar" || ship.status === "next_to_berth");
  const expectedShips = ships.filter(ship => ship.status === "expected");

  const handleLogout = () => {
    window.location.href = "/api/logout";
  };

  const handleShipInfo = (ship: ShipWithDetails) => {
    setSelectedShip(ship);
    setShowShipInfo(true);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-4">
              <Ship className="w-8 h-8 text-blue-600" />
              <div>
                <h1 className="text-xl font-bold text-gray-900">Beira Oil Terminal</h1>
                <p className="text-sm text-gray-500">Gestão de Navios</p>
              </div>
            </div>

            <div className="hidden md:flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <Badge variant={userMode === "operator" ? "default" : "secondary"}>
                  {userMode === "operator" ? "Operador" : "Público"}
                </Badge>
                {user.role === "operator" && (
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setUserMode(userMode === "operator" ? "public" : "operator")}
                  >
                    {userMode === "operator" ? "Modo Público" : "Modo Operador"}
                  </Button>
                )}
              </div>
              <LanguageSelector />
              <span className="text-sm text-gray-600">{user.username}</span>
              <Button variant="outline" size="sm" onClick={handleLogout}>
                <LogOut className="w-4 h-4" />
              </Button>
            </div>

            <div className="md:hidden">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setShowMobileMenu(!showMobileMenu)}
              >
                <Menu className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Mobile Menu */}
      {showMobileMenu && (
        <div className="md:hidden bg-white border-b p-4">
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <Badge variant={userMode === "operator" ? "default" : "secondary"}>
                {userMode === "operator" ? "Operador" : "Público"}
              </Badge>
              {user.role === "operator" && (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setUserMode(userMode === "operator" ? "public" : "operator")}
                >
                  {userMode === "operator" ? "Modo Público" : "Modo Operador"}
                </Button>
              )}
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-600">{user.username}</span>
              <Button variant="outline" size="sm" onClick={handleLogout}>
                <LogOut className="w-4 h-4 mr-1" />
                Sair
              </Button>
            </div>
          </div>
        </div>
      )}

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="space-y-6">
          {/* Quick Actions */}
          {userMode === "operator" && (
            <Card>
              <CardHeader>
                <CardTitle className="text-blue-600">Ações Rápidas</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 lg:grid-cols-5 gap-4">
                  <Button onClick={() => setShowRegisterModal(true)} className="h-16 bg-blue-600 hover:bg-blue-700">
                    <div className="text-center">
                      <Plus className="w-6 h-6 mx-auto mb-1" />
                      <span className="text-sm">Registrar Navio</span>
                    </div>
                  </Button>

                  <Button onClick={() => setShowBerthingRegistration(true)} className="h-16 bg-green-600 hover:bg-green-700">
                    <div className="text-center">
                      <Anchor className="w-6 h-6 mx-auto mb-1" />
                      <span className="text-sm">Atracação do Navio</span>
                    </div>
                  </Button>

                  <Button onClick={() => setShowDischargeUpdate(true)} className="h-16 bg-orange-600 hover:bg-orange-700">
                    <div className="text-center">
                      <Edit className="w-6 h-6 mx-auto mb-1" />
                      <span className="text-sm">Atualizar Descarga</span>
                    </div>
                  </Button>

                  <Button onClick={() => setShowInstructionModal(true)} className="h-16 bg-purple-600 hover:bg-purple-700">
                    <div className="text-center">
                      <Mail className="w-6 h-6 mx-auto mb-1" />
                      <span className="text-sm">Mover para Instrução</span>
                    </div>
                  </Button>

                  <Button onClick={() => setShowMaintenanceModal(true)} className="h-16 bg-red-600 hover:bg-red-700">
                    <div className="text-center">
                      <Settings className="w-6 h-6 mx-auto mb-1" />
                      <span className="text-sm">Manutenção do Cais</span>
                    </div>
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Status Cards */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center space-x-2">
                  <Waves className="w-5 h-5 text-blue-600" />
                  <div>
                    <p className="text-sm text-gray-600">Maré Atual</p>
                    <p className="text-xl font-bold text-blue-600">{terminalSettings?.currentTide || "8.5"}m</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center space-x-2">
                  <Ship className="w-5 h-5 text-blue-600" />
                  <div>
                    <p className="text-sm text-gray-600">Navios no Cais</p>
                    <p className="text-xl font-bold text-blue-600">{shipsAtBerth}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center space-x-2">
                  <Ship className="w-5 h-5 text-orange-600" />
                  <div>
                    <p className="text-sm text-gray-600">Na Fila</p>
                    <p className="text-xl font-bold text-orange-600">{shipsInQueue.length}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center space-x-2">
                  <Clock className="w-5 h-5 text-green-600" />
                  <div>
                    <p className="text-sm text-gray-600">Hora Atual</p>
                    <p className="text-sm font-bold text-green-600">
                      {formatTime(currentTime)}
                    </p>
                    <p className="text-xs text-gray-500">
                      {formatDate(currentTime)}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Berth Maintenance Status */}
          {berthMaintenanceStatus?.isUnderMaintenance && (
            <Card className="border-red-200 bg-red-50">
              <CardContent className="p-6">
                <div className="flex items-center space-x-3 mb-4">
                  <AlertTriangle className="w-6 h-6 text-red-600" />
                  <h3 className="text-lg font-bold text-red-800">CAIS EM MANUTENÇÃO</h3>
                </div>
                <div className="grid gap-4">
                  <div>
                    <p className="text-sm font-medium text-red-700 mb-1">Período:</p>
                    <p className="text-red-600">{berthMaintenanceStatus.maintenancePeriod}</p>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-red-700 mb-1">Descrição:</p>
                    <p className="text-red-600 text-xs font-['Algerian'] uppercase" style={{fontSize: '10px'}}>
                      {berthMaintenanceStatus.description || "MANUTENÇÃO PROGRAMADA DO CAIS (INSPEÇÃO ANUAL DOS MLA) & DIVERSOS TRABALHOS DE MANUTENÇÃO EM EQUIPAMENTOS USADOS NO CAIS"}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Ships Queue - Complete Layout */}
          <div className="space-y-6">
            {/* Expected Ships */}
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="flex items-center space-x-2 text-blue-600">
                  <List className="w-5 h-5" />
                  <span>Navios Esperados ({expectedShips.length})</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {expectedShips.length > 0 ? (
                    expectedShips.map((ship) => (
                      <div key={ship.id} className="p-4 bg-white border rounded-lg shadow-sm">
                        <div className="flex justify-between items-start">
                          <div className="flex-1">
                            <div className="flex items-center space-x-3 mb-2">
                              <h4 className="font-medium text-gray-900 cursor-pointer hover:text-blue-600" onClick={() => handleShipInfo(ship)}>
                                {ship.name}
                              </h4>
                              <Badge variant="outline" className="bg-yellow-50 text-yellow-700 border-yellow-200">
                                Esperado
                              </Badge>
                            </div>
                            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-sm text-gray-600">
                              <span>CM: {ship.countermark}</span>
                              <span>Calado: {ship.draft}m</span>
                              <span>Tipo: {ship.operationType}</span>
                              <span>{ship.parcels?.length || 0} parcela(s)</span>
                            </div>
                            <p className="text-xs text-gray-500 mt-1">
                              Chegada: {new Date(ship.arrivalDateTime).toLocaleDateString('pt-BR', {
                                day: '2-digit', month: '2-digit', year: 'numeric',
                                hour: '2-digit', minute: '2-digit'
                              })}
                            </p>
                          </div>
                        </div>
                      </div>
                    ))
                  ) : (
                    <div className="text-center py-8 text-gray-500">
                      <Ship className="w-12 h-12 mx-auto mb-3 text-gray-300" />
                      <p>Nenhum navio esperado</p>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Ships at Bar - Without Instructions */}
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="flex items-center space-x-2 text-orange-600">
                  <Ship className="w-5 h-5" />
                  <span>Sem Instrução de Descarga ({ships.filter(s => s.status === "at_bar" && !s.hasDischargeInstructions).length})</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {ships.filter(s => s.status === "at_bar" && !s.hasDischargeInstructions).map((ship) => (
                    <div key={ship.id} className="p-4 bg-white border rounded-lg shadow-sm">
                      <div className="flex justify-between items-start">
                        <div className="flex-1">
                          <div className="flex items-center space-x-3 mb-2">
                            <h4 className="font-medium text-gray-900 cursor-pointer hover:text-blue-600" onClick={() => handleShipInfo(ship)}>
                              {ship.name}
                            </h4>
                            <Badge variant="outline" className="bg-orange-50 text-orange-700 border-orange-200">
                              Na Barra
                            </Badge>
                          </div>
                          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-sm text-gray-600">
                            <span>CM: {ship.countermark}</span>
                            <span>Calado: {ship.draft}m</span>
                            <span>Tipo: {ship.operationType}</span>
                            <span>{ship.parcels?.length || 0} parcela(s)</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Ships with Instructions */}
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="flex items-center space-x-2 text-green-600">
                  <CheckCircle className="w-5 h-5" />
                  <span>Com Instrução de Descarga ({ships.filter(s => (s.status === "at_bar" || s.status === "next_to_berth") && s.hasDischargeInstructions).length})</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {ships.filter(s => (s.status === "at_bar" || s.status === "next_to_berth") && s.hasDischargeInstructions).map((ship) => (
                    <div key={ship.id} className="p-4 bg-white border rounded-lg shadow-sm">
                      <div className="flex justify-between items-start">
                        <div className="flex-1">
                          <div className="flex items-center space-x-3 mb-2">
                            <h4 className="font-medium text-gray-900 cursor-pointer hover:text-blue-600" onClick={() => handleShipInfo(ship)}>
                              {ship.name}
                            </h4>
                            <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                              {ship.status === "next_to_berth" ? "Próximo ao Cais" : "Com Instrução"}
                            </Badge>
                          </div>
                          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-sm text-gray-600">
                            <span>CM: {ship.countermark}</span>
                            <span>Calado: {ship.draft}m</span>
                            <span>Tipo: {ship.operationType}</span>
                            <span>{ship.parcels?.length || 0} parcela(s)</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Ships at Berth */}
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="flex items-center space-x-2 text-blue-600">
                  <Anchor className="w-5 h-5" />
                  <span>Navio no Cais 12 ({ships.filter(s => s.status === "at_berth").length})</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {ships.filter(s => s.status === "at_berth").map((ship) => (
                    <div key={ship.id} className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                      <div className="flex justify-between items-start">
                        <div className="flex-1">
                          <div className="flex items-center space-x-3 mb-2">
                            <h4 className="font-medium text-blue-900 cursor-pointer hover:text-blue-700" onClick={() => handleShipInfo(ship)}>
                              {ship.name}
                            </h4>
                            <Badge className="bg-blue-600 text-white">
                              Atracado
                            </Badge>
                          </div>
                          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-sm text-blue-700">
                            <span>CM: {ship.countermark}</span>
                            <span>Calado: {ship.draft}m</span>
                            <span>Tipo: {ship.operationType}</span>
                            <span>{ship.parcels?.length || 0} parcela(s)</span>
                          </div>
                          {ship.latestProgress && (
                            <div className="mt-3 p-3 bg-white/60 rounded border">
                              <div className="flex items-center justify-between mb-2">
                                <span className="text-sm font-medium text-blue-800">Progresso da Descarga</span>
                                <span className="text-lg font-bold text-blue-900">{ship.latestProgress.percentage}%</span>
                              </div>
                              <div className="w-full bg-blue-200 rounded-full h-2">
                                <div 
                                  className="bg-blue-600 h-2 rounded-full transition-all duration-300"
                                  style={{ width: `${ship.latestProgress.percentage}%` }}
                                ></div>
                              </div>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Departed Ships */}
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="flex items-center space-x-2 text-gray-600">
                  <Ship className="w-5 h-5" />
                  <span>Navios Desatracados ({ships.filter(s => s.status === "departed").length})</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {ships.filter(s => s.status === "departed").length > 0 ? (
                    ships.filter(s => s.status === "departed").map((ship) => (
                      <div key={ship.id} className="p-4 bg-gray-50 border rounded-lg">
                        <div className="flex justify-between items-start">
                          <div className="flex-1">
                            <div className="flex items-center space-x-3 mb-2">
                              <h4 className="font-medium text-gray-700">{ship.name}</h4>
                              <Badge variant="outline" className="bg-gray-100 text-gray-600 border-gray-300">
                                Desatracado
                              </Badge>
                            </div>
                            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-sm text-gray-600">
                              <span>CM: {ship.countermark}</span>
                              <span>Calado: {ship.draft}m</span>
                              <span>Tipo: {ship.operationType}</span>
                              <span>{ship.parcels?.length || 0} parcela(s)</span>
                            </div>
                            {ship.departedAt && (
                              <p className="text-xs text-gray-500 mt-1">
                                Desatracado: {new Date(ship.departedAt).toLocaleDateString('pt-BR', {
                                  day: '2-digit', month: '2-digit', year: 'numeric',
                                  hour: '2-digit', minute: '2-digit'
                                })}
                              </p>
                            )}
                          </div>
                          <Button 
                            size="sm" 
                            variant="outline"
                            onClick={() => handleShipInfo(ship)}
                          >
                            <Info className="w-3 h-3 mr-1" />
                            Info
                          </Button>
                        </div>
                      </div>
                    ))
                  ) : (
                    <div className="text-center py-8 text-gray-500">
                      <Ship className="w-12 h-12 mx-auto mb-3 text-gray-300" />
                      <p>Nenhum navio desatracado</p>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Footer */}
          <div className="text-center text-gray-500 text-sm py-4">
            <p>
              Desenvolvido por <span className="text-xs">Eng</span> Manuel António • {" "}
              <span className="font-medium">Beira Oil Terminal Management System</span>
            </p>
          </div>
        </div>
      </main>

      {/* Modals */}
      <ShipRegistrationModal
        isOpen={showRegisterModal}
        onClose={() => setShowRegisterModal(false)}
        onSuccess={() => {
          refetchShips();
          setShowRegisterModal(false);
        }}
      />

      {/* All modals render conditionally to avoid prop errors */}
      {showDischargeUpdate && (
        <DischargeUpdateModal
          isOpen={true}
          onClose={() => setShowDischargeUpdate(false)}
          onSuccess={() => {
            refetchShips();
            setShowDischargeUpdate(false);
          }}
        />
      )}

      {showBerthingRegistration && (
        <BerthingRegistrationModal
          isOpen={true}
          onClose={() => setShowBerthingRegistration(false)}
          onSuccess={() => {
            refetchShips();
            setShowBerthingRegistration(false);
          }}
        />
      )}

      {showPermissionsModal && user && (
        <PermissionsModal
          isOpen={true}
          onClose={() => setShowPermissionsModal(false)}
          user={user}
        />
      )}

      {showMaintenanceModal && (
        <BerthMaintenanceModal
          isOpen={true}
          onClose={() => {
            queryClient.invalidateQueries({ queryKey: ["/api/berth/maintenance"] });
            setShowMaintenanceModal(false);
          }}
        />
      )}

      {showInstructionModal && (
        <InstructionModal
          isOpen={true}
          onClose={() => setShowInstructionModal(false)}
          ships={ships}
          onInstructionSent={() => {
            refetchShips();
            setShowInstructionModal(false);
          }}
        />
      )}

      {showShipInfo && selectedShip && (
        <ShipInfoModal
          ship={selectedShip}
          isOpen={true}
          onClose={() => {
            setShowShipInfo(false);
            setSelectedShip(null);
          }}
        />
      )}
    </div>
  );
}