import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useAuth } from "../hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogTrigger } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { CheckCircle, XCircle, Clock, User, Mail, Calendar, Lock } from "lucide-react";

interface PendingUser {
  id: number;
  username: string;
  email: string;
  firstName: string;
  lastName: string;
  requestedRole: string;
  createdAt: string;
}

export default function AdminUsers() {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Redirect non-operators
  useEffect(() => {
    if (user && user.role !== "operator") {
      toast({
        title: "Acesso Negado",
        description: "Apenas operadores podem acessar esta página.",
        variant: "destructive",
      });
      window.location.href = "/";
    }
  }, [user, toast]);
  const [selectedUser, setSelectedUser] = useState<PendingUser | null>(null);
  const [adminPassword, setAdminPassword] = useState("");
  const [approvalAction, setApprovalAction] = useState<"approve" | "reject" | null>(null);
  const [showPasswordDialog, setShowPasswordDialog] = useState(false);

  const { data: pendingUsers = [], isLoading } = useQuery<PendingUser[]>({
    queryKey: ["/api/users/pending"],
    refetchInterval: 30000, // Refresh every 30 seconds
  });

  const approveMutation = useMutation({
    mutationFn: async (data: { userId: number; approved: boolean; role: string; adminPassword: string }) => {
      const response = await apiRequest("/api/users/approve", "POST", data);
      return await response.json();
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: ["/api/users/pending"] });
      setShowPasswordDialog(false);
      setAdminPassword("");
      setSelectedUser(null);
      setApprovalAction(null);
      toast({
        title: variables.approved ? "Usuário Aprovado" : "Usuário Rejeitado",
        description: variables.approved 
          ? "O usuário foi aprovado como operador e pode fazer login."
          : "A solicitação do usuário foi rejeitada.",
        variant: variables.approved ? "default" : "destructive",
      });
    },
    onError: (error) => {
      console.error("Approval error:", error);
      const errorMessage = error.message || "Erro desconhecido no processamento.";
      
      if (errorMessage.includes("Senha de administrador incorreta")) {
        toast({
          title: "Senha Incorreta",
          description: "A senha de administrador está incorreta. Tente novamente.",
          variant: "destructive",
        });
      } else if (errorMessage.includes("Missing required fields")) {
        toast({
          title: "Dados Incompletos",
          description: "Alguns campos obrigatórios estão faltando.",
          variant: "destructive",
        });
      } else {
        toast({
          title: "Erro no Processamento",
          description: `Falha ao processar a solicitação: ${errorMessage}`,
          variant: "destructive",
        });
      }
    },
  });

  const handleApprovalRequest = (user: PendingUser, action: "approve" | "reject") => {
    setSelectedUser(user);
    setApprovalAction(action);
    setShowPasswordDialog(true);
  };

  const handlePasswordSubmit = () => {
    if (!selectedUser || !approvalAction || !adminPassword.trim()) {
      toast({
        title: "Erro",
        description: "Por favor, digite a senha de administrador.",
        variant: "destructive",
      });
      return;
    }

    const requestData = {
      userId: selectedUser.id,
      approved: approvalAction === "approve",
      role: approvalAction === "approve" ? (selectedUser.requestedRole || "user") : "user",
      adminPassword: adminPassword.trim()
    };

    console.log("Sending approval request:", requestData);
    approveMutation.mutate(requestData);
  };

  if (isLoading) {
    return (
      <div className="container mx-auto py-8">
        <div className="flex items-center justify-center min-h-[400px]">
          <div className="text-center">
            <Clock className="h-12 w-12 mx-auto text-gray-400 mb-4" />
            <p className="text-gray-500">Carregando solicitações pendentes...</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">
          Gerenciamento de Usuários
        </h1>
        <p className="text-gray-600">
          Aprove ou rejeite solicitações de conta de operador
        </p>
      </div>

      {pendingUsers.length === 0 ? (
        <Card>
          <CardContent className="flex items-center justify-center py-12">
            <div className="text-center">
              <CheckCircle className="h-12 w-12 mx-auto text-green-500 mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">
                Nenhuma solicitação pendente
              </h3>
              <p className="text-gray-500">
                Todas as solicitações de operador foram processadas.
              </p>
            </div>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-4">
          {pendingUsers.map((user: PendingUser) => (
            <Card key={user.id} className="border-l-4 border-l-amber-400">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="flex items-center gap-2">
                    <User className="h-5 w-5" />
                    {user.firstName} {user.lastName}
                    <Badge variant="outline" className="ml-2">
                      {user.requestedRole === "operator" ? "Operador" : "Usuário"}
                    </Badge>
                  </CardTitle>
                  <Badge variant="secondary" className="flex items-center gap-1">
                    <Clock className="h-3 w-3" />
                    Pendente
                  </Badge>
                </div>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                  <div className="flex items-center gap-2 text-sm text-gray-600">
                    <User className="h-4 w-4" />
                    <span className="font-medium">Username:</span>
                    <span>{user.username}</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm text-gray-600">
                    <Mail className="h-4 w-4" />
                    <span className="font-medium">Email:</span>
                    <span>{user.email || "Não informado"}</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm text-gray-600">
                    <Calendar className="h-4 w-4" />
                    <span className="font-medium">Solicitado em:</span>
                    <span>{new Date(user.createdAt).toLocaleDateString("pt-BR")}</span>
                  </div>
                </div>

                <div className="flex gap-3">
                  <Button
                    onClick={() => handleApprovalRequest(user, "approve")}
                    disabled={approveMutation.isPending}
                    className="flex items-center gap-2 bg-green-600 hover:bg-green-700"
                  >
                    <Lock className="h-4 w-4" />
                    Aprovar como {user.requestedRole === "operator" ? "Operador" : "Usuário"}
                  </Button>
                  <Button
                    onClick={() => handleApprovalRequest(user, "reject")}
                    disabled={approveMutation.isPending}
                    variant="destructive"
                    className="flex items-center gap-2"
                  >
                    <Lock className="h-4 w-4" />
                    Rejeitar
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Modal de Senha Administrativa */}
      <Dialog open={showPasswordDialog} onOpenChange={setShowPasswordDialog}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Lock className="h-5 w-5" />
              Autorização de Administrador
            </DialogTitle>
            <DialogDescription>
              Digite a senha de administrador para confirmar esta ação de usuário.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="p-4 bg-amber-50 border border-amber-200 rounded-lg">
              <p className="text-sm text-amber-800">
                <strong>Ação:</strong> {approvalAction === "approve" ? "Aprovar" : "Rejeitar"} usuário{" "}
                <strong>{selectedUser?.firstName} {selectedUser?.lastName}</strong> como {selectedUser?.requestedRole === "operator" ? "Operador" : "Usuário"}
              </p>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="admin-password">Senha de Administrador</Label>
              <Input
                id="admin-password"
                type="password"
                placeholder="Digite a senha de administrador"
                value={adminPassword}
                onChange={(e) => setAdminPassword(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && handlePasswordSubmit()}
              />
            </div>
            
            <div className="flex gap-3 pt-4">
              <Button
                onClick={handlePasswordSubmit}
                disabled={approveMutation.isPending || !adminPassword.trim()}
                className={approvalAction === "approve" ? "bg-green-600 hover:bg-green-700" : "bg-red-600 hover:bg-red-700"}
              >
                {approveMutation.isPending ? "Processando..." : (approvalAction === "approve" ? "Confirmar Aprovação" : "Confirmar Rejeição")}
              </Button>
              <Button
                variant="outline"
                onClick={() => {
                  setShowPasswordDialog(false);
                  setAdminPassword("");
                  setSelectedUser(null);
                  setApprovalAction(null);
                }}
                disabled={approveMutation.isPending}
              >
                Cancelar
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}