import { useAuth } from "@/contexts/AuthContext";
import { useLocation } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import UserManagement from "@/components/admin/UserManagement";
import { Shield, Users, Settings, BarChart3 } from "lucide-react";

export default function AdminPanel() {
  const { user, isLoading, isAuthenticated } = useAuth();
  const [, setLocation] = useLocation();

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p>Verificando permissões...</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated || (user?.role !== 'admin' && user?.role !== 'desenvolvedor')) {
    setLocation('/');
    return null;
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto p-6">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-12 h-12 bg-red-600 rounded-full flex items-center justify-center">
              <Shield className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-gray-900">Painel Administrativo</h1>
              <p className="text-gray-600">Sistema de Gerenciamento do Terminal da Beira</p>
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <Users className="w-8 h-8 text-blue-600" />
                  <div>
                    <p className="text-sm text-gray-600">Sistema Hierárquico</p>
                    <p className="text-lg font-semibold">3 Níveis de Acesso</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <Settings className="w-8 h-8 text-green-600" />
                  <div>
                    <p className="text-sm text-gray-600">Controle Total</p>
                    <p className="text-lg font-semibold">Gestão de Usuários</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <BarChart3 className="w-8 h-8 text-purple-600" />
                  <div>
                    <p className="text-sm text-gray-600">Monitoramento</p>
                    <p className="text-lg font-semibold">Atividades do Sistema</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Content */}
        <Tabs defaultValue="users" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="users" className="flex items-center gap-2">
              <Users className="w-4 h-4" />
              Usuários
            </TabsTrigger>
            <TabsTrigger value="permissions" className="flex items-center gap-2">
              <Shield className="w-4 h-4" />
              Permissões
            </TabsTrigger>
            <TabsTrigger value="system" className="flex items-center gap-2">
              <Settings className="w-4 h-4" />
              Sistema
            </TabsTrigger>
            <TabsTrigger value="reports" className="flex items-center gap-2">
              <BarChart3 className="w-4 h-4" />
              Relatórios
            </TabsTrigger>
          </TabsList>

          <TabsContent value="users">
            <UserManagement />
          </TabsContent>

          <TabsContent value="permissions">
            <Card>
              <CardHeader>
                <CardTitle>Sistema de Permissões Hierárquico</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {/* Público */}
                  <div className="border rounded-lg p-4">
                    <div className="flex items-center gap-3 mb-3">
                      <div className="w-8 h-8 bg-gray-100 rounded-full flex items-center justify-center">
                        <Users className="w-4 h-4 text-gray-600" />
                      </div>
                      <div>
                        <h3 className="font-semibold text-gray-900">Nível Público</h3>
                        <p className="text-sm text-gray-600">Acesso somente leitura</p>
                      </div>
                    </div>
                    <div className="grid grid-cols-2 gap-2 text-sm">
                      <div className="text-green-600">✓ Visualizar informações de navios</div>
                      <div className="text-green-600">✓ Ver dados meteorológicos</div>
                      <div className="text-green-600">✓ Consultar cronograma de navios</div>
                      <div className="text-green-600">✓ Acessar informações públicas</div>
                      <div className="text-red-600">✗ Editar dados</div>
                      <div className="text-red-600">✗ Mover navios</div>
                    </div>
                  </div>

                  {/* Operador */}
                  <div className="border rounded-lg p-4">
                    <div className="flex items-center gap-3 mb-3">
                      <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                        <Settings className="w-4 h-4 text-blue-600" />
                      </div>
                      <div>
                        <h3 className="font-semibold text-gray-900">Nível Operador</h3>
                        <p className="text-sm text-gray-600">Permissões operacionais (requer aprovação)</p>
                      </div>
                    </div>
                    <div className="grid grid-cols-2 gap-2 text-sm">
                      <div className="text-green-600">✓ Todas as permissões do nível público</div>
                      <div className="text-green-600">✓ Registrar novos navios</div>
                      <div className="text-green-600">✓ Atualizar status de navios</div>
                      <div className="text-green-600">✓ Mover navios no cronograma</div>
                      <div className="text-green-600">✓ Confirmar operações de atracação</div>
                      <div className="text-green-600">✓ Controlar descarga de navios</div>
                      <div className="text-red-600">✗ Gerenciar outros usuários</div>
                      <div className="text-red-600">✗ Alterar configurações do sistema</div>
                    </div>
                  </div>

                  {/* Administrador */}
                  <div className="border rounded-lg p-4">
                    <div className="flex items-center gap-3 mb-3">
                      <div className="w-8 h-8 bg-red-100 rounded-full flex items-center justify-center">
                        <Shield className="w-4 h-4 text-red-600" />
                      </div>
                      <div>
                        <h3 className="font-semibold text-gray-900">Nível Administrador</h3>
                        <p className="text-sm text-gray-600">Controle total do sistema</p>
                      </div>
                    </div>
                    <div className="grid grid-cols-2 gap-2 text-sm">
                      <div className="text-green-600">✓ Todas as permissões de operador</div>
                      <div className="text-green-600">✓ Criar/editar/excluir usuários</div>
                      <div className="text-green-600">✓ Aprovar solicitações de operadores</div>
                      <div className="text-green-600">✓ Alterar níveis de acesso</div>
                      <div className="text-green-600">✓ Configurar sistema</div>
                      <div className="text-green-600">✓ Acessar todos os relatórios</div>
                      <div className="text-green-600">✓ Controlar manutenção de cais</div>
                      <div className="text-green-600">✓ Gerenciar configurações avançadas</div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="system">
            <Card>
              <CardHeader>
                <CardTitle>Configurações do Sistema</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="text-center py-8">
                    <Settings className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                    <p className="text-gray-600">Configurações avançadas do sistema</p>
                    <p className="text-sm text-gray-500 mt-2">
                      Funcionalidades de configuração serão implementadas conforme necessidade
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="reports">
            <Card>
              <CardHeader>
                <CardTitle>Relatórios Administrativos</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="text-center py-8">
                    <BarChart3 className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                    <p className="text-gray-600">Relatórios e análises do sistema</p>
                    <p className="text-sm text-gray-500 mt-2">
                      Dashboards e relatórios específicos para administradores
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}