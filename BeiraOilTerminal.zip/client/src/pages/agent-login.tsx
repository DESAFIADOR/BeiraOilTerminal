import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useLocation } from "wouter";
import { Ship, LogIn, User, ArrowLeft } from "lucide-react";

// Schema de validação para login de agente
const agentLoginSchema = z.object({
  username: z.string().min(1, "Nome de usuário é obrigatório"),
  password: z.string().min(1, "Senha é obrigatória")
});

type AgentLoginForm = z.infer<typeof agentLoginSchema>;

export default function AgentLogin() {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);

  const form = useForm<AgentLoginForm>({
    resolver: zodResolver(agentLoginSchema),
    defaultValues: {
      username: "",
      password: ""
    }
  });

  const loginMutation = useMutation({
    mutationFn: async (data: AgentLoginForm) => {
      return await apiRequest("/api/auth/agent-login", {
        method: "POST",
        body: JSON.stringify(data)
      });
    },
    onSuccess: () => {
      toast({
        title: "Login Realizado com Sucesso",
        description: "Bem-vindo ao painel do agente marítimo!",
        variant: "default"
      });
      navigate("/agent-dashboard");
    },
    onError: (error: any) => {
      toast({
        title: "Erro no Login",
        description: error.message || "Credenciais inválidas. Verifique seu usuário e senha.",
        variant: "destructive"
      });
    }
  });

  const onSubmit = async (data: AgentLoginForm) => {
    setIsLoading(true);
    try {
      await loginMutation.mutateAsync(data);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-blue-100 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center mb-4">
            <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-blue-700 rounded-full flex items-center justify-center">
              <Ship className="w-8 h-8 text-white" />
            </div>
          </div>
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Portal do Agente</h1>
          <p className="text-gray-600">Terminal Petrolífero da Beira - Cais 12</p>
          <p className="text-sm text-gray-500 mt-2">
            Desenvolvido por: Manuel Antonio, Eng.
          </p>
        </div>

        <Card className="shadow-xl border-0">
          <CardHeader className="bg-gradient-to-r from-blue-600 to-blue-700 text-white rounded-t-lg">
            <CardTitle className="text-2xl font-semibold flex items-center justify-center">
              <LogIn className="w-6 h-6 mr-2" />
              Login do Agente
            </CardTitle>
            <CardDescription className="text-blue-100 text-center">
              Acesse o sistema de gestão marítima
            </CardDescription>
          </CardHeader>
          
          <CardContent className="p-8">
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                <FormField
                  control={form.control}
                  name="username"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="flex items-center">
                        <User className="w-4 h-4 mr-2" />
                        Nome de Usuário
                      </FormLabel>
                      <FormControl>
                        <Input 
                          placeholder="Digite seu usuário" 
                          className="h-12"
                          {...field} 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="password"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Senha</FormLabel>
                      <FormControl>
                        <Input 
                          type="password" 
                          placeholder="Digite sua senha" 
                          className="h-12"
                          {...field} 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <Button
                  type="submit"
                  className="w-full h-12 bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-lg font-semibold"
                  disabled={isLoading || loginMutation.isPending}
                >
                  {isLoading || loginMutation.isPending ? "Entrando..." : "Entrar"}
                </Button>

                {/* Links de Navegação */}
                <div className="space-y-4 pt-4 border-t border-gray-200">
                  <div className="text-center">
                    <p className="text-sm text-gray-600 mb-3">
                      Não possui conta como agente?
                    </p>
                    <Button
                      type="button"
                      variant="outline"
                      className="w-full mb-3"
                      onClick={() => navigate("/agent-register")}
                    >
                      Solicitar Registro de Agente
                    </Button>
                  </div>

                  <div className="text-center">
                    <Button
                      type="button"
                      variant="ghost"
                      className="text-blue-600 hover:text-blue-700"
                      onClick={() => navigate("/login")}
                    >
                      <ArrowLeft className="w-4 h-4 mr-2" />
                      Voltar ao Login Principal
                    </Button>
                  </div>
                </div>

                {/* Nota Informativa */}
                <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                  <p className="text-sm text-blue-800">
                    <strong>Agentes Marítimos:</strong> Este portal é exclusivo para agentes cadastrados 
                    que gerenciam operações de navios no Terminal da Beira. Suas credenciais devem 
                    ter sido aprovadas pela administração portuária.
                  </p>
                </div>
              </form>
            </Form>
          </CardContent>
        </Card>

        {/* Demo Credentials */}
        <div className="mt-6 bg-gray-50 border border-gray-200 rounded-lg p-4">
          <h3 className="text-sm font-semibold text-gray-700 mb-2">Credenciais de Demonstração:</h3>
          <div className="text-xs text-gray-600 space-y-1">
            <p><strong>Usuário:</strong> agente</p>
            <p><strong>Senha:</strong> 123456</p>
          </div>
        </div>
      </div>
    </div>
  );
}