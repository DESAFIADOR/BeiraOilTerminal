export default function TestDashboard() {
  console.log("TestDashboard component rendering");
  
  return (
    <div className="min-h-screen bg-blue-50 p-8">
      <div className="max-w-6xl mx-auto">
        <div className="bg-white rounded-lg shadow-lg p-8 mb-6">
          <h1 className="text-4xl font-bold text-blue-900 mb-6 text-center">
            ✓ Sistema de Line-Up - Beira Oil Terminal
          </h1>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="bg-green-50 border-2 border-green-200 rounded-lg p-6">
              <h2 className="text-xl font-semibold text-green-800 mb-3">Sistema Funcionando</h2>
              <p className="text-green-700">
                ✓ Autenticação corrigida<br/>
                ✓ Banco de dados conectado<br/>
                ✓ Interface carregando
              </p>
            </div>
            <div className="bg-blue-50 border-2 border-blue-200 rounded-lg p-6">
              <h2 className="text-xl font-semibold text-blue-800 mb-3">Credenciais de Acesso</h2>
              <p className="text-blue-700">
                <strong>Operador:</strong> operator / 123456<br/>
                <strong>Usuários:</strong> Zinatara, Arlindo.Arlindo, lucas.vidigal / 123456
              </p>
            </div>
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow-lg p-8">
          <h2 className="text-2xl font-semibold text-gray-800 mb-4">Próximos Passos</h2>
          <p className="text-gray-600 text-lg">
            Sistema pronto para uso. Dashboard completo sendo preparado para restaurar todas as funcionalidades.
          </p>
        </div>
      </div>
    </div>
  );
}