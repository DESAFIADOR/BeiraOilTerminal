import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Ship, Users, UserCheck, Eye, EyeOff } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import { useLocation } from "wouter";
import { useTranslation } from "@/contexts/LanguageContext";
import logoPath from "@assets/LogTipo_1749832282954.png";

const loginSchema = z.object({
  username: z.string().min(1, "Nome de usuário é obrigatório"),
  password: z.string().min(1, "Senha é obrigatória"),
});

const registerSchema = z.object({
  username: z.string().min(3, "Nome de usuário deve ter pelo menos 3 caracteres"),
  password: z.string().min(6, "Senha deve ter pelo menos 6 caracteres"),
  firstName: z.string().optional(),
  lastName: z.string().optional(),
  email: z.string().email("Email inválido").optional().or(z.literal("")),
  role: z.enum(["operator", "user"]),
});

type LoginFormData = z.infer<typeof loginSchema>;
type RegisterFormData = z.infer<typeof registerSchema>;

export default function AuthPage() {
  const { user, loginMutation, registerMutation } = useAuth();
  const { t } = useTranslation();
  const [, setLocation] = useLocation();
  const [showPassword, setShowPassword] = useState(false);
  const [activeTab, setActiveTab] = useState("login");

  // Redirect if already logged in
  useEffect(() => {
    if (user) {
      setLocation("/");
    }
  }, [user, setLocation]);

  const loginForm = useForm<LoginFormData>({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      username: "",
      password: "",
    },
  });

  const registerForm = useForm<RegisterFormData>({
    resolver: zodResolver(registerSchema),
    defaultValues: {
      username: "",
      password: "",
      firstName: "",
      lastName: "",
      email: "",
      role: "user",
    },
  });

  const handleLogin = (data: LoginFormData) => {
    loginMutation.mutate(data);
  };

  const handleRegister = (data: RegisterFormData) => {
    const submitData = {
      ...data,
      email: data.email || undefined,
      firstName: data.firstName || undefined,
      lastName: data.lastName || undefined,
    };
    registerMutation.mutate(submitData);
  };

  if (user) {
    return null; // Will redirect via useEffect
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-blue-100">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-4">
              <div className="w-14 h-14 rounded-full bg-white flex items-center justify-center border-2 border-blue-400 shadow-lg p-2">
                <img 
                  src={logoPath} 
                  alt="CFM - Mozambique Ports and Railways" 
                  className="w-8 h-8 object-contain"
                  style={{
                    imageRendering: 'crisp-edges',
                    filter: 'contrast(1.15) brightness(1.05) saturate(1.05)',
                    transform: 'translateZ(0)',
                    backfaceVisibility: 'hidden',
                    WebkitFontSmoothing: 'antialiased',
                    MozOsxFontSmoothing: 'grayscale',
                    textRendering: 'optimizeLegibility'
                  }}
                />
              </div>
              <div>
                <h1 className="text-xl font-bold text-gray-900">Beira Oil Terminal</h1>
                <p className="text-sm text-gray-600">Sistema de Line-Up</p>
              </div>
            </div>
            <div className="text-right">
              <p className="text-xs text-gray-500">Developed by: Manuel Antonio, Eng.</p>
            </div>
          </div>
        </div>
      </header>

      <div className="flex min-h-[calc(100vh-4rem)]">
        {/* Left Column - Authentication Forms */}
        <div className="flex-1 flex items-center justify-center px-4 sm:px-6 lg:px-8">
          <div className="max-w-md w-full">
            <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
              <TabsList className="grid w-full grid-cols-2 mb-6">
                <TabsTrigger value="login">{t('common.login')}</TabsTrigger>
                <TabsTrigger value="register">{t('common.register')}</TabsTrigger>
              </TabsList>

              {/* Login Tab */}
              <TabsContent value="login">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-2xl text-center">{t('auth.welcomeBack')}</CardTitle>
                    <p className="text-gray-600 text-center">
                      {t('auth.signInToContinue')}
                    </p>
                  </CardHeader>
                  <CardContent>
                    <form onSubmit={loginForm.handleSubmit(handleLogin)} className="space-y-4">
                      <div>
                        <Label htmlFor="login-username">{t('common.username')}</Label>
                        <Input
                          id="login-username"
                          placeholder={t('common.username')}
                          {...loginForm.register("username")}
                        />
                        {loginForm.formState.errors.username && (
                          <p className="text-sm text-red-600 mt-1">
                            {loginForm.formState.errors.username.message}
                          </p>
                        )}
                      </div>
                      
                      <div>
                        <Label htmlFor="login-password">{t('common.password')}</Label>
                        <div className="relative">
                          <Input
                            id="login-password"
                            type={showPassword ? "text" : "password"}
                            placeholder={t('common.password')}
                            {...loginForm.register("password")}
                          />
                          <Button
                            type="button"
                            variant="ghost"
                            size="sm"
                            className="absolute right-0 top-0 h-full px-3"
                            onClick={() => setShowPassword(!showPassword)}
                          >
                            {showPassword ? (
                              <EyeOff className="h-4 w-4" />
                            ) : (
                              <Eye className="h-4 w-4" />
                            )}
                          </Button>
                        </div>
                        {loginForm.formState.errors.password && (
                          <p className="text-sm text-red-600 mt-1">
                            {loginForm.formState.errors.password.message}
                          </p>
                        )}
                      </div>
                      
                      <Button 
                        type="submit" 
                        className="w-full bg-blue-600 hover:bg-blue-700"
                        disabled={loginMutation.isPending}
                      >
                        {loginMutation.isPending ? t('status.processing') : t('buttons.login')}
                      </Button>
                    </form>
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Register Tab */}
              <TabsContent value="register">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-2xl text-center">{t('auth.createAccount')}</CardTitle>
                    <p className="text-gray-600 text-center">
                      {t('auth.joinPlatform')}
                    </p>
                  </CardHeader>
                  <CardContent>
                    <form onSubmit={registerForm.handleSubmit(handleRegister)} className="space-y-4">
                      <div>
                        <Label htmlFor="register-username">{t('common.username')} *</Label>
                        <Input
                          id="register-username"
                          placeholder={t('common.username')}
                          {...registerForm.register("username")}
                        />
                        {registerForm.formState.errors.username && (
                          <p className="text-sm text-red-600 mt-1">
                            {registerForm.formState.errors.username.message}
                          </p>
                        )}
                      </div>
                      
                      <div>
                        <Label htmlFor="register-password">{t('common.password')} *</Label>
                        <div className="relative">
                          <Input
                            id="register-password"
                            type={showPassword ? "text" : "password"}
                            placeholder={t('common.password')}
                            {...registerForm.register("password")}
                          />
                          <Button
                            type="button"
                            variant="ghost"
                            size="sm"
                            className="absolute right-0 top-0 h-full px-3"
                            onClick={() => setShowPassword(!showPassword)}
                          >
                            {showPassword ? (
                              <EyeOff className="h-4 w-4" />
                            ) : (
                              <Eye className="h-4 w-4" />
                            )}
                          </Button>
                        </div>
                        {registerForm.formState.errors.password && (
                          <p className="text-sm text-red-600 mt-1">
                            {registerForm.formState.errors.password.message}
                          </p>
                        )}
                      </div>

                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <Label htmlFor="register-firstName">{t('common.firstName')}</Label>
                          <Input
                            id="register-firstName"
                            placeholder={t('common.firstName')}
                            {...registerForm.register("firstName")}
                          />
                        </div>
                        <div>
                          <Label htmlFor="register-lastName">{t('common.lastName')}</Label>
                          <Input
                            id="register-lastName"
                            placeholder={t('common.lastName')}
                            {...registerForm.register("lastName")}
                          />
                        </div>
                      </div>
                      
                      <div>
                        <Label htmlFor="register-email">{t('common.email')}</Label>
                        <Input
                          id="register-email"
                          type="email"
                          placeholder={t('common.email')}
                          {...registerForm.register("email")}
                        />
                        {registerForm.formState.errors.email && (
                          <p className="text-sm text-red-600 mt-1">
                            {registerForm.formState.errors.email.message}
                          </p>
                        )}
                      </div>
                      
                      <div>
                        <Label htmlFor="register-role">Tipo de Conta *</Label>
                        <Select
                          value={registerForm.watch("role")}
                          onValueChange={(value: "operator" | "user") => 
                            registerForm.setValue("role", value)
                          }
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Selecione o tipo de conta" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="user">
                              <div className="flex items-center space-x-2">
                                <Eye className="h-4 w-4" />
                                <div>
                                  <p className="font-medium">Conta Pública</p>
                                  <p className="text-xs text-gray-500">Acesso imediato - visualização apenas</p>
                                </div>
                              </div>
                            </SelectItem>
                            <SelectItem value="operator">
                              <div className="flex items-center space-x-2">
                                <UserCheck className="h-4 w-4" />
                                <div>
                                  <p className="font-medium">Conta de Operador</p>
                                  <p className="text-xs text-gray-500">Requer aprovação - controle total do sistema</p>
                                </div>
                              </div>
                            </SelectItem>
                          </SelectContent>
                        </Select>
                        {registerForm.formState.errors.role && (
                          <p className="text-sm text-red-600 mt-1">
                            {registerForm.formState.errors.role.message}
                          </p>
                        )}
                        
                        {/* Account type explanation */}
                        <div className="mt-3 p-3 bg-blue-50 rounded-lg border-l-4 border-blue-400">
                          {registerForm.watch("role") === "user" ? (
                            <div>
                              <h4 className="text-sm font-medium text-blue-800 mb-1">Conta Pública</h4>
                              <p className="text-xs text-blue-600">
                                Acesso imediato ao sistema para visualizar informações de navios e status do terminal. 
                                Ideal para agentes, clientes e outros interessados.
                              </p>
                            </div>
                          ) : registerForm.watch("role") === "operator" ? (
                            <div>
                              <h4 className="text-sm font-medium text-amber-800 mb-1">Conta de Operador</h4>
                              <p className="text-xs text-amber-600">
                                Acesso completo para registrar navios, atualizar status e gerenciar operações. 
                                Requer aprovação por um administrador antes da ativação.
                              </p>
                            </div>
                          ) : (
                            <div>
                              <h4 className="text-sm font-medium text-gray-600 mb-1">Selecione um tipo de conta</h4>
                              <p className="text-xs text-gray-500">
                                Escolha entre acesso público imediato ou conta de operador com aprovação necessária.
                              </p>
                            </div>
                          )}
                        </div>
                      </div>
                      
                      <Button 
                        type="submit" 
                        className="w-full bg-green-600 hover:bg-green-700"
                        disabled={registerMutation.isPending}
                      >
                        {registerMutation.isPending ? t('status.processing') : t('auth.createAccount')}
                      </Button>
                    </form>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </div>

        {/* Right Column - Information */}
        <div className="hidden lg:flex lg:flex-1 bg-gradient-to-br from-blue-600 to-blue-800 text-white p-12 items-center">
          <div className="max-w-lg">
            <h2 className="text-3xl font-bold mb-6">
              Sistema de Gestão Portuária
            </h2>
            <p className="text-xl mb-8">
              Controle completo do line-up de navios do Beira Oil Terminal com 
              funcionalidades avançadas de monitoramento e gestão.
            </p>
            
            <div className="space-y-6">
              <div className="flex items-start space-x-4">
                <div className="w-12 h-12 bg-blue-500 rounded-lg flex items-center justify-center flex-shrink-0">
                  <UserCheck className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="font-semibold text-lg mb-2">Operadores</h3>
                  <p className="text-blue-100">
                    Acesso completo para registrar navios, atualizar descargas 
                    e gerenciar operações do terminal.
                  </p>
                </div>
              </div>
              
              <div className="flex items-start space-x-4">
                <div className="w-12 h-12 bg-blue-500 rounded-lg flex items-center justify-center flex-shrink-0">
                  <Users className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="font-semibold text-lg mb-2">Usuários</h3>
                  <p className="text-blue-100">
                    Visualização em tempo real do status do terminal, 
                    fila de navios e progresso das operações.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      {/* Developer Credit */}
      <div className="fixed bottom-4 right-4 text-xs text-gray-400">
        Developed by: Manuel Antonio, Eng.
      </div>
    </div>
  );
}