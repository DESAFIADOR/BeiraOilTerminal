import AuthPage from "./auth-page";

export default function NotFound() {
  // Instead of showing 404, redirect to login page
  return <AuthPage />;
}
