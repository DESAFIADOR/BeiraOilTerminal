import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Ship, Plus, Anchor, Cloud, Waves, Clock, User, LogOut,
  ArrowUp, Info, Settings, Calendar, MapPin, Package
} from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import { ShipRegistrationModal } from "@/components/ship-registration-modal";
import { ShipInfoModal } from "@/components/ship-info-modal";
import { apiRequest } from "@/lib/queryClient";
import logoPath from "@assets/LogTipo_1749832282954.png";
import terminalImagePath from "@assets/cais-terminal.png";

interface Ship {
  id: number;
  name: string;
  countermark: string;
  draft: number;
  cargoType: string;
  shipAgent: string;
  cargoAgent: string;
  shipowner: string;
  cargoDestination: string;
  operationType: 'Nacional' | 'Trânsito' | 'Combinado' | 'LPG';
  status: 'expected' | 'at_bar' | 'next_to_berth' | 'at_berth' | 'departed';
  hasDischargeInstructions: boolean;
  berthConfirmed: boolean;
  arrivalAtBar: string;
  shipAgentEmail?: string;
  cargoAgentEmail?: string;
  parcels?: Array<{
    id: number;
    parcelNumber: string;
    product: string;
    volumeMT: number;
    volumeM3: number;
    density: number;
    receiver: string;
    owner: string;
  }>;
}

export default function Dashboard() {
  const { user, isAuthenticated, isLoading } = useAuth();
  const [currentTime, setCurrentTime] = useState(new Date());
  const [showShipRegistration, setShowShipRegistration] = useState(false);
  const [selectedShip, setSelectedShip] = useState<Ship | null>(null);
  const queryClient = useQueryClient();

  const isOperator = user?.role === 'operator' || user?.role === 'admin';

  // Update time every second
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  // Fetch ships data
  const { data: ships = [] } = useQuery<Ship[]>({
    queryKey: ['/api/ships'],
    refetchInterval: 5000,
  });

  // Fetch weather data
  const { data: weatherData } = useQuery({
    queryKey: ['/api/weather'],
    refetchInterval: 60000,
  });

  // Fetch tide data
  const { data: tideData } = useQuery({
    queryKey: ['/api/tide'],
    refetchInterval: 30000,
  });

  // Fetch berth maintenance status
  const { data: maintenanceData } = useQuery({
    queryKey: ['/api/berth-maintenance/active'],
    refetchInterval: 15000,
  });

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString('pt-PT', {
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      timeZone: 'Africa/Maputo'
    });
  };

  const formatDate = (date: Date) => {
    return date.toLocaleDateString('pt-PT', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      timeZone: 'Africa/Maputo'
    });
  };

  const handleLogout = async () => {
    try {
      await fetch('/api/logout', {
        method: 'POST',
        credentials: 'include'
      });
      
      // Clear all possible authentication data
      localStorage.clear();
      sessionStorage.clear();
      
      // Clear cookies
      document.cookie.split(";").forEach(function(c) { 
        document.cookie = c.replace(/^ +/, "").replace(/=.*/, "=;expires=" + new Date().toUTCString() + ";path=/"); 
      });
      
      // Force reload to clear all state
      window.location.href = '/login';
    } catch (error) {
      console.error('Logout error:', error);
      window.location.href = '/login';
    }
  };

  // Filter ships by status and priority
  const prioritizeShips = (ships: Ship[]) => {
    return ships.sort((a, b) => {
      // IMOPETRO priority (absolute)
      const aIsImopetro = a.cargoAgent?.toLowerCase().includes('imopetro');
      const bIsImopetro = b.cargoAgent?.toLowerCase().includes('imopetro');
      if (aIsImopetro && !bIsImopetro) return -1;
      if (!aIsImopetro && bIsImopetro) return 1;

      // Nacional priority (after IMOPETRO)
      if (a.operationType === 'Nacional' && b.operationType !== 'Nacional') return -1;
      if (a.operationType !== 'Nacional' && b.operationType === 'Nacional') return 1;

      // LPG priority (after Nacional)
      if (a.operationType === 'LPG' && b.operationType !== 'LPG') return -1;
      if (a.operationType !== 'LPG' && b.operationType === 'LPG') return 1;

      // 2:1 rule for Trânsito:Combinado
      const arrivalTimeA = new Date(a.arrivalAtBar).getTime();
      const arrivalTimeB = new Date(b.arrivalAtBar).getTime();
      return arrivalTimeA - arrivalTimeB;
    });
  };

  const expectedArrivals = ships.filter(ship => ship.status === 'expected');
  const shipsAtBar = ships.filter(ship => ship.status === 'at_bar');
  const shipsWithoutInstructions = prioritizeShips(shipsAtBar.filter(ship => !ship.hasDischargeInstructions));
  const shipsWithInstructions = prioritizeShips(shipsAtBar.filter(ship => ship.hasDischargeInstructions));
  const nextShips = prioritizeShips(ships.filter(ship => ship.status === 'next_to_berth'));
  const currentShipAtBerth = ships.find(ship => ship.status === 'at_berth');
  const departedShips = ships.filter(ship => ship.status === 'departed').slice(0, 10);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-600"></div>
          <p className="mt-4 text-gray-600">Carregando sistema...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 p-4">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <header className="bg-white shadow-lg rounded-lg border border-gray-200">
          <div className="px-6 py-4">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 items-center">
              {/* CFM Logo */}
              <div className="flex flex-col items-center">
                <div className="w-24 h-24 rounded-full bg-gradient-to-br from-blue-500 to-blue-700 border-4 border-white shadow-xl flex items-center justify-center overflow-hidden">
                  <img
                    src={logoPath}
                    alt="CFM Logo"
                    className="w-20 h-20 object-contain filter brightness-110 contrast-110"
                    style={{
                      imageRendering: 'crisp-edges',
                      transform: 'translateZ(0)',
                      backfaceVisibility: 'hidden'
                    }}
                  />
                </div>
                <span className="text-xs text-gray-600 mt-1 font-medium">CFM</span>
              </div>

              {/* Clock */}
              <div className="flex flex-col items-center">
                <div className="w-24 h-24 rounded-full bg-gradient-to-br from-green-500 to-green-700 border-4 border-white shadow-xl flex flex-col items-center justify-center">
                  <Clock className="w-6 h-6 text-white mb-1" />
                  <div className="text-white text-xs font-bold text-center leading-tight">
                    <div>{formatTime(currentTime)}</div>
                    <div className="text-xs opacity-90">{formatDate(currentTime)}</div>
                  </div>
                </div>
                <span className="text-xs text-gray-600 mt-1 font-medium">Hora Local</span>
              </div>

              {/* Terminal Image */}
              <div className="flex flex-col items-center">
                <div className="w-24 h-24 rounded-full bg-gradient-to-br from-purple-500 to-purple-700 border-4 border-white shadow-xl flex items-center justify-center overflow-hidden">
                  <img
                    src={terminalImagePath}
                    alt="Terminal da Beira"
                    className="w-20 h-20 object-cover filter saturate-150"
                  />
                </div>
                <span className="text-xs text-gray-600 mt-1 font-medium">Terminal da Beira</span>
              </div>

              {/* User Info */}
              <div className="flex flex-col items-center">
                <div className="w-24 h-24 rounded-full bg-gradient-to-br from-orange-500 to-orange-700 border-4 border-white shadow-xl flex flex-col items-center justify-center">
                  {isAuthenticated ? (
                    <>
                      <User className="w-6 h-6 text-white mb-1" />
                      <button
                        onClick={handleLogout}
                        className="flex items-center gap-1 text-white text-xs hover:bg-white hover:bg-opacity-20 px-2 py-1 rounded transition-colors"
                      >
                        <LogOut className="w-3 h-3" />
                        Sair
                      </button>
                    </>
                  ) : (
                    <a href="/api/login" className="text-white text-xs hover:bg-white hover:bg-opacity-20 px-2 py-1 rounded">
                      Entrar
                    </a>
                  )}
                </div>
                <span className="text-xs text-gray-600 mt-1 font-medium">
                  {isAuthenticated ? user?.username : 'Visitante'}
                </span>
              </div>
            </div>

            {/* Title and System Info */}
            <div className="text-center mt-4">
              <h1 className="text-2xl md:text-3xl font-bold text-gray-800 mb-2">
                Line Up - Beira Oil Terminal
              </h1>
              <div className="flex flex-col sm:flex-row items-center justify-center space-y-1 sm:space-y-0 sm:space-x-4 text-sm text-gray-600">
                <div className="flex items-center gap-1">
                  <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                  <span>Sistema Operacional</span>
                </div>
                <div>Developed by: Manuel Antonio, Eng.</div>
              </div>
            </div>
          </div>
        </header>

        {/* Berth Maintenance Alert */}
        {maintenanceData?.isActive && (
          <Card className="shadow-sm bg-red-50 border-red-200">
            <CardContent className="pt-6">
              <div className="text-center">
                <h2 className="text-xl font-bold text-red-700 mb-2">
                  🚧 CAIS EM MANUTENÇÃO 🚧
                </h2>
                <div className="text-sm text-red-600 mb-2">
                  Período: {maintenanceData.startDate} - {maintenanceData.endDate}
                </div>
                {maintenanceData.description && (
                  <div 
                    className="text-red-700 font-bold uppercase text-center leading-tight"
                    style={{ 
                      fontFamily: 'Algerian, serif', 
                      fontSize: '10px'
                    }}
                  >
                    {maintenanceData.description}
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Ship at Berth - NAVIO NO CAIS 12 */}
        {currentShipAtBerth && (
          <Card className="shadow-sm bg-green-50 border-green-200">
            <CardHeader className="pb-3">
              <CardTitle className="text-lg font-semibold flex items-center gap-2 text-green-700">
                <Anchor className="w-5 h-5" />
                NAVIO NO CAIS 12
              </CardTitle>
            </CardHeader>
            <CardContent className="pt-0">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {/* Ship Name and Basic Info */}
                <div className="bg-white p-4 rounded-lg border">
                  <h3 className="font-bold text-lg text-blue-700 mb-3">{currentShipAtBerth.name}</h3>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-gray-600">Contramarcha:</span>
                      <span className="font-medium">{currentShipAtBerth.countermark}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Calado:</span>
                      <span className="font-medium">{currentShipAtBerth.draft}m</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Tipo de Operação:</span>
                      <Badge variant="outline" className="text-xs">
                        {currentShipAtBerth.operationType === 'Nacional' && '🇲🇿 Nacional'}
                        {currentShipAtBerth.operationType === 'LPG' && '⛽ LPG'}
                        {currentShipAtBerth.operationType === 'Trânsito' && '🚢 Trânsito'}
                        {currentShipAtBerth.operationType === 'Combinado' && '🔄 Combinado'}
                      </Badge>
                    </div>
                  </div>
                  <div className="mt-4 flex space-x-2">
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => setSelectedShip(currentShipAtBerth)}
                      className="flex-1"
                    >
                      <Info className="w-4 h-4 mr-1" />
                      Info
                    </Button>
                    {isOperator && (
                      <Button
                        size="sm"
                        className="flex-1 bg-blue-600 hover:bg-blue-700"
                      >
                        Atualizar Descarga
                      </Button>
                    )}
                  </div>
                </div>

                {/* Cargo Information */}
                <div className="bg-white p-4 rounded-lg border">
                  <h4 className="font-semibold text-gray-700 mb-3">Informações da Carga</h4>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-gray-600">Armador:</span>
                      <span className="font-medium">{currentShipAtBerth.shipowner}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Destino:</span>
                      <span className="font-medium">{currentShipAtBerth.cargoDestination}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Agente do Navio:</span>
                      <span className="font-medium">{currentShipAtBerth.shipAgent}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Agente da Carga:</span>
                      <span className="font-medium">{currentShipAtBerth.cargoAgent}</span>
                    </div>
                  </div>
                </div>

                {/* Cargo Parcels */}
                <div className="bg-white p-4 rounded-lg border">
                  <h4 className="font-semibold text-gray-700 mb-3">Parcelas ({currentShipAtBerth.parcels?.length || 0})</h4>
                  <div className="space-y-2 max-h-40 overflow-y-auto">
                    {currentShipAtBerth.parcels?.map((parcel) => (
                      <div key={parcel.id} className="p-2 bg-gray-50 rounded text-xs">
                        <div className="font-medium text-blue-600 mb-1">{parcel.parcelNumber}</div>
                        <div className="grid grid-cols-2 gap-1">
                          <div>{parcel.product}</div>
                          <div className="font-medium">{parcel.volumeMT} MT</div>
                          <div className="text-gray-500">{parcel.receiver}</div>
                          <div className="text-gray-500">{parcel.owner}</div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Ship Queue Tabs */}
        <Tabs defaultValue="next" className="w-full">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="next" className="text-xs">PRÓXIMOS 5 NAVIOS A ATRACAR</TabsTrigger>
            <TabsTrigger value="with-instructions" className="text-xs">NAVIOS COM INSTRUÇÃO</TabsTrigger>
            <TabsTrigger value="without-instructions" className="text-xs">NAVIOS SEM INSTRUÇÃO</TabsTrigger>
            <TabsTrigger value="expected" className="text-xs">PREVISTOS A CHEGAR</TabsTrigger>
            <TabsTrigger value="departed" className="text-xs">NAVIOS PARTIDOS</TabsTrigger>
          </TabsList>

          {/* Next Ships Tab */}
          <TabsContent value="next" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {nextShips.slice(0, 5).map((ship, index) => (
                <Card key={ship.id} className="bg-white shadow-sm">
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between mb-2">
                      <h3 className="font-semibold text-gray-800">{ship.name}</h3>
                      <Badge variant="secondary" className="text-xs">#{index + 1}</Badge>
                    </div>
                    <div className="space-y-1 text-sm text-gray-600 mb-3">
                      <div>{ship.countermark}</div>
                      <div>Calado: {ship.draft}m</div>
                      <div className="flex items-center gap-1">
                        <Badge variant="outline" className="text-xs">
                          {ship.operationType === 'Nacional' && '🇲🇿 Nacional'}
                          {ship.operationType === 'LPG' && '⛽ LPG'}
                          {ship.operationType === 'Trânsito' && '🚢 Trânsito'}
                          {ship.operationType === 'Combinado' && '🔄 Combinado'}
                        </Badge>
                        {ship.cargoAgent?.toLowerCase().includes('imopetro') && (
                          <Badge variant="destructive" className="text-xs">
                            🚨 PRIORIDADE - Decreto 89/2019
                          </Badge>
                        )}
                      </div>
                    </div>
                    <div className="grid grid-cols-2 gap-2">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => setSelectedShip(ship)}
                        className="w-full"
                      >
                        <Info className="w-4 h-4 mr-1" />
                        Info
                      </Button>
                      {isOperator && (
                        <Button size="sm" variant="outline" className="w-full">
                          <ArrowUp className="w-4 h-4 mr-1" />
                          Mover
                        </Button>
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Ships with Instructions Tab */}
          <TabsContent value="with-instructions" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {shipsWithInstructions.map((ship) => (
                <Card key={ship.id} className="bg-green-50 border-green-200 shadow-sm">
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between mb-2">
                      <h3 className="font-semibold text-gray-800">{ship.name}</h3>
                      <Badge className="bg-green-100 text-green-800 text-xs">Com Instrução</Badge>
                    </div>
                    <div className="space-y-1 text-sm text-gray-600 mb-3">
                      <div>{ship.countermark}</div>
                      <div>Calado: {ship.draft}m</div>
                      <div className="flex items-center gap-1">
                        <Badge variant="outline" className="text-xs">
                          {ship.operationType === 'Nacional' && '🇲🇿 Nacional'}
                          {ship.operationType === 'LPG' && '⛽ LPG'}
                          {ship.operationType === 'Trânsito' && '🚢 Trânsito'}
                          {ship.operationType === 'Combinado' && '🔄 Combinado'}
                        </Badge>
                        {ship.cargoAgent?.toLowerCase().includes('imopetro') && (
                          <Badge variant="destructive" className="text-xs">
                            🚨 PRIORIDADE
                          </Badge>
                        )}
                      </div>
                    </div>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => setSelectedShip(ship)}
                      className="w-full"
                    >
                      <Info className="w-4 h-4 mr-1" />
                      Ver Detalhes
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Ships without Instructions Tab */}
          <TabsContent value="without-instructions" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {shipsWithoutInstructions.map((ship) => (
                <Card key={ship.id} className="bg-orange-50 border-orange-200 shadow-sm">
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between mb-2">
                      <h3 className="font-semibold text-gray-800">{ship.name}</h3>
                      <Badge variant="secondary" className="bg-orange-100 text-orange-800 text-xs">Sem Instrução</Badge>
                    </div>
                    <div className="space-y-1 text-sm text-gray-600 mb-3">
                      <div>{ship.countermark}</div>
                      <div>Calado: {ship.draft}m</div>
                      <div className="flex items-center gap-1">
                        <Badge variant="outline" className="text-xs">
                          {ship.operationType === 'Nacional' && '🇲🇿 Nacional'}
                          {ship.operationType === 'LPG' && '⛽ LPG'}
                          {ship.operationType === 'Trânsito' && '🚢 Trânsito'}
                          {ship.operationType === 'Combinado' && '🔄 Combinado'}
                        </Badge>
                        {ship.cargoAgent?.toLowerCase().includes('imopetro') && (
                          <Badge variant="destructive" className="text-xs">
                            🚨 PRIORIDADE
                          </Badge>
                        )}
                      </div>
                    </div>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => setSelectedShip(ship)}
                      className="w-full"
                    >
                      <Info className="w-4 h-4 mr-1" />
                      Ver Detalhes
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Expected Arrivals Tab */}
          <TabsContent value="expected" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {expectedArrivals.map((ship) => (
                <Card key={ship.id} className="bg-purple-50 border-purple-200 shadow-sm">
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between mb-2">
                      <h3 className="font-semibold text-gray-800">{ship.name}</h3>
                      <Badge className="bg-purple-100 text-purple-800 text-xs">Previsto</Badge>
                    </div>
                    <div className="space-y-1 text-sm text-gray-600 mb-3">
                      <div>{ship.countermark}</div>
                      <div>Calado: {ship.draft}m</div>
                      <div className="flex items-center gap-1">
                        <Badge variant="outline" className="text-xs">
                          {ship.operationType === 'Nacional' && '🇲🇿 Nacional'}
                          {ship.operationType === 'LPG' && '⛽ LPG'}
                          {ship.operationType === 'Trânsito' && '🚢 Trânsito'}
                          {ship.operationType === 'Combinado' && '🔄 Combinado'}
                        </Badge>
                      </div>
                    </div>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => setSelectedShip(ship)}
                      className="w-full"
                    >
                      <Info className="w-4 h-4 mr-1" />
                      Ver Detalhes
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Departed Ships Tab */}
          <TabsContent value="departed" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {departedShips.map((ship) => (
                <Card key={ship.id} className="bg-gray-50 border-gray-200 shadow-sm">
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between mb-2">
                      <h3 className="font-semibold text-gray-500">{ship.name}</h3>
                      <Badge variant="secondary" className="text-xs">Partiu</Badge>
                    </div>
                    <div className="space-y-1 text-sm text-gray-500 mb-3">
                      <div>{ship.countermark}</div>
                      <div>Calado: {ship.draft}m</div>
                    </div>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => setSelectedShip(ship)}
                      className="w-full"
                    >
                      <Info className="w-4 h-4 mr-1" />
                      Histórico
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>
        </Tabs>

        {/* Weather and Tide Information */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Card className="shadow-sm">
            <CardHeader className="pb-3">
              <CardTitle className="text-lg font-semibold flex items-center gap-2">
                <Cloud className="w-5 h-5" />
                Condições Meteorológicas
              </CardTitle>
            </CardHeader>
            <CardContent className="pt-0">
              {weatherData ? (
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <div className="text-gray-600">Temperatura</div>
                    <div className="font-semibold">{(weatherData as any).temperature || 'N/A'}°C</div>
                  </div>
                  <div>
                    <div className="text-gray-600">Humidade</div>
                    <div className="font-semibold">{(weatherData as any).humidity || 'N/A'}%</div>
                  </div>
                  <div>
                    <div className="text-gray-600">Pressão</div>
                    <div className="font-semibold">{(weatherData as any).pressure || 'N/A'} hPa</div>
                  </div>
                  <div>
                    <div className="text-gray-600">Vento</div>
                    <div className="font-semibold">{(weatherData as any).windSpeed || 'N/A'} km/h</div>
                  </div>
                </div>
              ) : (
                <div className="text-gray-500">Carregando dados meteorológicos...</div>
              )}
            </CardContent>
          </Card>

          <Card className="shadow-sm">
            <CardHeader className="pb-3">
              <CardTitle className="text-lg font-semibold flex items-center gap-2">
                <Waves className="w-5 h-5" />
                Informações de Maré
              </CardTitle>
            </CardHeader>
            <CardContent className="pt-0">
              {tideData ? (
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Altura Atual:</span>
                    <span className="font-semibold">{(tideData as any).currentTide?.toFixed(2) || 'N/A'}m</span>
                  </div>
                  {(tideData as any).nextHigh && (
                    <div className="flex justify-between">
                      <span className="text-gray-600">Próxima Preamar:</span>
                      <span className="font-semibold">{(tideData as any).nextHigh.height?.toFixed(2)}m às {formatTime(new Date((tideData as any).nextHigh.time))}</span>
                    </div>
                  )}
                  {(tideData as any).nextLow && (
                    <div className="flex justify-between">
                      <span className="text-gray-600">Próxima Baixamar:</span>
                      <span className="font-semibold">{(tideData as any).nextLow.height?.toFixed(2)}m às {formatTime(new Date((tideData as any).nextLow.time))}</span>
                    </div>
                  )}
                  <div className="mt-3 pt-3 border-t">
                    <div className="text-xs text-gray-500 mb-1">Estado da Maré:</div>
                    <div className="text-sm font-medium text-blue-600">
                      {(tideData as any).currentTide > 2.5 ? '📈 Enchente' : '📉 Vazante'}
                    </div>
                  </div>
                </div>
              ) : (
                <div className="text-gray-500">Carregando dados de maré...</div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Operator Actions */}
        {isOperator && (
          <Card className="shadow-sm">
            <CardHeader className="pb-3">
              <CardTitle className="text-lg font-semibold">Ações Rápidas</CardTitle>
            </CardHeader>
            <CardContent className="pt-0">
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                <Button 
                  onClick={() => setShowShipRegistration(true)}
                  className="w-full bg-blue-600 hover:bg-blue-700"
                >
                  <Plus className="w-4 h-4 mr-2" />
                  Registrar Navio
                </Button>
                <Button 
                  variant="outline"
                  className="w-full border-green-500 text-green-700 hover:bg-green-50"
                  disabled={!nextShips.length}
                >
                  <Anchor className="w-4 h-4 mr-2" />
                  Atracação do Navio
                </Button>
                <Button 
                  variant="outline"
                  className="w-full border-red-500 text-red-700 hover:bg-red-50"
                  disabled={!currentShipAtBerth}
                >
                  <Ship className="w-4 h-4 mr-2" />
                  Desatracação do Navio
                </Button>
                <Button 
                  variant="outline"
                  className="w-full border-orange-500 text-orange-700 hover:bg-orange-50"
                  disabled={!shipsWithoutInstructions.length}
                >
                  <ArrowUp className="w-4 h-4 mr-2" />
                  Mover para Instrução
                </Button>
              </div>
            </CardContent>
          </Card>
        )}
      </div>

      {/* Modals */}
      {showShipRegistration && (
        <ShipRegistrationModal
          isOpen={showShipRegistration}
          onClose={() => setShowShipRegistration(false)}
        />
      )}

      {selectedShip && (
        <ShipInfoModal
          isOpen={!!selectedShip}
          onClose={() => setSelectedShip(null)}
          ship={selectedShip}
        />
      )}
    </div>
  );
}