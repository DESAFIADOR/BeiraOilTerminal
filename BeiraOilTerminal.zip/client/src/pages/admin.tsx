import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { CheckCircle, XCircle, Clock, Users, Shield } from "lucide-react";
import { USER_LEVELS, type UserRole, getUserPermissions } from "@shared/userLevels";

export function Admin() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [showPasswordModal, setShowPasswordModal] = useState(false);
  const [selectedUserId, setSelectedUserId] = useState<number | null>(null);
  const [password, setPassword] = useState("");
  const [selectedRole, setSelectedRole] = useState<UserRole>("publico");
  const [selectedPermissions, setSelectedPermissions] = useState<string[]>([]);

  // Get users data
  const { data: users = [], isLoading } = useQuery({
    queryKey: ["/api/users"],
  });

  const approveMutation = useMutation({
    mutationFn: async ({ userId, password, role, permissions }: { 
      userId: number; 
      password: string; 
      role: UserRole;
      permissions: string[];
    }) => {
      return await apiRequest(`/api/admin/users/${userId}/approve`, {
        method: "POST",
        body: JSON.stringify({ adminPassword: password, role, permissions }),
      });
    },
    onSuccess: () => {
      toast({
        title: "Usuário aprovado",
        description: "O usuário foi aprovado com sucesso e recebeu as permissões do nível selecionado.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/users"] });
      setSelectedPermissions([]);
      setSelectedRole("line_up");
      setShowPasswordModal(false);
      setPassword("");
    },
    onError: (error: any) => {
      toast({
        title: "Erro na aprovação",
        description: error.message || "Erro ao aprovar usuário.",
        variant: "destructive",
      });
    },
  });

  const rejectMutation = useMutation({
    mutationFn: async ({ userId, password }: { userId: number; password: string }) => {
      return await apiRequest(`/api/admin/users/${userId}/reject`, {
        method: "POST",
        body: JSON.stringify({ adminPassword: password }),
      });
    },
    onSuccess: () => {
      toast({
        title: "Usuário rejeitado",
        description: "A solicitação foi rejeitada.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/users"] });
    },
    onError: (error: any) => {
      toast({
        title: "Erro na rejeição",
        description: error.message || "Erro ao rejeitar usuário.",
        variant: "destructive",
      });
    },
  });

  const handleApproveUser = (userId: number) => {
    setSelectedUserId(userId);
    setShowPasswordModal(true);
  };

  const handleConfirmApproval = () => {
    if (!selectedUserId || !password || !selectedRole) return;

    const rolePermissions = getUserPermissions(selectedRole);
    
    approveMutation.mutate({
      userId: selectedUserId,
      password,
      role: selectedRole,
      permissions: rolePermissions,
    });
  };

  const handleRoleChange = (role: UserRole) => {
    setSelectedRole(role);
    setSelectedPermissions(getUserPermissions(role));
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "active":
        return <Badge className="bg-green-500"><CheckCircle className="h-3 w-3 mr-1" />Ativo</Badge>;
      case "pending":
        return <Badge className="bg-yellow-500"><Clock className="h-3 w-3 mr-1" />Pendente</Badge>;
      case "rejected":
        return <Badge variant="destructive"><XCircle className="h-3 w-3 mr-1" />Rejeitado</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  const getRoleBadge = (role: string) => {
    const roleInfo = USER_LEVELS[role as UserRole];
    if (!roleInfo) return <Badge variant="outline">{role}</Badge>;

    const colorMap = {
      publico: "bg-gray-500",
      line_up: "bg-blue-500",
      gestores: "bg-purple-500", 
      ctos: "bg-orange-500",
      desenvolvedor: "bg-red-500"
    };

    return (
      <Badge className={`${colorMap[role as UserRole]} text-white`}>
        <Shield className="h-3 w-3 mr-1" />
        {roleInfo.name}
      </Badge>
    );
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  const pendingUsers = users.filter((user: any) => user.status === "pending");
  const activeUsers = users.filter((user: any) => user.status === "active");

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="flex items-center gap-3 mb-6">
        <Users className="h-8 w-8 text-blue-600" />
        <div>
          <h1 className="text-2xl font-bold">Administração de Usuários</h1>
          <p className="text-gray-600">Gerencie aprovações e permissões dos usuários</p>
        </div>
      </div>

      {/* Níveis de Usuário */}
      <Card>
        <CardHeader>
          <CardTitle>Níveis de Usuário Disponíveis</CardTitle>
          <CardDescription>Estrutura hierárquica do sistema</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {Object.values(USER_LEVELS).map((level) => (
              <div key={level.id} className="border rounded-lg p-4">
                <div className="flex items-center gap-2 mb-2">
                  {getRoleBadge(level.id)}
                  <span className="text-sm text-gray-500">Nível {level.hierarchyLevel}</span>
                </div>
                <h3 className="font-semibold">{level.name}</h3>
                <p className="text-sm text-gray-600 mb-2">{level.description}</p>
                <div className="text-xs text-gray-500">
                  {level.permissions.length} permissões
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Usuários Pendentes */}
      {pendingUsers.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Clock className="h-5 w-5 text-yellow-500" />
              Usuários Aguardando Aprovação ({pendingUsers.length})
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {pendingUsers.map((user: any) => (
                <div key={user.id} className="border rounded-lg p-4">
                  <div className="flex items-center justify-between">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <h3 className="font-semibold">{user.firstName} {user.lastName}</h3>
                        {getStatusBadge(user.status)}
                      </div>
                      <p className="text-sm text-gray-600">@{user.username}</p>
                      {user.email && <p className="text-sm text-gray-500">{user.email}</p>}
                      <p className="text-sm">
                        <span className="font-medium">Nível solicitado:</span> {getRoleBadge(user.requestedRole)}
                      </p>
                    </div>
                    <div className="flex gap-2">
                      <Button
                        onClick={() => handleApproveUser(user.id)}
                        className="bg-green-600 hover:bg-green-700"
                        size="sm"
                      >
                        <CheckCircle className="h-4 w-4 mr-1" />
                        Aprovar
                      </Button>
                      <Button
                        onClick={() => rejectMutation.mutate({ userId: user.id, password: "admin123" })}
                        variant="destructive"
                        size="sm"
                      >
                        <XCircle className="h-4 w-4 mr-1" />
                        Rejeitar
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Usuários Ativos */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <CheckCircle className="h-5 w-5 text-green-500" />
            Usuários Ativos ({activeUsers.length})
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {activeUsers.map((user: any) => (
              <div key={user.id} className="border rounded-lg p-4">
                <div className="flex items-center justify-between">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <h3 className="font-semibold">{user.firstName} {user.lastName}</h3>
                      {getStatusBadge(user.status)}
                      {getRoleBadge(user.role)}
                    </div>
                    <p className="text-sm text-gray-600">@{user.username}</p>
                    {user.email && <p className="text-sm text-gray-500">{user.email}</p>}
                    <p className="text-sm text-gray-500">
                      Cadastrado em: {new Date(user.createdAt).toLocaleDateString('pt-BR')}
                    </p>
                    {user.permissions && user.permissions.length > 0 && (
                      <p className="text-sm text-gray-500">
                        {user.permissions.length} permissões ativas
                      </p>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Modal de Confirmação */}
      <Dialog open={showPasswordModal} onOpenChange={setShowPasswordModal}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle>Aprovar Usuário</DialogTitle>
            <DialogDescription>
              Defina o nível de acesso e confirme com a senha de administrador.
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="space-y-2">
              <Label>Nível de Usuário</Label>
              <Select value={selectedRole} onValueChange={handleRoleChange}>
                <SelectTrigger>
                  <SelectValue placeholder="Selecione o nível" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="publico">Público</SelectItem>
                  <SelectItem value="line_up">Line Up</SelectItem>
                  <SelectItem value="gestores">Gestores</SelectItem>
                  <SelectItem value="ctos">CTOs</SelectItem>
                  <SelectItem value="desenvolvedor">Desenvolvedor</SelectItem>
                </SelectContent>
              </Select>
              <p className="text-sm text-gray-600">
                {USER_LEVELS[selectedRole]?.description}
              </p>
            </div>

            <div className="space-y-2">
              <Label>Permissões do Nível {USER_LEVELS[selectedRole]?.name}</Label>
              <div className="max-h-40 overflow-y-auto border rounded p-3 space-y-1">
                {selectedPermissions.map((permission) => (
                  <div key={permission} className="text-sm text-gray-600">
                    • {permission}
                  </div>
                ))}
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="password">Senha de Administrador</Label>
              <Input
                id="password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Digite a senha de administrador"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => {
              setShowPasswordModal(false);
              setPassword("");
              setSelectedRole("publico");
              setSelectedPermissions([]);
            }}>
              Cancelar
            </Button>
            <Button 
              onClick={handleConfirmApproval}
              disabled={approveMutation.isPending || !password}
            >
              {approveMutation.isPending ? "Aprovando..." : "Aprovar"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}