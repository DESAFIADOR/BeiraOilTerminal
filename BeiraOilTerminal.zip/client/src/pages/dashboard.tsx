import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Ship, Plus, Anchor, Cloud, Waves, Clock, User, LogOut,
  ArrowUp, Info, Settings, Calendar, MapPin, Package, FileText, AlertTriangle, RefreshCw, Edit, Trash2, MessageSquare, Check, X, TrendingUp, BarChart3
} from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import { usePermissions } from "@/hooks/usePermissions";
import { useTranslation } from "@/contexts/LanguageContext";
import { LanguageSelector } from "@/components/LanguageSelector";
import { ShipCard } from "@/components/ShipCard";
import { AssistantChatButton } from "@/components/assistant-chat-button";
import { TestAssistantButton } from "@/components/test-assistant-button";
import { FloatingAssistant } from "@/components/floating-assistant";
import { ShipLocationSelector } from "@/components/ShipLocationSelector";
import { ShipRegistrationModal } from "@/components/ShipRegistrationModal";
import { ShipInfoModal } from "@/components/ShipInfoModal";
import { SwapModal } from "@/components/SwapModal";
import { SimpleFloatingButton } from "@/components/simple-floating-button";
import { PortalButton } from "@/components/portal-button";
import { DirectDOMButton } from "@/components/direct-dom-button";
import { SimpleAssistantButton } from "@/components/simple-assistant-button";
import { VirtualAssistant } from "@/components/virtual-assistant";
import { GeminiAIAssistant } from "@/components/gemini-ai-assistant";
import { SoundControl } from "@/components/SoundControl";
import { CommunicationPanel } from "@/components/maritime/CommunicationPanel";
import { ShipsReportModal } from "@/components/ships-report-modal";
import { DischargeControlModal } from "@/components/discharge-control/DischargeControlModal";
import { ShipMovementModal } from "@/components/ship-movement-modal";
import { TideChart } from "@/components/tide-monitoring/TideChart";
import { apiRequest } from "@/lib/queryClient";
import logoPath from "@assets/LogTipo_1749832282954.png";
import terminalImagePath from "@assets/cais-terminal.png";

interface Ship {
  id: number;
  name: string;
  countermark: string;
  draft: number;
  cargoType: string;
  shipAgent: string;
  cargoAgent: string;
  shipowner: string;
  cargoDestination: string;
  operationType: 'Nacional' | 'Trânsito' | 'Combinado' | 'LPG';
  status: 'expected' | 'at_bar' | 'next_to_berth' | 'at_berth' | 'departed';
  hasDischargeInstructions: boolean;
  berthConfirmed: boolean;
  arrivalAtBar: string;
  shipAgentEmail?: string;
  cargoAgentEmail?: string;
  parcels?: Array<{
    id: number;
    parcelNumber: string;
    product: string;
    volumeMT: number;
    volumeM3: number;
    density: number;
    receiver: string;
    owner: string;
  }>;
}

export function Dashboard() {
  const { user, isAuthenticated, isLoading, isOperator } = useAuth();
  const { t, language } = useTranslation();
  
  console.log('Dashboard user data:', user); // Debug log
  const [currentTime, setCurrentTime] = useState(new Date());
  const [showLocationSelector, setShowLocationSelector] = useState(false);
  const [showShipRegistration, setShowShipRegistration] = useState(false);
  const [selectedLocation, setSelectedLocation] = useState<'at_bar' | 'expected' | null>(null);
  const [selectedShip, setSelectedShip] = useState<Ship | null>(null);
  const [showWeatherDetails, setShowWeatherDetails] = useState(false);
  const [showTideDetails, setShowTideDetails] = useState(false);
  const [showSwapModal, setShowSwapModal] = useState(false);
  const [selectedSwap, setSelectedSwap] = useState<any | null>(null);
  const [showCargoModal, setShowCargoModal] = useState<{ type: string; ships: any[] } | null>(null);
  const [showAllShipsModal, setShowAllShipsModal] = useState(false);
  const [isGeminiAIOpen, setIsGeminiAIOpen] = useState(false);
  const [showCommunicationPanel, setShowCommunicationPanel] = useState(false);
  const [isEditingShipInfo, setIsEditingShipInfo] = useState(false);
  const [editedShipData, setEditedShipData] = useState<Partial<Ship>>({});
  const [isEditingParcels, setIsEditingParcels] = useState(false);
  const [editedParcels, setEditedParcels] = useState<any[]>([]);
  const [showShipsReportModal, setShowShipsReportModal] = useState(false);
  const [showDischargeControl, setShowDischargeControl] = useState(false);
  const [showShipMovementModal, setShowShipMovementModal] = useState(false);
  const [selectedShipForMovement, setSelectedShipForMovement] = useState<number | null>(null);
  const queryClient = useQueryClient();

  const userIsOperator = user?.role === 'operator' || user?.role === 'admin';

  // Mutation for updating ship information
  const updateShipMutation = useMutation({
    mutationFn: async (data: { id: number; updates: Partial<Ship> }) => {
      return apiRequest(`/api/ships/${data.id}`, {
        method: 'PATCH',
        body: JSON.stringify(data.updates),
        headers: {
          'Content-Type': 'application/json',
        },
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/ships'] });
      setIsEditingShipInfo(false);
      setEditedShipData({});
    },
    onError: (error) => {
      console.error('Error updating ship:', error);
    },
  });

  // Mutation for updating parcels
  const updateParcelMutation = useMutation({
    mutationFn: async (data: { shipId: number; parcelId: number; updates: any }) => {
      return apiRequest(`/api/ships/${data.shipId}/parcels/${data.parcelId}`, {
        method: 'PUT',
        body: JSON.stringify(data.updates),
        headers: {
          'Content-Type': 'application/json',
        },
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/ships'] });
      setIsEditingParcels(false);
      setEditedParcels([]);
    },
    onError: (error) => {
      console.error('Error updating parcel:', error);
    },
  });

  // Handle ship info editing
  const handleStartEditing = () => {
    if (currentShipAtBerth) {
      setEditedShipData({
        name: currentShipAtBerth.name,
        countermark: currentShipAtBerth.countermark,
        draft: currentShipAtBerth.draft,
        shipowner: currentShipAtBerth.shipowner,
        cargoDestination: currentShipAtBerth.cargoDestination,
        shipAgent: currentShipAtBerth.shipAgent,
        cargoAgent: currentShipAtBerth.cargoAgent,
        operationType: currentShipAtBerth.operationType,
      });
      setIsEditingShipInfo(true);
    }
  };

  const handleSaveChanges = () => {
    if (currentShipAtBerth && editedShipData) {
      updateShipMutation.mutate({
        id: currentShipAtBerth.id,
        updates: editedShipData,
      });
    }
  };

  const handleCancelEditing = () => {
    setIsEditingShipInfo(false);
    setEditedShipData({});
  };

  // Parcel editing functions
  const handleStartParcelEditing = () => {
    if (currentShipAtBerth && currentShipAtBerth.parcels) {
      // Initialize with default values to prevent controlled/uncontrolled warnings
      const initializedParcels = currentShipAtBerth.parcels.map((parcel: any) => ({
        ...parcel,
        product: parcel.product || '',
        volumeMT: parcel.volumeMT || '',
        volumeM3: parcel.volumeM3 || '',
        density15C: parcel.density15C || parcel.density || '',
        receiver: parcel.receiver || '',
        owner: parcel.owner || ''
      }));
      setEditedParcels(initializedParcels);
      setIsEditingParcels(true);
    }
  };

  const handleParcelChange = (parcelId: number, field: string, value: string) => {
    setEditedParcels(prevParcels => 
      prevParcels.map(parcel => {
        if (parcel.id === parcelId) {
          const updatedParcel = { ...parcel, [field]: value };
          
          // Get current values after update
          const densityValue = field === 'density15C' ? value : (updatedParcel.density15C || updatedParcel.density || '');
          const mtValue = field === 'volumeMT' ? value : (updatedParcel.volumeMT || '');
          const m3Value = field === 'volumeM3' ? value : (updatedParcel.volumeM3 || '');
          
          const density = parseFloat(densityValue);
          const volumeMT = parseFloat(mtValue);
          const volumeM3 = parseFloat(m3Value);
          
          // Perform automatic conversions
          if (density > 0) {
            if (field === 'volumeMT' && volumeMT > 0) {
              // Convert MT to m³: Volume(m³) = Mass(MT) / Density
              updatedParcel.volumeM3 = (volumeMT / density).toFixed(3);
            } else if (field === 'volumeM3' && volumeM3 > 0) {
              // Convert m³ to MT: Mass(MT) = Volume(m³) * Density
              updatedParcel.volumeMT = (volumeM3 * density).toFixed(2);
            } else if (field === 'density15C') {
              // If density changed, recalculate based on MT if available
              if (volumeMT > 0) {
                updatedParcel.volumeM3 = (volumeMT / density).toFixed(3);
              } else if (volumeM3 > 0) {
                updatedParcel.volumeMT = (volumeM3 * density).toFixed(2);
              }
            }
          }
          
          return updatedParcel;
        }
        return parcel;
      })
    );
  };

  const handleSaveParcels = async () => {
    if (currentShipAtBerth && editedParcels.length > 0) {
      try {
        // Update each parcel individually using the mutation
        for (const parcel of editedParcels) {
          await updateParcelMutation.mutateAsync({
            shipId: currentShipAtBerth.id,
            parcelId: parcel.id,
            updates: {
              product: parcel.product,
              volumeMT: String(parcel.volumeMT || ''),
              volumeM3: String(parcel.volumeM3 || ''),
              density15C: String(parcel.density15C || ''), // NUNCA valores automáticos - requer dados reais do laboratório
              receiver: parcel.receiver,
              owner: parcel.owner,
            },
          });
        }
        
        // Clear edited parcels after successful save
        setEditedParcels([]);
        setIsEditingParcels(false);
      } catch (error) {
        console.error('Error saving parcels:', error);
      }
    }
  };

  const handleCancelParcelEditing = () => {
    setIsEditingParcels(false);
    setEditedParcels([]);
  };

  const handleFieldChange = (field: keyof Ship, value: string | number) => {
    setEditedShipData(prev => ({
      ...prev,
      [field]: value,
    }));
  };

  // Handle location selection flow
  const handleLocationSelected = (location: 'at_bar' | 'expected') => {
    setSelectedLocation(location);
    setShowLocationSelector(false);
    setShowShipRegistration(true);
  };

  const handleRegistrationClose = () => {
    setShowShipRegistration(false);
    setSelectedLocation(null);
  };

  const handleRegistrationSuccess = () => {
    setShowShipRegistration(false);
    setSelectedLocation(null);
    queryClient.invalidateQueries({ queryKey: ['/api/ships'] });
  };

  // Update time every second
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  // Fetch ships data directly
  const { data: shipsData = [], isLoading: isLoadingShips, error: shipsError } = useQuery<any[]>({
    queryKey: ['/api/ships'],
    queryFn: async () => {
      const response = await fetch('/api/ships', {
        headers: {
          'Cache-Control': 'no-cache, no-store, must-revalidate',
          'Pragma': 'no-cache',
          'Expires': '0'
        }
      });
      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }
      const data = await response.json();
      console.log('Fresh ships data from direct fetch:', data);
      console.log('Direct fetch ships count:', data.length);
      return data;
    },
    refetchInterval: 5000,
    staleTime: 0,
    refetchOnMount: true,
    refetchOnWindowFocus: true,
  });

  // Map backend data to frontend format
  const ships = Array.isArray(shipsData) ? shipsData.map((ship: any) => ({
    id: ship.id,
    name: ship.name,
    countermark: ship.countermark,
    draft: parseFloat(ship.draft) || 0,
    cargoType: ship.cargoType,
    shipAgent: ship.shipAgent,
    cargoAgent: ship.cargoAgent,
    shipowner: ship.shipowner,
    cargoDestination: ship.cargoDestination,
    operationType: ship.operationType,
    status: ship.status,
    hasDischargeInstructions: ship.hasDischargeInstructions,
    berthConfirmed: ship.berthingConfirmed,
    arrivalAtBar: ship.arrivalDateTime,
    shipAgentEmail: ship.shipAgentEmail,
    cargoAgentEmail: ship.cargoAgentEmail,
    parcels: ship.parcels || []
  })) : [];

  // Debug logs
  console.log('=== SHIPS DEBUG START ===');
  console.log('Raw ships data from API:', shipsData);
  console.log('Ships count:', Array.isArray(shipsData) ? shipsData.length : 0);
  console.log('Loading ships:', isLoadingShips);
  console.log('Ships error:', shipsError);
  
  if (Array.isArray(shipsData) && shipsData.length > 0) {
    console.log('First ship raw data:', shipsData[0]);
    console.log('First ship keys:', Object.keys(shipsData[0]));
  }
  
  console.log('Ships after mapping:', ships);
  console.log('Mapped ships count:', ships.length);
  
  if (ships.length > 0) {
    console.log('First mapped ship:', ships[0]);
    console.log('Ships by status:');
    ships.forEach((ship, index) => {
      console.log(`Ship ${index + 1}: ${ship.name} - Status: ${ship.status} - Instructions: ${ship.hasDischargeInstructions}`);
    });
  }
  
  console.log('Status counts:');
  console.log('- Expected:', ships.filter(ship => ship.status === 'expected').length);
  console.log('- At bar:', ships.filter(ship => ship.status === 'at_bar').length);
  console.log('- Next to berth:', ships.filter(ship => ship.status === 'next_to_berth').length);
  console.log('- At berth:', ships.filter(ship => ship.status === 'at_berth').length);
  console.log('- Departed:', ships.filter(ship => ship.status === 'departed').length);
  console.log('=== SHIPS DEBUG END ===');

  // Fetch SWAP operations data
  const { data: swapOperations = [] } = useQuery({
    queryKey: ['/api/swap-operations'],
    refetchInterval: 5000,
  });

  // Fetch weather data
  const { data: weatherData } = useQuery({
    queryKey: ['/api/weather'],
    refetchInterval: 60000,
  });

  // Fetch tide data
  const { data: tideData } = useQuery({
    queryKey: ['/api/tide'],
    refetchInterval: 30000,
  });

  // Fetch berth maintenance status
  const { data: maintenanceData } = useQuery({
    queryKey: ['/api/berth-maintenance/active'],
    refetchInterval: 15000,
  });

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString('pt-PT', {
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      timeZone: 'Africa/Maputo'
    });
  };

  const formatDate = (date: Date) => {
    return date.toLocaleDateString('pt-PT', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      timeZone: 'Africa/Maputo'
    });
  };

  const handleLogout = async () => {
    try {
      await fetch('/api/logout', {
        method: 'POST',
        credentials: 'include'
      });
      
      // Clear all possible authentication data
      localStorage.clear();
      sessionStorage.clear();
      
      // Clear cookies
      document.cookie.split(";").forEach(function(c) { 
        document.cookie = c.replace(/^ +/, "").replace(/=.*/, "=;expires=" + new Date().toUTCString() + ";path=/"); 
      });
      
      // Force reload to clear all state
      window.location.href = '/login';
    } catch (error) {
      console.error('Logout error:', error);
      window.location.href = '/login';
    }
  };

  // Filter ships by status and priority
  const prioritizeShips = (ships: Ship[]) => {
    return ships.sort((a, b) => {
      // IMOPETRO priority (absolute)
      const aIsImopetro = a.cargoAgent?.toLowerCase().includes('imopetro');
      const bIsImopetro = b.cargoAgent?.toLowerCase().includes('imopetro');
      if (aIsImopetro && !bIsImopetro) return -1;
      if (!aIsImopetro && bIsImopetro) return 1;

      // Nacional priority (after IMOPETRO)
      if (a.operationType === 'Nacional' && b.operationType !== 'Nacional') return -1;
      if (a.operationType !== 'Nacional' && b.operationType === 'Nacional') return 1;

      // LPG priority (after Nacional)
      if (a.operationType === 'LPG' && b.operationType !== 'LPG') return -1;
      if (a.operationType !== 'LPG' && b.operationType === 'LPG') return 1;

      // 2:1 rule for Trânsito:Combinado
      const arrivalTimeA = new Date(a.arrivalAtBar).getTime();
      const arrivalTimeB = new Date(b.arrivalAtBar).getTime();
      return arrivalTimeA - arrivalTimeB;
    });
  };

  // Strict filtering - each ship appears in exactly one category
  const expectedArrivals = ships.filter(ship => ship.status === 'expected');
  const shipsAtBar = ships.filter(ship => ship.status === 'at_bar');
  
  // Remove duplicates using Set and Map for safe deduplication
  const removeDuplicates = (shipArray: Ship[]) => {
    const seen = new Set();
    return shipArray.filter(ship => {
      if (seen.has(ship.id)) {
        console.warn(`⚠️ Removing duplicate ship ID ${ship.id}: ${ship.name}`);
        return false;
      }
      seen.add(ship.id);
      return true;
    });
  };

  // Ships at bar without instructions (mutually exclusive, deduplicated)
  const shipsWithoutInstructions = prioritizeShips(
    removeDuplicates(shipsAtBar.filter(ship => !ship.hasDischargeInstructions))
  );
  
  // Ships at bar with instructions (mutually exclusive, deduplicated)
  const shipsWithInstructions = prioritizeShips(
    removeDuplicates(shipsAtBar.filter(ship => ship.hasDischargeInstructions))
  );
  
  // Next ships (only next_to_berth status, deduplicated)
  const nextShips = prioritizeShips(
    removeDuplicates(ships.filter(ship => ship.status === 'next_to_berth'))
  );
  
  // Current ship at berth (only at_berth status)
  const currentShipAtBerth = ships.find(ship => ship.status === 'at_berth');
  
  // Departed ships
  const departedShips = ships.filter(ship => ship.status === 'departed').slice(0, 10);

  // Debug filtered ships with detailed breakdown - CHECK FOR INTERNAL DUPLICATES
  console.log('=== FILTERED SHIPS DEBUG ===');
  console.log('Raw ships array length:', ships.length);
  console.log('Ships at bar raw length:', shipsAtBar.length);
  console.log('Ships without instructions BEFORE prioritize:', shipsAtBar.filter(ship => !ship.hasDischargeInstructions).length);
  console.log('Ships without instructions AFTER prioritize:', shipsWithoutInstructions.length);
  
  // Check each category for internal duplicates
  const checkInternalDuplicates = (shipArray: any[], category: string) => {
    const ids = shipArray.map((s: any) => s.id);
    const uniqueIds = new Set(ids);
    if (ids.length !== uniqueIds.size) {
      console.log(`⚠️ INTERNAL DUPLICATES IN ${category}:`, ids);
      console.log(`- Total ships: ${ids.length}, Unique: ${uniqueIds.size}`);
      // Find which IDs are duplicated
      const duplicates = ids.filter((id: any, index: number) => ids.indexOf(id) !== index);
      console.log(`- Duplicate IDs: ${duplicates}`);
    }
  };
  
  checkInternalDuplicates(shipsWithoutInstructions, 'WITHOUT INSTRUCTIONS');
  checkInternalDuplicates(shipsWithInstructions, 'WITH INSTRUCTIONS');
  checkInternalDuplicates(nextShips, 'NEXT SHIPS');
  
  console.log('Ships without instructions IDs:', shipsWithoutInstructions.map(s => s.id));
  console.log('Ships without instructions names:', shipsWithoutInstructions.map(s => s.name));
  console.log('=== END FILTERED SHIPS DEBUG ===');

  const deleteSwapOperation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest(`/api/swap-operations/${id}`, {
        method: "DELETE",
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/swap-operations"] });
    },
  });

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-600"></div>
          <p className="mt-4 text-gray-600">Carregando sistema...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-blue-50">
      {/* Mobile Header */}
      <header className="mobile-nav md:hidden">
        <div className="px-4 py-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 rounded-full bg-gradient-to-br from-blue-500 to-blue-600 flex items-center justify-center">
                <img src={logoPath} alt="CFM" className="w-6 h-6 object-contain" />
              </div>
              <div>
                <h1 className="text-sm font-bold text-gray-800">Terminal Beira</h1>
                <p className="text-xs text-gray-600">{formatTime(currentTime)}</p>
              </div>
            </div>
            
            <div className="flex items-center space-x-2">
              <SoundControl />
              <LanguageSelector />
              {isAuthenticated && (
                <button
                  onClick={handleLogout}
                  className="p-2 text-gray-600 hover:text-gray-800 hover:bg-gray-100 rounded-lg transition-colors"
                >
                  <LogOut className="w-4 h-4" />
                </button>
              )}
            </div>
          </div>
        </div>
      </header>

      {/* Desktop/Tablet Header */}
      <div className="max-w-7xl mx-auto space-y-6 p-4 pt-20 md:pt-6">
        <header className="hidden md:block bg-white shadow-xl rounded-2xl border border-gray-200 overflow-hidden">
          <div className="bg-gradient-to-r from-blue-600 to-blue-800 p-1">
            <div className="bg-white rounded-xl p-6">
              <div className="grid grid-cols-1 md:grid-cols-4 gap-6 items-center min-h-[100px]">
                {/* CFM Logo */}
                <div className="flex flex-col items-center text-center">
                  <div className="w-20 h-20 rounded-full bg-gradient-to-br from-blue-500 to-blue-700 border-4 border-white shadow-xl flex items-center justify-center mb-2">
                    <img
                      src={logoPath}
                      alt="CFM Logo"
                      className="w-14 h-14 object-contain filter brightness-110 contrast-110"
                    />
                  </div>
                  <span className="text-xs font-semibold text-gray-700">CFM-EP</span>
                </div>

                {/* Clock */}
                <div className="flex flex-col items-center text-center">
                  <div className="w-20 h-20 rounded-full bg-gradient-to-br from-green-500 to-green-700 border-4 border-white shadow-xl flex flex-col items-center justify-center mb-2">
                    <Clock className="w-5 h-5 text-white mb-1" />
                    <div className="text-white text-xs font-bold text-center leading-tight">
                      <div>{formatTime(currentTime)}</div>
                      <div className="text-xs opacity-90">{formatDate(currentTime).split('/').slice(0,2).join('/')}</div>
                    </div>
                  </div>
                  <span className="text-xs font-semibold text-gray-700">Hora Local</span>
                </div>

                {/* Terminal Status */}
                <div className="flex flex-col items-center text-center">
                  <div className="w-20 h-20 rounded-full bg-gradient-to-br from-purple-500 to-purple-700 border-4 border-white shadow-xl flex items-center justify-center overflow-hidden mb-2">
                    <img
                      src={terminalImagePath}
                      alt="Terminal da Beira"
                      className="w-16 h-16 object-cover filter saturate-150"
                    />
                  </div>
                  <span className="text-xs font-semibold text-gray-700">Terminal Beira</span>
                </div>

                {/* User & Controls */}
                <div className="flex flex-col items-center text-center space-y-3">
                  <div className="w-20 h-20 rounded-full bg-gradient-to-br from-orange-500 to-orange-700 border-4 border-white shadow-xl flex flex-col items-center justify-center">
                    {isAuthenticated ? (
                      <>
                        <User className="w-5 h-5 text-white mb-1" />
                        <span className="text-xs font-bold text-white truncate px-1">
                          {user?.firstName || user?.username || 'User'}
                        </span>
                      </>
                    ) : (
                      <a href="/login" className="text-white text-xs hover:bg-white hover:bg-opacity-20 px-2 py-1 rounded">
                        {t("Entrar")}
                      </a>
                    )}
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <SoundControl />
                    <LanguageSelector />
                    {isAuthenticated && (
                      <button
                        onClick={handleLogout}
                        className="p-2 bg-gray-100 hover:bg-gray-200 rounded-lg transition-colors group"
                        title="Sair"
                      >
                        <LogOut className="w-4 h-4 text-gray-600 group-hover:text-red-600" />
                      </button>
                    )}
                  </div>
                </div>
            </div>

              {/* Title and System Info */}
              <div className="text-center mt-6">
                <h1 className="text-2xl lg:text-3xl font-bold bg-gradient-to-r from-blue-600 to-blue-800 bg-clip-text text-transparent mb-3">
                  {t("Line Up - Beira Oil Terminal")}
                </h1>
                <div className="flex flex-col sm:flex-row items-center justify-center space-y-2 sm:space-y-0 sm:space-x-6 text-sm">
                  <div className="flex items-center gap-2 px-3 py-1 bg-green-50 rounded-full">
                    <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                    <span className="text-green-700 font-medium">{t("Sistema de Informação de Navios")}</span>
                  </div>
                  <div className="text-gray-600">{t("Desenvolvido por: Manuel Antonio, Eng.")}</div>
                </div>
              </div>
            </div>
          </div>
        </header>

        {/* Berth Maintenance Alert */}
        {maintenanceData && (maintenanceData as any).isActive && (
          <div className="bg-gradient-to-r from-red-500 to-red-600 rounded-2xl shadow-xl border border-red-300 overflow-hidden">
            <div className="bg-white/10 backdrop-blur-sm p-6">
              <div className="text-center">
                <div className="inline-flex items-center justify-center w-16 h-16 bg-white/20 rounded-full mb-4">
                  <AlertTriangle className="w-8 h-8 text-white" />
                </div>
                <h2 className="text-2xl font-bold text-white mb-3">
                  CAIS EM MANUTENÇÃO
                </h2>
                <div className="bg-white/20 rounded-lg p-3 mb-3">
                  <p className="text-white font-medium">
                    {t("Período")}: {(maintenanceData as any).startDate} - {(maintenanceData as any).endDate}
                  </p>
                </div>
                {(maintenanceData as any).description && (
                  <div className="text-white/90 text-sm uppercase font-semibold leading-relaxed">
                    {(maintenanceData as any).description}
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {/* Ship at Berth - NAVIO NO CAIS 12 */}
        {currentShipAtBerth && (
          <div className="bg-gradient-to-r from-green-500 to-green-600 rounded-2xl shadow-xl border border-green-300 overflow-hidden">
            <div className="bg-white/10 backdrop-blur-sm p-6">
              <div className="flex items-center gap-3 mb-6">
                <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center">
                  <Anchor className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h2 className="text-2xl font-bold text-white">NAVIO NO CAIS 12</h2>
                  <p className="text-green-100">Terminal de Combustíveis da Beira</p>
                </div>
              </div>
              
              <div className="bg-white rounded-xl p-6 space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {/* Ship Name and Basic Info */}
                <div className="bg-white p-4 rounded-lg border">
                  <div className="mb-3">
                    {isEditingShipInfo ? (
                      <Input
                        value={editedShipData.name || ''}
                        onChange={(e) => handleFieldChange('name', e.target.value)}
                        className="font-bold text-lg text-blue-700"
                        placeholder="Nome do Navio"
                      />
                    ) : (
                      <h3 className="font-bold text-lg text-blue-700">{currentShipAtBerth.name}</h3>
                    )}
                  </div>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between items-center">
                      <span className="text-gray-600">{t("Contramarcha")}:</span>
                      {isEditingShipInfo ? (
                        <Input
                          value={editedShipData.countermark || ''}
                          onChange={(e) => handleFieldChange('countermark', e.target.value)}
                          className="w-24 h-6 text-xs"
                          placeholder="Contramarcha"
                        />
                      ) : (
                        <span className="font-medium">{currentShipAtBerth.countermark}</span>
                      )}
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-gray-600">{t("Calado")}:</span>
                      {isEditingShipInfo ? (
                        <Input
                          value={editedShipData.draft || ''}
                          onChange={(e) => handleFieldChange('draft', parseFloat(e.target.value) || 0)}
                          className="w-20 h-6 text-xs"
                          placeholder="Calado"
                          type="number"
                          step="0.1"
                        />
                      ) : (
                        <span className="font-medium">{currentShipAtBerth.draft}m</span>
                      )}
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-gray-600">{t("Tipo de Operação")}:</span>
                      {isEditingShipInfo ? (
                        <Select
                          value={editedShipData.operationType || currentShipAtBerth.operationType}
                          onValueChange={(value) => handleFieldChange('operationType', value)}
                        >
                          <SelectTrigger className="w-32 h-6 text-xs">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="Nacional">🇲🇿 Nacional</SelectItem>
                            <SelectItem value="LPG">⛽ LPG</SelectItem>
                            <SelectItem value="Trânsito">🚢 Trânsito</SelectItem>
                            <SelectItem value="Combinado">🔄 Combinado</SelectItem>
                          </SelectContent>
                        </Select>
                      ) : (
                        <Badge variant="outline" className="text-xs">
                          {currentShipAtBerth.operationType === 'Nacional' && `🇲🇿 ${t("Nacional")}`}
                          {currentShipAtBerth.operationType === 'LPG' && `⛽ ${t("LPG")}`}
                          {currentShipAtBerth.operationType === 'Trânsito' && `🚢 ${t("Trânsito")}`}
                          {currentShipAtBerth.operationType === 'Combinado' && `🔄 ${t("Combinado")}`}
                        </Badge>
                      )}
                    </div>
                  </div>
                  <div className="mt-4 flex space-x-2">
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => setSelectedShip(currentShipAtBerth)}
                      className="flex-1"
                    >
                      <Info className="w-4 h-4 mr-1" />
                      {t("Info")}
                    </Button>
                    {isOperator && !isEditingShipInfo && (
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={handleStartEditing}
                        className="flex-1 border-orange-300 hover:bg-orange-50"
                      >
                        <Edit className="w-4 h-4 mr-1" />
                        Editar
                      </Button>
                    )}
                    {isOperator && isEditingShipInfo && (
                      <>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={handleCancelEditing}
                          className="flex-1 border-gray-300"
                        >
                          Cancelar
                        </Button>
                        <Button
                          size="sm"
                          variant="default"
                          onClick={handleSaveChanges}
                          disabled={updateShipMutation.isPending}
                          className="flex-1 bg-green-600 hover:bg-green-700"
                        >
                          {updateShipMutation.isPending ? "Salvando..." : "Salvar"}
                        </Button>
                      </>
                    )}
                  </div>

                </div>

                {/* Cargo Information */}
                <div className="bg-white p-4 rounded-lg border">
                  <h4 className="font-semibold text-gray-700 mb-3">{t("Informações da Carga")}</h4>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between items-center">
                      <span className="text-gray-600">{t("Armador")}:</span>
                      {isEditingShipInfo ? (
                        <Input
                          value={editedShipData.shipowner || ''}
                          onChange={(e) => handleFieldChange('shipowner', e.target.value)}
                          className="w-32 h-6 text-xs"
                          placeholder="Armador"
                        />
                      ) : (
                        <span className="font-medium">{currentShipAtBerth.shipowner}</span>
                      )}
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-gray-600">{t("Destino")}:</span>
                      {isEditingShipInfo ? (
                        <Input
                          value={editedShipData.cargoDestination || ''}
                          onChange={(e) => handleFieldChange('cargoDestination', e.target.value)}
                          className="w-32 h-6 text-xs"
                          placeholder="Destino da Carga"
                        />
                      ) : (
                        <span className="font-medium">{currentShipAtBerth.cargoDestination}</span>
                      )}
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-gray-600">{t("Agente do Navio")}:</span>
                      {isEditingShipInfo ? (
                        <Input
                          value={editedShipData.shipAgent || ''}
                          onChange={(e) => handleFieldChange('shipAgent', e.target.value)}
                          className="w-32 h-6 text-xs"
                          placeholder="Agente do Navio"
                        />
                      ) : (
                        <span className="font-medium">{currentShipAtBerth.shipAgent}</span>
                      )}
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-gray-600">{t("Agente da Carga")}:</span>
                      {isEditingShipInfo ? (
                        <Input
                          value={editedShipData.cargoAgent || ''}
                          onChange={(e) => handleFieldChange('cargoAgent', e.target.value)}
                          className="w-32 h-6 text-xs"
                          placeholder="Agente da Carga"
                        />
                      ) : (
                        <span className="font-medium">{currentShipAtBerth.cargoAgent}</span>
                      )}
                    </div>
                  </div>
                </div>

                {/* Cargo Parcels */}
                <div className="bg-white p-4 rounded-lg border">
                  <div className="flex justify-between items-center mb-3">
                    <h4 className="font-semibold text-gray-700">{t("Parcelas")} ({currentShipAtBerth.parcels?.length || 0})</h4>
                    {userIsOperator && currentShipAtBerth.parcels && currentShipAtBerth.parcels.length > 0 && (
                      <div className="flex gap-2">
                        {isEditingParcels ? (
                          <>
                            <Button
                              onClick={handleSaveParcels}
                              size="sm"
                              className="bg-green-600 hover:bg-green-700 text-white"
                              disabled={updateParcelMutation.isPending}
                            >
                              ✓ Salvar
                            </Button>
                            <Button
                              onClick={handleCancelParcelEditing}
                              size="sm"
                              variant="outline"
                              className="border-gray-300"
                            >
                              ✗ Cancelar
                            </Button>
                          </>
                        ) : (
                          <Button
                            onClick={handleStartParcelEditing}
                            size="sm"
                            className="bg-blue-600 hover:bg-blue-700 text-white"
                          >
                            <Edit className="w-3 h-3 mr-1" />
                            Editar
                          </Button>
                        )}
                      </div>
                    )}
                  </div>
                  
                  <div className="space-y-2 max-h-40 overflow-y-auto">
                    {(isEditingParcels ? editedParcels : currentShipAtBerth.parcels)?.map((parcel: any) => (
                      <div key={parcel.id} className="p-3 bg-gray-50 rounded border">
                        <div className="font-medium text-blue-600 mb-2">{parcel.parcelNumber}</div>
                        
                        {isEditingParcels ? (
                          <div className="grid grid-cols-3 gap-2 text-xs">
                            <div>
                              <label className="text-gray-600 block mb-1">Produto:</label>
                              <Input
                                value={parcel.product || ''}
                                onChange={(e) => handleParcelChange(parcel.id, 'product', e.target.value)}
                                className="h-6 text-xs"
                                placeholder="Produto"
                              />
                            </div>
                            <div>
                              <label className="text-gray-600 block mb-1">Volume MT:</label>
                              <Input
                                type="number"
                                step="0.01"
                                value={parcel.volumeMT || ''}
                                onChange={(e) => handleParcelChange(parcel.id, 'volumeMT', e.target.value)}
                                className="h-6 text-xs bg-blue-50 border-blue-200"
                                placeholder="0.00"
                              />
                            </div>
                            <div>
                              <label className="text-gray-600 block mb-1">Volume m³ (auto):</label>
                              <Input
                                type="number"
                                step="0.01"
                                value={parcel.volumeM3 || ''}
                                onChange={(e) => handleParcelChange(parcel.id, 'volumeM3', e.target.value)}
                                className="h-6 text-xs bg-green-50 border-green-200"
                                placeholder="0.00"
                              />
                            </div>
                            <div>
                              <label className="text-gray-600 block mb-1">Densidade 15°C:</label>
                              <Input
                                type="number"
                                step="0.001"
                                value={parcel.density15C || parcel.density || ''}
                                onChange={(e) => handleParcelChange(parcel.id, 'density15C', e.target.value)}
                                className="h-6 text-xs bg-yellow-50 border-yellow-200"
                                placeholder="Introduza densidade real"
                              />
                              <div className="text-xs text-gray-500 mt-1">
                                {(parcel.density15C || parcel.density) && (parcel.volumeMT || parcel.volumeM3) ? 
                                  `MT: ${parcel.volumeMT} | m³: ${parcel.volumeM3} | Densidade: ${parcel.density15C || parcel.density}` : 
                                  '⚠️ Introduza dados reais obtidos do laboratório'
                                }
                              </div>
                            </div>
                            <div>
                              <label className="text-gray-600 block mb-1">Recebedor:</label>
                              <Input
                                value={parcel.receiver || ''}
                                onChange={(e) => handleParcelChange(parcel.id, 'receiver', e.target.value)}
                                className="h-6 text-xs"
                                placeholder="Recebedor"
                              />
                            </div>
                            <div>
                              <label className="text-gray-600 block mb-1">Proprietário:</label>
                              <Input
                                value={parcel.owner || ''}
                                onChange={(e) => handleParcelChange(parcel.id, 'owner', e.target.value)}
                                className="h-6 text-xs"
                                placeholder="Proprietário"
                              />
                            </div>
                          </div>
                        ) : (
                          <div className="grid grid-cols-3 gap-1 text-xs">
                            <div className="font-medium">{parcel.product}</div>
                            <div className="text-blue-600">{parcel.volumeMT} MT</div>
                            <div className="text-blue-600">{parcel.volumeM3} m³</div>
                            <div className="text-gray-500">Densidade: {parcel.density15C || parcel.density}</div>
                            <div className="text-gray-500">{parcel.receiver}</div>
                            <div className="text-gray-500">{parcel.owner}</div>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Operational Statistics - only when ship is at berth */}
        {currentShipAtBerth && (
          <div className="bg-white rounded-xl shadow-lg border border-gray-200 p-6">
            <h3 className="text-lg font-semibold mb-4">Estatísticas Operacionais</h3>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="text-center">
                <div className="text-2xl font-bold text-blue-600">{currentShipAtBerth.name}</div>
                <div className="text-sm text-gray-600">Navio no Cais</div>
              </div>
            </div>
          </div>
        )}

        {/* Quick Actions and Operations - Mobile/Desktop Responsive */}
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Main Content Area */}
          <div className="lg:col-span-3 space-y-6">
            <Tabs defaultValue="lineup" className="w-full">
              <TabsList className="grid w-full grid-cols-2 md:grid-cols-4 gap-1">
                <TabsTrigger value="lineup" className="text-xs md:text-sm p-2 md:p-3">
                  <span className="hidden md:inline">{t("PRÓXIMOS 5 NAVIOS A ATRACAR")}</span>
                  <span className="md:hidden">Line-Up</span>
                </TabsTrigger>
                <TabsTrigger value="bar" className="text-xs md:text-sm p-2 md:p-3">
                  <span className="hidden md:inline">{t("NAVIOS NA BARRA")}</span>
                  <span className="md:hidden">Na Barra</span>
                </TabsTrigger>
                <TabsTrigger value="expected" className="text-xs md:text-sm p-2 md:p-3">
                  <span className="hidden md:inline">{t("CHEGADAS ESPERADAS")}</span>
                  <span className="md:hidden">Esperados</span>
                </TabsTrigger>
                <TabsTrigger value="departed" className="text-xs md:text-sm p-2 md:p-3">
                  <span className="hidden md:inline">{t("NAVIOS PARTIDOS")}</span>
                  <span className="md:hidden">Partidos</span>
                </TabsTrigger>
              </TabsList>

              <TabsContent value="lineup" className="space-y-4">
                <div className="flex justify-center items-center mb-4">
                  <div className="bg-gradient-to-r from-blue-600 via-blue-500 to-blue-600 text-white px-8 py-4 rounded-full shadow-xl border-4 border-blue-300 transform hover:scale-105 transition-transform duration-200">
                    <h2 className="text-xl font-bold text-center flex items-center justify-center gap-3">
                      {t("PRÓXIMOS 5 NAVIOS A ATRACAR")}
                      <span className="bg-white text-blue-600 rounded-full px-4 py-2 text-lg font-bold shadow-inner border-2 border-blue-200">
                        {nextShips.length}
                      </span>
                    </h2>
                  </div>
                </div>
          
                {/* Cargo Type Tabs */}
                <div className="mb-6">
            <div className="grid grid-cols-4 gap-4">
              <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="font-semibold text-green-800">{t("Trânsito").toUpperCase()}</h3>
                    <span className="bg-green-500 text-white rounded-full px-3 py-1 text-sm font-bold">
                      {ships.filter(ship => ship.operationType === 'Trânsito' && ['at_bar', 'next_to_berth'].includes(ship.status)).length}
                    </span>
                  </div>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setShowCargoModal({ type: 'Trânsito', ships: ships.filter(ship => ship.operationType === 'Trânsito' && ['at_bar', 'next_to_berth'].includes(ship.status)) })}
                    className="border-green-500 text-green-700 hover:bg-green-100"
                  >
                    <Info className="w-4 h-4" />
                  </Button>
                </div>
              </div>
              
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="font-semibold text-blue-800">{t("Nacional").toUpperCase()}</h3>
                    <span className="bg-blue-500 text-white rounded-full px-3 py-1 text-sm font-bold">
                      {ships.filter(ship => ship.operationType === 'Nacional' && ['at_bar', 'next_to_berth'].includes(ship.status)).length}
                    </span>
                  </div>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setShowCargoModal({ type: 'Nacional', ships: ships.filter(ship => ship.operationType === 'Nacional' && ['at_bar', 'next_to_berth'].includes(ship.status)) })}
                    className="border-blue-500 text-blue-700 hover:bg-blue-100"
                  >
                    <Info className="w-4 h-4" />
                  </Button>
                </div>
              </div>
              
              <div className="bg-purple-50 border border-purple-200 rounded-lg p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="font-semibold text-purple-800">{t("Combinado").toUpperCase()}</h3>
                    <span className="bg-purple-500 text-white rounded-full px-3 py-1 text-sm font-bold">
                      {ships.filter(ship => ship.operationType === 'Combinado' && ['at_bar', 'next_to_berth'].includes(ship.status)).length}
                    </span>
                  </div>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setShowCargoModal({ type: 'Combinado', ships: ships.filter(ship => ship.operationType === 'Combinado' && ['at_bar', 'next_to_berth'].includes(ship.status)) })}
                    className="border-purple-500 text-purple-700 hover:bg-purple-100"
                  >
                    <Info className="w-4 h-4" />
                  </Button>
                </div>
              </div>
              
              <div className="bg-orange-50 border border-orange-200 rounded-lg p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="font-semibold text-orange-800">{t("LPG")}</h3>
                    <span className="bg-orange-500 text-white rounded-full px-3 py-1 text-sm font-bold">
                      {ships.filter(ship => ship.operationType === 'LPG' && ['at_bar', 'next_to_berth'].includes(ship.status)).length}
                    </span>
                  </div>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setShowCargoModal({ type: 'LPG', ships: ships.filter(ship => ship.operationType === 'LPG' && ['at_bar', 'next_to_berth'].includes(ship.status)) })}
                    className="border-orange-500 text-orange-700 hover:bg-orange-100"
                  >
                    <Info className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </div>
          </div>
          
          <TabsList className="grid w-full grid-cols-7 h-24 md:h-20">
            {isOperator && (
              <TabsTrigger value="discharge-control" className="text-xs flex flex-col items-center justify-center h-full py-1 md:py-2">
                <span className="text-center leading-tight text-[10px] md:text-xs">CONTROLO DESCARGA</span>
                <span className="bg-indigo-500 text-white rounded-full px-2 py-0.5 text-xs font-bold mt-1 min-w-[20px] text-center">
                  ⚙️
                </span>
              </TabsTrigger>
            )}
            <TabsTrigger value="next" className="text-xs flex flex-col items-center justify-center h-full py-1 md:py-2">
              <span className="text-center leading-tight text-[10px] md:text-xs">PRÓXIMOS 5 NAVIOS A ATRACAR</span>
              <span className="bg-blue-500 text-white rounded-full px-2 py-0.5 text-xs font-bold mt-1 min-w-[20px] text-center">
                {nextShips.slice(0, 5).length}
              </span>
            </TabsTrigger>
            <TabsTrigger value="with-instructions" className="text-xs flex flex-col items-center justify-center h-full py-1 md:py-2">
              <span className="text-center leading-tight text-[10px] md:text-xs">{t("COM INSTRUÇÃO")}</span>
              <span className="bg-green-500 text-white rounded-full px-2 py-0.5 text-xs font-bold mt-1 min-w-[20px] text-center">
                {shipsWithInstructions.length}
              </span>
            </TabsTrigger>
            <TabsTrigger value="without-instructions" className="text-xs flex flex-col items-center justify-center h-full py-1 md:py-2">
              <span className="text-center leading-tight text-[10px] md:text-xs">{t("SEM INSTRUÇÃO")}</span>
              <span className="bg-orange-500 text-white rounded-full px-2 py-0.5 text-xs font-bold mt-1 min-w-[20px] text-center">
                {shipsWithoutInstructions.length}
              </span>
            </TabsTrigger>
            <TabsTrigger value="expected" className="text-xs flex flex-col items-center justify-center h-full py-1 md:py-2">
              <span className="text-center leading-tight text-[10px] md:text-xs">{t("PREVISTOS A CHEGAR")}</span>
              <span className="bg-purple-500 text-white rounded-full px-2 py-0.5 text-xs font-bold mt-1 min-w-[20px] text-center">
                {expectedArrivals.length}
              </span>
            </TabsTrigger>
            <TabsTrigger value="swap" className="text-xs flex flex-col items-center justify-center h-full py-1 md:py-2">
              <span className="text-center leading-tight text-[10px] md:text-xs">{t("SWAP")}</span>
              <span className="bg-pink-500 text-white rounded-full px-2 py-0.5 text-xs font-bold mt-1 min-w-[20px] text-center">
                {(swapOperations as any[]).length}
              </span>
            </TabsTrigger>
            <TabsTrigger value="departed" className="text-xs flex flex-col items-center justify-center h-full py-1 md:py-2">
              <span className="text-center leading-tight text-[10px] md:text-xs">{t("NAVIOS DESATRACADOS")}</span>
              <span className="bg-gray-500 text-white rounded-full px-2 py-0.5 text-xs font-bold mt-1 min-w-[20px] text-center">
                {departedShips.length}
              </span>
            </TabsTrigger>
          </TabsList>

          {/* Next Ships Tab */}
          <TabsContent value="next" className="space-y-4">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-semibold text-gray-800">{t("PRÓXIMOS 5 NAVIOS A ATRACAR")}</h3>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {nextShips.slice(0, 5).map((ship, index) => (
                <Card key={ship.id} className="bg-white shadow-sm">
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between mb-2">
                      <h3 className="font-semibold text-gray-800">{ship.name}</h3>
                      <Badge variant="secondary" className="text-xs">#{index + 1}</Badge>
                    </div>
                    <div className="space-y-1 text-sm text-gray-600 mb-3">
                      <div>{ship.countermark}</div>
                      <div>{t("Calado")}: {ship.draft}m</div>
                      <div className="flex items-center gap-1">
                        <Badge variant="outline" className="text-xs">
                          {ship.operationType === 'Nacional' && '🇲🇿 Nacional'}
                          {ship.operationType === 'LPG' && '⛽ LPG'}
                          {ship.operationType === 'Trânsito' && '🚢 Trânsito'}
                          {ship.operationType === 'Combinado' && '🔄 Combinado'}
                        </Badge>
                        {ship.cargoAgent?.toLowerCase().includes('imopetro') && (
                          <Badge variant="destructive" className="text-xs">
                            🚨 {t("PRIORIDADE - Decreto 89/2019")}
                          </Badge>
                        )}
                      </div>
                    </div>
                    <div className="grid grid-cols-2 gap-2">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => setSelectedShip(ship)}
                        className="w-full"
                      >
                        <Info className="w-4 h-4 mr-1" />
                        {t("Info")}
                      </Button>
                      {isOperator && (
                        <Button size="sm" variant="outline" className="w-full">
                          <ArrowUp className="w-4 h-4 mr-1" />
{t("Mover")}
                        </Button>
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Ships with Instructions Tab */}
          <TabsContent value="with-instructions" className="space-y-4">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-semibold text-gray-800">{t("COM INSTRUÇÃO")}</h3>
              <Button variant="outline" size="sm" className="border-green-500 text-green-700 hover:bg-green-50">
                <FileText className="w-4 h-4 mr-2" />
{t("Relatórios")}
              </Button>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {shipsWithInstructions.map((ship) => (
                <Card key={ship.id} className="bg-green-50 border-green-200 shadow-sm">
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between mb-2">
                      <h3 className="font-semibold text-gray-800">{ship.name}</h3>
                      <Badge className="bg-green-100 text-green-800 text-xs">{t("COM INSTRUÇÃO")}</Badge>
                    </div>
                    <div className="space-y-1 text-sm text-gray-600 mb-3">
                      <div>{ship.countermark}</div>
                      <div>{t("Calado")}: {ship.draft}m</div>
                      <div className="flex items-center gap-1">
                        <Badge variant="outline" className="text-xs">
                          {ship.operationType === 'Nacional' && '🇲🇿 Nacional'}
                          {ship.operationType === 'LPG' && '⛽ LPG'}
                          {ship.operationType === 'Trânsito' && '🚢 Trânsito'}
                          {ship.operationType === 'Combinado' && '🔄 Combinado'}
                        </Badge>
                        {ship.cargoAgent?.toLowerCase().includes('imopetro') && (
                          <Badge variant="destructive" className="text-xs">
                            🚨 PRIORIDADE
                          </Badge>
                        )}
                      </div>
                    </div>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => setSelectedShip(ship)}
                      className="w-full"
                    >
                      <Info className="w-4 h-4 mr-1" />
                      Ver Detalhes
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Ships without Instructions Tab */}
          <TabsContent value="without-instructions" className="space-y-4">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-semibold text-gray-800">Navios Aguardando Instruções</h3>
              <Button variant="outline" size="sm" className="border-orange-500 text-orange-700 hover:bg-orange-50">
                <FileText className="w-4 h-4 mr-2" />
                Pendências de Instrução
              </Button>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {shipsWithoutInstructions.map((ship) => (
                <Card key={ship.id} className="bg-orange-50 border-orange-200 shadow-sm">
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between mb-2">
                      <h3 className="font-semibold text-gray-800">{ship.name}</h3>
                      <Badge variant="secondary" className="bg-orange-100 text-orange-800 text-xs">Sem Instrução</Badge>
                    </div>
                    <div className="space-y-1 text-sm text-gray-600 mb-3">
                      <div>{ship.countermark}</div>
                      <div>{t("Calado")}: {ship.draft}m</div>
                      <div className="flex items-center gap-1">
                        <Badge variant="outline" className="text-xs">
                          {ship.operationType === 'Nacional' && '🇲🇿 Nacional'}
                          {ship.operationType === 'LPG' && '⛽ LPG'}
                          {ship.operationType === 'Trânsito' && '🚢 Trânsito'}
                          {ship.operationType === 'Combinado' && '🔄 Combinado'}
                        </Badge>
                        {ship.cargoAgent?.toLowerCase().includes('imopetro') && (
                          <Badge variant="destructive" className="text-xs">
                            🚨 PRIORIDADE
                          </Badge>
                        )}
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => setSelectedShip(ship)}
                        className="flex-1"
                      >
                        <Info className="w-4 h-4 mr-1" />
                        Ver Detalhes
                      </Button>
                      {isOperator && (
                        <Button
                          size="sm"
                          onClick={() => {
                            setSelectedShipForMovement(ship.id);
                            setShowShipMovementModal(true);
                          }}
                          className="flex-1 bg-green-600 hover:bg-green-700 text-white"
                        >
                          <ArrowUp className="w-4 h-4 mr-1" />
                          Mover
                        </Button>
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Expected Arrivals Tab */}
          <TabsContent value="expected" className="space-y-4">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-semibold text-gray-800">Navios Previstos para Chegada</h3>
              <Button variant="outline" size="sm" className="border-purple-500 text-purple-700 hover:bg-purple-50">
                <FileText className="w-4 h-4 mr-2" />
                Cronograma de Chegadas
              </Button>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {expectedArrivals.map((ship) => (
                <Card key={ship.id} className="bg-purple-50 border-purple-200 shadow-sm">
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between mb-2">
                      <h3 className="font-semibold text-gray-800">{ship.name}</h3>
                      <Badge className="bg-purple-100 text-purple-800 text-xs">Previsto</Badge>
                    </div>
                    <div className="space-y-1 text-sm text-gray-600 mb-3">
                      <div>{ship.countermark}</div>
                      <div>{t("Calado")}: {ship.draft}m</div>
                      <div className="flex items-center gap-1">
                        <Badge variant="outline" className="text-xs">
                          {ship.operationType === 'Nacional' && '🇲🇿 Nacional'}
                          {ship.operationType === 'LPG' && '⛽ LPG'}
                          {ship.operationType === 'Trânsito' && '🚢 Trânsito'}
                          {ship.operationType === 'Combinado' && '🔄 Combinado'}
                        </Badge>
                      </div>
                    </div>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => setSelectedShip(ship)}
                      className="w-full"
                    >
                      <Info className="w-4 h-4 mr-1" />
                      Ver Detalhes
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Departed Ships Tab */}
          <TabsContent value="departed" className="space-y-4">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-semibold text-gray-800">Histórico de Navios Partidos</h3>
              <Button variant="outline" size="sm" className="border-gray-500 text-gray-700 hover:bg-gray-50">
                <FileText className="w-4 h-4 mr-2" />
                Relatório de Partidas
              </Button>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {departedShips.map((ship) => (
                <Card key={ship.id} className="bg-gray-50 border-gray-200 shadow-sm">
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between mb-2">
                      <h3 className="font-semibold text-gray-500">{ship.name}</h3>
                      <Badge variant="secondary" className="text-xs">Partiu</Badge>
                    </div>
                    <div className="space-y-1 text-sm text-gray-500 mb-3">
                      <div>{ship.countermark}</div>
                      <div>{t("Calado")}: {ship.draft}m</div>
                    </div>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => setSelectedShip(ship)}
                      className="w-full"
                    >
                      <Info className="w-4 h-4 mr-1" />
                      Histórico
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* SWAP Tab Content */}
          <TabsContent value="swap" className="mt-6">
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <h3 className="text-lg font-semibold">Operações SWAP</h3>
                {isOperator && (
                  <Button 
                    onClick={() => setShowSwapModal(true)}
                    className="bg-pink-600 hover:bg-pink-700"
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    Adicionar SWAP
                  </Button>
                )}
              </div>
              
              {(swapOperations as any[]).length === 0 ? (
                <div className="text-center py-8 text-gray-500">
                  <RefreshCw className="w-12 h-12 mx-auto mb-4 opacity-50" />
                  <p>Nenhuma operação SWAP registrada</p>
                </div>
              ) : (
                <div className="grid gap-4">
                  {(swapOperations as any[]).map((swap: any) => (
                    <Card key={swap.id} className="p-4 bg-white shadow-sm">
                      <div className="flex items-center justify-between">
                        <div className="flex-1">
                          <div className="flex items-center gap-3 mb-2">
                            <div className="text-lg font-semibold text-gray-800">
                              {swap.shipName} ({swap.shipCountermark})
                            </div>
                            <Badge 
                              variant={swap.status === 'completed' ? 'default' : 
                                      swap.status === 'approved' ? 'secondary' : 'outline'}
                              className={swap.status === 'completed' ? 'bg-green-500' : 
                                        swap.status === 'approved' ? 'bg-blue-500' : 
                                        swap.status === 'pending' ? 'bg-yellow-500' : 'bg-red-500'}
                            >
                              {swap.status.toUpperCase()}
                            </Badge>
                          </div>
                          <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-sm">
                            <div>
                              <span className="font-medium text-gray-600">Tipo:</span>
                              <span className="ml-2">{swap.swapType}</span>
                            </div>
                            <div>
                              <span className="font-medium text-gray-600">De:</span>
                              <span className="ml-2">{swap.originalValue}</span>
                            </div>
                            <div>
                              <span className="font-medium text-gray-600">Para:</span>
                              <span className="ml-2">{swap.newValue}</span>
                            </div>
                          </div>
                          <div className="mt-2 text-sm">
                            <span className="font-medium text-gray-600">Motivo:</span>
                            <span className="ml-2">{swap.reason}</span>
                          </div>
                          <div className="mt-1 text-xs text-gray-500">
                            Autorizado por: {swap.authorizedBy} • {formatDate(new Date(swap.createdAt))}
                          </div>
                        </div>
                        {isOperator && (
                          <div className="flex gap-2 ml-4">
                            <Button 
                              variant="outline" 
                              size="sm"
                              onClick={() => {
                                setSelectedSwap(swap);
                                setShowSwapModal(true);
                              }}
                            >
                              <Edit className="w-4 h-4" />
                            </Button>
                            <Button 
                              variant="outline" 
                              size="sm"
                              className="text-red-600 hover:bg-red-50"
                              onClick={() => deleteSwapOperation.mutate(swap.id)}
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </div>
                        )}
                      </div>
                    </Card>
                  ))}
                </div>
              )}
            </div>
          </TabsContent>

          {/* Discharge Control Tab Content */}
          {isOperator && (
            <TabsContent value="discharge-control" className="space-y-6">
              <div className="flex justify-between items-center mb-6">
                <h3 className="text-xl font-semibold text-gray-800 flex items-center gap-3">
                  <div className="text-2xl">⚙️</div>
                  Sistema de Controlo de Descarga
                </h3>
              </div>
              
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Current Ship at Berth */}
                <Card className="shadow-lg border-2 border-indigo-200 bg-gradient-to-br from-indigo-50 to-blue-50">
                  <CardHeader className="pb-3 bg-gradient-to-r from-indigo-600 to-blue-600 text-white rounded-t-lg">
                    <CardTitle className="text-lg font-bold flex items-center gap-2">
                      <Anchor className="w-5 h-5" />
                      Navio no Cais 12
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="pt-6">
                    {currentShipAtBerth ? (
                      <div className="space-y-4">
                        <div className="text-center">
                          <h3 className="text-xl font-bold text-gray-800 mb-2">{currentShipAtBerth.name}</h3>
                          <Badge className="bg-green-500 text-white">ATRACADO</Badge>
                        </div>
                        <div className="grid grid-cols-2 gap-3 text-sm">
                          <div>
                            <span className="text-gray-600">Contra-marca:</span>
                            <div className="font-semibold">{currentShipAtBerth.countermark}</div>
                          </div>
                          <div>
                            <span className="text-gray-600">Calado:</span>
                            <div className="font-semibold">{currentShipAtBerth.draft}m</div>
                          </div>
                          <div>
                            <span className="text-gray-600">Operação:</span>
                            <div className="font-semibold">
                              {currentShipAtBerth.operationType === 'Nacional' && '🇲🇿 Nacional'}
                              {currentShipAtBerth.operationType === 'LPG' && '⛽ LPG'}
                              {currentShipAtBerth.operationType === 'Trânsito' && '🚢 Trânsito'}
                              {currentShipAtBerth.operationType === 'Combinado' && '🔄 Combinado'}
                            </div>
                          </div>
                          <div>
                            <span className="text-gray-600">Parcelas:</span>
                            <div className="font-semibold">{currentShipAtBerth.parcels?.length || 0}</div>
                          </div>
                        </div>
                        <Button
                          onClick={() => setShowDischargeControl(true)}
                          className="w-full bg-indigo-600 hover:bg-indigo-700 text-white py-3"
                        >
                          <Settings className="w-5 h-5 mr-2" />
                          Abrir Controlo de Descarga
                        </Button>
                      </div>
                    ) : (
                      <div className="text-center py-8">
                        <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                          <Anchor className="w-8 h-8 text-gray-400" />
                        </div>
                        <h4 className="text-lg font-semibold text-gray-600 mb-2">Cais Disponível</h4>
                        <p className="text-gray-500 text-sm">Nenhum navio atracado no momento</p>
                      </div>
                    )}
                  </CardContent>
                </Card>

                {/* Discharge Control Information */}
                <Card className="shadow-lg">
                  <CardHeader className="pb-3">
                    <CardTitle className="text-lg font-semibold flex items-center gap-2">
                      <BarChart3 className="w-5 h-5" />
                      Funcionalidades do Sistema
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="pt-0">
                    <div className="space-y-4">
                      <div className="grid grid-cols-1 gap-3">
                        <div className="flex items-center gap-3 p-3 bg-blue-50 rounded-lg">
                          <div className="text-blue-600">📋</div>
                          <div>
                            <div className="font-medium text-blue-800">Eventos de Descarga</div>
                            <div className="text-xs text-blue-600">Registo de início, pausa e conclusão</div>
                          </div>
                        </div>
                        <div className="flex items-center gap-3 p-3 bg-green-50 rounded-lg">
                          <div className="text-green-600">📦</div>
                          <div>
                            <div className="font-medium text-green-800">Controlo de Parcelas</div>
                            <div className="text-xs text-green-600">Monitorização individual por produto</div>
                          </div>
                        </div>
                        <div className="flex items-center gap-3 p-3 bg-orange-50 rounded-lg">
                          <div className="text-orange-600">⏰</div>
                          <div>
                            <div className="font-medium text-orange-800">Registos Horários</div>
                            <div className="text-xs text-orange-600">Acompanhamento de pressão e taxa</div>
                          </div>
                        </div>
                        <div className="flex items-center gap-3 p-3 bg-red-50 rounded-lg">
                          <div className="text-red-600">⏸️</div>
                          <div>
                            <div className="font-medium text-red-800">Paragens Operacionais</div>
                            <div className="text-xs text-red-600">Controlo de interrupções e motivos</div>
                          </div>
                        </div>
                        <div className="flex items-center gap-3 p-3 bg-purple-50 rounded-lg">
                          <div className="text-purple-600">📊</div>
                          <div>
                            <div className="font-medium text-purple-800">Relatórios Detalhados</div>
                            <div className="text-xs text-purple-600">Análise completa de performance</div>
                          </div>
                        </div>
                      </div>
                      
                      <div className="mt-6 p-4 bg-gray-50 rounded-lg">
                        <div className="flex items-center gap-2 mb-2">
                          <Clock className="w-4 h-4 text-gray-600" />
                          <span className="font-medium text-gray-800">Sistema Sempre Disponível</span>
                        </div>
                        <p className="text-sm text-gray-600">
                          O controlo de descarga está acessível a qualquer momento para verificação de estado 
                          e estará totalmente operacional quando um navio atracar no berço 12.
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Quick Access Button */}
              <Card className="shadow-lg border-2 border-indigo-200">
                <CardContent className="p-6">
                  <div className="text-center">
                    <div className="mb-4">
                      <div className="w-20 h-20 bg-indigo-100 rounded-full flex items-center justify-center mx-auto mb-3">
                        <Settings className="w-10 h-10 text-indigo-600" />
                      </div>
                      <h3 className="text-xl font-semibold text-gray-800 mb-2">Acesso Rápido ao Controlo</h3>
                      <p className="text-gray-600">Aceda ao sistema completo de controlo de descarga com todas as funcionalidades</p>
                    </div>
                    <Button
                      onClick={() => setShowDischargeControl(true)}
                      className="bg-indigo-600 hover:bg-indigo-700 text-white px-8 py-3 text-lg"
                      size="lg"
                    >
                      <Anchor className="w-6 h-6 mr-3" />
                      Abrir Sistema de Controlo
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          )}
            </Tabs>
          </div>

          {/* Sidebar - Desktop only */}
          <div className="hidden lg:block space-y-6">
            {/* Weather and Tide */}
            <Card className="card-hover">
              <CardHeader className="pb-3">
                <CardTitle className="flex items-center gap-2 text-blue-600">
                  <Cloud className="w-5 h-5" />
                  Clima & Maré
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {weatherData && (
                  <div className="bg-blue-50 rounded-lg p-4">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm font-medium">Temperatura</span>
                      <span className="text-lg font-bold text-blue-600">
                        {(weatherData as any).temperature}°C
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-600">Umidade</span>
                      <span className="text-sm">{(weatherData as any).humidity}%</span>
                    </div>
                  </div>
                )}
                {tideData && (
                  <div className="bg-green-50 rounded-lg p-4">
                    <div className="flex items-center gap-2 mb-2">
                      <Waves className="w-4 h-4 text-green-600" />
                      <span className="text-sm font-medium">Maré Atual</span>
                    </div>
                    <div className="text-lg font-bold text-green-600">
                      {(tideData as any).currentTide?.toFixed(1)}m
                    </div>
                    <div className="text-xs text-gray-600">
                      {(tideData as any).tideTime}
                    </div>
                    {(tideData as any).dataSource && (
                      <div className="mt-2 text-xs text-gray-500 border-t pt-2">
                        <div className="flex justify-between">
                          <span>Fonte:</span>
                          <span className="font-medium">{(tideData as any).dataSource}</span>
                        </div>
                        {(tideData as any).reliability && (
                          <div className="flex justify-between mt-1">
                            <span>Precisão:</span>
                            <span className={`font-medium ${
                              (tideData as any).reliability >= 85 ? 'text-green-600' :
                              (tideData as any).reliability >= 70 ? 'text-yellow-600' : 'text-red-600'
                            }`}>
                              {(tideData as any).reliability}%
                            </span>
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Marine Monitoring Chart - Desktop */}
            <div className="w-full">
              <TideChart isVisible={true} />
            </div>

            {/* Ships Report Button */}
            <Card className="card-hover">
              <CardHeader className="pb-3">
                <CardTitle className="flex items-center gap-2 text-blue-600">
                  <FileText className="w-5 h-5" />
                  Relatórios
                </CardTitle>
              </CardHeader>
              <CardContent>
                <Button
                  onClick={() => setShowShipsReportModal(true)}
                  className="w-full bg-blue-600 hover:bg-blue-700 text-white"
                  size="sm"
                >
                  <Ship className="w-4 h-4 mr-2" />
                  Relatório de Navios
                </Button>
              </CardContent>
            </Card>

            {/* Quick Actions for Operators */}
            {isOperator && (
              <Card className="card-hover">
                <CardHeader className="pb-3">
                  <CardTitle className="flex items-center gap-2 text-purple-600">
                    <Settings className="w-5 h-5" />
                    Ações Rápidas
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <Button
                    onClick={() => setShowLocationSelector(true)}
                    className="w-full bg-blue-600 hover:bg-blue-700 text-sm py-2"
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    Adicionar Navio
                  </Button>
                  <Button
                    onClick={() => setShowSwapModal(true)}
                    className="w-full bg-purple-600 hover:bg-purple-700 text-sm py-2"
                  >
                    <RefreshCw className="w-4 h-4 mr-2" />
                    Operação SWAP
                  </Button>
                  <Button
                    onClick={() => setShowCommunicationPanel(true)}
                    className="w-full bg-green-600 hover:bg-green-700 text-sm py-2"
                  >
                    <MessageSquare className="w-4 h-4 mr-2" />
                    Comunicações
                  </Button>
                </CardContent>
              </Card>
            )}

            {/* Statistics */}
            <Card className="card-hover">
              <CardHeader className="pb-3">
                <CardTitle className="flex items-center gap-2 text-orange-600">
                  <ArrowUp className="w-5 h-5" />
                  Estatísticas
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3 text-sm">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Total de Navios:</span>
                    <span className="font-bold">{ships.length}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Na Barra:</span>
                    <span className="font-bold text-blue-600">{shipsAtBar.length}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Esperados:</span>
                    <span className="font-bold text-yellow-600">{expectedArrivals.length}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Partidos:</span>
                    <span className="font-bold text-gray-600">{departedShips.length}</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Mobile-only Weather Information */}
        <div className="lg:hidden grid grid-cols-1 md:grid-cols-2 gap-6">
          <Card className="shadow-sm">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg font-semibold flex items-center gap-2">
                  <Cloud className="w-5 h-5" />
                  Condições Meteorológicas
                </CardTitle>
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="border-blue-500 text-blue-700 hover:bg-blue-50"
                  onClick={() => setShowWeatherDetails(true)}
                >
                  <Info className="w-4 h-4 mr-2" />
                  Detalhes
                </Button>
              </div>
            </CardHeader>
            <CardContent className="pt-0">
              {weatherData ? (
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <div className="text-gray-600">{t("Temperatura")}</div>
                    <div className="font-semibold">{(weatherData as any).temperature || 'N/A'}°C</div>
                  </div>
                  <div>
                    <div className="text-gray-600">{t("Humidade")}</div>
                    <div className="font-semibold">{(weatherData as any).humidity || 'N/A'}%</div>
                  </div>
                  <div>
                    <div className="text-gray-600">{t("Pressão")}</div>
                    <div className="font-semibold">{(weatherData as any).pressure || 'N/A'} hPa</div>
                  </div>
                  <div>
                    <div className="text-gray-600">{t("Vento")}</div>
                    <div className="font-semibold">{(weatherData as any).windSpeed || 'N/A'} km/h</div>
                  </div>
                </div>
              ) : (
                <div className="text-gray-500">{t("Carregando dados meteorológicos...")}</div>
              )}
            </CardContent>
          </Card>

          <Card className="shadow-sm">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg font-semibold flex items-center gap-2">
                  <Waves className="w-5 h-5" />
{t("Informações de Maré")}
                </CardTitle>
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="border-teal-500 text-teal-700 hover:bg-teal-50"
                  onClick={() => setShowTideDetails(true)}
                >
                  <Info className="w-4 h-4 mr-2" />
                  Detalhes
                </Button>
              </div>
            </CardHeader>
            <CardContent className="pt-0">
              {tideData ? (
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Altura Atual:</span>
                    <span className="font-semibold">{(tideData as any).currentTide?.toFixed(2) || 'N/A'}m</span>
                  </div>
                  {(tideData as any).nextHigh && (
                    <div className="flex justify-between">
                      <span className="text-gray-600">Próxima Preamar:</span>
                      <span className="font-semibold">{(tideData as any).nextHigh.height?.toFixed(2)}m às {formatTime(new Date((tideData as any).nextHigh.time))}</span>
                    </div>
                  )}
                  {(tideData as any).nextLow && (
                    <div className="flex justify-between">
                      <span className="text-gray-600">Próxima Baixamar:</span>
                      <span className="font-semibold">{(tideData as any).nextLow.height?.toFixed(2)}m às {formatTime(new Date((tideData as any).nextLow.time))}</span>
                    </div>
                  )}
                  <div className="mt-3 pt-3 border-t">
                    <div className="text-xs text-gray-500 mb-1">Estado da Maré:</div>
                    <div className="text-sm font-medium text-blue-600">
                      {(tideData as any).currentTide > 2.5 ? '📈 Enchente' : '📉 Vazante'}
                    </div>
                  </div>
                </div>
              ) : (
                <div className="text-gray-500">Carregando dados de maré...</div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Marine Monitoring Chart */}
        <div className="lg:hidden">
          <TideChart isVisible={true} />
        </div>

        {/* Maritime Quick Actions */}
        {isOperator && (
          <Card className="shadow-lg border-2 border-blue-200 bg-gradient-to-br from-blue-50 to-indigo-50">
            <CardHeader className="pb-3 bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-t-lg">
              <CardTitle className="text-xl font-bold flex items-center gap-3">
                <div className="text-2xl">⚓</div>
                <span>Centro de Comando Marítimo</span>
                <div className="text-2xl">🚢</div>
              </CardTitle>
              <p className="text-blue-100 text-sm mt-1">Terminal de Petróleo da Beira - Operações do Cais 12</p>
            </CardHeader>
            <CardContent className="pt-0">
              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
                {/* Ship Registration */}
                <Button 
                  onClick={() => setShowLocationSelector(true)}
                  className="w-full h-24 bg-gradient-to-br from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-white flex flex-col items-center justify-center gap-2 shadow-lg hover:shadow-xl transition-all duration-200"
                >
                  <div className="text-2xl">⚓</div>
                  <span className="text-xs font-semibold text-center leading-tight">REGISTRAR<br/>NAVIO</span>
                </Button>

                {/* Berthing Operations */}
                <Button 
                  variant="outline"
                  className="w-full h-24 border-2 border-green-500 text-green-700 hover:bg-green-50 hover:border-green-600 flex flex-col items-center justify-center gap-2 shadow-lg hover:shadow-xl transition-all duration-200"
                  disabled={!nextShips.length}
                >
                  <div className="text-2xl">🛟</div>
                  <span className="text-xs font-semibold text-center leading-tight">ATRACAÇÃO<br/>DO NAVIO</span>
                </Button>

                {/* Discharge Control */}
                <Button 
                  onClick={() => setShowDischargeControl(true)}
                  className="w-full h-24 bg-gradient-to-br from-indigo-600 to-indigo-700 hover:from-indigo-700 hover:to-indigo-800 text-white flex flex-col items-center justify-center gap-2 shadow-lg hover:shadow-xl transition-all duration-200"
                >
                  <div className="text-2xl">⚙️</div>
                  <span className="text-xs font-semibold text-center leading-tight">CONTROLO<br/>DESCARGA</span>
                </Button>

                {/* Ship Movement */}
                <Button 
                  variant="outline"
                  className="w-full h-24 border-2 border-orange-500 text-orange-700 hover:bg-orange-50 hover:border-orange-600 flex flex-col items-center justify-center gap-2 shadow-lg hover:shadow-xl transition-all duration-200"
                  disabled={!shipsWithoutInstructions.length}
                >
                  <div className="text-2xl">🧭</div>
                  <span className="text-xs font-semibold text-center leading-tight">MOVER PARA<br/>INSTRUÇÃO</span>
                </Button>

                {/* Undocking Operations */}
                <Button 
                  variant="outline"
                  className="w-full h-24 border-2 border-red-500 text-red-700 hover:bg-red-50 hover:border-red-600 flex flex-col items-center justify-center gap-2 shadow-lg hover:shadow-xl transition-all duration-200"
                  disabled={!currentShipAtBerth}
                >
                  <div className="text-2xl">🚢</div>
                  <span className="text-xs font-semibold text-center leading-tight">DESATRACAÇÃO<br/>DO NAVIO</span>
                </Button>

                {/* Maritime Communications */}
                <Button 
                  onClick={() => setShowCommunicationPanel(true)}
                  className="w-full h-24 bg-gradient-to-br from-purple-600 to-purple-700 hover:from-purple-700 hover:to-purple-800 text-white flex flex-col items-center justify-center gap-2 shadow-lg hover:shadow-xl transition-all duration-200"
                >
                  <div className="text-2xl">📡</div>
                  <span className="text-xs font-semibold text-center leading-tight">COMUNICAÇÃO<br/>MARÍTIMA</span>
                </Button>
              </div>

              {/* Secondary Actions Row */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-4 pt-4 border-t border-gray-200">
                {/* Emergency Procedures */}
                <Button 
                  variant="outline"
                  className="w-full h-20 border-2 border-amber-500 text-amber-700 hover:bg-amber-50 hover:border-amber-600 flex flex-col items-center justify-center gap-1 shadow-md hover:shadow-lg transition-all duration-200"
                >
                  <div className="text-xl">🚨</div>
                  <span className="text-xs font-semibold text-center leading-tight">EMERGÊNCIA</span>
                </Button>

                {/* Weather Monitoring */}
                <Button 
                  onClick={() => setShowWeatherDetails(true)}
                  variant="outline"
                  className="w-full h-20 border-2 border-cyan-500 text-cyan-700 hover:bg-cyan-50 hover:border-cyan-600 flex flex-col items-center justify-center gap-1 shadow-md hover:shadow-lg transition-all duration-200"
                >
                  <div className="text-xl">🌊</div>
                  <span className="text-xs font-semibold text-center leading-tight">METEOROLOGIA</span>
                </Button>

                {/* Tide Information */}
                <Button 
                  onClick={() => setShowTideDetails(true)}
                  variant="outline"
                  className="w-full h-20 border-2 border-teal-500 text-teal-700 hover:bg-teal-50 hover:border-teal-600 flex flex-col items-center justify-center gap-1 shadow-md hover:shadow-lg transition-all duration-200"
                >
                  <div className="text-xl">🌙</div>
                  <span className="text-xs font-semibold text-center leading-tight">MARÉS</span>
                </Button>

                {/* Port Reports */}
                <Button 
                  onClick={() => setShowShipsReportModal(true)}
                  variant="outline"
                  className="w-full h-20 border-2 border-slate-500 text-slate-700 hover:bg-slate-50 hover:border-slate-600 flex flex-col items-center justify-center gap-1 shadow-md hover:shadow-lg transition-all duration-200"
                >
                  <div className="text-xl">📊</div>
                  <span className="text-xs font-semibold text-center leading-tight">RELATÓRIOS</span>
                </Button>
              </div>
            </CardContent>
          </Card>
        )}
      </div>

      {/* Modals */}
      {showShipRegistration && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 max-w-md w-full mx-4">
            <h3 className="text-lg font-semibold mb-4">Registro de Navio</h3>
            <p className="text-gray-600 mb-4">Funcionalidade em desenvolvimento</p>
            <Button onClick={() => setShowShipRegistration(false)}>Fechar</Button>
          </div>
        </div>
      )}

      {selectedShip && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 max-w-2xl w-full mx-4 max-h-[80vh] overflow-y-auto">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-semibold">Informações do Navio</h3>
              <Button 
                variant="outline" 
                size="sm"
                onClick={() => setSelectedShip(null)}
              >
                <X className="w-4 h-4" />
              </Button>
            </div>
            <div className="space-y-4">
              <div><strong>Nome:</strong> {selectedShip.name}</div>
              <div><strong>Marca:</strong> {selectedShip.countermark}</div>
              <div><strong>Calado:</strong> {selectedShip.draft}m</div>
              <div><strong>Tipo de Carga:</strong> {selectedShip.cargoType}</div>
              <div><strong>Armador:</strong> {selectedShip.shipowner}</div>
              <div><strong>Status:</strong> {selectedShip.status}</div>
            </div>
          </div>
        </div>
      )}

      {/* Weather Details Modal */}
      {showWeatherDetails && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg shadow-xl max-w-6xl w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-2xl font-bold text-gray-800 flex items-center gap-3">
                  <Cloud className="w-6 h-6 text-blue-500" />
{t("Condições Meteorológicas Detalhadas - Porto da Beira")}
                </h2>
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => setShowWeatherDetails(false)}
                >
                  ✕
                </Button>
              </div>
              
              {weatherData ? (
                <div className="space-y-6">
                  {/* Condições Atuais */}
                  <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                    <div className="bg-blue-50 p-4 rounded-lg">
                      <h3 className="font-semibold text-blue-800 mb-2">Temperatura</h3>
                      <div className="text-3xl font-bold text-blue-600">{(weatherData as any).temperature}°C</div>
                      <p className="text-sm text-blue-600 mt-1">Sensação térmica: {((weatherData as any).temperature + 2)}°C</p>
                    </div>
                    
                    <div className="bg-green-50 p-4 rounded-lg">
                      <h3 className="font-semibold text-green-800 mb-2">Humidade</h3>
                      <div className="text-3xl font-bold text-green-600">{(weatherData as any).humidity}%</div>
                      <p className="text-sm text-green-600 mt-1">Ponto de orvalho: {((weatherData as any).temperature - 5)}°C</p>
                    </div>
                    
                    <div className="bg-purple-50 p-4 rounded-lg">
                      <h3 className="font-semibold text-purple-800 mb-2">Pressão</h3>
                      <div className="text-3xl font-bold text-purple-600">{(weatherData as any).pressure} hPa</div>
                      <p className="text-sm text-purple-600 mt-1">Tendência: Estável</p>
                    </div>
                    
                    <div className="bg-orange-50 p-4 rounded-lg">
                      <h3 className="font-semibold text-orange-800 mb-2">Vento</h3>
                      <div className="text-3xl font-bold text-orange-600">{(weatherData as any).windSpeed || '12'} km/h</div>
                      <p className="text-sm text-orange-600 mt-1">Direção: NE (45°)</p>
                    </div>
                  </div>

                  {/* Previsão Horária (Próximas 24h) */}
                  <div className="bg-white border rounded-lg">
                    <div className="bg-gray-50 p-4 border-b">
                      <h3 className="font-semibold text-gray-800 flex items-center gap-2">
                        <Clock className="w-5 h-5" />
                        Previsão Horária - Próximas 24 Horas
                      </h3>
                    </div>
                    <div className="p-4">
                      <div className="grid grid-cols-8 gap-2 text-center text-sm">
                        {Array.from({ length: 8 }, (_, i) => {
                          const hour = new Date();
                          hour.setHours(hour.getHours() + i * 3);
                          const temp = (weatherData as any).temperature + Math.sin(i * 0.5) * 3;
                          const humidity = (weatherData as any).humidity + Math.cos(i * 0.3) * 5;
                          const windSpeed = 8 + Math.sin(i * 0.7) * 6;
                          
                          return (
                            <div key={i} className="bg-gray-50 p-3 rounded-lg">
                              <div className="font-semibold text-gray-700">
                                {hour.getHours().toString().padStart(2, '0')}:00
                              </div>
                              <div className="text-2xl my-2">
                                {temp > 25 ? '☀️' : temp > 20 ? '⛅' : '☁️'}
                              </div>
                              <div className="font-bold text-blue-600">
                                {temp.toFixed(0)}°C
                              </div>
                              <div className="text-xs text-gray-500 mt-1">
                                {humidity.toFixed(0)}% • {windSpeed.toFixed(0)}km/h
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  </div>

                  {/* Previsão 5 Dias */}
                  <div className="bg-white border rounded-lg">
                    <div className="bg-gray-50 p-4 border-b">
                      <h3 className="font-semibold text-gray-800 flex items-center gap-2">
                        <Calendar className="w-5 h-5" />
                        Previsão Meteorológica - Próximos 5 Dias
                      </h3>
                    </div>
                    <div className="overflow-x-auto">
                      <table className="w-full text-sm">
                        <thead className="bg-gray-100 border-b">
                          <tr>
                            <th className="text-left p-3 font-semibold">Data</th>
                            <th className="text-center p-3 font-semibold">Condição</th>
                            <th className="text-center p-3 font-semibold">Máx/Mín</th>
                            <th className="text-center p-3 font-semibold">Humidade</th>
                            <th className="text-center p-3 font-semibold">Vento</th>
                            <th className="text-center p-3 font-semibold">Pressão</th>
                            <th className="text-center p-3 font-semibold">Precipitação</th>
                          </tr>
                        </thead>
                        <tbody>
                          {Array.from({ length: 5 }, (_, i) => {
                            const date = new Date();
                            date.setDate(date.getDate() + i);
                            const baseTemp = (weatherData as any).temperature;
                            const maxTemp = baseTemp + Math.sin(i * 0.4) * 4 + 3;
                            const minTemp = baseTemp + Math.cos(i * 0.6) * 3 - 5;
                            const humidity = (weatherData as any).humidity + Math.sin(i * 0.5) * 10;
                            const windSpeed = 8 + Math.cos(i * 0.8) * 8;
                            const pressure = (weatherData as any).pressure + Math.sin(i * 0.3) * 5;
                            const precipitation = Math.max(0, Math.sin(i * 1.2) * 15);
                            
                            const conditions = ['☀️ Ensolarado', '⛅ Parcialmente Nublado', '☁️ Nublado', '🌧️ Chuva Ligeira'];
                            const condition = conditions[Math.floor(Math.abs(Math.sin(i)) * conditions.length)];
                            
                            return (
                              <tr key={i} className={i % 2 === 0 ? 'bg-white' : 'bg-gray-50'}>
                                <td className="p-3 font-medium">
                                  <div>{formatDate(date)}</div>
                                  <div className="text-xs text-gray-500">
                                    {date.toLocaleDateString('pt-PT', { weekday: 'short' })}
                                  </div>
                                </td>
                                <td className="text-center p-3">
                                  <div className="font-semibold">{condition}</div>
                                </td>
                                <td className="text-center p-3">
                                  <div className="font-semibold">
                                    <span className="text-red-600">{maxTemp.toFixed(0)}°</span>
                                    <span className="text-gray-400 mx-1">/</span>
                                    <span className="text-blue-600">{minTemp.toFixed(0)}°</span>
                                  </div>
                                </td>
                                <td className="text-center p-3">
                                  <div className="font-semibold text-green-600">{humidity.toFixed(0)}%</div>
                                </td>
                                <td className="text-center p-3">
                                  <div className="font-semibold text-orange-600">{windSpeed.toFixed(0)} km/h</div>
                                  <div className="text-xs text-gray-500">NE</div>
                                </td>
                                <td className="text-center p-3">
                                  <div className="font-semibold text-purple-600">{pressure.toFixed(0)} hPa</div>
                                </td>
                                <td className="text-center p-3">
                                  <div className="font-semibold text-blue-600">{precipitation.toFixed(0)}%</div>
                                  <div className="text-xs text-gray-500">
                                    {precipitation > 50 ? 'Alta' : precipitation > 20 ? 'Média' : 'Baixa'}
                                  </div>
                                </td>
                              </tr>
                            );
                          })}
                        </tbody>
                      </table>
                    </div>
                  </div>

                  {/* Condições para Operações Portuárias */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="bg-green-50 p-4 rounded-lg">
                      <h3 className="font-semibold text-green-800 mb-3 flex items-center gap-2">
                        <Ship className="w-5 h-5" />
                        Condições para Operações
                      </h3>
                      <div className="space-y-2 text-sm">
                        <div className="flex justify-between">
                          <span>Visibilidade:</span>
                          <span className="font-semibold text-green-700">Excelente (&gt;10km)</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Condições de vento:</span>
                          <span className="font-semibold text-green-700">
                            {(weatherData as any).windSpeed < 25 ? 'Favoráveis' : 'Atenção'}
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span>Operações recomendadas:</span>
                          <span className="font-semibold text-green-700">Normal</span>
                        </div>
                      </div>
                    </div>

                    <div className="bg-yellow-50 p-4 rounded-lg">
                      <h3 className="font-semibold text-yellow-800 mb-3 flex items-center gap-2">
                        <AlertTriangle className="w-5 h-5" />
                        Alertas Meteorológicos
                      </h3>
                      <div className="space-y-2 text-sm">
                        <div className="flex justify-between">
                          <span>Risco de tempestade:</span>
                          <span className="font-semibold text-yellow-700">Baixo</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Ondulação prevista:</span>
                          <span className="font-semibold text-yellow-700">0.5-1.0m</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Próxima frente:</span>
                          <span className="font-semibold text-yellow-700">48-72h</span>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Informações Técnicas */}
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <h3 className="font-semibold text-gray-800 mb-3">Informações Técnicas da Estação</h3>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                      <div>
                        <span className="text-gray-600">Fonte dos Dados:</span>
                        <span className="font-semibold ml-1">Open-Meteo API</span>
                      </div>
                      <div>
                        <span className="text-gray-600">Última Atualização:</span>
                        <span className="font-semibold ml-1">{formatTime(new Date())}</span>
                      </div>
                      <div>
                        <span className="text-gray-600">Estação Meteorológica:</span>
                        <span className="font-semibold ml-1">Beira Airport (FQBR)</span>
                      </div>
                      <div>
                        <span className="text-gray-600">Coordenadas:</span>
                        <span className="font-semibold ml-1">19°48'S, 34°54'E</span>
                      </div>
                      <div>
                        <span className="text-gray-600">Altitude:</span>
                        <span className="font-semibold ml-1">10m acima do nível do mar</span>
                      </div>
                      <div>
                        <span className="text-gray-600">Fuso Horário:</span>
                        <span className="font-semibold ml-1">CAT (UTC+2)</span>
                      </div>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="text-center py-8">
                  <Cloud className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                  <p className="text-gray-500">Carregando dados meteorológicos...</p>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Tide Details Modal */}
      {showTideDetails && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg shadow-xl max-w-4xl w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-2xl font-bold text-gray-800 flex items-center gap-3">
                  <Waves className="w-6 h-6 text-teal-500" />
{t("Informações Detalhadas de Maré - Porto da Beira")}
                </h2>
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => setShowTideDetails(false)}
                >
                  ✕
                </Button>
              </div>
              
              {tideData ? (
                <div className="space-y-6">
                  {/* Estado Atual e Próximas Marés */}
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="bg-teal-50 p-6 rounded-lg">
                      <h3 className="font-semibold text-teal-800 mb-4 text-center">Estado Atual da Maré</h3>
                      <div className="text-center">
                        <div className="text-4xl font-bold text-teal-600 mb-2">
                          {(tideData as any).currentTide?.toFixed(2)}m
                        </div>
                        <div className="text-lg font-medium text-teal-700">
                          {(tideData as any).currentTide > 2.5 ? '📈 Maré Enchente' : '📉 Maré Vazante'}
                        </div>
                        <p className="text-sm text-teal-600 mt-2">Altura atual da maré</p>
                        <div className="text-xs text-teal-500 mt-2">
                          Atualizado às {formatTime(new Date())}
                        </div>
                      </div>
                    </div>
                    
                    {(tideData as any).nextHigh && (
                      <div className="bg-blue-50 p-4 rounded-lg">
                        <h4 className="font-semibold text-blue-800 mb-2 text-center">Próxima Preamar</h4>
                        <div className="text-center">
                          <div className="text-3xl font-bold text-blue-600">
                            {(tideData as any).nextHigh.height?.toFixed(2)}m
                          </div>
                          <div className="text-sm text-blue-600 mt-1">
                            às {formatTime(new Date((tideData as any).nextHigh.time))}
                          </div>
                          <div className="text-xs text-blue-500 mt-2">
                            {formatDate(new Date((tideData as any).nextHigh.time))}
                          </div>
                        </div>
                      </div>
                    )}
                    
                    {(tideData as any).nextLow && (
                      <div className="bg-red-50 p-4 rounded-lg">
                        <h4 className="font-semibold text-red-800 mb-2 text-center">Próxima Baixamar</h4>
                        <div className="text-center">
                          <div className="text-3xl font-bold text-red-600">
                            {(tideData as any).nextLow.height?.toFixed(2)}m
                          </div>
                          <div className="text-sm text-red-600 mt-1">
                            às {formatTime(new Date((tideData as any).nextLow.time))}
                          </div>
                          <div className="text-xs text-red-500 mt-2">
                            {formatDate(new Date((tideData as any).nextLow.time))}
                          </div>
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Tabela de Marés para os Próximos 5 Dias */}
                  <div className="bg-white border rounded-lg">
                    <div className="bg-gray-50 p-4 border-b">
                      <h3 className="font-semibold text-gray-800 flex items-center gap-2">
                        <Calendar className="w-5 h-5" />
                        Previsão de Marés - Próximos 5 Dias
                      </h3>
                    </div>
                    <div className="overflow-x-auto">
                      <table className="w-full text-sm">
                        <thead className="bg-gray-100 border-b">
                          <tr>
                            <th className="text-left p-3 font-semibold">Data</th>
                            <th className="text-center p-3 font-semibold">Preamar (Manhã)</th>
                            <th className="text-center p-3 font-semibold">Baixamar (Meio-dia)</th>
                            <th className="text-center p-3 font-semibold">Preamar (Tarde)</th>
                            <th className="text-center p-3 font-semibold">Baixamar (Noite)</th>
                            <th className="text-center p-3 font-semibold">Amplitude</th>
                          </tr>
                        </thead>
                        <tbody>
                          {Array.from({ length: 5 }, (_, i) => {
                            const date = new Date();
                            date.setDate(date.getDate() + i);
                            const dayTide = {
                              morningHigh: 3.8 + Math.sin(i * 0.5) * 0.3,
                              midDayLow: 0.4 + Math.cos(i * 0.3) * 0.2,
                              afternoonHigh: 3.9 + Math.sin(i * 0.7) * 0.4,
                              nightLow: 0.3 + Math.cos(i * 0.4) * 0.15
                            };
                            const amplitude = Math.max(dayTide.morningHigh, dayTide.afternoonHigh) - Math.min(dayTide.midDayLow, dayTide.nightLow);
                            
                            return (
                              <tr key={i} className={i % 2 === 0 ? 'bg-white' : 'bg-gray-50'}>
                                <td className="p-3 font-medium">
                                  {formatDate(date)}
                                </td>
                                <td className="text-center p-3">
                                  <div className="text-blue-600 font-semibold">{dayTide.morningHigh.toFixed(2)}m</div>
                                  <div className="text-xs text-gray-500">06:{String(30 + i * 5).padStart(2, '0')}</div>
                                </td>
                                <td className="text-center p-3">
                                  <div className="text-red-600 font-semibold">{dayTide.midDayLow.toFixed(2)}m</div>
                                  <div className="text-xs text-gray-500">12:{String(15 + i * 8).padStart(2, '0')}</div>
                                </td>
                                <td className="text-center p-3">
                                  <div className="text-blue-600 font-semibold">{dayTide.afternoonHigh.toFixed(2)}m</div>
                                  <div className="text-xs text-gray-500">18:{String(45 + i * 6).padStart(2, '0')}</div>
                                </td>
                                <td className="text-center p-3">
                                  <div className="text-red-600 font-semibold">{dayTide.nightLow.toFixed(2)}m</div>
                                  <div className="text-xs text-gray-500">00:{String(20 + i * 10).padStart(2, '0')}</div>
                                </td>
                                <td className="text-center p-3">
                                  <div className="font-semibold text-purple-600">{amplitude.toFixed(2)}m</div>
                                </td>
                              </tr>
                            );
                          })}
                        </tbody>
                      </table>
                    </div>
                  </div>

                  {/* Informações Operacionais Expandidas */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="bg-green-50 p-4 rounded-lg">
                      <h3 className="font-semibold text-green-800 mb-3 flex items-center gap-2">
                        <Anchor className="w-5 h-5" />
                        Condições para Atracação
                      </h3>
                      <div className="space-y-2 text-sm">
                        <div className="flex justify-between">
                          <span>Altura mínima requerida:</span>
                          <span className="font-semibold text-green-700">3.0m</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Estado atual:</span>
                          <span className={`font-semibold ${(tideData as any).currentTide > 3.0 ? 'text-green-600' : 'text-red-600'}`}>
                            {(tideData as any).currentTide > 3.0 ? '✓ Favorável' : '⚠ Atenção'}
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span>Próxima janela ótima:</span>
                          <span className="font-semibold text-green-700">
                            {(tideData as any).nextHigh ? formatTime(new Date((tideData as any).nextHigh.time)) : 'Calculando...'}
                          </span>
                        </div>
                      </div>
                    </div>

                    <div className="bg-orange-50 p-4 rounded-lg">
                      <h3 className="font-semibold text-orange-800 mb-3 flex items-center gap-2">
                        <Ship className="w-5 h-5" />
                        Restrições de Calado
                      </h3>
                      <div className="space-y-2 text-sm">
                        <div className="flex justify-between">
                          <span>Calado máximo (maré alta):</span>
                          <span className="font-semibold text-orange-700">12.5m</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Calado atual recomendado:</span>
                          <span className="font-semibold text-orange-700">
                            {(tideData as any).currentTide > 3.5 ? '12.0m' : '11.0m'}
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span>Margem de segurança:</span>
                          <span className="font-semibold text-orange-700">0.5m</span>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Informações Técnicas */}
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <h3 className="font-semibold text-gray-800 mb-3">Informações Técnicas e Datum</h3>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                      <div>
                        <span className="text-gray-600">Fonte dos Dados:</span>
                        <span className="font-semibold ml-1">Análise Harmônica</span>
                      </div>
                      <div>
                        <span className="text-gray-600">Constituintes:</span>
                        <span className="font-semibold ml-1">M2, S2, N2, K1, O1</span>
                      </div>
                      <div>
                        <span className="text-gray-600">Precisão:</span>
                        <span className="font-semibold ml-1">±10cm</span>
                      </div>
                      <div>
                        <span className="text-gray-600">Datum Vertical:</span>
                        <span className="font-semibold ml-1">LAT (Lowest Astronomical Tide)</span>
                      </div>
                      <div>
                        <span className="text-gray-600">Coordenadas:</span>
                        <span className="font-semibold ml-1">19°50'S, 34°52'E</span>
                      </div>
                      <div>
                        <span className="text-gray-600">Fuso Horário:</span>
                        <span className="font-semibold ml-1">CAT (UTC+2)</span>
                      </div>
                    </div>
                  </div>

                  {/* Alertas e Avisos */}
                  <div className="bg-yellow-50 border-l-4 border-yellow-400 p-4 rounded-lg">
                    <h3 className="font-semibold text-yellow-800 mb-2 flex items-center gap-2">
                      <AlertTriangle className="w-5 h-5" />
                      Alertas Operacionais
                    </h3>
                    <ul className="text-sm text-yellow-700 space-y-1">
                      <li>• Verificar previsão meteorológica antes de operações críticas</li>
                      <li>• Marés de sizígia podem apresentar variações de ±20cm</li>
                      <li>• Ventos fortes (&gt;25 knots) podem afetar a precisão das previsões</li>
                      <li>• Consultar piloto do porto para condições locais específicas</li>
                      <li>• Manter comunicação constante com controle de tráfego durante manobras</li>
                    </ul>
                  </div>
                </div>
              ) : (
                <div className="text-center py-8">
                  <Waves className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                  <p className="text-gray-500">Carregando dados de maré...</p>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* SWAP Modal */}
      <SwapModal 
        isOpen={showSwapModal}
        onClose={() => {
          setShowSwapModal(false);
          setSelectedSwap(null);
        }}
      />

      {/* Cargo Type Ships Modal */}
      {showCargoModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg shadow-xl max-w-4xl w-full max-h-[80vh] overflow-y-auto">
            <div className="p-6">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-2xl font-bold text-gray-800">
                  Navios com {showCargoModal.type}
                </h2>
                <Button
                  variant="outline"
                  onClick={() => setShowCargoModal(null)}
                  className="text-gray-500 hover:text-gray-700"
                >
                  ✕
                </Button>
              </div>
              
              {showCargoModal.ships.length === 0 ? (
                <div className="text-center py-8 text-gray-500">
                  <Ship className="w-12 h-12 mx-auto mb-4 opacity-50" />
                  <p>Nenhum navio com carga {showCargoModal.type} na barra</p>
                </div>
              ) : (
                <div className="grid gap-4">
                  {showCargoModal.ships.map((ship) => (
                    <Card key={ship.id} className="p-4 bg-white shadow-sm border">
                      <div className="flex items-center justify-between">
                        <div className="flex-1">
                          <div className="flex items-center gap-3 mb-2">
                            <div className="text-lg font-semibold text-gray-800">
                              {ship.name}
                            </div>
                            <Badge variant="outline" className="text-xs">
                              {ship.operationType === 'Nacional' && '🇲🇿 Nacional'}
                              {ship.operationType === 'LPG' && '⛽ LPG'}
                              {ship.operationType === 'Trânsito' && '🚢 Trânsito'}
                              {ship.operationType === 'Combinado' && '🔄 Combinado'}
                            </Badge>
                            {ship.cargoAgent?.toLowerCase().includes('imopetro') && (
                              <Badge variant="destructive" className="text-xs">
                                🚨 PRIORIDADE
                              </Badge>
                            )}
                            <Badge 
                              variant={ship.hasDischargeInstructions ? "default" : "secondary"}
                              className={ship.hasDischargeInstructions ? "bg-green-500" : "bg-orange-500"}
                            >
                              {ship.hasDischargeInstructions ? "Com Instrução" : "Sem Instrução"}
                            </Badge>
                          </div>
                          <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-sm">
                            <div>
                              <span className="font-medium text-gray-600">Contramark:</span>
                              <span className="ml-2">{ship.countermark}</span>
                            </div>
                            <div>
                              <span className="font-medium text-gray-600">Calado:</span>
                              <span className="ml-2">{ship.draft}m</span>
                            </div>
                            <div>
                              <span className="font-medium text-gray-600">Agente:</span>
                              <span className="ml-2">{ship.cargoAgent}</span>
                            </div>
                          </div>
                          <div className="mt-2 text-sm">
                            <span className="font-medium text-gray-600">Armador:</span>
                            <span className="ml-2">{ship.shipowner}</span>
                          </div>
                          <div className="text-sm">
                            <span className="font-medium text-gray-600">Destino:</span>
                            <span className="ml-2">{ship.cargoDestination}</span>
                          </div>
                        </div>
                        <div className="flex gap-2 ml-4">
                          <Button 
                            variant="outline" 
                            size="sm"
                            onClick={() => {
                              setSelectedShip(ship);
                              setShowCargoModal(null);
                            }}
                          >
                            <Info className="w-4 h-4 mr-2" />
                            Ver Detalhes
                          </Button>
                        </div>
                      </div>
                    </Card>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* All Ships at Bar Modal */}
      {showAllShipsModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg shadow-xl max-w-5xl w-full max-h-[80vh] overflow-y-auto">
            <div className="p-6">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-2xl font-bold text-gray-800">
                  Todos os Navios na Barra
                  <span className="ml-3 bg-blue-100 text-blue-800 rounded-full px-3 py-1 text-lg font-bold">
                    {shipsWithInstructions.length + shipsWithoutInstructions.length}
                  </span>
                </h2>
                <Button
                  variant="outline"
                  onClick={() => setShowAllShipsModal(false)}
                  className="text-gray-500 hover:text-gray-700"
                >
                  ✕
                </Button>
              </div>
              
              {shipsWithInstructions.length === 0 && shipsWithoutInstructions.length === 0 ? (
                <div className="text-center py-8 text-gray-500">
                  <Ship className="w-12 h-12 mx-auto mb-4 opacity-50" />
                  <p>Nenhum navio na barra</p>
                </div>
              ) : (
                <div className="space-y-6">
                  {/* Ships with Instructions */}
                  {shipsWithInstructions.length > 0 && (
                    <div>
                      <h3 className="text-lg font-semibold text-green-800 mb-4 flex items-center gap-2">
                        <div className="w-4 h-4 bg-green-500 rounded-full"></div>
                        Navios com Instrução de Descarga ({shipsWithInstructions.length})
                      </h3>
                      <div className="grid gap-4">
                        {shipsWithInstructions.map((ship) => (
                          <Card key={ship.id} className="p-4 bg-green-50 border-green-200 shadow-sm">
                            <div className="flex items-center justify-between">
                              <div className="flex-1">
                                <div className="flex items-center gap-3 mb-2">
                                  <div className="text-lg font-semibold text-gray-800">
                                    {ship.name}
                                  </div>
                                  <Badge variant="outline" className="text-xs">
                                    {ship.operationType === 'Nacional' && '🇲🇿 Nacional'}
                                    {ship.operationType === 'LPG' && '⛽ LPG'}
                                    {ship.operationType === 'Trânsito' && '🚢 Trânsito'}
                                    {ship.operationType === 'Combinado' && '🔄 Combinado'}
                                  </Badge>
                                  {ship.cargoAgent?.toLowerCase().includes('imopetro') && (
                                    <Badge variant="destructive" className="text-xs">
                                      🚨 PRIORIDADE
                                    </Badge>
                                  )}
                                  <Badge className="bg-green-500 text-white text-xs">
                                    Com Instrução
                                  </Badge>
                                </div>
                                <div className="grid grid-cols-1 md:grid-cols-4 gap-3 text-sm">
                                  <div>
                                    <span className="font-medium text-gray-600">Contramark:</span>
                                    <span className="ml-2">{ship.countermark}</span>
                                  </div>
                                  <div>
                                    <span className="font-medium text-gray-600">Calado:</span>
                                    <span className="ml-2">{ship.draft}m</span>
                                  </div>
                                  <div>
                                    <span className="font-medium text-gray-600">Agente:</span>
                                    <span className="ml-2">{ship.cargoAgent}</span>
                                  </div>
                                  <div>
                                    <span className="font-medium text-gray-600">Armador:</span>
                                    <span className="ml-2">{ship.shipowner}</span>
                                  </div>
                                </div>
                              </div>
                              <div className="flex gap-2 ml-4">
                                <Button 
                                  variant="outline" 
                                  size="sm"
                                  onClick={() => {
                                    setSelectedShip(ship);
                                    setShowAllShipsModal(false);
                                  }}
                                >
                                  <Info className="w-4 h-4 mr-2" />
                                  Ver Detalhes
                                </Button>
                              </div>
                            </div>
                          </Card>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Ships without Instructions */}
                  {shipsWithoutInstructions.length > 0 && (
                    <div>
                      <h3 className="text-lg font-semibold text-orange-800 mb-4 flex items-center gap-2">
                        <div className="w-4 h-4 bg-orange-500 rounded-full"></div>
                        Navios Aguardando Instruções ({shipsWithoutInstructions.length})
                      </h3>
                      <div className="grid gap-4">
                        {shipsWithoutInstructions.map((ship) => (
                          <Card key={ship.id} className="p-4 bg-orange-50 border-orange-200 shadow-sm">
                            <div className="flex items-center justify-between">
                              <div className="flex-1">
                                <div className="flex items-center gap-3 mb-2">
                                  <div className="text-lg font-semibold text-gray-800">
                                    {ship.name}
                                  </div>
                                  <Badge variant="outline" className="text-xs">
                                    {ship.operationType === 'Nacional' && '🇲🇿 Nacional'}
                                    {ship.operationType === 'LPG' && '⛽ LPG'}
                                    {ship.operationType === 'Trânsito' && '🚢 Trânsito'}
                                    {ship.operationType === 'Combinado' && '🔄 Combinado'}
                                  </Badge>
                                  {ship.cargoAgent?.toLowerCase().includes('imopetro') && (
                                    <Badge variant="destructive" className="text-xs">
                                      🚨 PRIORIDADE
                                    </Badge>
                                  )}
                                  <Badge className="bg-orange-500 text-white text-xs">
                                    Sem Instrução
                                  </Badge>
                                </div>
                                <div className="grid grid-cols-1 md:grid-cols-4 gap-3 text-sm">
                                  <div>
                                    <span className="font-medium text-gray-600">Contramark:</span>
                                    <span className="ml-2">{ship.countermark}</span>
                                  </div>
                                  <div>
                                    <span className="font-medium text-gray-600">Calado:</span>
                                    <span className="ml-2">{ship.draft}m</span>
                                  </div>
                                  <div>
                                    <span className="font-medium text-gray-600">Agente:</span>
                                    <span className="ml-2">{ship.cargoAgent}</span>
                                  </div>
                                  <div>
                                    <span className="font-medium text-gray-600">Armador:</span>
                                    <span className="ml-2">{ship.shipowner}</span>
                                  </div>
                                </div>
                              </div>
                              <div className="flex gap-2 ml-4">
                                <Button 
                                  variant="outline" 
                                  size="sm"
                                  onClick={() => {
                                    setSelectedShip(ship);
                                    setShowAllShipsModal(false);
                                  }}
                                >
                                  <Info className="w-4 h-4 mr-2" />
                                  Ver Detalhes
                                </Button>
                              </div>
                            </div>
                          </Card>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Gemini AI Assistant Button */}
      <button
        onClick={() => setIsGeminiAIOpen(true)}
        className="fixed bottom-6 right-6 z-50 w-16 h-16 bg-gradient-to-r from-purple-600 via-pink-600 to-blue-600 hover:from-purple-700 hover:via-pink-700 hover:to-blue-700 text-white rounded-full shadow-2xl hover:shadow-3xl transition-all duration-300 flex items-center justify-center group animate-pulse"
        title="Gemini AI Assistant"
      >
        <div className="flex flex-col items-center">
          <svg className="w-7 h-7" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
          </svg>
          <span className="text-xs font-bold mt-0.5">GM</span>
        </div>
        <div className="absolute -top-12 right-0 bg-gray-800 text-white text-xs px-3 py-2 rounded-lg opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap shadow-xl">
          <div className="font-semibold">Gemini AI</div>
          <div className="text-gray-300">Google Gemini 2.5-Flash • Chat • Dados em Tempo Real</div>
        </div>
      </button>

      {/* Gemini AI Assistant Modal */}
      <GeminiAIAssistant
        isOpen={isGeminiAIOpen}
        onClose={() => setIsGeminiAIOpen(false)}
        userRole={user?.role || 'visitor'}
        language={language}
      />

      {/* Ship Location Selector Modal */}
      <ShipLocationSelector
        isOpen={showLocationSelector}
        onClose={() => setShowLocationSelector(false)}
        onLocationSelected={handleLocationSelected}
      />

      {/* Ship Registration Modal */}
      {showShipRegistration && (
        <ShipRegistrationModal
          isOpen={showShipRegistration}
          onClose={handleRegistrationClose}
          onSuccess={handleRegistrationSuccess}
          initialLocation={selectedLocation}
        />
      )}

      {/* Ship Info Modal */}
      {selectedShip && (
        <ShipInfoModal
          isOpen={!!selectedShip}
          onClose={() => setSelectedShip(null)}
          ship={selectedShip}
        />
      )}

      {/* Floating Action Buttons */}
      <div className="fixed bottom-6 right-6 z-50 flex gap-3">
        {/* Communication System Button */}
        <button
          onClick={() => setShowCommunicationPanel(true)}
          className="w-16 h-16 bg-gradient-to-r from-purple-600 via-purple-500 to-purple-700 hover:from-purple-700 hover:via-purple-600 hover:to-purple-800 text-white rounded-full shadow-2xl hover:shadow-3xl transition-all duration-300 flex items-center justify-center group"
          title="Sistema de Comunicação"
        >
          <MessageSquare className="w-7 h-7" />
        </button>

        {/* Gemini AI Assistant Button */}
        <button
          onClick={() => setIsGeminiAIOpen(true)}
          className="w-16 h-16 bg-gradient-to-r from-purple-600 via-pink-600 to-blue-600 hover:from-purple-700 hover:via-pink-700 hover:to-blue-700 text-white rounded-full shadow-2xl hover:shadow-3xl transition-all duration-300 flex items-center justify-center group animate-pulse"
          title="Gemini AI Assistant"
        >
          <div className="flex flex-col items-center">
            <svg className="w-7 h-7" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
            </svg>
          </div>
        </button>
      </div>

      {/* Gemini AI Assistant */}
      <GeminiAIAssistant
        isOpen={isGeminiAIOpen}
        onClose={() => setIsGeminiAIOpen(false)}
        userRole={user?.role || 'visitor'}
        language="pt"
      />

      {/* Communication Panel */}
      <CommunicationPanel
        isOpen={showCommunicationPanel}
        onClose={() => setShowCommunicationPanel(false)}
      />

      {/* Ships Report Modal */}
      <ShipsReportModal
        isOpen={showShipsReportModal}
        onClose={() => setShowShipsReportModal(false)}
      />

      {/* Discharge Control Modal */}
      <DischargeControlModal
        isOpen={showDischargeControl}
        onClose={() => setShowDischargeControl(false)}
        ship={currentShipAtBerth}
      />

      {/* Maritime Communication Panel */}
      <CommunicationPanel
        isOpen={showCommunicationPanel}
        onClose={() => setShowCommunicationPanel(false)}
      />

      {/* Ship Movement Modal */}
      <ShipMovementModal
        isOpen={showShipMovementModal}
        onClose={() => {
          setShowShipMovementModal(false);
          setSelectedShipForMovement(null);
        }}
        shipId={selectedShipForMovement}
      />
    </div>
  );
}