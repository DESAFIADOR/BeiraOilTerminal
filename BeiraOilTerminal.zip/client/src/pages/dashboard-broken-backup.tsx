import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Clock, MapPin, Anchor, Ship, Waves, Wind, Thermometer, Eye, Calendar, Package, 
  Edit, Save, Plus, X, ArrowUp, CheckCircle, XCircle, Flag, Cloud, Mail
} from "lucide-react";
import { useClock } from "@/hooks/use-clock";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { formatTime, formatDate } from "@/lib/utils";
import { EnhancedShipCard } from "@/components/enhanced-ship-card";
import { ShipsQueue } from "@/components/ships-queue";
import { ShipRegistrationModal } from "@/components/ship-registration-modal";
import { BerthingRegistrationModal } from "@/components/berthing-registration-modal";
import { UndockingModal } from "@/components/undocking-modal";
import { DischargeUpdateModal } from "@/components/discharge-update-modal";
import { BerthMaintenanceModal } from "@/components/berth-maintenance-modal";
import { InstructionModal } from "@/components/instruction-modal";
import { ShipMovementModal } from "@/components/ship-movement-modal";
import { ShipInfoModal } from "@/components/ship-info-modal";
import { WeatherMonitoringCard } from "@/components/weather-monitoring-card";
import { TideInfoCard } from "@/components/tide-info-card";
import cfmLogo from "@assets/LogTipo_1749832282954.png";
import caisImage from "@assets/cais-terminal.png";

interface ShipWithDetails {
  id: number;
  name: string;
  countermark: string;
  draft: string;
  arrivalDateTime: string;
  status: string;
  shipAgent: string;
  cargoAgent: string;
  cargoType: string;
  operationType: string;
  shipowner: string;
  cargoDestination: string;
  shipAgentEmail?: string;
  cargoAgentEmail?: string;
  hasDischargeInstructions: boolean;
  parcels: {
    id: number;
    parcelNumber: string;
    product: string;
    volumeMT: string;
    volumeM3: string;
    density15C: string;
    receiver: string;
    owner: string;
    status: string;
    createdAt: Date | null;
    shipId: number;
  }[];
  latestProgress?: {
    id: number;
    shipId: number;
    parcelId: number;
    percentage: number;
    updatedAt: Date | null;
  };
}

interface BerthMaintenance {
  id: number;
  isActive: boolean;
  startDate: string;
  endDate: string;
  description: string;
  createdAt: Date | null;
  updatedAt: Date | null;
}

const Dashboard = () => {
  const clock = useClock();
  const { user, isLoading: authLoading } = useAuth();
  const { toast } = useToast();
  
  const [showShipRegistration, setShowShipRegistration] = useState(false);
  const [showBerthingModal, setShowBerthingModal] = useState(false);
  const [showUndockingModal, setShowUndockingModal] = useState(false);
  const [showDischargeModal, setShowDischargeModal] = useState(false);
  const [showBerthMaintenanceModal, setShowBerthMaintenanceModal] = useState(false);
  const [showInstructionModal, setShowInstructionModal] = useState(false);
  const [showShipMovementModal, setShowShipMovementModal] = useState(false);
  const [showShipInfo, setShowShipInfo] = useState(false);
  const [selectedShipId, setSelectedShipId] = useState<number | null>(null);
  const [selectedShipForInfo, setSelectedShipForInfo] = useState<ShipWithDetails | null>(null);
  const [defaultTab, setDefaultTab] = useState<string>("info");

  const isOperator = user?.role === 'operator' || user?.role === 'admin';

  // Data queries
  const { data: allShips = [] } = useQuery<ShipWithDetails[]>({
    queryKey: ['/api/ships'],
    refetchInterval: 30000,
  });

  const { data: weatherData } = useQuery({
    queryKey: ['/api/weather'],
    refetchInterval: 300000,
  });

  const { data: tideData } = useQuery({
    queryKey: ['/api/tide'],
    refetchInterval: 300000,
  });

  const { data: activeMaintenance } = useQuery<BerthMaintenance>({
    queryKey: ['/api/berth-maintenance/active'],
    refetchInterval: 30000,
  });

  // Ship categorization
  const currentShipAtBerth = allShips.find((ship: ShipWithDetails) => ship.status === 'at_berth');
  const nextShips = allShips.filter((ship: ShipWithDetails) => ship.status === 'next_to_berth');
  const shipsWithInstructions = allShips.filter((ship: ShipWithDetails) => 
    (ship.status === 'at_bar' || ship.status === 'next_to_berth') && ship.hasDischargeInstructions
  );
  const shipsWithoutInstructions = allShips.filter((ship: ShipWithDetails) => 
    ship.status === 'at_bar' && !ship.hasDischargeInstructions
  );
  const expectedArrivals = allShips.filter((ship: ShipWithDetails) => ship.status === 'expected');
  const departedShips = allShips.filter((ship: ShipWithDetails) => ship.status === 'departed');

  if (authLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-blue-100 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-4 text-gray-600">Carregando...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-blue-100 p-4">
      {/* Header */}
      <header className="bg-white shadow-lg rounded-lg mb-6 border border-gray-200">
        <div className="px-6 py-4">
          <div className="flex items-center justify-between">
            {/* Left Side - CFM Logo and Clock */}
            <div className="flex items-center space-x-4">
              {/* CFM Logo Circle */}
              <div className="flex flex-col items-center">
                <div className="w-24 h-24 bg-gradient-to-br from-blue-50 to-blue-100 rounded-full flex items-center justify-center border-4 border-blue-200 shadow-xl overflow-hidden">
                  <img 
                    src={cfmLogo} 
                    alt="CFM - Portos e Caminhos de Ferro de Moçambique" 
                    className="w-20 h-20 object-contain rounded-full bg-white p-1" 
                    style={{
                      imageRendering: 'crisp-edges',
                      filter: 'contrast(1.1) brightness(1.05)',
                      backfaceVisibility: 'hidden',
                      transform: 'translateZ(0)'
                    } as React.CSSProperties}
                  />
                </div>
              </div>

              {/* Clock Circle */}
              <div className="flex flex-col items-center">
                <div className="w-24 h-24 bg-gradient-to-br from-gray-50 to-gray-100 rounded-full flex items-center justify-center border-4 border-gray-200 shadow-xl">
                  <div className="text-center">
                    <div className="text-lg font-bold text-gray-800">{clock.time}</div>
                    <div className="text-xs text-gray-600">{clock.date}</div>
                  </div>
                </div>
              </div>
            </div>

            {/* Center - Title and System Info */}
            <div className="flex-1 text-center mx-8">
              <h1 className="text-2xl font-bold text-gray-800 mb-2">
                Line Up - Beira Oil Terminal
              </h1>
              <div className="flex flex-col items-center space-y-1">
                <div className="flex items-center space-x-2 text-sm text-gray-600">
                  <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                  <span>Sistema Operacional</span>
                </div>
                <p className="text-xs text-gray-500">
                  Developed by: Manuel Antonio, Eng.
                </p>
              </div>
            </div>

            {/* Right Side - Terminal Image and Auth */}
            <div className="flex items-center space-x-4">
              {/* Terminal Image Circle */}
              <div className="flex flex-col items-center">
                <div className="w-24 h-24 bg-gradient-to-br from-blue-50 to-blue-100 rounded-full flex items-center justify-center border-4 border-blue-200 shadow-xl overflow-hidden">
                  <img 
                    src={caisImage} 
                    alt="Terminal da Beira" 
                    className="w-20 h-20 object-cover rounded-full" 
                    style={{ filter: 'saturate(1.2)' }}
                  />
                </div>
                <p className="text-xs text-gray-600 mt-1">Terminal da Beira</p>
              </div>

              {/* Auth Circle */}
              <div className="flex flex-col items-center">
                <div className="w-24 h-24 bg-gradient-to-br from-green-50 to-green-100 rounded-full flex items-center justify-center border-4 border-green-200 shadow-xl">
                  {user ? (
                    <div className="text-center">
                      <div className="text-xs font-medium text-green-800">{user.firstName || user.username}</div>
                      <div className="text-xs text-green-600 mb-1">{user.role}</div>
                      <Button
                        onClick={() => window.location.href = '/api/logout'}
                        size="sm"
                        variant="outline"
                        className="text-xs py-0 px-2 h-6"
                      >
                        Sair
                      </Button>
                    </div>
                  ) : (
                    <Button
                      onClick={() => window.location.href = '/api/login'}
                      size="sm"
                      className="text-xs"
                    >
                      Entrar
                    </Button>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="space-y-6">
        {/* Berth Status Section */}
        <div className="space-y-4">
          {activeMaintenance?.isActive ? (
            <Card className="border-0 shadow-sm bg-red-50 border-red-200">
              <CardHeader className="pb-3">
                <CardTitle className="text-lg font-semibold flex items-center gap-2 text-red-700">
                  <Anchor className="w-5 h-5" />
                  CAIS EM MANUTENÇÃO
                </CardTitle>
              </CardHeader>
              <CardContent className="pt-0">
                <div className="text-center py-4">
                  <div className="text-red-600 font-bold text-sm mb-2">
                    {formatDate(new Date(activeMaintenance.startDate))} - {formatDate(new Date(activeMaintenance.endDate))}
                  </div>
                  <div 
                    className="text-red-800 text-xs uppercase leading-tight"
                    style={{ fontFamily: 'Algerian, sans-serif', fontSize: '10px' }}
                  >
                    MANUTENÇÃO PROGRAMADA DO CAIS (INSPEÇÃO ANUAL DOS MLA) & DIVERSOS TRABALHOS DE MANUTENÇÃO EM EQUIPAMENTOS USADOS NO CAIS
                  </div>
                </div>
              </CardContent>
            </Card>
          ) : currentShipAtBerth ? (
            <Card className="border-0 shadow-sm">
              <CardHeader className="pb-3">
                <CardTitle className="text-lg font-semibold flex items-center gap-2">
                  <Anchor className="w-5 h-5 text-blue-600" />
                  Navio no Cais 12
                </CardTitle>
              </CardHeader>
              <CardContent className="pt-0">
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="text-xl font-bold text-gray-900">{currentShipAtBerth.name}</h3>
                      <p className="text-sm text-gray-600">
                        Produto: {currentShipAtBerth.parcels?.map(p => p.product).join(', ') || 'N/A'}
                      </p>
                    </div>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => {
                        setSelectedShipForInfo(currentShipAtBerth);
                        setDefaultTab("info");
                        setShowShipInfo(true);
                      }}
                    >
                      <Eye className="w-4 h-4 mr-2" />
                      Informações
                    </Button>
                  </div>
                  
                  {/* Discharge Progress */}
                  <div className="bg-gradient-to-r from-blue-50 to-blue-100 rounded-lg p-4 border border-blue-200">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm font-medium text-blue-800">Progresso da Descarga</span>
                      <span className="text-2xl font-bold text-blue-900">
                        {currentShipAtBerth.latestProgress?.percentage || 0}%
                      </span>
                    </div>
                    <div className="w-full bg-blue-200 rounded-full h-3 mb-2">
                      <div 
                        className="bg-gradient-to-r from-blue-500 to-blue-600 h-3 rounded-full transition-all duration-300"
                        style={{ width: `${currentShipAtBerth.latestProgress?.percentage || 0}%` }}
                      ></div>
                    </div>
                    <div className="text-xs text-blue-700">
                      Volume Total: {currentShipAtBerth.parcels?.reduce((acc, p) => acc + parseFloat(p.volumeMT || '0'), 0).toFixed(2)} MT
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ) : (
            <Card className="border-0 shadow-sm">
              <CardHeader>
                <CardTitle className="text-lg font-semibold flex items-center gap-2">
                  <Anchor className="w-5 h-5 text-blue-600" />
                  Nenhum Navio no Cais
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-center py-8">
                  <p className="text-gray-500">O cais está disponível para atracação</p>
                </div>
              </CardContent>
            </Card>
          )}
        </div>

        {/* Other sections */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Next Ships Section */}
          <Card className="border-0 shadow-sm">
            <CardHeader className="pb-3">
              <CardTitle className="text-lg font-semibold flex items-center gap-2">
                <Clock className="w-5 h-5 text-green-600" />
                PRÓXIMOS 5 NAVIOS A ATRACAR
              </CardTitle>
            </CardHeader>
            <CardContent className="pt-0">
              <div className="space-y-3">
                {nextShips.length === 0 ? (
                  <p className="text-gray-500 text-center py-4">Nenhum navio próximo à atracação</p>
                ) : (
                  nextShips.slice(0, 5).map((ship: ShipWithDetails) => (
                    <ShipCard 
                      key={ship.id} 
                      ship={ship} 
                      onClick={() => {
                        setSelectedShipForInfo(ship);
                        setDefaultTab("info");
                        setShowShipInfo(true);
                      }}
                      actions={
                        isOperator ? [
                          {
                            label: "Atualizar Descarga",
                            icon: Package,
                            onClick: () => {
                              setSelectedShipId(ship.id);
                              setShowDischargeModal(true);
                            }
                          },
                          {
                            label: "Mover Navio",
                            icon: ArrowUp,
                            onClick: () => setShowShipMovementModal(true)
                          }
                        ] : []
                      }
                    />
                  ))
                )}
              </div>
            </CardContent>
          </Card>

          {/* Weather and Tide Section */}
          <Card className="border-0 shadow-sm">
            <CardHeader className="pb-3">
              <CardTitle className="text-lg font-semibold flex items-center gap-2">
                <Cloud className="w-5 h-5 text-blue-600" />
                Condições Meteorológicas
              </CardTitle>
            </CardHeader>
            <CardContent className="pt-0">
              {weatherData ? (
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="text-center p-3 bg-blue-50 rounded-lg">
                      <div className="text-2xl font-bold text-blue-600">
                        {Math.round((weatherData as any).temperature)}°C
                      </div>
                      <div className="text-sm text-gray-600">Temperatura</div>
                    </div>
                    <div className="text-center p-3 bg-green-50 rounded-lg">
                      <div className="text-2xl font-bold text-green-600">
                        {Math.round((weatherData as any).windSpeed)} km/h
                      </div>
                      <div className="text-sm text-gray-600">Vento</div>
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="text-center p-3 bg-purple-50 rounded-lg">
                      <div className="text-2xl font-bold text-purple-600">
                        {Math.round((weatherData as any).humidity)}%
                      </div>
                      <div className="text-sm text-gray-600">Humidade</div>
                    </div>
                    <div className="text-center p-3 bg-orange-50 rounded-lg">
                      <div className="text-2xl font-bold text-orange-600">
                        {Math.round((weatherData as any).pressure)} hPa
                      </div>
                      <div className="text-sm text-gray-600">Pressão</div>
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="text-center p-3 bg-cyan-50 rounded-lg">
                      <div className="text-lg font-bold text-cyan-600">
                        {formatTime((tideData as any)?.nextHigh?.time)} 
                      </div>
                      <div className="text-sm text-gray-600">Próxima Maré Alta</div>
                      <div className="text-xs text-gray-500">
                        {(tideData as any)?.nextHigh?.height?.toFixed(1)}m
                      </div>
                    </div>
                    <div className="text-center p-3 bg-indigo-50 rounded-lg">
                      <div className="text-lg font-bold text-indigo-600">
                        {formatTime((tideData as any)?.nextLow?.time)}
                      </div>
                      <div className="text-sm text-gray-600">Próxima Maré Baixa</div>
                      <div className="text-xs text-gray-500">
                        {(tideData as any)?.nextLow?.height?.toFixed(1)}m
                      </div>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="text-center py-4">
                  <p className="text-gray-500">Carregando dados meteorológicos...</p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Ships with and without instructions sections */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <ShipsSection
            title="Navios com Instrução de Descarga"
            ships={shipsWithInstructions}
            icon={CheckCircle}
            iconColor="text-green-600"
            emptyMessage="Nenhum navio com instrução de descarga"
            onShipClick={(ship) => {
              setSelectedShipForInfo(ship);
              setDefaultTab("info");
              setShowShipInfo(true);
            }}
            isOperator={isOperator}
            onUpdateDischarge={(shipId) => {
              setSelectedShipId(shipId);
              setShowDischargeModal(true);
            }}
            onMoveShip={() => setShowShipMovementModal(true)}
          />

          <ShipsSection
            title="Navios sem Instrução de Descarga"
            ships={shipsWithoutInstructions}
            icon={XCircle}
            iconColor="text-red-600"
            emptyMessage="Nenhum navio sem instrução de descarga"
            onShipClick={(ship) => {
              setSelectedShipForInfo(ship);
              setDefaultTab("info");
              setShowShipInfo(true);
            }}
            isOperator={isOperator}
            onUpdateDischarge={(shipId) => {
              setSelectedShipId(shipId);
              setShowDischargeModal(true);
            }}
            onMoveShip={() => setShowShipMovementModal(true)}
          />
        </div>

        {/* Expected arrivals and departed ships sections */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <ShipsSection
            title="Previstos a Chegar"
            ships={expectedArrivals}
            icon={Ship}
            iconColor="text-blue-600"
            emptyMessage="Nenhum navio previsto para chegar"
            onShipClick={(ship) => {
              setSelectedShipForInfo(ship);
              setDefaultTab("info");
              setShowShipInfo(true);
            }}
            isOperator={isOperator}
            onUpdateDischarge={(shipId) => {
              setSelectedShipId(shipId);
              setShowDischargeModal(true);
            }}
            onMoveShip={() => setShowShipMovementModal(true)}
          />

          <ShipsSection
            title="Navios que Partiram"
            ships={departedShips}
            icon={Flag}
            iconColor="text-gray-600"
            emptyMessage="Nenhum navio partiu"
            onShipClick={(ship) => {
              setSelectedShipForInfo(ship);
              setDefaultTab("info");
              setShowShipInfo(true);
            }}
            isOperator={isOperator}
            onUpdateDischarge={(shipId) => {
              setSelectedShipId(shipId);
              setShowDischargeModal(true);
            }}
            onMoveShip={() => setShowShipMovementModal(true)}
          />
        </div>

        {/* Quick Actions - only for operators */}
        {isOperator && (
          <Card className="border-0 shadow-sm">
            <CardHeader>
              <CardTitle className="text-lg font-semibold">Ações Rápidas</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
                <Button 
                  onClick={() => setShowShipRegistration(true)}
                  className="flex flex-col items-center gap-2 h-auto py-4"
                >
                  <Plus className="w-6 h-6" />
                  <span className="text-sm">Registar Navio</span>
                </Button>
                <Button 
                  onClick={() => setShowBerthingModal(true)}
                  className="flex flex-col items-center gap-2 h-auto py-4"
                  disabled={!currentShipAtBerth}
                >
                  <Anchor className="w-6 h-6" />
                  <span className="text-sm">Atracação do Navio</span>
                </Button>
                <Button 
                  onClick={() => setShowDischargeModal(true)}
                  className="flex flex-col items-center gap-2 h-auto py-4"
                  disabled={!currentShipAtBerth}
                >
                  <Package className="w-6 h-6" />
                  <span className="text-sm">Atualizar Descarga</span>
                </Button>
                <Button 
                  onClick={() => setShowUndockingModal(true)}
                  className="flex flex-col items-center gap-2 h-auto py-4"
                  disabled={!currentShipAtBerth}
                >
                  <Ship className="w-6 h-6" />
                  <span className="text-sm">Desatracado</span>
                </Button>
                <Button 
                  onClick={() => setShowShipMovementModal(true)}
                  className="flex flex-col items-center gap-2 h-auto py-4"
                >
                  <ArrowUp className="w-6 h-6" />
                  <span className="text-sm">Mover Navio</span>
                </Button>
                <Button 
                  onClick={() => setShowInstructionModal(true)}
                  className="flex flex-col items-center gap-2 h-auto py-4"
                  disabled={shipsWithoutInstructions.length === 0}
                >
                  <Mail className="w-6 h-6" />
                  <span className="text-sm">Mover para Instrução</span>
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Modals */}
        {showShipRegistration && (
          <ShipRegistrationModal
            isOpen={showShipRegistration}
            onClose={() => setShowShipRegistration(false)}
          />
        )}

        {showBerthingModal && selectedShipId && (
          <BerthingRegistrationModal
            isOpen={showBerthingModal}
            shipId={selectedShipId}
            onClose={() => {
              setShowBerthingModal(false);
              setSelectedShipId(null);
            }}
            onSuccess={() => {
              setShowBerthingModal(false);
              setSelectedShipId(null);
            }}
          />
        )}

        {showUndockingModal && selectedShipId && (
          <UndockingModal
            isOpen={showUndockingModal}
            shipId={selectedShipId}
            onClose={() => {
              setShowUndockingModal(false);
              setSelectedShipId(null);
            }}
            onSuccess={() => {
              setShowUndockingModal(false);
              setSelectedShipId(null);
            }}
          />
        )}

        {showDischargeModal && selectedShipId && (
          <DischargeUpdateModal
            isOpen={showDischargeModal}
            shipId={selectedShipId}
            onClose={() => {
              setShowDischargeModal(false);
              setSelectedShipId(null);
            }}
            onSuccess={() => {
              setShowDischargeModal(false);
              setSelectedShipId(null);
            }}
          />
        )}

        {showBerthMaintenanceModal && (
          <BerthMaintenanceModal
            isOpen={showBerthMaintenanceModal}
            onClose={() => setShowBerthMaintenanceModal(false)}
          />
        )}

        {showInstructionModal && (
          <InstructionModal
            isOpen={showInstructionModal}
            onClose={() => setShowInstructionModal(false)}
            ships={shipsWithoutInstructions}
          />
        )}

        {showShipMovementModal && (
          <ShipMovementModal
            isOpen={showShipMovementModal}
            onClose={() => setShowShipMovementModal(false)}
          />
        )}

        {showShipInfo && selectedShipForInfo && (
          <ShipInfoModal
            isOpen={showShipInfo}
            onClose={() => setShowShipInfo(false)}
            shipId={selectedShipForInfo.id}
            defaultTab={defaultTab}
          />
        )}
      </div>
    </div>
  );
};

export default Dashboard;