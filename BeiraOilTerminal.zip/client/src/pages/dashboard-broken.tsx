import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { Clock, MapPin, Anchor, Ship, Waves, Wind, Thermometer, Eye, Calendar, Package, Edit, Save, Plus, X } from "lucide-react";
import { useClock } from "@/hooks/use-clock";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { formatTime, formatDate } from "@/lib/utils";
import { TideInfoCard } from "@/components/tide-info-card";
import { WeatherMonitoringCard } from "@/components/weather-monitoring-card";
import { QuickActions } from "@/components/quick-actions";
import { ShipsQueue } from "@/components/ships-queue";
import { ShipRegistrationModal } from "@/components/ship-registration-modal";
import { BerthingRegistrationModal } from "@/components/berthing-registration-modal";
import { UndockingModal } from "@/components/undocking-modal";
import { DischargeUpdateModal } from "@/components/discharge-update-modal";
import { BerthMaintenanceModal } from "@/components/berth-maintenance-modal";
import { InstructionModal } from "@/components/instruction-modal";
import { ShipMovementModal } from "@/components/ship-movement-modal";
import { AdminConfirmationModal } from "@/components/admin-confirmation-modal";
import { ShipInfoModal } from "@/components/ship-info-modal";
import { queryClient } from "@/lib/queryClient";
import cfmLogo from "@assets/LogTipo_1749832282954.png";
import caisImage from "@assets/cais-terminal.png";

interface ShipWithDetails {
  id: number;
  name: string;
  countermark: string;
  draft: string;
  arrivalDateTime: string;
  status: string;
  shipAgent: string;
  cargoAgent: string;
  cargoType: string;
  operationType: string;
  shipowner: string;
  cargoDestination: string;
  shipAgentEmail?: string;
  cargoAgentEmail?: string;
  hasDischargeInstructions: boolean;
  parcels: {
    id: number;
    parcelNumber: string;
    product: string;
    volumeMT: string;
    volumeM3: string;
    density15C: string;
    receiver: string;
    owner: string;
    status: string;
    createdAt: Date | null;
    shipId: number;
  }[];
  latestProgress?: {
    id: number;
    shipId: number;
    parcelId: number;
    percentage: number;
    updatedAt: Date | null;
  };
}

interface BerthMaintenance {
  id: number;
  isActive: boolean;
  startDate: string;
  endDate: string;
  description: string;
  createdAt: Date | null;
  updatedAt: Date | null;
}

const Dashboard = () => {
  const { user, logoutMutation } = useAuth();
  const { toast } = useToast();
  const currentTime = useClock();

  // State management
  const [showShipRegistration, setShowShipRegistration] = useState(false);
  const [showBerthingModal, setShowBerthingModal] = useState(false);
  const [showUndockingModal, setShowUndockingModal] = useState(false);
  const [showDischargeModal, setShowDischargeModal] = useState(false);
  const [showBerthMaintenanceModal, setShowBerthMaintenanceModal] = useState(false);
  const [showInstructionModal, setShowInstructionModal] = useState(false);
  const [showShipMovementModal, setShowShipMovementModal] = useState(false);
  const [showAdminConfirmation, setShowAdminConfirmation] = useState(false);
  const [showShipInfo, setShowShipInfo] = useState(false);
  const [selectedShipId, setSelectedShipId] = useState<number | null>(null);
  const [selectedShipForInfo, setSelectedShipForInfo] = useState<ShipWithDetails | null>(null);
  const [defaultTab, setDefaultTab] = useState("info");
  const [adminAction, setAdminAction] = useState<(() => void) | null>(null);
  const [adminModalTitle, setAdminModalTitle] = useState("");
  const [adminModalMessage, setAdminModalMessage] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  // Form state for inline editing
  const [formData, setFormData] = useState<any>({});
  const [parcelData, setParcelData] = useState<any>({});
  const [newParcels, setNewParcels] = useState<any[]>([]);

  // Data fetching
  const { data: ships = [], refetch: refetchShips } = useQuery({
    queryKey: ['/api/ships'],
  });

  const { data: maintenanceData } = useQuery<BerthMaintenance[]>({
    queryKey: ['/api/berth-maintenance'],
  });

  // Process ships data
  const allShips = ships as ShipWithDetails[];
  const currentShipAtBerth = allShips.find((ship: ShipWithDetails) => ship.status === 'at_berth');

  // Get berthing data for current ship at berth
  const { data: berthingData } = useQuery({
    queryKey: ["/api/ships", currentShipAtBerth?.id, "berthing"],
    enabled: !!currentShipAtBerth?.id,
  });

  const nextShips = allShips.filter((ship: ShipWithDetails) => ship.status === 'next_to_berth');
  const shipsWithInstructions = allShips.filter((ship: ShipWithDetails) => 
    ship.status === 'at_bar' && ship.hasDischargeInstructions
  );
  const shipsWithoutInstructions = allShips.filter((ship: ShipWithDetails) => 
    ship.status === 'at_bar' && !ship.hasDischargeInstructions
  );
  const expectedArrivals = allShips.filter((ship: ShipWithDetails) => ship.status === 'expected');
  const departedShips = allShips.filter((ship: ShipWithDetails) => ship.status === 'departed');

  const activeMaintenance = maintenanceData?.find(m => m.isActive);

  const isOperator = user?.role === 'operator' || user?.role === 'admin';

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-blue-100 p-4">
      {/* Header */}
      <header className="bg-white shadow-lg rounded-lg mb-6 border border-gray-200">
        <div className="px-6 py-4">
          <div className="flex items-center justify-between">
            {/* Left Side - CFM Logo and Clock */}
            <div className="flex items-center space-x-4">
              {/* CFM Logo Circle */}
              <div className="flex flex-col items-center">
                <div className="w-24 h-24 bg-gradient-to-br from-blue-50 to-blue-100 rounded-full flex items-center justify-center border-4 border-blue-200 shadow-xl overflow-hidden">
                  <img 
                    src={cfmLogo} 
                    alt="CFM - Portos e Caminhos de Ferro de Moçambique" 
                    className="w-20 h-20 object-contain rounded-full bg-white p-1" 
                    style={{
                      imageRendering: 'crisp-edges',
                      filter: 'contrast(1.1) brightness(1.05)',
                      backfaceVisibility: 'hidden',
                      transform: 'translateZ(0)'
                    } as React.CSSProperties}
                  />
                </div>
                <div className="text-xs text-gray-600 text-center mt-1 font-medium">CFM</div>
              </div>

              {/* Real-time Clock in Circular Container */}
              <div className="flex flex-col items-center">
                <div className="w-24 h-24 bg-gradient-to-br from-purple-50 to-purple-100 rounded-full flex flex-col items-center justify-center border-4 border-purple-200 shadow-xl">
                  <div className="text-lg font-bold text-purple-800 text-center font-mono leading-tight">
                    {currentTime.time}
                  </div>
                  <div className="text-xs text-purple-600 text-center">
                    {currentTime.date}
                  </div>
                </div>
                <div className="text-xs text-gray-600 text-center mt-1 font-medium">Horário CAT</div>
              </div>
            </div>

            {/* Center - Title Section */}
            <div className="text-center">
              <h1 className="text-xl lg:text-2xl font-bold text-gray-900 leading-tight">
                Line Up - Beira Oil Terminal
              </h1>
              <p className="text-sm text-blue-600 font-medium">
                Sistema de Gestão de Navios • CFM-EP
              </p>
              <div className="flex items-center justify-center space-x-4 mt-2">
                {/* System Status */}
                <div className="flex items-center space-x-2">
                  <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                  <span className="text-xs text-gray-600 font-medium">Sistema Online</span>
                </div>
                
                {/* Developer Credit */}
                <div className="text-xs text-gray-400 hidden lg:block">
                  <span>Desenvolvido por: Manuel Antonio, <span className="text-xs">Eng</span></span>
                </div>
              </div>
            </div>

            {/* Right Side - Terminal Image and Login */}
            <div className="flex items-center space-x-4">
              {/* Terminal Image */}
              <div className="flex flex-col items-center">
                <div className="w-24 h-24 bg-gradient-to-br from-orange-50 to-orange-100 rounded-full flex items-center justify-center border-4 border-orange-200 shadow-xl overflow-hidden">
                  <img 
                    src={caisImage} 
                    alt="Terminal de Petróleo da Beira - Vista do Cais com Arco-íris" 
                    className="w-20 h-20 object-cover rounded-full hover:scale-105 transition-transform duration-300" 
                    style={{
                      imageRendering: 'crisp-edges',
                      filter: 'contrast(1.1) brightness(1.05) saturate(1.2)',
                      backfaceVisibility: 'hidden',
                      transform: 'translateZ(0)'
                    } as React.CSSProperties}
                  />
                </div>
                <div className="text-xs text-gray-600 text-center mt-1 font-medium">Terminal da Beira</div>
              </div>

              {/* Login/Logout in Circular Container */}
              <div className="flex flex-col items-center">
                {user ? (
                  <div className="w-24 h-24 bg-gradient-to-br from-green-50 to-green-100 rounded-full flex flex-col items-center justify-center border-4 border-green-200 shadow-xl">
                    <div className="text-sm font-bold text-green-800 text-center leading-tight">
                      {user.firstName || user.username}
                    </div>
                    <div className="text-xs text-green-600 text-center">
                      {user.role === 'operator' ? 'Operador' : 'Usuário'}
                    </div>
                    <Button 
                      onClick={async () => {
                        try {
                          // Call logout API
                          const response = await fetch('/api/logout', {
                            method: 'POST',
                            credentials: 'include',
                            headers: {
                              'Content-Type': 'application/json',
                            },
                          });
                          
                          const result = await response.json();
                          console.log('Logout response:', result);
                          
                          if (result.success) {
                            // Clear client storage
                            localStorage.clear();
                            sessionStorage.clear();
                            
                            // Redirect to login
                            window.location.href = '/login';
                          } else {
                            throw new Error('Logout failed');
                          }
                        } catch (error) {
                          console.error('Logout error:', error);
                          
                          // Force logout even if API fails
                          localStorage.clear();
                          sessionStorage.clear();
                          
                          // Clear cookies manually
                          document.cookie = 'connect.sid=; expires=Thu, 01 Jan 1970 00:00:00 GMT; path=/';
                          
                          // Force navigation
                          window.location.href = '/login';
                        }
                      }}
                      variant="outline" 
                      size="sm" 
                      className="mt-1 text-xs h-5 px-2 border-green-300 text-green-700 hover:bg-green-100"
                    >
                      Sair
                    </Button>
                  </div>
                ) : (
                  <div className="w-24 h-24 bg-gradient-to-br from-gray-50 to-gray-100 rounded-full flex flex-col items-center justify-center border-4 border-gray-200 shadow-xl">
                    <div className="text-sm font-bold text-gray-800 text-center mb-1">
                      Acesso
                    </div>
                    <Button 
                      onClick={() => window.location.href = '/api/login'}
                      variant="outline" 
                      size="sm" 
                      className="text-xs h-5 px-2 border-gray-300 text-gray-700 hover:bg-gray-100"
                    >
                      Entrar
                    </Button>
                  </div>
                )}
                <div className="text-xs text-gray-600 text-center mt-1 font-medium">
                  {user ? 'Usuário Logado' : 'Fazer Login'}
                </div>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
        {/* Left Column - Environmental Data */}
        <div className="space-y-4">
          <TideInfoCard />
          <WeatherMonitoringCard />
        </div>

        {/* Center Column - Berth Status */}
        <div className="lg:col-span-2">
          {activeMaintenance ? (
            <Card className="border-red-200 bg-red-50">
              <CardHeader className="pb-3">
                <CardTitle className="text-lg font-semibold text-red-800 flex items-center gap-2">
                  <Anchor className="w-5 h-5" />
                  CAIS EM MANUTENÇÃO
                </CardTitle>
              </CardHeader>
              <CardContent className="pt-0">
                <div className="text-center py-4">
                  <div className="text-red-600 font-bold text-sm mb-2">
                    {formatDate(new Date(activeMaintenance.startDate))} - {formatDate(new Date(activeMaintenance.endDate))}
                  </div>
                  <div 
                    className="text-red-800 text-xs uppercase leading-tight"
                    style={{ fontFamily: 'Algerian, sans-serif', fontSize: '10px' }}
                  >
                    MANUTENÇÃO PROGRAMADA DO CAIS (INSPEÇÃO ANUAL DOS MLA) & DIVERSOS TRABALHOS DE MANUTENÇÃO EM EQUIPAMENTOS USADOS NO CAIS
                  </div>
                </div>
              </CardContent>
            </Card>
          ) : currentShipAtBerth ? (
            <div className="space-y-4">
              <Card className="border-0 shadow-sm">
                <CardHeader className="pb-3">
                  <div className="flex justify-between items-center">
                    <CardTitle className="text-lg font-semibold flex items-center gap-2">
                      <Anchor className="w-5 h-5 text-blue-600" />
                      Navio no Cais 12
                    </CardTitle>
                    <div className="flex gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => {
                          setSelectedShipForInfo(currentShipAtBerth);
                          setDefaultTab("info");
                          setShowShipInfo(true);
                        }}
                        className="flex items-center gap-2"
                      >
                        <Eye className="w-4 h-4" />
                        Informações
                      </Button>
                      {isOperator && (
                        <>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => setShowDischargeModal(true)}
                            className="flex items-center gap-2"
                          >
                            <Package className="w-4 h-4" />
                            Atualizar Descarga
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => setShowUndockingModal(true)}
                            className="flex items-center gap-2"
                          >
                            <Ship className="w-4 h-4" />
                            Desatracado
                          </Button>
                        </>
                      )}
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="pt-0">
                  <div className="space-y-6">
                    {/* Nome do Navio */}
                    <div className="text-center">
                      <h3 className="text-2xl font-bold text-blue-600 mb-2">
                        {currentShipAtBerth.name}
                      </h3>
                      <p className="text-gray-600">Contramarca: {currentShipAtBerth.countermark}</p>
                    </div>

                    {/* Produtos */}
                    <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                      <h4 className="text-lg font-semibold text-gray-800 mb-3">Produtos em Descarga</h4>
                      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                        {(currentShipAtBerth.parcels || []).map((parcel: any) => (
                          <div key={parcel.id} className="bg-white border border-gray-200 rounded-lg p-3">
                            <div className="flex justify-between items-center">
                              <div>
                                <p className="font-medium text-gray-800">{parcel.product}</p>
                                <p className="text-sm text-gray-600">{parcel.volumeMT} MT</p>
                                <p className="text-xs text-gray-500">Recebedor: {parcel.receiver}</p>
                              </div>
                              <div className={`px-2 py-1 rounded-full text-xs font-medium ${
                                parcel.status === 'completed' 
                                  ? 'bg-green-100 text-green-800' 
                                  : parcel.status === 'in_progress'
                                  ? 'bg-yellow-100 text-yellow-800'
                                  : 'bg-gray-100 text-gray-800'
                              }`}>
                                {parcel.status === 'completed' ? 'Concluída' : 
                                 parcel.status === 'in_progress' ? 'Em Descarga' : 'Aguardando'}
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Progresso da Descarga */}
                    <div className="bg-gradient-to-r from-blue-50 to-purple-50 border border-blue-200 rounded-lg p-6">
                      <h4 className="text-lg font-semibold text-gray-800 mb-4 text-center">Progresso da Descarga</h4>
                      {(() => {
                        const totalParcels = (currentShipAtBerth.parcels || []).length;
                        const completedParcels = (currentShipAtBerth.parcels || []).filter((p: any) => p.status === 'completed').length;
                        const progressPercentage = totalParcels > 0 ? Math.round((completedParcels / totalParcels) * 100) : 0;
                        
                        // Calculate total volume
                        const totalVolume = (currentShipAtBerth.parcels || []).reduce((sum: number, p: any) => {
                          return sum + (parseFloat(p.volumeMT) || 0);
                        }, 0);
                        
                        const completedVolume = (currentShipAtBerth.parcels || [])
                          .filter((p: any) => p.status === 'completed')
                          .reduce((sum: number, p: any) => {
                            return sum + (parseFloat(p.volumeMT) || 0);
                          }, 0);
                        
                        return (
                          <div className="space-y-4">
                            {/* Progress Bar */}
                            <div className="relative">
                              <div className="w-full bg-gray-200 rounded-full h-8 shadow-inner">
                                <div 
                                  className={`h-8 rounded-full transition-all duration-500 flex items-center justify-center text-white font-bold text-lg shadow-lg ${
                                    progressPercentage === 100 
                                      ? 'bg-gradient-to-r from-green-500 to-green-600' 
                                      : 'bg-gradient-to-r from-blue-500 to-purple-600'
                                  }`}
                                  style={{ width: `${progressPercentage}%` }}
                                >
                                  {progressPercentage > 15 && `${progressPercentage}%`}
                                </div>
                              </div>
                              {progressPercentage <= 15 && (
                                <div className="absolute inset-0 flex items-center justify-center text-gray-700 font-bold text-lg">
                                  {progressPercentage}%
                                </div>
                              )}
                            </div>

                            {/* Statistics */}
                            <div className="grid grid-cols-2 md:grid-cols-3 gap-4 text-center">
                              <div className="bg-white rounded-lg p-3 shadow-sm">
                                <p className="text-2xl font-bold text-blue-600">{completedParcels}</p>
                                <p className="text-sm text-gray-600">de {totalParcels} parcelas</p>
                              </div>
                              <div className="bg-white rounded-lg p-3 shadow-sm">
                                <p className="text-2xl font-bold text-purple-600">{completedVolume.toFixed(0)}</p>
                                <p className="text-sm text-gray-600">de {totalVolume.toFixed(0)} MT</p>
                              </div>
                              <div className="bg-white rounded-lg p-3 shadow-sm col-span-2 md:col-span-1">
                                <p className={`text-2xl font-bold ${progressPercentage === 100 ? 'text-green-600' : 'text-orange-600'}`}>
                                  {progressPercentage === 100 ? 'CONCLUÍDA' : 'EM PROGRESSO'}
                                </p>
                                <p className="text-sm text-gray-600">Status da Descarga</p>
                              </div>
                            </div>

                            {progressPercentage === 100 && (
                              <div className="text-center text-green-600 font-bold text-xl bg-green-50 border border-green-200 rounded-lg p-4">
                                ✓ DESCARGA TOTALMENTE CONCLUÍDA
                              </div>
                            )}
                          </div>
                        );
                      })()}
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          ) : (
            <Card className="border-0 shadow-sm">
              <CardHeader>
                <CardTitle className="text-lg font-semibold flex items-center gap-2">
                  <Anchor className="w-5 h-5 text-blue-600" />
                  Nenhum Navio no Cais
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-center py-8">
                  <p className="text-gray-500">O cais está disponível para atracação</p>
                </div>
              </CardContent>
            </Card>
          )}
        </div>

        {/* Other sections remain unchanged */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Next Ships Section */}
          <Card className="border-0 shadow-sm">
            <CardHeader className="pb-3">
              <CardTitle className="text-lg font-semibold flex items-center gap-2">
                <Clock className="w-5 h-5 text-green-600" />
                PRÓXIMOS 5 NAVIOS A ATRACAR
              </CardTitle>
            </CardHeader>
            <CardContent className="pt-0">
              <div className="space-y-3">
                {nextShips.length === 0 ? (
                  <p className="text-gray-500 text-center py-4">Nenhum navio próximo à atracação</p>
                ) : (
                  nextShips.slice(0, 5).map((ship: ShipWithDetails) => (
                    <ShipCard 
                      key={ship.id} 
                      ship={ship} 
                      onClick={() => {
                        setSelectedShipForInfo(ship);
                        setDefaultTab("info");
                        setShowShipInfo(true);
                      }}
                      actions={
                        isOperator ? [
                          {
                            label: "Atualizar Descarga",
                            icon: Package,
                            onClick: () => {
                              setSelectedShipId(ship.id);
                              setShowDischargeModal(true);
                            }
                          },
                          {
                            label: "Mover Navio",
                            icon: ArrowUp,
                            onClick: () => setShowShipMovementModal(true)
                          }
                        ] : []
                      }
                    />
                  ))
                )}
              </div>
            </CardContent>
          </Card>

          {/* Weather and Tide Section - keep existing code */}
          <Card className="border-0 shadow-sm">
            <CardHeader className="pb-3">
              <CardTitle className="text-lg font-semibold flex items-center gap-2">
                <Cloud className="w-5 h-5 text-blue-600" />
                Condições Meteorológicas
              </CardTitle>
            </CardHeader>
            <CardContent className="pt-0">
              {weatherData ? (
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="text-center p-3 bg-blue-50 rounded-lg">
                      <div className="text-2xl font-bold text-blue-600">
                        {Math.round(weatherData.temperature)}°C
                      </div>
                      <div className="text-sm text-gray-600">Temperatura</div>
                    </div>
                    <div className="text-center p-3 bg-green-50 rounded-lg">
                      <div className="text-2xl font-bold text-green-600">
                        {Math.round(weatherData.windSpeed)} km/h
                      </div>
                      <div className="text-sm text-gray-600">Vento</div>
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="text-center p-3 bg-purple-50 rounded-lg">
                      <div className="text-2xl font-bold text-purple-600">
                        {Math.round(weatherData.humidity)}%
                      </div>
                      <div className="text-sm text-gray-600">Humidade</div>
                    </div>
                    <div className="text-center p-3 bg-orange-50 rounded-lg">
                      <div className="text-2xl font-bold text-orange-600">
                        {Math.round(weatherData.pressure)} hPa
                      </div>
                      <div className="text-sm text-gray-600">Pressão</div>
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="text-center p-3 bg-cyan-50 rounded-lg">
                      <div className="text-lg font-bold text-cyan-600">
                        {formatTime(tideData?.nextHigh?.time)} 
                      </div>
                      <div className="text-sm text-gray-600">Próxima Maré Alta</div>
                      <div className="text-xs text-gray-500">
                        {tideData?.nextHigh?.height?.toFixed(1)}m
                      </div>
                    </div>
                    <div className="text-center p-3 bg-indigo-50 rounded-lg">
                      <div className="text-lg font-bold text-indigo-600">
                        {formatTime(tideData?.nextLow?.time)}
                      </div>
                      <div className="text-sm text-gray-600">Próxima Maré Baixa</div>
                      <div className="text-xs text-gray-500">
                        {tideData?.nextLow?.height?.toFixed(1)}m
                      </div>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="text-center py-4">
                  <p className="text-gray-500">Carregando dados meteorológicos...</p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Ships with and without instructions sections */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <ShipsSection
            title="Navios com Instrução de Descarga"
            ships={shipsWithInstructions}
            icon={CheckCircle}
            iconColor="text-green-600"
            emptyMessage="Nenhum navio com instrução de descarga"
            onShipClick={(ship) => {
              setSelectedShipForInfo(ship);
              setDefaultTab("info");
              setShowShipInfo(true);
            }}
            isOperator={isOperator}
            onUpdateDischarge={(shipId) => {
              setSelectedShipId(shipId);
              setShowDischargeModal(true);
            }}
            onMoveShip={() => setShowShipMovementModal(true)}
          />

          <ShipsSection
            title="Navios sem Instrução de Descarga"
            ships={shipsWithoutInstructions}
            icon={XCircle}
            iconColor="text-red-600"
            emptyMessage="Nenhum navio sem instrução de descarga"
            onShipClick={(ship) => {
              setSelectedShipForInfo(ship);
              setDefaultTab("info");
              setShowShipInfo(true);
            }}
            isOperator={isOperator}
            onUpdateDischarge={(shipId) => {
              setSelectedShipId(shipId);
              setShowDischargeModal(true);
            }}
            onMoveShip={() => setShowShipMovementModal(true)}
          />
        </div>

        {/* Expected arrivals and departed ships sections */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <ShipsSection
            title="Previstos a Chegar"
            ships={expectedArrivals}
            icon={Ship}
            iconColor="text-blue-600"
            emptyMessage="Nenhum navio previsto para chegar"
            onShipClick={(ship) => {
              setSelectedShipForInfo(ship);
              setDefaultTab("info");
              setShowShipInfo(true);
            }}
            isOperator={isOperator}
            onUpdateDischarge={(shipId) => {
              setSelectedShipId(shipId);
              setShowDischargeModal(true);
            }}
            onMoveShip={() => setShowShipMovementModal(true)}
          />

          <ShipsSection
            title="Navios que Partiram"
            ships={departedShips}
            icon={Flag}
            iconColor="text-gray-600"
            emptyMessage="Nenhum navio partiu"
            onShipClick={(ship) => {
              setSelectedShipForInfo(ship);
              setDefaultTab("info");
              setShowShipInfo(true);
            }}
            isOperator={isOperator}
            onUpdateDischarge={(shipId) => {
              setSelectedShipId(shipId);
              setShowDischargeModal(true);
            }}
            onMoveShip={() => setShowShipMovementModal(true)}
          />
        </div>

        {/* Quick Actions - only for operators */}
        {isOperator && (
          <Card className="border-0 shadow-sm">
            <CardHeader>
              <CardTitle className="text-lg font-semibold">Ações Rápidas</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
                <Button 
                  onClick={() => setShowShipRegistration(true)}
                  className="flex flex-col items-center gap-2 h-auto py-4"
                >
                  <Plus className="w-6 h-6" />
                  <span className="text-sm">Registar Navio</span>
                </Button>
                <Button 
                  onClick={() => setShowBerthingModal(true)}
                  className="flex flex-col items-center gap-2 h-auto py-4"
                  disabled={!currentShipAtBerth}
                >
                  <Anchor className="w-6 h-6" />
                  <span className="text-sm">Atracação do Navio</span>
                </Button>
                <Button 
                  onClick={() => setShowDischargeModal(true)}
                  className="flex flex-col items-center gap-2 h-auto py-4"
                  disabled={!currentShipAtBerth}
                >
                  <Package className="w-6 h-6" />
                  <span className="text-sm">Atualizar Descarga</span>
                </Button>
                <Button 
                  onClick={() => setShowUndockingModal(true)}
                  className="flex flex-col items-center gap-2 h-auto py-4"
                  disabled={!currentShipAtBerth}
                >
                  <Ship className="w-6 h-6" />
                  <span className="text-sm">Desatracado</span>
                </Button>
                <Button 
                  onClick={() => setShowShipMovementModal(true)}
                  className="flex flex-col items-center gap-2 h-auto py-4"
                >
                  <ArrowUp className="w-6 h-6" />
                  <span className="text-sm">Mover Navio</span>
                </Button>
                <Button 
                  onClick={() => setShowInstructionModal(true)}
                  className="flex flex-col items-center gap-2 h-auto py-4"
                  disabled={shipsWithoutInstructions.length === 0}
                >
                  <Mail className="w-6 h-6" />
                  <span className="text-sm">Mover para Instrução</span>
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Modals */}
        {showShipRegistration && (
          <ShipRegistrationModal
            isOpen={showShipRegistration}
            onClose={() => setShowShipRegistration(false)}
            onSubmit={() => setShowShipRegistration(false)}
          />
        )}

        {showBerthingModal && selectedShipId && (
          <BerthingModal
            isOpen={showBerthingModal}
            shipId={selectedShipId}
            onClose={() => {
              setShowBerthingModal(false);
              setSelectedShipId(null);
            }}
            onSuccess={() => {
              setShowBerthingModal(false);
              setSelectedShipId(null);
            }}
          />
        )}

        {showUndockingModal && selectedShipId && (
          <UndockingModal
            isOpen={showUndockingModal}
            shipId={selectedShipId}
            ship={allShips.find(s => s.id === selectedShipId)}
            onClose={() => {
              setShowUndockingModal(false);
              setSelectedShipId(null);
            }}
            onSuccess={() => {
              setShowUndockingModal(false);
              setSelectedShipId(null);
            }}
          />
        )}

        {showDischargeModal && selectedShipId && (
          <DischargeModal
            isOpen={showDischargeModal}
            shipId={selectedShipId}
            onClose={() => {
              setShowDischargeModal(false);
              setSelectedShipId(null);
            }}
            onSuccess={() => {
              setShowDischargeModal(false);
              setSelectedShipId(null);
            }}
          />
        )}

        {showBerthMaintenanceModal && (
          <BerthMaintenanceModal
            isOpen={showBerthMaintenanceModal}
            onClose={() => setShowBerthMaintenanceModal(false)}
          />
        )}

        {showInstructionModal && (
          <InstructionModal
            isOpen={showInstructionModal}
            onClose={() => setShowInstructionModal(false)}
            ships={shipsWithoutInstructions}
          />
        )}

        {showShipMovementModal && (
          <ShipMovementModal
            isOpen={showShipMovementModal}
            onClose={() => setShowShipMovementModal(false)}
          />
        )}

        {showShipInfo && selectedShipForInfo && (
          <ShipInfoModal
            isOpen={showShipInfo}
            onClose={() => setShowShipInfo(false)}
            shipId={selectedShipForInfo.id}
            defaultTab={defaultTab}
          />
        )}
      </div>
    );
  };

export default Dashboard;
                                  >
                                    <SelectTrigger>
                                      <SelectValue />
                                    </SelectTrigger>
                                    <SelectContent>
                                      <SelectItem value="Gasolina">Gasolina</SelectItem>
                                      <SelectItem value="Diesel">Diesel</SelectItem>
                                      <SelectItem value="Jet A1">Jet A1</SelectItem>
                                      <SelectItem value="LPG">LPG</SelectItem>
                                    </SelectContent>
                                  </Select>
                                </div>
                                
                                <div>
                                  <label className="block text-sm font-medium text-gray-700 mb-1">Volume (m³)</label>
                                  <Input
                                    defaultValue={parcel.volumeM3}
                                    onChange={(e) => {
                                      const volumeM3 = parseFloat(e.target.value) || 0;
                                      const density = parseFloat(parcelData[`${parcel.id}_density15C`] || parcel.density15C) || 0;
                                      const volumeMT = volumeM3 * density;
                                      
                                      setParcelData((prev: any) => ({ 
                                        ...prev, 
                                        [`${parcel.id}_volumeM3`]: e.target.value,
                                        [`${parcel.id}_volumeMT`]: volumeMT.toFixed(2)
                                      }));
                                    }}
                                    className="w-full"
                                  />
                                </div>
                                
                                <div>
                                  <label className="block text-sm font-medium text-gray-700 mb-1">Densidade 15°C</label>
                                  <Input
                                    defaultValue={parcel.density15C}
                                    onChange={(e) => {
                                      const density = parseFloat(e.target.value) || 0;
                                      const volumeM3 = parseFloat(parcelData[`${parcel.id}_volumeM3`] || parcel.volumeM3) || 0;
                                      const volumeMT = volumeM3 * density;
                                      
                                      setParcelData((prev: any) => ({ 
                                        ...prev, 
                                        [`${parcel.id}_density15C`]: e.target.value,
                                        [`${parcel.id}_volumeMT`]: volumeMT.toFixed(2)
                                      }));
                                    }}
                                    className="w-full"
                                  />
                                </div>
                                
                                <div>
                                  <label className="block text-sm font-medium text-gray-700 mb-1">Volume (MT) - Calculado</label>
                                  <Input
                                    value={parcelData[`${parcel.id}_volumeMT`] || parcel.volumeMT || ''}
                                    className="w-full bg-gray-50"
                                    readOnly
                                  />
                                </div>
                                
                                <div>
                                  <label className="block text-sm font-medium text-gray-700 mb-1">Recebedor</label>
                                  <Input
                                    defaultValue={parcel.receiver}
                                    onChange={(e) => setParcelData((prev: any) => ({ 
                                      ...prev, 
                                      [`${parcel.id}_receiver`]: e.target.value 
                                    }))}
                                    className="w-full"
                                  />
                                </div>
                                
                                <div>
                                  <label className="block text-sm font-medium text-gray-700 mb-1">Dono da Parcela</label>
                                  <Input
                                    defaultValue={parcel.owner}
                                    onChange={(e) => setParcelData((prev: any) => ({ 
                                      ...prev, 
                                      [`${parcel.id}_owner`]: e.target.value 
                                    }))}
                                    className="w-full"
                                  />
                                </div>
                              </div>
                            </div>
                          ))}
                          
                          {/* New Parcels */}
                          {newParcels.map((newParcel: any, index: number) => (
                            <div key={`new-${newParcel.tempId}`} className="border rounded-lg p-4 bg-blue-50 border-blue-200">
                              <div className="flex items-center justify-between mb-2">
                                <span className="text-sm font-medium text-blue-800">Nova Parcela {index + 1}</span>
                                <Button
                                  onClick={() => {
                                    setNewParcels((prev: any) => prev.filter((p: any) => p.tempId !== newParcel.tempId));
                                  }}
                                  variant="ghost"
                                  size="sm"
                                  className="text-red-600 hover:text-red-800"
                                >
                                  <X className="w-4 h-4" />
                                </Button>
                              </div>
                              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                                <div>
                                  <label className="block text-sm font-medium text-gray-700 mb-1">Produto</label>
                                  <Select 
                                    defaultValue={newParcel.product}
                                    onValueChange={(value) => {
                                      setNewParcels((prev: any) => prev.map((p: any) => 
                                        p.tempId === newParcel.tempId ? { ...p, product: value } : p
                                      ));
                                    }}
                                  >
                                    <SelectTrigger>
                                      <SelectValue />
                                    </SelectTrigger>
                                    <SelectContent>
                                      <SelectItem value="Gasolina">Gasolina</SelectItem>
                                      <SelectItem value="Diesel">Diesel</SelectItem>
                                      <SelectItem value="Jet A1">Jet A1</SelectItem>
                                      <SelectItem value="LPG">LPG</SelectItem>
                                    </SelectContent>
                                  </Select>
                                </div>
                                
                                <div>
                                  <label className="block text-sm font-medium text-gray-700 mb-1">Volume (m³)</label>
                                  <Input
                                    placeholder="Volume em m³"
                                    value={newParcel.volumeM3}
                                    onChange={(e) => {
                                      const volumeM3 = parseFloat(e.target.value) || 0;
                                      const density = parseFloat(newParcel.density15C) || 0;
                                      const volumeMT = volumeM3 * density;
                                      
                                      setNewParcels((prev: any) => prev.map((p: any) => 
                                        p.tempId === newParcel.tempId ? { 
                                          ...p, 
                                          volumeM3: e.target.value,
                                          volumeMT: volumeMT.toFixed(2)
                                        } : p
                                      ));
                                    }}
                                    className="w-full"
                                  />
                                </div>
                                
                                <div>
                                  <label className="block text-sm font-medium text-gray-700 mb-1">Densidade 15°C</label>
                                  <Input
                                    placeholder="Densidade"
                                    value={newParcel.density15C}
                                    onChange={(e) => {
                                      const density = parseFloat(e.target.value) || 0;
                                      const volumeM3 = parseFloat(newParcel.volumeM3) || 0;
                                      const volumeMT = volumeM3 * density;
                                      
                                      setNewParcels((prev: any) => prev.map((p: any) => 
                                        p.tempId === newParcel.tempId ? { 
                                          ...p, 
                                          density15C: e.target.value,
                                          volumeMT: volumeMT.toFixed(2)
                                        } : p
                                      ));
                                    }}
                                    className="w-full"
                                  />
                                </div>
                                
                                <div>
                                  <label className="block text-sm font-medium text-gray-700 mb-1">Volume (MT) - Calculado</label>
                                  <Input
                                    placeholder="Calculado automaticamente"
                                    value={newParcel.volumeMT}
                                    className="w-full bg-gray-50"
                                    readOnly
                                  />
                                </div>
                                
                                <div>
                                  <label className="block text-sm font-medium text-gray-700 mb-1">Recebedor</label>
                                  <Input
                                    placeholder="Nome do recebedor"
                                    value={newParcel.receiver}
                                    onChange={(e) => {
                                      setNewParcels((prev: any) => prev.map((p: any) => 
                                        p.tempId === newParcel.tempId ? { ...p, receiver: e.target.value } : p
                                      ));
                                    }}
                                    className="w-full"
                                  />
                                </div>
                                
                                <div>
                                  <label className="block text-sm font-medium text-gray-700 mb-1">Dono da Parcela</label>
                                  <Input
                                    placeholder="Nome do proprietário"
                                    value={newParcel.owner}
                                    onChange={(e) => {
                                      setNewParcels((prev: any) => prev.map((p: any) => 
                                        p.tempId === newParcel.tempId ? { ...p, owner: e.target.value } : p
                                      ));
                                    }}
                                    className="w-full"
                                  />
                                </div>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Save Buttons */}
                    {isOperator && (
                      <>
                        <div className="mt-6 flex justify-center">
                          <Button
                            onClick={async () => {
                              try {
                                setIsLoading(true);

                                const updatedFormData = {
                                  ...formData,
                                  name: formData.name || currentShipAtBerth.name,
                                  countermark: formData.countermark || currentShipAtBerth.countermark,
                                  draft: formData.draft || currentShipAtBerth.draft,
                                  shipAgent: formData.shipAgent || currentShipAtBerth.shipAgent,
                                  cargoAgent: formData.cargoAgent || currentShipAtBerth.cargoAgent,
                                  cargoType: formData.cargoType || currentShipAtBerth.cargoType,
                                  operationType: formData.operationType || currentShipAtBerth.operationType,
                                  shipowner: formData.shipowner || currentShipAtBerth.shipowner,
                                  cargoDestination: formData.cargoDestination || currentShipAtBerth.cargoDestination,
                                  shipAgentEmail: formData.shipAgentEmail || currentShipAtBerth.shipAgentEmail,
                                  cargoAgentEmail: formData.cargoAgentEmail || currentShipAtBerth.cargoAgentEmail,
                                  arrivalDateTime: currentShipAtBerth.arrivalDateTime,
                                  status: currentShipAtBerth.status,
                                };

                                const existingParcels = (currentShipAtBerth.parcels || []).map((parcel: any) => ({
                                  id: parcel.id,
                                  parcelNumber: parcel.parcelNumber,
                                  product: parcelData[`${parcel.id}_product`] || parcel.product,
                                  volumeM3: parcelData[`${parcel.id}_volumeM3`] || parcel.volumeM3,
                                  density15C: parcelData[`${parcel.id}_density15C`] || parcel.density15C,
                                  volumeMT: parcelData[`${parcel.id}_volumeMT`] || parcel.volumeMT,
                                  receiver: parcelData[`${parcel.id}_receiver`] || parcel.receiver,
                                  owner: parcelData[`${parcel.id}_owner`] || parcel.owner,
                                  status: parcel.status,
                                }));

                                // First update ship basic info (without parcels)
                                const shipResponse = await fetch(`/api/ships/${currentShipAtBerth.id}`, {
                                  method: 'PUT',
                                  headers: {
                                    'Content-Type': 'application/json',
                                  },
                                  body: JSON.stringify({
                                    ...updatedFormData,
                                    // Don't send parcels array to avoid overwriting
                                  }),
                                });

                                if (!shipResponse.ok) {
                                  throw new Error('Falha ao atualizar navio');
                                }

                                // Then save new parcels individually
                                for (const parcel of newParcels) {
                                  const parcelData = {
                                    parcelNumber: parcel.parcelNumber,
                                    product: parcel.product,
                                    volumeM3: parcel.volumeM3,
                                    density15C: parcel.density15C,
                                    volumeMT: parcel.volumeMT,
                                    receiver: parcel.receiver,
                                    owner: parcel.owner,
                                  };

                                  const parcelResponse = await fetch(`/api/ships/${currentShipAtBerth.id}/parcels`, {
                                    method: 'POST',
                                    headers: {
                                      'Content-Type': 'application/json',
                                    },
                                    body: JSON.stringify(parcelData),
                                  });

                                  if (!parcelResponse.ok) {
                                    throw new Error('Falha ao adicionar parcela');
                                  }
                                }

                                // All operations completed successfully

                                // Clear local state and refresh data
                                setFormData({});
                                setParcelData({});
                                setNewParcels([]);
                                
                                // Force complete refresh of ship data
                                await queryClient.invalidateQueries({ queryKey: ['/api/ships'] });
                                await queryClient.refetchQueries({ queryKey: ['/api/ships'] });
                                
                                toast({
                                  title: "Sucesso",
                                  description: "Alterações salvas com sucesso!",
                                });

                              } catch (error) {
                                console.error('Erro ao salvar:', error);
                                toast({
                                  title: "Erro",
                                  description: "Falha ao salvar alterações. Tente novamente.",
                                  variant: "destructive",
                                });
                              } finally {
                                setIsLoading(false);
                              }
                            }}
                            disabled={isLoading}
                            className="bg-green-600 hover:bg-green-700 text-white px-8 py-2"
                          >
                            {isLoading ? (
                              <>
                                <span className="mr-2">Salvando...</span>
                                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                              </>
                            ) : (
                              <>
                                <Save className="w-4 h-4 mr-2" />
                                Salvar Alterações
                              </>
                            )}
                          </Button>
                        </div>


                      </>
                    )}
                  </div>
                </CardContent>
              </Card>
            </div>
          ) : (
            <Card className="border-0 shadow-sm">
              <CardHeader className="pb-3">
                <CardTitle className="text-lg font-semibold flex items-center gap-2">
                  <Anchor className="w-5 h-5 text-gray-400" />
                  Navio no Cais 12
                </CardTitle>
              </CardHeader>
              <CardContent className="pt-0">
                <div className="text-center py-8 text-gray-500">
                  <Ship className="w-12 h-12 mx-auto mb-3 text-gray-300" />
                  <p className="text-lg font-medium">Cais Livre</p>
                  <p className="text-sm">Nenhum navio atracado</p>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>

      {/* Quick Actions */}
      {isOperator && (
        <QuickActions
          onRegisterShip={() => setShowShipRegistration(true)}
          onUpdateDischarge={() => setShowDischargeModal(true)}
          onRegisterBerthing={() => setShowBerthingModal(true)}
          onUndockShip={() => setShowUndockingModal(true)}
          onShipMovement={() => setShowShipMovementModal(true)}
          onAdvancedDischarge={() => setShowDischargeModal(true)}
          onDischargePlanning={() => {}}
          onRatesConfiguration={() => {}}
          canUndock={!!currentShipAtBerth}
          canBerth={nextShips.length > 0}
          hasShipAtBerth={!!currentShipAtBerth}
          canEdit={isOperator}
        />
      )}

      {/* Ships Queue */}
      <ShipsQueue
        shipsWithInstructions={shipsWithInstructions}
        shipsWithoutInstructions={shipsWithoutInstructions}
        expectedArrivals={expectedArrivals}
        departedShips={departedShips}
        isOperator={isOperator}
      />

      {/* Modals */}
      {showShipRegistration && (
        <ShipRegistrationModal
          isOpen={showShipRegistration}
          onClose={() => setShowShipRegistration(false)}
          onSuccess={() => {
            setShowShipRegistration(false);
            queryClient.invalidateQueries({ queryKey: ['/api/ships'] });
          }}
        />
      )}

      {showBerthingModal && selectedShipId && (
        <BerthingRegistrationModal
          isOpen={showBerthingModal}
          onClose={() => {
            setShowBerthingModal(false);
            setSelectedShipId(null);
          }}
          onSuccess={() => {
            setShowBerthingModal(false);
            setSelectedShipId(null);
            queryClient.invalidateQueries({ queryKey: ['/api/ships'] });
          }}
        />
      )}

      {showUndockingModal && selectedShipId && (
        <UndockingModal
          isOpen={showUndockingModal}
          shipId={selectedShipId}
          shipName={allShips.find(s => s.id === selectedShipId)?.name || ''}
          onClose={() => {
            setShowUndockingModal(false);
            setSelectedShipId(null);
          }}
          onSuccess={() => {
            setShowUndockingModal(false);
            setSelectedShipId(null);
            queryClient.invalidateQueries({ queryKey: ['/api/ships'] });
          }}
        />
      )}

      {showDischargeModal && selectedShipId && (
        <DischargeUpdateModal
          isOpen={showDischargeModal}
          shipId={selectedShipId}
          onClose={() => {
            setShowDischargeModal(false);
            setSelectedShipId(null);
          }}
          onSuccess={() => {
            setShowDischargeModal(false);
            setSelectedShipId(null);
            queryClient.invalidateQueries({ queryKey: ['/api/ships'] });
          }}
        />
      )}

      {showBerthMaintenanceModal && (
        <BerthMaintenanceModal
          isOpen={showBerthMaintenanceModal}
          onClose={() => setShowBerthMaintenanceModal(false)}
        />
      )}

      {showInstructionModal && (
        <InstructionModal
          isOpen={showInstructionModal}
          onClose={() => setShowInstructionModal(false)}
          ships={shipsWithoutInstructions}
        />
      )}

      {showShipMovementModal && (
        <ShipMovementModal
          isOpen={showShipMovementModal}
          onClose={() => setShowShipMovementModal(false)}
        />
      )}

      {showShipInfo && selectedShipForInfo && (
        <ShipInfoModal
          isOpen={showShipInfo}
          onClose={() => setShowShipInfo(false)}
          ship={selectedShipForInfo}
          defaultTab={defaultTab}
        />
      )}
    </div>
  );
};

export default Dashboard;