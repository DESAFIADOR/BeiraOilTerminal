import { useState, useEffect } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Ship, Plus, Anchor, Cloud, Waves, Clock, User, LogOut,
  ArrowUp, Info, Settings, Calendar, MapPin, Package, FileText, AlertTriangle, RefreshCw, Edit, Trash2, MessageSquare, Check, X
} from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import { useTranslation } from "@/contexts/LanguageContext";
import { LanguageSelector } from "@/components/LanguageSelector";
import { GeminiAIAssistant } from "@/components/gemini-ai-assistant";
import { CommunicationPanel } from "@/components/communication-panel";
import logoPath from "@assets/LogTipo_1749832282954.png";
import terminalImagePath from "@assets/cais-terminal.png";

interface Ship {
  id: number;
  name: string;
  countermark: string;
  draft: number;
  cargoType: string;
  shipAgent: string;
  cargoAgent: string;
  shipowner: string;
  cargoDestination: string;
  operationType: 'Nacional' | 'Trânsito' | 'Combinado' | 'LPG';
  status: 'expected' | 'at_bar' | 'next_to_berth' | 'at_berth' | 'departed';
  hasDischargeInstructions: boolean;
  berthConfirmed: boolean;
  arrivalAtBar: string;
  shipAgentEmail?: string;
  cargoAgentEmail?: string;
}

export default function Dashboard() {
  const { user, isAuthenticated, isLoading } = useAuth();
  const { t } = useTranslation();
  const queryClient = useQueryClient();
  const [currentTime, setCurrentTime] = useState(new Date());
  const [selectedShip, setSelectedShip] = useState<Ship | null>(null);
  const [showShipRegistration, setShowShipRegistration] = useState(false);
  const [isGeminiAIOpen, setIsGeminiAIOpen] = useState(false);
  const [showCommunicationPanel, setShowCommunicationPanel] = useState(false);

  // Update time every second
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  // Fetch ships data
  const { data: ships = [], isLoading: shipsLoading } = useQuery({
    queryKey: ['/api/ships'],
    refetchInterval: 5000,
  });

  // Fetch weather data
  const { data: weatherData } = useQuery({
    queryKey: ['/api/weather'],
    refetchInterval: 300000, // 5 minutes
  });

  // Fetch tide data
  const { data: tideData } = useQuery({
    queryKey: ['/api/tide'],
    refetchInterval: 300000, // 5 minutes
  });

  // Fetch maintenance data
  const { data: maintenanceData } = useQuery({
    queryKey: ['/api/berth-maintenance'],
    refetchInterval: 30000,
  });

  const formatTime = (date: Date) => {
    if (!date || !(date instanceof Date)) return '--:--';
    return date.toLocaleTimeString('pt-BR', {
      hour: '2-digit',
      minute: '2-digit',
      timeZone: 'Africa/Maputo'
    });
  };

  const formatDate = (date: Date) => {
    if (!date || !(date instanceof Date)) return '--/--/----';
    return date.toLocaleDateString('pt-BR', {
      timeZone: 'Africa/Maputo'
    });
  };

  const handleLogout = async () => {
    try {
      await fetch('/api/logout', {
        method: 'POST',
        credentials: 'include'
      });
      localStorage.clear();
      sessionStorage.clear();
      window.location.href = '/login';
    } catch (error) {
      console.error('Logout error:', error);
      window.location.href = '/login';
    }
  };

  // Filter ships by status and priority
  const prioritizeShips = (ships: Ship[]) => {
    return ships.sort((a, b) => {
      // IMOPETRO priority (absolute)
      const aIsImopetro = a.cargoAgent?.toLowerCase().includes('imopetro');
      const bIsImopetro = b.cargoAgent?.toLowerCase().includes('imopetro');
      if (aIsImopetro && !bIsImopetro) return -1;
      if (!aIsImopetro && bIsImopetro) return 1;

      // Nacional priority (after IMOPETRO)
      if (a.operationType === 'Nacional' && b.operationType !== 'Nacional') return -1;
      if (a.operationType !== 'Nacional' && b.operationType === 'Nacional') return 1;

      // LPG priority (after Nacional)
      if (a.operationType === 'LPG' && b.operationType !== 'LPG') return -1;
      if (a.operationType !== 'LPG' && b.operationType === 'LPG') return 1;

      // Arrival time
      const arrivalTimeA = new Date(a.arrivalAtBar).getTime();
      const arrivalTimeB = new Date(b.arrivalAtBar).getTime();
      return arrivalTimeA - arrivalTimeB;
    });
  };

  const shipsArray = Array.isArray(ships) ? ships as Ship[] : [];
  const expectedArrivals = shipsArray.filter((ship: Ship) => ship.status === 'expected');
  const shipsAtBar = shipsArray.filter((ship: Ship) => ship.status === 'at_bar');
  const shipsWithoutInstructions = prioritizeShips(shipsAtBar.filter((ship: Ship) => !ship.hasDischargeInstructions));
  const shipsWithInstructions = prioritizeShips(shipsAtBar.filter((ship: Ship) => ship.hasDischargeInstructions));
  const nextShips = prioritizeShips(shipsArray.filter((ship: Ship) => ship.status === 'next_to_berth'));
  const currentShipAtBerth = shipsArray.find((ship: Ship) => ship.status === 'at_berth');
  const departedShips = shipsArray.filter((ship: Ship) => ship.status === 'departed').slice(0, 10);

  if (isLoading || shipsLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-600"></div>
          <p className="mt-4 text-gray-600">Carregando sistema...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-blue-50">
      {/* Mobile Header */}
      <header className="md:hidden bg-white shadow-lg border-b border-gray-200 fixed top-0 left-0 right-0 z-40">
        <div className="px-4 py-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 rounded-full bg-gradient-to-br from-blue-500 to-blue-600 flex items-center justify-center">
                <img src={logoPath} alt="CFM" className="w-6 h-6 object-contain" />
              </div>
              <div>
                <h1 className="text-sm font-bold text-gray-800">Terminal Beira</h1>
                <p className="text-xs text-gray-600">{formatTime(currentTime)}</p>
              </div>
            </div>
            
            <div className="flex items-center space-x-2">
              <LanguageSelector />
              {isAuthenticated && (
                <button
                  onClick={handleLogout}
                  className="p-2 text-gray-600 hover:text-gray-800 hover:bg-gray-100 rounded-lg transition-colors"
                >
                  <LogOut className="w-4 h-4" />
                </button>
              )}
            </div>
          </div>
        </div>
      </header>

      {/* Desktop Header */}
      <div className="max-w-7xl mx-auto space-y-6 p-4 pt-20 md:pt-6">
        <header className="hidden md:block bg-white shadow-xl rounded-2xl border border-gray-200 overflow-hidden">
          <div className="bg-gradient-to-r from-blue-600 to-blue-800 p-1">
            <div className="bg-white rounded-xl p-6">
              <div className="grid grid-cols-1 md:grid-cols-4 gap-6 items-center min-h-[100px]">
                {/* CFM Logo */}
                <div className="flex flex-col items-center text-center">
                  <div className="w-20 h-20 rounded-full bg-gradient-to-br from-blue-500 to-blue-700 border-4 border-white shadow-xl flex items-center justify-center mb-2">
                    <img
                      src={logoPath}
                      alt="CFM Logo"
                      className="w-14 h-14 object-contain filter brightness-110 contrast-110"
                    />
                  </div>
                  <span className="text-xs font-semibold text-gray-700">CFM-EP</span>
                </div>

                {/* Clock */}
                <div className="flex flex-col items-center text-center">
                  <div className="w-20 h-20 rounded-full bg-gradient-to-br from-green-500 to-green-700 border-4 border-white shadow-xl flex flex-col items-center justify-center mb-2">
                    <Clock className="w-5 h-5 text-white mb-1" />
                    <div className="text-white text-xs font-bold text-center leading-tight">
                      <div>{formatTime(currentTime)}</div>
                      <div className="text-xs opacity-90">{formatDate(currentTime).split('/').slice(0,2).join('/')}</div>
                    </div>
                  </div>
                  <span className="text-xs font-semibold text-gray-700">Hora Local</span>
                </div>

                {/* Terminal Status */}
                <div className="flex flex-col items-center text-center">
                  <div className="w-20 h-20 rounded-full bg-gradient-to-br from-purple-500 to-purple-700 border-4 border-white shadow-xl flex items-center justify-center overflow-hidden mb-2">
                    <img
                      src={terminalImagePath}
                      alt="Terminal da Beira"
                      className="w-16 h-16 object-cover filter saturate-150"
                    />
                  </div>
                  <span className="text-xs font-semibold text-gray-700">Terminal Beira</span>
                </div>

                {/* User & Controls */}
                <div className="flex flex-col items-center text-center space-y-3">
                  <div className="w-20 h-20 rounded-full bg-gradient-to-br from-orange-500 to-orange-700 border-4 border-white shadow-xl flex flex-col items-center justify-center">
                    {isAuthenticated ? (
                      <>
                        <User className="w-5 h-5 text-white mb-1" />
                        <span className="text-xs font-bold text-white truncate px-1">
                          {user?.firstName || user?.username || 'User'}
                        </span>
                      </>
                    ) : (
                      <a href="/login" className="text-white text-xs hover:bg-white hover:bg-opacity-20 px-2 py-1 rounded">
                        {t("Entrar")}
                      </a>
                    )}
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <LanguageSelector />
                    {isAuthenticated && (
                      <button
                        onClick={handleLogout}
                        className="p-2 bg-gray-100 hover:bg-gray-200 rounded-lg transition-colors group"
                        title="Sair"
                      >
                        <LogOut className="w-4 h-4 text-gray-600 group-hover:text-red-600" />
                      </button>
                    )}
                  </div>
                </div>
              </div>

              {/* Title and System Info */}
              <div className="text-center mt-6">
                <h1 className="text-2xl lg:text-3xl font-bold bg-gradient-to-r from-blue-600 to-blue-800 bg-clip-text text-transparent mb-3">
                  {t("Line Up - Beira Oil Terminal")}
                </h1>
                <div className="flex flex-col sm:flex-row items-center justify-center space-y-2 sm:space-y-0 sm:space-x-6 text-sm">
                  <div className="flex items-center gap-2 px-3 py-1 bg-green-50 rounded-full">
                    <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                    <span className="text-green-700 font-medium">{t("Sistema de Informação de Navios")}</span>
                  </div>
                  <div className="text-gray-600">{t("Desenvolvido por: Manuel Antonio, Eng.")}</div>
                </div>
              </div>
            </div>
          </div>
        </header>

        {/* Berth Maintenance Alert */}
        {maintenanceData && (maintenanceData as any).isActive && (
          <div className="bg-gradient-to-r from-red-500 to-red-600 rounded-2xl shadow-xl border border-red-300 overflow-hidden">
            <div className="bg-white/10 backdrop-blur-sm p-6">
              <div className="text-center">
                <div className="inline-flex items-center justify-center w-16 h-16 bg-white/20 rounded-full mb-4">
                  <AlertTriangle className="w-8 h-8 text-white" />
                </div>
                <h2 className="text-2xl font-bold text-white mb-3">
                  CAIS EM MANUTENÇÃO
                </h2>
                <div className="bg-white/20 rounded-lg p-3 mb-3">
                  <p className="text-white font-medium">
                    {t("Período")}: {(maintenanceData as any).startDate} - {(maintenanceData as any).endDate}
                  </p>
                </div>
                {(maintenanceData as any).description && (
                  <div className="text-white/90 text-sm uppercase font-semibold leading-relaxed">
                    {(maintenanceData as any).description}
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {/* Weather and Environmental Conditions */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Weather Conditions */}
          <Card className="bg-gradient-to-br from-blue-50 to-cyan-50 border-blue-200 shadow-lg">
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center gap-2 text-blue-800">
                <Cloud className="w-5 h-5" />
                {t("Condições Meteorológicas")}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-4">
                <div className="text-center">
                  <div className="text-2xl font-bold text-blue-600">
                    {weatherData && typeof weatherData === 'object' && (weatherData as any).temperature 
                      ? `${(weatherData as any).temperature}°C` 
                      : '--°C'}
                  </div>
                  <div className="text-sm text-gray-600">{t("Temperatura")}</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-blue-600">
                    {weatherData && typeof weatherData === 'object' && (weatherData as any).humidity 
                      ? `${(weatherData as any).humidity}%` 
                      : '--%'}
                  </div>
                  <div className="text-sm text-gray-600">{t("Humidade")}</div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Tide Information */}
          <Card className="bg-gradient-to-br from-teal-50 to-blue-50 border-teal-200 shadow-lg">
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center gap-2 text-teal-800">
                <Waves className="w-5 h-5" />
                {t("Informações de Maré")}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-4">
                <div className="text-center">
                  <div className="text-2xl font-bold text-teal-600">
                    {tideData && typeof tideData === 'object' && (tideData as any).currentTide 
                      ? `${((tideData as any).currentTide).toFixed(2)}m` 
                      : '--m'}
                  </div>
                  <div className="text-sm text-gray-600">{t("Altura da Maré")}</div>
                </div>
                <div className="text-center">
                  <div className="text-lg font-bold text-teal-600">
                    {tideData && typeof tideData === 'object' && (tideData as any).tideTime 
                      ? (tideData as any).tideTime 
                      : '--:--'}
                  </div>
                  <div className="text-sm text-gray-600">{t("Próxima Maré")}</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Current Ship at Berth */}
        {currentShipAtBerth && (
          <Card className="bg-gradient-to-br from-green-50 to-emerald-50 border-green-200 shadow-xl">
            <CardHeader className="pb-4">
              <CardTitle className="flex items-center gap-2 text-green-800 text-xl">
                <Anchor className="w-6 h-6" />
                {t("NAVIO NO CAIS 12")}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-2xl font-bold text-gray-800">{currentShipAtBerth.name}</h3>
                  <Badge variant="outline" className="text-green-700 border-green-300 bg-green-100">
                    {currentShipAtBerth.operationType === 'Nacional' && '🇲🇿 Nacional'}
                    {currentShipAtBerth.operationType === 'LPG' && '⛽ LPG'}
                    {currentShipAtBerth.operationType === 'Trânsito' && '🚢 Trânsito'}
                    {currentShipAtBerth.operationType === 'Combinado' && '🔄 Combinado'}
                  </Badge>
                </div>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                  <div>
                    <span className="font-semibold">{t("Marca")}:</span>
                    <div>{currentShipAtBerth.countermark}</div>
                  </div>
                  <div>
                    <span className="font-semibold">{t("Calado")}:</span>
                    <div>{currentShipAtBerth.draft}m</div>
                  </div>
                  <div>
                    <span className="font-semibold">{t("Armador")}:</span>
                    <div>{currentShipAtBerth.shipowner}</div>
                  </div>
                  <div>
                    <span className="font-semibold">{t("Agente")}:</span>
                    <div>{currentShipAtBerth.shipAgent}</div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Ship Queue Tabs */}
        <div className="space-y-6">
          <Tabs defaultValue="lineup" className="w-full">
            <TabsList className="grid w-full grid-cols-2 md:grid-cols-4 gap-1">
              <TabsTrigger value="lineup" className="text-xs md:text-sm p-2 md:p-3">
                <span className="hidden md:inline">{t("PRÓXIMOS 5 NAVIOS A ATRACAR")}</span>
                <span className="md:hidden">Próximos ({nextShips.length})</span>
              </TabsTrigger>
              <TabsTrigger value="with-instructions" className="text-xs md:text-sm p-2 md:p-3">
                <span className="hidden md:inline">{t("COM INSTRUÇÃO")}</span>
                <span className="md:hidden">Com Instrução ({shipsWithInstructions.length})</span>
              </TabsTrigger>
              <TabsTrigger value="without-instructions" className="text-xs md:text-sm p-2 md:p-3">
                <span className="hidden md:inline">{t("SEM INSTRUÇÃO")}</span>
                <span className="md:hidden">Sem Instrução ({shipsWithoutInstructions.length})</span>
              </TabsTrigger>
              <TabsTrigger value="expected" className="text-xs md:text-sm p-2 md:p-3">
                <span className="hidden md:inline">{t("PREVISTOS A CHEGAR")}</span>
                <span className="md:hidden">Previstos ({expectedArrivals.length})</span>
              </TabsTrigger>
            </TabsList>

            {/* Next Ships Tab */}
            <TabsContent value="lineup" className="space-y-4">
              <div className="flex justify-center items-center mb-4">
                <div className="bg-gradient-to-r from-blue-600 via-blue-500 to-blue-600 text-white px-8 py-4 rounded-full shadow-xl border-4 border-blue-300 transform hover:scale-105 transition-transform duration-200">
                  <h2 className="text-xl font-bold text-center flex items-center justify-center gap-3">
                    {t("PRÓXIMOS 5 NAVIOS A ATRACAR")}
                    <span className="bg-white text-blue-600 rounded-full px-4 py-2 text-lg font-bold shadow-inner border-2 border-blue-200">
                      {nextShips.length}
                    </span>
                  </h2>
                </div>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {nextShips.map((ship: Ship) => (
                  <Card key={ship.id} className="bg-blue-50 border-blue-200 shadow-sm">
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between mb-2">
                        <h3 className="font-semibold text-gray-800">{ship.name}</h3>
                        <Badge className="bg-blue-100 text-blue-800 text-xs">Próximo</Badge>
                      </div>
                      <div className="space-y-1 text-sm text-gray-600 mb-3">
                        <div>{ship.countermark}</div>
                        <div>{t("Calado")}: {ship.draft}m</div>
                        <div className="flex items-center gap-1">
                          <Badge variant="outline" className="text-xs">
                            {ship.operationType === 'Nacional' && '🇲🇿 Nacional'}
                            {ship.operationType === 'LPG' && '⛽ LPG'}
                            {ship.operationType === 'Trânsito' && '🚢 Trânsito'}
                            {ship.operationType === 'Combinado' && '🔄 Combinado'}
                          </Badge>
                          {ship.cargoAgent?.toLowerCase().includes('imopetro') && (
                            <Badge variant="destructive" className="text-xs">
                              🚨 PRIORIDADE
                            </Badge>
                          )}
                        </div>
                      </div>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => setSelectedShip(ship)}
                        className="w-full"
                      >
                        <Info className="w-4 h-4 mr-1" />
                        Ver Detalhes
                      </Button>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            {/* Ships with Instructions Tab */}
            <TabsContent value="with-instructions" className="space-y-4">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-lg font-semibold text-gray-800">Navios com Instruções de Descarga</h3>
                <Button variant="outline" size="sm" className="border-green-500 text-green-700 hover:bg-green-50">
                  <FileText className="w-4 h-4 mr-2" />
                  Instruções Confirmadas
                </Button>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {shipsWithInstructions.map((ship: Ship) => (
                  <Card key={ship.id} className="bg-green-50 border-green-200 shadow-sm">
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between mb-2">
                        <h3 className="font-semibold text-gray-800">{ship.name}</h3>
                        <Badge className="bg-green-100 text-green-800 text-xs">Com Instrução</Badge>
                      </div>
                      <div className="space-y-1 text-sm text-gray-600 mb-3">
                        <div>{ship.countermark}</div>
                        <div>{t("Calado")}: {ship.draft}m</div>
                        <div className="flex items-center gap-1">
                          <Badge variant="outline" className="text-xs">
                            {ship.operationType === 'Nacional' && '🇲🇿 Nacional'}
                            {ship.operationType === 'LPG' && '⛽ LPG'}
                            {ship.operationType === 'Trânsito' && '🚢 Trânsito'}
                            {ship.operationType === 'Combinado' && '🔄 Combinado'}
                          </Badge>
                          {ship.cargoAgent?.toLowerCase().includes('imopetro') && (
                            <Badge variant="destructive" className="text-xs">
                              🚨 PRIORIDADE
                            </Badge>
                          )}
                        </div>
                      </div>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => setSelectedShip(ship)}
                        className="w-full"
                      >
                        <Info className="w-4 h-4 mr-1" />
                        Ver Detalhes
                      </Button>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            {/* Ships without Instructions Tab */}
            <TabsContent value="without-instructions" className="space-y-4">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-lg font-semibold text-gray-800">Navios Aguardando Instruções</h3>
                <Button variant="outline" size="sm" className="border-orange-500 text-orange-700 hover:bg-orange-50">
                  <FileText className="w-4 h-4 mr-2" />
                  Pendências de Instrução
                </Button>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {shipsWithoutInstructions.map((ship: Ship) => (
                  <Card key={ship.id} className="bg-orange-50 border-orange-200 shadow-sm">
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between mb-2">
                        <h3 className="font-semibold text-gray-800">{ship.name}</h3>
                        <Badge variant="secondary" className="bg-orange-100 text-orange-800 text-xs">Sem Instrução</Badge>
                      </div>
                      <div className="space-y-1 text-sm text-gray-600 mb-3">
                        <div>{ship.countermark}</div>
                        <div>{t("Calado")}: {ship.draft}m</div>
                        <div className="flex items-center gap-1">
                          <Badge variant="outline" className="text-xs">
                            {ship.operationType === 'Nacional' && '🇲🇿 Nacional'}
                            {ship.operationType === 'LPG' && '⛽ LPG'}
                            {ship.operationType === 'Trânsito' && '🚢 Trânsito'}
                            {ship.operationType === 'Combinado' && '🔄 Combinado'}
                          </Badge>
                          {ship.cargoAgent?.toLowerCase().includes('imopetro') && (
                            <Badge variant="destructive" className="text-xs">
                              🚨 PRIORIDADE
                            </Badge>
                          )}
                        </div>
                      </div>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => setSelectedShip(ship)}
                        className="w-full"
                      >
                        <Info className="w-4 h-4 mr-1" />
                        Ver Detalhes
                      </Button>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            {/* Expected Arrivals Tab */}
            <TabsContent value="expected" className="space-y-4">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-lg font-semibold text-gray-800">Navios Previstos para Chegada</h3>
                <Button variant="outline" size="sm" className="border-purple-500 text-purple-700 hover:bg-purple-50">
                  <FileText className="w-4 h-4 mr-2" />
                  Cronograma de Chegadas
                </Button>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {expectedArrivals.map((ship: Ship) => (
                  <Card key={ship.id} className="bg-purple-50 border-purple-200 shadow-sm">
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between mb-2">
                        <h3 className="font-semibold text-gray-800">{ship.name}</h3>
                        <Badge className="bg-purple-100 text-purple-800 text-xs">Previsto</Badge>
                      </div>
                      <div className="space-y-1 text-sm text-gray-600 mb-3">
                        <div>{ship.countermark}</div>
                        <div>{t("Calado")}: {ship.draft}m</div>
                        <div className="flex items-center gap-1">
                          <Badge variant="outline" className="text-xs">
                            {ship.operationType === 'Nacional' && '🇲🇿 Nacional'}
                            {ship.operationType === 'LPG' && '⛽ LPG'}
                            {ship.operationType === 'Trânsito' && '🚢 Trânsito'}
                            {ship.operationType === 'Combinado' && '🔄 Combinado'}
                          </Badge>
                        </div>
                      </div>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => setSelectedShip(ship)}
                        className="w-full"
                      >
                        <Info className="w-4 h-4 mr-1" />
                        Ver Detalhes
                      </Button>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>
          </Tabs>
        </div>

        {/* Quick Actions - Only for authenticated users */}
        {isAuthenticated && (
          <Card className="bg-gradient-to-br from-indigo-50 to-purple-50 border-indigo-200 shadow-lg">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-indigo-800">
                <Settings className="w-5 h-5" />
                {t("Ações Rápidas")}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                <Button 
                  variant="outline"
                  className="w-full border-blue-500 text-blue-700 hover:bg-blue-50"
                  onClick={() => setShowShipRegistration(true)}
                >
                  <Plus className="w-4 h-4 mr-2" />
                  Registrar Navio
                </Button>
                <Button 
                  variant="outline"
                  className="w-full border-green-500 text-green-700 hover:bg-green-50"
                  disabled={!currentShipAtBerth}
                >
                  <Anchor className="w-4 h-4 mr-2" />
                  Atracação do Navio
                </Button>
                <Button 
                  variant="outline"
                  className="w-full border-red-500 text-red-700 hover:bg-red-50"
                  disabled={!currentShipAtBerth}
                >
                  <Ship className="w-4 h-4 mr-2" />
                  Desatracação do Navio
                </Button>
                <Button 
                  variant="outline"
                  className="w-full border-orange-500 text-orange-700 hover:bg-orange-50"
                  disabled={!shipsWithoutInstructions.length}
                >
                  <ArrowUp className="w-4 h-4 mr-2" />
                  Mover para Instrução
                </Button>
              </div>
            </CardContent>
          </Card>
        )}
      </div>

      {/* Floating AI Assistant Button */}
      <div className="fixed bottom-6 right-6 z-50">
        <button
          onClick={() => setIsGeminiAIOpen(true)}
          className="w-16 h-16 bg-gradient-to-r from-purple-600 via-pink-600 to-blue-600 hover:from-purple-700 hover:via-pink-700 hover:to-blue-700 text-white rounded-full shadow-2xl hover:shadow-3xl transition-all duration-300 flex items-center justify-center group animate-pulse"
          title="Gemini AI Assistant"
        >
          <div className="flex flex-col items-center">
            <svg className="w-7 h-7" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
            </svg>
          </div>
        </button>
      </div>

      {/* Simple Ship Registration Modal */}
      {showShipRegistration && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 max-w-md w-full mx-4">
            <h3 className="text-lg font-semibold mb-4">Registro de Navio</h3>
            <p className="text-gray-600 mb-4">Funcionalidade em desenvolvimento</p>
            <Button onClick={() => setShowShipRegistration(false)}>Fechar</Button>
          </div>
        </div>
      )}

      {/* Simple Ship Info Modal */}
      {selectedShip && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 max-w-2xl w-full mx-4 max-h-[80vh] overflow-y-auto">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-semibold">Informações do Navio</h3>
              <Button 
                variant="outline" 
                size="sm"
                onClick={() => setSelectedShip(null)}
              >
                <X className="w-4 h-4" />
              </Button>
            </div>
            <div className="space-y-4">
              <div><strong>Nome:</strong> {selectedShip.name}</div>
              <div><strong>Marca:</strong> {selectedShip.countermark}</div>
              <div><strong>Calado:</strong> {selectedShip.draft}m</div>
              <div><strong>Tipo de Carga:</strong> {selectedShip.cargoType}</div>
              <div><strong>Armador:</strong> {selectedShip.shipowner}</div>
              <div><strong>Status:</strong> {selectedShip.status}</div>
            </div>
          </div>
        </div>
      )}

      {/* Gemini AI Assistant */}
      <GeminiAIAssistant
        isOpen={isGeminiAIOpen}
        onClose={() => setIsGeminiAIOpen(false)}
        userRole={user?.role || 'visitor'}
        language="pt"
      />

      {/* Communication Panel */}
      <CommunicationPanel
        isOpen={showCommunicationPanel}
        onClose={() => setShowCommunicationPanel(false)}
        userRole={user?.role || 'visitor'}
      />
    </div>
  );
}