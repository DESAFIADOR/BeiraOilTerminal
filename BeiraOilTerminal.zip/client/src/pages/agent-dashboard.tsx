import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Ship, User, Calendar, Clock, FileText, CheckCircle, AlertCircle, Plus, Navigation, Anchor } from "lucide-react";

interface Ship {
  id: number;
  name: string;
  countermark: string;
  status: string;
  operationType: string;
  hasDischargeInstructions: boolean;
  arrivalDateTime: string;
  shipowner: string;
  cargoDestination: string;
}

export default function AgentDashboard() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const [newShipData, setNewShipData] = useState({
    name: "",
    countermark: "",
    expectedArrivalDate: "",
    draft: "",
    armador: "",
    destinoCarga: "",
    operationType: "Trânsito",
    cargoType: "",
    shipAgentEmail: "",
    cargoAgentEmail: ""
  });

  const [arrivalConfirmation, setArrivalConfirmation] = useState({
    shipId: 0,
    arrivalDateTime: ""
  });

  const [instructionConfirmation, setInstructionConfirmation] = useState({
    shipId: 0,
    confirmationType: "manual" as "manual" | "email",
    confirmationNotes: "",
    attachmentData: ""
  });

  const [showAddShip, setShowAddShip] = useState(false);
  const [showConfirmArrival, setShowConfirmArrival] = useState(false);
  const [showConfirmInstructions, setShowConfirmInstructions] = useState(false);

  // Buscar navios
  const { data: shipsData, isLoading: loadingShips } = useQuery({
    queryKey: ["/api/agent/ships"],
    refetchInterval: 10000
  });

  const ships = Array.isArray(shipsData) ? shipsData : [];

  // Buscar navios ordenados
  const { data: orderedShipsData } = useQuery({
    queryKey: ["/api/agent/ships/ordered"],
    refetchInterval: 15000
  });

  // Adicionar navio
  const addShipMutation = useMutation({
    mutationFn: async (shipData: any) => {
      return await apiRequest("/api/agent/ships", {
        method: "POST",
        body: JSON.stringify(shipData)
      });
    },
    onSuccess: () => {
      toast({
        title: "Sucesso",
        description: "Navio adicionado aos Previstos a Chegar"
      });
      setNewShipData({
        name: "",
        countermark: "",
        expectedArrivalDate: "",
        draft: "",
        armador: "",
        destinoCarga: "",
        operationType: "Trânsito",
        cargoType: "",
        shipAgentEmail: "",
        cargoAgentEmail: ""
      });
      setShowAddShip(false);
      queryClient.invalidateQueries({ queryKey: ["/api/agent/ships"] });
    },
    onError: (error: any) => {
      toast({
        title: "Erro",
        description: error.message || "Falha ao adicionar navio",
        variant: "destructive"
      });
    }
  });

  // Confirmar chegada
  const confirmArrivalMutation = useMutation({
    mutationFn: async ({ shipId, arrivalDateTime }: { shipId: number; arrivalDateTime: string }) => {
      return await apiRequest(`/api/agent/ships/${shipId}/confirm-arrival`, {
        method: "POST",
        body: JSON.stringify({ arrivalDateTime })
      });
    },
    onSuccess: () => {
      toast({
        title: "Sucesso",
        description: "Chegada confirmada - navio movido para Sem Instrução"
      });
      setShowConfirmArrival(false);
      queryClient.invalidateQueries({ queryKey: ["/api/agent/ships"] });
    },
    onError: (error: any) => {
      toast({
        title: "Erro",
        description: error.message || "Falha ao confirmar chegada",
        variant: "destructive"
      });
    }
  });

  // Confirmar instruções
  const confirmInstructionsMutation = useMutation({
    mutationFn: async ({ shipId, data }: { shipId: number; data: any }) => {
      return await apiRequest(`/api/agent/ships/${shipId}/confirm-instructions`, {
        method: "POST",
        body: JSON.stringify(data)
      });
    },
    onSuccess: () => {
      toast({
        title: "Sucesso",
        description: "Instruções confirmadas - email enviado automaticamente"
      });
      setShowConfirmInstructions(false);
      queryClient.invalidateQueries({ queryKey: ["/api/agent/ships"] });
    },
    onError: (error: any) => {
      toast({
        title: "Erro",
        description: error.message || "Falha ao confirmar instruções",
        variant: "destructive"
      });
    }
  });

  const expectedShips = Array.isArray(ships) ? ships.filter((ship: Ship) => ship.status === "expected") : [];
  const atBarShips = Array.isArray(ships) ? ships.filter((ship: Ship) => ship.status === "at_bar") : [];
  const withoutInstructions = atBarShips.filter((ship: Ship) => !ship.hasDischargeInstructions);
  const withInstructions = atBarShips.filter((ship: Ship) => ship.hasDischargeInstructions);
  const awaitingInstructions = Array.isArray(ships) ? ships.filter((ship: Ship) => 
    ship.status === "next_to_berth" && ship.hasDischargeInstructions
  ) : [];

  const formatDateTime = (dateString: string) => {
    return new Date(dateString).toLocaleString('pt-BR', { 
      timeZone: 'Africa/Maputo',
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const getOperationTypeBadge = (operationType: string) => {
    const colors = {
      'Nacional': 'bg-blue-100 text-blue-800',
      'LPG': 'bg-orange-100 text-orange-800',
      'Trânsito': 'bg-green-100 text-green-800',
      'Combinada': 'bg-purple-100 text-purple-800'
    };
    return colors[operationType as keyof typeof colors] || 'bg-gray-100 text-gray-800';
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="bg-white rounded-lg shadow-md p-6 mb-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-3">
                <Anchor className="h-8 w-8 text-blue-600" />
                Painel do Agente Marítimo
              </h1>
              <p className="text-gray-600 mt-2">Gestão de navios e confirmações de instruções</p>
            </div>
            <div className="flex gap-3">
              <Dialog open={showAddShip} onOpenChange={setShowAddShip}>
                <DialogTrigger asChild>
                  <Button className="bg-blue-600 hover:bg-blue-700">
                    <Plus className="h-4 w-4 mr-2" />
                    Adicionar Navio
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-2xl">
                  <DialogHeader>
                    <DialogTitle>Adicionar Navio aos Previstos a Chegar</DialogTitle>
                    <DialogDescription>
                      Preencha os dados do navio que será adicionado à lista de previstos
                    </DialogDescription>
                  </DialogHeader>
                  <div className="grid grid-cols-2 gap-4 py-4">
                    <div>
                      <Label htmlFor="name">Nome do Navio *</Label>
                      <Input
                        id="name"
                        value={newShipData.name}
                        onChange={(e) => setNewShipData({...newShipData, name: e.target.value})}
                        placeholder="Ex: MV ATLANTICO"
                      />
                    </div>
                    <div>
                      <Label htmlFor="countermark">Contramarque *</Label>
                      <Input
                        id="countermark"
                        value={newShipData.countermark}
                        onChange={(e) => setNewShipData({...newShipData, countermark: e.target.value})}
                        placeholder="Ex: 1234A"
                      />
                    </div>
                    <div>
                      <Label htmlFor="expectedArrivalDate">Data/Hora Prevista *</Label>
                      <Input
                        id="expectedArrivalDate"
                        type="datetime-local"
                        value={newShipData.expectedArrivalDate}
                        onChange={(e) => setNewShipData({...newShipData, expectedArrivalDate: e.target.value})}
                      />
                    </div>
                    <div>
                      <Label htmlFor="draft">Calado (m) *</Label>
                      <Input
                        id="draft"
                        type="number"
                        step="0.1"
                        value={newShipData.draft}
                        onChange={(e) => setNewShipData({...newShipData, draft: e.target.value})}
                        placeholder="Ex: 8.5"
                      />
                    </div>
                    <div>
                      <Label htmlFor="armador">Armador *</Label>
                      <Input
                        id="armador"
                        value={newShipData.armador}
                        onChange={(e) => setNewShipData({...newShipData, armador: e.target.value})}
                        placeholder="Nome do armador"
                      />
                    </div>
                    <div>
                      <Label htmlFor="destinoCarga">Destino da Carga *</Label>
                      <Input
                        id="destinoCarga"
                        value={newShipData.destinoCarga}
                        onChange={(e) => setNewShipData({...newShipData, destinoCarga: e.target.value})}
                        placeholder="Destino da carga"
                      />
                    </div>
                    <div>
                      <Label htmlFor="operationType">Tipo de Operação *</Label>
                      <Select value={newShipData.operationType} onValueChange={(value) => setNewShipData({...newShipData, operationType: value})}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="Nacional">Nacional</SelectItem>
                          <SelectItem value="Trânsito">Trânsito</SelectItem>
                          <SelectItem value="Combinada">Combinada</SelectItem>
                          <SelectItem value="LPG">LPG</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label htmlFor="cargoType">Tipo de Carga *</Label>
                      <Input
                        id="cargoType"
                        value={newShipData.cargoType}
                        onChange={(e) => setNewShipData({...newShipData, cargoType: e.target.value})}
                        placeholder="Ex: Gasolina, Diesel"
                      />
                    </div>
                    <div>
                      <Label htmlFor="shipAgentEmail">Email Agente Marítimo</Label>
                      <Input
                        id="shipAgentEmail"
                        type="email"
                        value={newShipData.shipAgentEmail}
                        onChange={(e) => setNewShipData({...newShipData, shipAgentEmail: e.target.value})}
                        placeholder="agente@exemplo.com"
                      />
                    </div>
                    <div>
                      <Label htmlFor="cargoAgentEmail">Email Agente de Carga</Label>
                      <Input
                        id="cargoAgentEmail"
                        type="email"
                        value={newShipData.cargoAgentEmail}
                        onChange={(e) => setNewShipData({...newShipData, cargoAgentEmail: e.target.value})}
                        placeholder="carga@exemplo.com"
                      />
                    </div>
                  </div>
                  <DialogFooter>
                    <Button variant="outline" onClick={() => setShowAddShip(false)}>
                      Cancelar
                    </Button>
                    <Button 
                      onClick={() => {
                        const shipDataForAPI = {
                          ...newShipData,
                          expectedArrivalDate: new Date(newShipData.expectedArrivalDate).toISOString(),
                          draft: parseFloat(newShipData.draft) || 0
                        };
                        addShipMutation.mutate(shipDataForAPI);
                      }}
                      disabled={addShipMutation.isPending || !newShipData.name || !newShipData.countermark || !newShipData.expectedArrivalDate}
                    >
                      {addShipMutation.isPending ? "Adicionando..." : "Adicionar Navio"}
                    </Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
            </div>
          </div>
        </div>

        {/* Statistics Cards */}
        <div className="grid grid-cols-1 md:grid-cols-5 gap-6 mb-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Previstos a Chegar</CardTitle>
              <Calendar className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{expectedShips.length}</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Sem Instrução</CardTitle>
              <AlertCircle className="h-4 w-4 text-orange-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{withoutInstructions.length}</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Com Instrução</CardTitle>
              <CheckCircle className="h-4 w-4 text-green-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{withInstructions.length}</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Aguardando Instrução</CardTitle>
              <Clock className="h-4 w-4 text-blue-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{awaitingInstructions.length}</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total de Navios</CardTitle>
              <Ship className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{ships.length}</div>
            </CardContent>
          </Card>
        </div>

        {/* Ship Lists */}
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Previstos a Chegar */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Calendar className="h-5 w-5" />
                Previstos a Chegar ({expectedShips.length})
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {expectedShips.map((ship: Ship) => (
                <div key={ship.id} className="p-3 border rounded-lg">
                  <div className="flex justify-between items-start mb-2">
                    <h4 className="font-semibold">{ship.name}</h4>
                    <span className={`px-2 py-1 text-xs rounded-full ${getOperationTypeBadge(ship.operationType)}`}>
                      {ship.operationType}
                    </span>
                  </div>
                  <p className="text-sm text-gray-600">{ship.countermark}</p>
                  <p className="text-xs text-gray-500 mt-1">
                    Previsto: {formatDateTime(ship.arrivalDateTime)}
                  </p>
                  <Button
                    size="sm"
                    className="mt-2 w-full"
                    onClick={() => {
                      setArrivalConfirmation({ shipId: ship.id, arrivalDateTime: "" });
                      setShowConfirmArrival(true);
                    }}
                  >
                    <Clock className="h-4 w-4 mr-1" />
                    Confirmar Chegada
                  </Button>
                </div>
              ))}
              {expectedShips.length === 0 && (
                <div className="text-center text-gray-500 py-4">
                  Nenhum navio previsto
                </div>
              )}
            </CardContent>
          </Card>

          {/* Sem Instrução */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <AlertCircle className="h-5 w-5 text-orange-500" />
                Sem Instrução ({withoutInstructions.length})
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {withoutInstructions.map((ship: Ship) => (
                <div key={ship.id} className="p-3 border rounded-lg">
                  <div className="flex justify-between items-start mb-2">
                    <h4 className="font-semibold">{ship.name}</h4>
                    <span className={`px-2 py-1 text-xs rounded-full ${getOperationTypeBadge(ship.operationType)}`}>
                      {ship.operationType}
                    </span>
                  </div>
                  <p className="text-sm text-gray-600">{ship.countermark}</p>
                  <p className="text-xs text-gray-500 mt-1">
                    Chegou: {formatDateTime(ship.arrivalDateTime)}
                  </p>
                  <Button
                    size="sm"
                    className="mt-2 w-full"
                    variant="outline"
                    onClick={() => {
                      setInstructionConfirmation({ 
                        shipId: ship.id, 
                        confirmationType: "manual",
                        confirmationNotes: "",
                        attachmentData: ""
                      });
                      setShowConfirmInstructions(true);
                    }}
                  >
                    <FileText className="h-4 w-4 mr-1" />
                    Confirmar Instruções
                  </Button>
                </div>
              ))}
              {withoutInstructions.length === 0 && (
                <div className="text-center text-gray-500 py-4">
                  Todos os navios têm instruções
                </div>
              )}
            </CardContent>
          </Card>

          {/* Com Instrução */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <CheckCircle className="h-5 w-5 text-green-500" />
                Com Instrução ({withInstructions.length})
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {withInstructions.map((ship: Ship) => (
                <div key={ship.id} className="p-3 border rounded-lg bg-green-50">
                  <div className="flex justify-between items-start mb-2">
                    <h4 className="font-semibold">{ship.name}</h4>
                    <span className={`px-2 py-1 text-xs rounded-full ${getOperationTypeBadge(ship.operationType)}`}>
                      {ship.operationType}
                    </span>
                  </div>
                  <p className="text-sm text-gray-600">{ship.countermark}</p>
                  <p className="text-xs text-gray-500 mt-1">
                    Chegou: {formatDateTime(ship.arrivalDateTime)}
                  </p>
                  <div className="mt-2 flex items-center text-green-700">
                    <CheckCircle className="h-4 w-4 mr-1" />
                    <span className="text-xs">Instruções confirmadas</span>
                  </div>
                </div>
              ))}
              {withInstructions.length === 0 && (
                <div className="text-center text-gray-500 py-4">
                  Nenhum navio com instruções
                </div>
              )}
            </CardContent>
          </Card>

          {/* Navios Aguardando Instrução */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Clock className="h-5 w-5 text-blue-500" />
                Aguardando Instrução ({awaitingInstructions.length})
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {awaitingInstructions.map((ship: Ship) => (
                <div key={ship.id} className="p-3 border rounded-lg bg-blue-50">
                  <div className="flex justify-between items-start mb-2">
                    <h4 className="font-semibold">{ship.name}</h4>
                    <span className={`px-2 py-1 text-xs rounded-full ${getOperationTypeBadge(ship.operationType)}`}>
                      {ship.operationType}
                    </span>
                  </div>
                  <p className="text-sm text-gray-600">{ship.countermark}</p>
                  <p className="text-xs text-gray-500 mt-1">
                    Chegou: {formatDateTime(ship.arrivalDateTime)}
                  </p>
                  <div className="mt-2 flex items-center text-blue-700">
                    <Clock className="h-4 w-4 mr-1" />
                    <span className="text-xs">Próximo a atracar</span>
                  </div>
                </div>
              ))}
              {awaitingInstructions.length === 0 && (
                <div className="text-center text-gray-500 py-4">
                  Nenhum navio aguardando
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Confirm Arrival Dialog */}
        <Dialog open={showConfirmArrival} onOpenChange={setShowConfirmArrival}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Confirmar Chegada na Barra</DialogTitle>
              <DialogDescription>
                Confirme a data e hora exata da chegada do navio na barra
              </DialogDescription>
            </DialogHeader>
            <div className="py-4">
              <Label htmlFor="arrivalDateTime">Data e Hora da Chegada</Label>
              <Input
                id="arrivalDateTime"
                type="datetime-local"
                value={arrivalConfirmation.arrivalDateTime}
                onChange={(e) => setArrivalConfirmation({
                  ...arrivalConfirmation,
                  arrivalDateTime: e.target.value
                })}
              />
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setShowConfirmArrival(false)}>
                Cancelar
              </Button>
              <Button 
                onClick={() => confirmArrivalMutation.mutate(arrivalConfirmation)}
                disabled={confirmArrivalMutation.isPending || !arrivalConfirmation.arrivalDateTime}
              >
                {confirmArrivalMutation.isPending ? "Confirmando..." : "Confirmar Chegada"}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Confirm Instructions Dialog */}
        <Dialog open={showConfirmInstructions} onOpenChange={setShowConfirmInstructions}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Confirmar Instruções de Descarga</DialogTitle>
              <DialogDescription>
                Confirme as instruções de descarga. Um email será enviado automaticamente para doptp03@gmail.com
              </DialogDescription>
            </DialogHeader>
            <div className="py-4 space-y-4">
              <div>
                <Label htmlFor="confirmationType">Tipo de Confirmação</Label>
                <Select 
                  value={instructionConfirmation.confirmationType} 
                  onValueChange={(value: "manual" | "email") => 
                    setInstructionConfirmation({
                      ...instructionConfirmation,
                      confirmationType: value
                    })
                  }
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="manual">Confirmação Manual</SelectItem>
                    <SelectItem value="email">Confirmação por Email</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="confirmationNotes">Observações (opcional)</Label>
                <Textarea
                  id="confirmationNotes"
                  value={instructionConfirmation.confirmationNotes}
                  onChange={(e) => setInstructionConfirmation({
                    ...instructionConfirmation,
                    confirmationNotes: e.target.value
                  })}
                  placeholder="Adicione observações sobre a confirmação..."
                />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setShowConfirmInstructions(false)}>
                Cancelar
              </Button>
              <Button 
                onClick={() => confirmInstructionsMutation.mutate({
                  shipId: instructionConfirmation.shipId,
                  data: {
                    confirmationType: instructionConfirmation.confirmationType,
                    confirmationNotes: instructionConfirmation.confirmationNotes
                  }
                })}
                disabled={confirmInstructionsMutation.isPending}
              >
                {confirmInstructionsMutation.isPending ? "Confirmando..." : "Confirmar Instruções"}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}