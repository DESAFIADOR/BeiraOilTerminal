import { useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { UserPlus, ArrowLeft } from "lucide-react";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

export function Register() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [formData, setFormData] = useState({
    username: "",
    password: "",
    confirmPassword: "",
    email: "",
    firstName: "",
    lastName: "",
    role: "publico"
  });

  const registerMutation = useMutation({
    mutationFn: async (data: any) => {
      console.log("Iniciando registro com dados:", data);
      
      // Validar dados antes de enviar
      if (!data.username || !data.password || !data.firstName || !data.lastName) {
        throw new Error("Todos os campos obrigatórios devem ser preenchidos");
      }

      try {
        // Tentativa principal com fetch
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 10000); // 10s timeout

        const response = await fetch("/api/register", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "Accept": "application/json",
          },
          credentials: "include",
          body: JSON.stringify(data),
          signal: controller.signal,
        });

        clearTimeout(timeoutId);
        console.log("Status da resposta:", response.status);

        if (!response.ok) {
          let errorMessage = "Erro no servidor";
          try {
            const errorText = await response.text();
            const errorData = JSON.parse(errorText);
            errorMessage = errorData.message || errorText;
          } catch (e) {
            errorMessage = response.statusText || `Erro HTTP ${response.status}`;
          }
          console.error("Erro HTTP:", response.status, errorMessage);
          throw new Error(errorMessage);
        }

        const result = await response.json();
        console.log("Resposta do registro:", result);
        
        if (!result || typeof result !== 'object') {
          throw new Error("Resposta inválida do servidor");
        }

        return result;
      } catch (error: any) {
        console.error("Erro na API de registro:", error);
        
        if (error.name === 'AbortError') {
          throw new Error("Timeout na conexão. Tente novamente.");
        }
        
        if (error.message.includes('Failed to fetch') || error.message.includes('NetworkError')) {
          throw new Error("Erro de conexão. Verifique sua internet e tente novamente.");
        }
        
        throw error;
      }
    },
    onSuccess: (data: any) => {
      console.log("Registro bem-sucedido:", data);
      if (data && data.status === "pending") {
        toast({
          title: "Cadastro realizado com sucesso!",
          description: "Sua solicitação está aguardando aprovação do administrador.",
        });
      } else {
        toast({
          title: "Cadastro realizado com sucesso!",
          description: "Você já pode fazer login no sistema.",
        });
      }
      setTimeout(() => {
        setLocation("/login");
      }, 1500);
    },
    onError: (error: any) => {
      console.error("Erro no processo de registro:", error);
      toast({
        title: "Erro no cadastro",
        description: error.message || "Ocorreu um erro durante o cadastro. Tente novamente.",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log("Formulário submetido com dados:", formData);

    // Validações detalhadas
    if (!formData.username || formData.username.trim().length === 0) {
      toast({
        title: "Campo obrigatório",
        description: "Nome de usuário é obrigatório.",
        variant: "destructive",
      });
      return;
    }

    if (!formData.password || formData.password.length === 0) {
      toast({
        title: "Campo obrigatório",
        description: "Senha é obrigatória.",
        variant: "destructive",
      });
      return;
    }

    if (!formData.firstName || formData.firstName.trim().length === 0) {
      toast({
        title: "Campo obrigatório",
        description: "Nome é obrigatório.",
        variant: "destructive",
      });
      return;
    }

    if (!formData.lastName || formData.lastName.trim().length === 0) {
      toast({
        title: "Campo obrigatório",
        description: "Sobrenome é obrigatório.",
        variant: "destructive",
      });
      return;
    }

    if (!formData.confirmPassword || formData.confirmPassword.length === 0) {
      toast({
        title: "Campo obrigatório",
        description: "Confirmação de senha é obrigatória.",
        variant: "destructive",
      });
      return;
    }

    if (formData.password !== formData.confirmPassword) {
      toast({
        title: "Senhas não coincidem",
        description: "A confirmação de senha deve ser igual à senha.",
        variant: "destructive",
      });
      return;
    }

    if (formData.password.length < 3) {
      toast({
        title: "Senha muito curta",
        description: "A senha deve ter pelo menos 3 caracteres.",
        variant: "destructive",
      });
      return;
    }

    // Preparar dados para submissão
    const { confirmPassword, ...submitData } = formData;
    
    // Garantir que todos os campos estão limpos e válidos
    const cleanData = {
      username: submitData.username.trim(),
      password: submitData.password,
      firstName: submitData.firstName.trim(),
      lastName: submitData.lastName.trim(),
      email: submitData.email ? submitData.email.trim() : null,
      role: submitData.role || "user"
    };

    console.log("Dados limpos para envio:", cleanData);
    registerMutation.mutate(cleanData);
  };

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-slate-100 flex items-center justify-center p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="space-y-1">
          <div className="flex items-center gap-2">
            <UserPlus className="h-6 w-6 text-blue-600" />
            <CardTitle className="text-2xl">Cadastro</CardTitle>
          </div>
          <CardDescription>
            Crie sua conta para acessar o sistema de line-up do Terminal Beira
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="firstName">Nome *</Label>
                <Input
                  id="firstName"
                  type="text"
                  placeholder="Seu nome"
                  value={formData.firstName}
                  onChange={(e) => handleInputChange("firstName", e.target.value)}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="lastName">Sobrenome *</Label>
                <Input
                  id="lastName"
                  type="text"
                  placeholder="Seu sobrenome"
                  value={formData.lastName}
                  onChange={(e) => handleInputChange("lastName", e.target.value)}
                  required
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="username">Nome de Usuário *</Label>
              <Input
                id="username"
                type="text"
                placeholder="Digite seu nome de usuário"
                value={formData.username}
                onChange={(e) => handleInputChange("username", e.target.value)}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                type="email"
                placeholder="seu.email@exemplo.com"
                value={formData.email}
                onChange={(e) => handleInputChange("email", e.target.value)}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="password">Senha *</Label>
              <Input
                id="password"
                type="password"
                placeholder="Digite sua senha"
                value={formData.password}
                onChange={(e) => handleInputChange("password", e.target.value)}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="confirmPassword">Confirmar Senha *</Label>
              <Input
                id="confirmPassword"
                type="password"
                placeholder="Confirme sua senha"
                value={formData.confirmPassword}
                onChange={(e) => handleInputChange("confirmPassword", e.target.value)}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="role">Tipo de Usuário</Label>
              <Select value={formData.role} onValueChange={(value) => handleInputChange("role", value)}>
                <SelectTrigger>
                  <SelectValue placeholder="Selecione o tipo de usuário" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="publico">Público</SelectItem>
                  <SelectItem value="line_up">Line Up</SelectItem>
                  <SelectItem value="gestores">Gestores</SelectItem>
                  <SelectItem value="ctos">CTOs</SelectItem>
                  <SelectItem value="desenvolvedor">Desenvolvedor</SelectItem>
                  <SelectItem value="agente_navio">Agente do Navio</SelectItem>
                </SelectContent>
              </Select>
              <p className="text-sm text-gray-600">
                {formData.role === 'publico' && 'Acesso público apenas para visualização básica do line-up.'}
                {formData.role === 'line_up' && 'Acesso básico para visualização e operações básicas de line-up.'}
                {formData.role === 'gestores' && 'Acesso de gestão com permissões para aprovar e supervisionar operações.'}
                {formData.role === 'ctos' && 'Acesso executivo com controle total sobre o sistema e relatórios.'}
                {formData.role === 'desenvolvedor' && 'Acesso completo ao sistema incluindo configurações técnicas.'}
                {formData.role === 'agente_navio' && 'Agente marítimo com permissões para adicionar navios, confirmar chegadas e gerenciar instruções de descarga.'}
              </p>
            </div>

            <Button
              type="submit"
              className="w-full bg-blue-600 hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed"
              disabled={registerMutation.isPending}
            >
              {registerMutation.isPending ? (
                <div className="flex items-center justify-center">
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
                  Criando conta...
                </div>
              ) : (
                "Criar Conta"
              )}
            </Button>
          </form>

          <div className="mt-6 text-center">
            <Button
              variant="ghost"
              onClick={() => setLocation("/login")}
              className="inline-flex items-center gap-2"
            >
              <ArrowLeft className="h-4 w-4" />
              Voltar para Login
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}