import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Ship, Clock, User, LogOut, Cloud, Waves, ArrowUp, Users, Plus, Info, 
  Settings, MessageSquare, FileText, Move, Anchor, Download, ArrowUpDown, Edit
} from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";
import { useTranslation } from "@/contexts/LanguageContext";
import { ShipInfoModal } from "@/components/ship-info-modal";
import { BerthShipInfoModal } from "@/components/berth-ship-info-modal";
import { ShipEditModal } from "@/components/ship-edit-modal";
import { ShipMovementModal } from "@/components/ship-movement-modal";
import { ShipRegistrationModal } from "@/components/ship-registration-modal";
import { ShipSelectionModal } from "@/components/ship-selection-modal";
import { BerthingActionModal } from "@/components/berthing-action-modal";
import { UndockingActionModal } from "@/components/undocking-action-modal";
import { GeminiAIAssistant } from "@/components/gemini-ai-assistant";
import { OperationalStatistics } from "@/components/operational-statistics";
import { WeatherDetailsModal } from "@/components/weather-details-modal";
import { TideDetailsModal } from "@/components/tide-details-modal";
import { DischargeControlModal } from "@/components/discharge-control/DischargeControlModal";
import { ShipReportModal } from "@/components/ship-report/ShipReportModal";

import { apiRequest } from "@/lib/queryClient";
import { LanguageSelector } from "@/components/LanguageSelector";
import logoPath from "@assets/LogTipo_1749832282954.png";
import terminalImagePath from "@assets/cais-terminal.png";

export function Dashboard() {
  const { user, isAuthenticated, isLoading, isOperator } = useAuth();
  const { t } = useTranslation();
  const [currentTime, setCurrentTime] = useState(new Date());
  const [selectedShip, setSelectedShip] = useState<any>(null);
  const [showShipInfo, setShowShipInfo] = useState(false);
  const [showBerthShipInfo, setShowBerthShipInfo] = useState(false);
  const [showShipEdit, setShowShipEdit] = useState(false);
  const [showShipMovement, setShowShipMovement] = useState(false);
  const [showShipRegistration, setShowShipRegistration] = useState(false);
  const [showShipSelection, setShowShipSelection] = useState(false);
  const [showBerthingModal, setShowBerthingModal] = useState(false);
  const [showUndockingModal, setShowUndockingModal] = useState(false);
  const [showAIAssistant, setShowAIAssistant] = useState(false);
  const [showWeatherDetails, setShowWeatherDetails] = useState(false);
  const [showTideDetails, setShowTideDetails] = useState(false);
  const [showDischargeControl, setShowDischargeControl] = useState(false);
  const [showShipReport, setShowShipReport] = useState(false);
  const [activeTab, setActiveTab] = useState("next-5");
  const queryClient = useQueryClient();

  // Update time every second
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  // Fetch ships data with real-time updates for immediate registration visibility
  const { data: ships = [], isLoading: shipsLoading, refetch: refetchShips } = useQuery({
    queryKey: ['/api/ships'],
    refetchInterval: 3000, // 3 seconds for immediate updates
    refetchOnWindowFocus: true,
    staleTime: 1000, // Data considered stale after 1 second
    refetchIntervalInBackground: true,
    refetchOnMount: true,
    refetchOnReconnect: true,
  });

  // Event listener for immediate ship updates when registered
  useEffect(() => {
    const handleShipRegistered = () => {
      refetchShips();
    };

    window.addEventListener('shipRegistered', handleShipRegistered);
    window.addEventListener('shipUpdated', handleShipRegistered);
    
    return () => {
      window.removeEventListener('shipRegistered', handleShipRegistered);
      window.removeEventListener('shipUpdated', handleShipRegistered);
    };
  }, [refetchShips]);

  // Fetch weather data
  const { data: weatherData } = useQuery({
    queryKey: ['/api/weather'],
    refetchInterval: 300000, // 5 minutes
    refetchOnWindowFocus: false,
    staleTime: 240000, // 4 minutes
  });

  // Fetch tide data
  const { data: tideData } = useQuery({
    queryKey: ['/api/tide'],
    refetchInterval: 300000, // 5 minutes
    refetchOnWindowFocus: false,
    staleTime: 240000, // 4 minutes
  });

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString('pt-PT', {
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      timeZone: 'Africa/Maputo'
    });
  };

  const formatDate = (date: Date) => {
    return date.toLocaleDateString('pt-PT', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      timeZone: 'Africa/Maputo'
    });
  };

  const handleLogout = async () => {
    try {
      await fetch('/api/logout', {
        method: 'POST',
        credentials: 'include'
      });
      // Force page reload to clear auth state
      window.location.reload();
    } catch (error) {
      console.error('Logout error:', error);
      window.location.reload();
    }
  };

  // Helper functions for ship operations
  const canShowQuickActions = () => {
    return user && (user.permissions?.includes('move_ships') || user.role === 'admin' || user.role === 'operator');
  };



  const getOperationTypeColor = (type: string) => {
    switch (type) {
      case 'Nacional': return 'bg-blue-100 text-blue-800';
      case 'Trânsito': return 'bg-purple-100 text-purple-800';
      case 'Combinado': return 'bg-green-100 text-green-800';
      case 'LPG': return 'bg-orange-100 text-orange-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'expected': return 'bg-blue-100 text-blue-800';
      case 'at_bar': return 'bg-yellow-100 text-yellow-800';
      case 'next_to_berth': return 'bg-purple-100 text-purple-800';
      case 'at_berth': return 'bg-green-100 text-green-800';
      case 'departed': return 'bg-gray-100 text-gray-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusLabel = (status: string, hasInstructions?: boolean) => {
    switch (status) {
      case 'expected': return 'Esperado';
      case 'at_bar': return hasInstructions ? 'Com Instrução' : 'Na Barra';
      case 'next_to_berth': return 'Próximo a Atracar';
      case 'at_berth': return 'No Cais';
      case 'departed': return 'Partido';
      default: return status;
    }
  };

  const handleShipClick = (ship: any) => {
    setSelectedShip(ship);
    setShowShipInfo(true);
  };

  const downloadPDFMutation = useMutation({
    mutationFn: async () => {
      const response = await fetch('/api/reports/ships/pdf');
      if (!response.ok) throw new Error('Failed to download PDF');
      return response.blob();
    },
    onSuccess: (blob) => {
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `ships-report-${new Date().toISOString().split('T')[0]}.pdf`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
    }
  });

  // Filter ships by status with safe fallbacks
  const safeShips = Array.isArray(ships) ? ships : [];
  const shipsAtBar = safeShips.filter((ship: any) => ship.status === 'at_bar');
  
  // Função para ordenar navios por data de chegada na barra (quem chegou primeiro fica no topo)
  const sortByArrivalDate = (ships: any[]) => {
    return ships.sort((a: any, b: any) => {
      const dateA = new Date(a.arrivalDateTime).getTime();
      const dateB = new Date(b.arrivalDateTime).getTime();
      return dateA - dateB; // Ordem crescente: mais antigo primeiro
    });
  };
  
  // Navios previstos - ordenados por data de chegada (quem chega primeiro fica no topo)
  const expectedArrivals = sortByArrivalDate(
    safeShips.filter((ship: any) => ship.status === 'expected')
  );
  
  const currentShipAtBerth = safeShips.find((ship: any) => ship.status === 'at_berth');
  
  // Navios partidos - ordenados por data de chegada (mais recente primeiro para histórico)
  const departedShips = safeShips.filter((ship: any) => ship.status === 'departed')
    .sort((a: any, b: any) => {
      const dateA = new Date(a.arrivalDateTime).getTime();
      const dateB = new Date(b.arrivalDateTime).getTime();
      return dateB - dateA; // Ordem decrescente: mais recente primeiro
    });
  
  const nextShips = safeShips.filter((ship: any) => ['at_bar', 'next_to_berth'].includes(ship.status)).slice(0, 5);

  // Check if undocking is allowed (ship at berth with 100% discharge + 1 hour after completion)
  const canUndockShip = () => {
    if (!currentShipAtBerth) return false;
    
    // Check if discharge is 100% complete
    const totalCargo = currentShipAtBerth.parcels?.reduce((sum: number, parcel: any) => sum + (parcel.volumeMT || 0), 0) || 0;
    const dischargedCargo = currentShipAtBerth.parcels?.reduce((sum: number, parcel: any) => sum + (parcel.dischargedVolume || 0), 0) || 0;
    const dischargePercentage = totalCargo > 0 ? (dischargedCargo / totalCargo) * 100 : 0;
    
    if (dischargePercentage < 100) return false;
    
    // Find the latest discharge completion time
    const latestDischargeTime = currentShipAtBerth.parcels?.reduce((latest: Date | null, parcel: any) => {
      if (parcel.dischargedVolume === parcel.volumeMT && parcel.lastUpdated) {
        const parcelTime = new Date(parcel.lastUpdated);
        return !latest || parcelTime > latest ? parcelTime : latest;
      }
      return latest;
    }, null);
    
    if (!latestDischargeTime) return false;
    
    // Check if 1 hour has passed since completion
    const oneHourLater = new Date(latestDischargeTime.getTime() + 60 * 60 * 1000);
    return new Date() >= oneHourLater;
  };

  // Check if berthing is allowed (berth must be empty for 3 hours after last undocking)
  const canBerth = () => {
    // If there's already a ship at berth, cannot berth another
    if (currentShipAtBerth) return false;
    
    // Find the most recent undocking time from departed ships
    const recentDepartures = departedShips
      .filter((ship: any) => ship.undockingTime)
      .sort((a: any, b: any) => new Date(b.undockingTime).getTime() - new Date(a.undockingTime).getTime());
    
    if (recentDepartures.length === 0) return true; // No previous undocking, can berth
    
    const lastUndockingTime = new Date(recentDepartures[0].undockingTime);
    const threeHoursLater = new Date(lastUndockingTime.getTime() + 3 * 60 * 60 * 1000);
    
    return new Date() >= threeHoursLater;
  };

  // Próximos navios programados (next_to_berth) - ordenados por chegada
  const nextProgrammedShips = sortByArrivalDate(
    safeShips.filter((ship: any) => ship.status === 'next_to_berth')
  );
  
  // Navios at_bar com instruções (todos) - ordenados por chegada
  const allShipsAtBarWithInstructions = sortByArrivalDate(
    safeShips.filter((ship: any) => 
      ship.status === 'at_bar' && ship.hasDischargeInstructions === true
    )
  );
  
  // Navios at_berth com instruções (no cais) - ordenados por chegada
  const allShipsAtBerthWithInstructions = sortByArrivalDate(
    safeShips.filter((ship: any) => 
      ship.status === 'at_berth' && ship.hasDischargeInstructions === true
    )
  );
  
  // Navios sem instruções - ordenados por chegada
  const shipsWithoutInstructions = sortByArrivalDate(
    safeShips.filter((ship: any) => 
      ship.status === 'at_bar' && ship.hasDischargeInstructions === false
    )
  );
  
  // TODOS os navios com instrução (independente do status)
  const allShipsWithInstructions = safeShips.filter((ship: any) => 
    ship.hasDischargeInstructions === true && ship.status !== 'departed'
  );
  
  // Para compatibilidade com interface existente
  const shipsWithInstructions = allShipsWithInstructions;
  
  // Debug removido para evitar spam no console
  


  // Calculate totals for "Navios na Barra" counter - SOMA TODAS AS CATEGORIAS NA BARRA
  // 1. Navios sem instrução (at_bar sem instruções)
  // 2. Navios com instrução (at_bar com instruções) 
  // 3. Próximos navios programados (next_to_berth)
  // 4. Próximo navio a atracar (também next_to_berth - já incluído acima)
  const shipsAtBarWithInstructions = allShipsAtBarWithInstructions;
  const totalBarShipsCounter = shipsWithoutInstructions.length + shipsAtBarWithInstructions.length + nextProgrammedShips.length;
  const next5ShipsCount = nextProgrammedShips.length;

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-50 to-blue-50 flex items-center justify-center">
        <div className="text-center">
          <div className="w-8 h-8 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600">Carregando...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-blue-50">
      {/* Mobile Header */}
      <header className="mobile-nav md:hidden">
        <div className="px-4 py-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 rounded-full bg-gradient-to-br from-blue-500 to-blue-600 flex items-center justify-center">
                <img src={logoPath} alt="CFM" className="w-6 h-6 object-contain" />
              </div>
              <div>
                <h1 className="text-sm font-bold text-gray-800">Beira Oil Terminal Berth 12</h1>
                <p className="text-xs text-gray-600">Vessels Line Up & Operations Management</p>
                <p className="text-xs text-gray-600">{formatTime(currentTime)}</p>
              </div>
            </div>
            
            <div className="flex flex-col items-end space-y-1">
              <div className="flex items-center space-x-2">
                <LanguageSelector />
                {isAuthenticated ? (
                  <div className="flex items-center space-x-2">
                    <div className="hidden sm:flex items-center space-x-1 text-xs text-gray-600">
                      <User className="w-3 h-3" />
                      <span>{user?.username || 'Usuário'}</span>
                    </div>
                    <Button
                      onClick={handleLogout}
                      variant="ghost"
                      size="sm"
                      className="text-red-600 hover:text-red-700 hover:bg-red-50 px-2 py-1"
                    >
                      <LogOut className="w-4 h-4 sm:mr-1" />
                      <span className="text-xs">Sair</span>
                    </Button>
                  </div>
                ) : (
                  <Button
                    onClick={() => window.location.href = '/login'}
                    variant="default"
                    size="sm"
                    className="bg-blue-600 hover:bg-blue-700 text-white px-2 py-1"
                  >
                    <User className="w-4 h-4 sm:mr-1" />
                    <span className="text-xs">Entrar</span>
                  </Button>
                )}
              </div>
              <div className="text-[10px] text-gray-400 italic">
                Developed by Manuel Antonio, Eng.
              </div>
            </div>
          </div>
        </div>
      </header>
      {/* Desktop/Tablet Header */}
      <div className="max-w-7xl mx-auto space-y-6 p-4 pt-20 md:pt-6">
        <header className="hidden md:block bg-white shadow-xl rounded-2xl border border-gray-200 overflow-hidden">
          <div className="bg-gradient-to-r from-blue-600 to-blue-800 p-1">
            <div className="bg-white rounded-xl p-6">
              <div className="responsive-grid responsive-grid-md-4 gap-6 items-center min-h-[100px]">
                {/* CFM Logo */}
                <div className="flex flex-col items-center text-center">
                  <div className="w-20 h-20 rounded-full bg-gradient-to-br from-blue-500 to-blue-700 border-4 border-white shadow-xl flex items-center justify-center mb-2">
                    <img
                      src={logoPath}
                      alt="CFM Logo"
                      className="w-14 h-14 object-contain filter brightness-110 contrast-110"
                    />
                  </div>
                  <span className="text-xs font-semibold text-gray-700">CFM-EP</span>
                </div>

                {/* Clock */}
                <div className="flex flex-col items-center text-center">
                  <div className="w-20 h-20 rounded-full bg-gradient-to-br from-green-500 to-green-700 border-4 border-white shadow-xl flex flex-col items-center justify-center mb-2">
                    <Clock className="w-5 h-5 text-white mb-1" />
                    <div className="text-white text-xs font-bold text-center leading-tight">
                      <div>{formatTime(currentTime)}</div>
                      <div className="text-xs opacity-90">{formatDate(currentTime).split('/').slice(0,2).join('/')}</div>
                    </div>
                  </div>
                  <span className="text-xs font-semibold text-gray-700">Hora Local</span>
                </div>

                {/* Terminal Status */}
                <div className="flex flex-col items-center text-center">
                  <div className="w-20 h-20 rounded-full bg-gradient-to-br from-purple-500 to-purple-700 border-4 border-white shadow-xl flex items-center justify-center overflow-hidden mb-2">
                    <img
                      src={terminalImagePath}
                      alt="Terminal da Beira"
                      className="w-16 h-16 object-cover filter saturate-150"
                    />
                  </div>
                  <span className="text-xs font-semibold text-gray-700">Beira Oil Terminal</span>
                </div>

                {/* User & Controls */}
                <div className="flex flex-col items-center text-center space-y-3">
                  <div className="w-20 h-20 rounded-full bg-gradient-to-br from-orange-500 to-orange-700 border-4 border-white shadow-xl flex flex-col items-center justify-center">
                    {isAuthenticated ? (
                      <>
                        <User className="w-5 h-5 text-white mb-1" />
                        <span className="text-xs font-bold text-white truncate px-1">
                          {user?.firstName || user?.username || 'User'}
                        </span>
                      </>
                    ) : (
                      <a href="/login" className="text-white text-xs hover:bg-white hover:bg-opacity-20 px-2 py-1 rounded">
                        {t("Entrar")}
                      </a>
                    )}
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <LanguageSelector />
                    {isAuthenticated && (user?.role === 'admin' || user?.role === 'desenvolvedor') && (
                      <a
                        href="/admin"
                        className="p-2 bg-blue-100 hover:bg-blue-200 rounded-lg transition-colors group"
                        title="Painel Administrativo - Aprovações"
                      >
                        <Users className="w-4 h-4 text-blue-600 group-hover:text-blue-700" />
                      </a>
                    )}
                    {isAuthenticated && (
                      <button
                        onClick={handleLogout}
                        className="p-2 bg-gray-100 hover:bg-gray-200 rounded-lg transition-colors group"
                        title="Sair"
                      >
                        <LogOut className="w-4 h-4 text-gray-600 group-hover:text-red-600" />
                      </button>
                    )}
                  </div>
                  <div className="text-[10px] text-gray-400 italic mt-1">
                    Developed by Manuel Antonio, Eng.
                  </div>
                </div>
              </div>

              {/* Title and System Info */}
              <div className="text-center mt-6">
                <h1 className="text-2xl lg:text-3xl font-bold bg-gradient-to-r from-blue-600 to-blue-800 bg-clip-text text-transparent mb-2">
                  Line Up - Beira Oil Terminal Berth 12
                </h1>
                <p className="text-sm text-gray-600 mb-3">Vessels Line Up & Operations Management</p>
                <div className="flex flex-col sm:flex-row items-center justify-center space-y-2 sm:space-y-0 sm:space-x-6 text-sm">
                  <div className="flex items-center gap-2 px-3 py-1 bg-green-50 rounded-full">
                    <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                    <span className="text-green-700 font-medium">Sistema de Informação de Navios</span>
                  </div>
                  <div className="flex items-center gap-2 px-3 py-1 bg-red-50 rounded-full">
                    <Users className="w-4 h-4 text-red-600" />
                    <span className="text-red-700 font-medium">{isAuthenticated ? 'Conectado' : 'Público'}</span>
                  </div>
                  <div className="text-[10px] text-gray-400 italic">
                    Developed by M.A,Eng. 2025
                  </div>
                </div>
              </div>
            </div>
          </div>
        </header>

        {/* Ship at Berth */}
        {currentShipAtBerth ? (
          <div className="bg-gradient-to-r from-green-500 to-green-600 rounded-2xl shadow-xl border border-green-300 overflow-hidden">
            <div className="bg-white/10 backdrop-blur-sm p-6">
              <div className="flex items-center gap-3 mb-6">
                <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center">
                  <Ship className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h2 className="text-2xl font-bold text-white">NAVIO NO CAIS 12</h2>
                  <p className="text-green-100">Terminal de Combustíveis da Beira</p>
                </div>
              </div>
              
              <div className="bg-white rounded-xl p-6">
                <div className="flex items-center justify-between mb-3">
                  <h3 className="font-bold text-lg text-blue-700">{currentShipAtBerth.name}</h3>
                  <div className="flex gap-2">
                    <Button
                      onClick={() => {
                        setSelectedShip(currentShipAtBerth);
                        setShowBerthShipInfo(true);
                      }}
                      size="sm"
                      variant="outline"
                      className="w-8 h-8 p-0 rounded-full border-blue-300 hover:bg-blue-50 hover:border-blue-400"
                      title="Informações Detalhadas do Navio"
                    >
                      <Info className="w-4 h-4 text-blue-600" />
                    </Button>
                    {/* Editar Informações do Navio - Only for operators */}
                    {isAuthenticated && (user?.role === 'operator' || user?.role === 'admin') && (
                      <Button
                        onClick={() => {
                          setSelectedShip(currentShipAtBerth);
                          setShowShipEdit(true);
                        }}
                        size="sm"
                        variant="outline"
                        className="w-8 h-8 p-0 rounded-full border-orange-300 hover:bg-orange-50 hover:border-orange-400"
                        title="Editar Informações do Navio"
                      >
                        <Edit className="w-4 h-4 text-orange-600" />
                      </Button>
                    )}
                    {/* Relatório Operacional - Only for operators */}
                    {isAuthenticated && (user?.role === 'operator' || user?.role === 'admin') && (
                      <Button
                        onClick={() => {
                          setSelectedShip(currentShipAtBerth);
                          setShowShipReport(true);
                        }}
                        size="sm"
                        variant="outline"
                        className="w-8 h-8 p-0 rounded-full border-purple-300 hover:bg-purple-50 hover:border-purple-400"
                        title="Relatório Operacional do Navio"
                      >
                        <FileText className="w-4 h-4 text-purple-600" />
                      </Button>
                    )}
                  </div>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                  <div>
                    <span className="text-gray-600">Contramarca:</span>
                    <span className="font-medium ml-2">{currentShipAtBerth.countermark}</span>
                  </div>
                  <div>
                    <span className="text-gray-600">Calado:</span>
                    <span className="font-medium ml-2">{currentShipAtBerth.draft}m</span>
                  </div>
                  <div>
                    <span className="text-gray-600">Agente do Navio:</span>
                    <span className="font-medium ml-2">{currentShipAtBerth.shipAgent}</span>
                  </div>
                  <div>
                    <span className="text-gray-600">Tipo de Operação:</span>
                    <span className="font-medium ml-2">{currentShipAtBerth.operationType}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        ) : (
          <div className="bg-gradient-to-r from-gray-400 to-gray-500 rounded-2xl shadow-xl border border-gray-300 overflow-hidden">
            <div className="bg-white/10 backdrop-blur-sm p-6">
              <div className="text-center">
                <div className="inline-flex items-center justify-center w-16 h-16 bg-white/20 rounded-full mb-4">
                  <Ship className="w-8 h-8 text-white" />
                </div>
                <h2 className="text-2xl font-bold text-white mb-3">
                  {t("Aguardando Navio")}
                </h2>
                <div className="bg-white/20 rounded-lg p-3">
                  <p className="text-white font-medium">
                    {t("O cais está disponível para atracação")}
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}



        {/* Quick Action Buttons - Enhanced Layout */}
        <div className="bg-white rounded-lg shadow-lg border border-gray-200 p-4 mb-6">
          <h3 className="text-lg font-bold text-gray-800 mb-4 flex items-center gap-2">
            <Settings className="w-5 h-5 text-blue-600" />
            Ações Rápidas
          </h3>
          
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
            {/* Register Ship - Always visible for authenticated users */}
            {isAuthenticated && (
              <Button
                onClick={() => setShowShipRegistration(true)}
                className="bg-gradient-to-r from-green-600 to-green-700 hover:from-green-700 hover:to-green-800 text-white p-4 h-auto flex flex-col items-center gap-2 rounded-lg shadow-lg hover:shadow-xl transition-all duration-200"
              >
                <Plus className="w-5 h-5" />
                <span className="text-xs font-semibold text-center">REGISTRAR NAVIO</span>
              </Button>
            )}

            {/* Atracar Navio - Active when no ship at berth */}
            {isAuthenticated && canShowQuickActions() && (
              <Button
                onClick={() => setShowBerthingModal(true)}
                disabled={!!currentShipAtBerth}
                className={`p-4 h-auto flex flex-col items-center gap-2 rounded-lg shadow-lg hover:shadow-xl transition-all duration-200 ${
                  currentShipAtBerth 
                    ? 'bg-gray-300 text-gray-500 cursor-not-allowed' 
                    : 'bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-white'
                }`}
              >
                <Anchor className="w-5 h-5" />
                <span className="text-xs font-semibold text-center">ATRACAR NAVIO</span>
              </Button>
            )}

            {/* Desatracar Navio - Active 1 hour after discharge completion */}
            {isAuthenticated && canShowQuickActions() && (
              <Button
                onClick={() => setShowUndockingModal(true)}
                disabled={!canUndockShip()}
                className={`p-4 h-auto flex flex-col items-center gap-2 rounded-lg shadow-lg hover:shadow-xl transition-all duration-200 ${
                  !canUndockShip() 
                    ? 'bg-gray-300 text-gray-500 cursor-not-allowed' 
                    : 'bg-gradient-to-r from-red-600 to-red-700 hover:from-red-700 hover:to-red-800 text-white'
                }`}
              >
                <ArrowUpDown className="w-5 h-5" />
                <span className="text-xs font-semibold text-center">DESATRACAR NAVIO</span>
              </Button>
            )}

            {/* Mover Navio - Allows moving ships between positions */}
            {isAuthenticated && canShowQuickActions() && (
              <Button
                onClick={() => setShowShipMovement(true)}
                className="bg-gradient-to-r from-purple-600 to-purple-700 hover:from-purple-700 hover:to-purple-800 text-white p-4 h-auto flex flex-col items-center gap-2 rounded-lg shadow-lg hover:shadow-xl transition-all duration-200"
              >
                <Move className="w-5 h-5" />
                <span className="text-xs font-semibold text-center">MOVER NAVIO</span>
              </Button>
            )}
            

          </div>
          
          {/* Additional Quick Actions for Mobile */}
          <div className="mt-4 pt-4 border-t border-gray-100 lg:hidden">
            <div className="grid grid-cols-2 gap-3">
              {/* AI Assistant */}
              <Button
                onClick={() => setShowAIAssistant(true)}
                variant="outline"
                className="flex items-center gap-2 justify-center p-3"
              >
                <MessageSquare className="w-4 h-4" />
                <span className="text-xs font-medium">ASSISTENTE IA</span>
              </Button>
              
              {/* Settings/Info */}
              <Button
                variant="outline"
                className="flex items-center gap-2 justify-center p-3"
              >
                <Info className="w-4 h-4" />
                <span className="text-xs font-medium">INFORMAÇÕES</span>
              </Button>
            </div>
          </div>
        </div>

        {/* Ships Tabs - Mobile Responsive */}
        <div className="bg-white rounded-lg shadow-lg border border-gray-200 mb-6">
          {/* Mobile Tab Navigation - Horizontal Scroll */}
          <div className="border-b border-gray-200 overflow-x-auto lg:overflow-x-visible">
            <div className="flex lg:grid lg:grid-cols-7 min-w-max lg:min-w-0">
              {isOperator && (
                <button
                  onClick={() => setShowDischargeControl(true)}
                  className="px-3 py-3 text-xs font-medium whitespace-nowrap border-b-2 transition-colors uppercase border-transparent text-indigo-600 hover:text-indigo-800 hover:bg-indigo-50"
                >
                  <span className="hidden lg:inline">CONTROLO DESCARGA ⚙️</span>
                  <span className="lg:hidden">CONTROLO ⚙️</span>
                </button>
              )}
              <button
                onClick={() => setActiveTab('next-5')}
                className={`px-3 py-3 text-xs font-medium whitespace-nowrap border-b-2 transition-colors uppercase ${
                  activeTab === 'next-5'
                    ? 'border-green-500 text-red-600 bg-green-100 font-bold'
                    : 'border-transparent text-gray-500 hover:text-gray-700'
                }`}
              >
                <span className="hidden lg:inline">NAVIOS NA BARRA ({totalBarShipsCounter})</span>
                <span className="lg:hidden">BARRA ({totalBarShipsCounter})</span>
              </button>
              <button
                onClick={() => setActiveTab('with-instructions')}
                className={`px-3 py-3 text-xs font-medium whitespace-nowrap border-b-2 transition-colors uppercase ${
                  activeTab === 'with-instructions'
                    ? 'border-green-500 text-red-600 bg-green-100 font-bold'
                    : 'border-transparent text-gray-500 hover:text-gray-700'
                }`}
              >
                <span className="hidden lg:inline">NAVIOS COM INSTRUÇÃO</span>
                <span className="lg:hidden">COM INSTR ({shipsWithInstructions.length})</span>
              </button>
              <button
                onClick={() => setActiveTab('without-instructions')}
                className={`px-3 py-3 text-xs font-medium whitespace-nowrap border-b-2 transition-colors uppercase ${
                  activeTab === 'without-instructions'
                    ? 'border-green-500 text-red-600 bg-green-100 font-bold'
                    : 'border-transparent text-gray-500 hover:text-gray-700'
                }`}
              >
                <span className="hidden lg:inline">NAVIOS SEM INSTRUÇÃO</span>
                <span className="lg:hidden">SEM INSTR ({shipsWithoutInstructions.length})</span>
              </button>
              <button
                onClick={() => setActiveTab('expected')}
                className={`px-3 py-3 text-xs font-medium whitespace-nowrap border-b-2 transition-colors uppercase ${
                  activeTab === 'expected'
                    ? 'border-green-500 text-red-600 bg-green-100 font-bold'
                    : 'border-transparent text-gray-500 hover:text-gray-700'
                }`}
              >
                <span className="hidden lg:inline">PREVISTOS A CHEGAR</span>
                <span className="lg:hidden">PREVISTOS ({expectedArrivals.length})</span>
              </button>
              <button
                onClick={() => setActiveTab('statistics')}
                className={`px-3 py-3 text-xs font-medium whitespace-nowrap border-b-2 transition-colors uppercase ${
                  activeTab === 'statistics'
                    ? 'border-green-500 text-red-600 bg-green-100 font-bold'
                    : 'border-transparent text-gray-500 hover:text-gray-700'
                }`}
              >
                <span className="hidden lg:inline">ESTATÍSTICAS OPERACIONAIS</span>
                <span className="lg:hidden">STATS</span>
              </button>
              <button
                onClick={() => setActiveTab('departed')}
                className={`px-3 py-3 text-xs font-medium whitespace-nowrap border-b-2 transition-colors uppercase ${
                  activeTab === 'departed'
                    ? 'border-green-500 text-red-600 bg-green-100 font-bold'
                    : 'border-transparent text-gray-500 hover:text-gray-700'
                }`}
              >
                <span className="hidden lg:inline">NAVIOS PARTIDOS</span>
                <span className="lg:hidden">PARTIDOS ({departedShips.length})</span>
              </button>
            </div>
          </div>

          {/* Tab Content */}
          <div className="p-4">
            {activeTab === 'next-5' && (
              <div className="space-y-4">
                {/* Contador de Navios na Barra */}
                <div className="bg-gradient-to-r from-blue-50 to-blue-100 rounded-lg p-4 border border-blue-200">
                  <h3 className="font-semibold text-lg text-blue-800 mb-3 flex items-center gap-2">
                    <Anchor className="w-5 h-5" />
                    Resumo - Navios na Barra
                  </h3>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                    <div className="bg-white rounded-lg p-3 border border-blue-200">
                      <div className="flex items-center justify-between">
                        <span className="text-gray-600">Navios Sem Instrução:</span>
                        <Badge className="bg-orange-100 text-orange-800 font-bold">
                          {shipsWithoutInstructions.length}
                        </Badge>
                      </div>
                    </div>
                    <div className="bg-white rounded-lg p-3 border border-blue-200">
                      <div className="flex items-center justify-between">
                        <span className="text-gray-600">Navios Com Instrução:</span>
                        <Badge className="bg-green-100 text-green-800 font-bold">
                          {shipsWithInstructions.length}
                        </Badge>
                      </div>
                    </div>
                    <div className="bg-white rounded-lg p-3 border border-blue-200">
                      <div className="flex items-center justify-between">
                        <span className="text-gray-600">Próximos navios programados:</span>
                        <Badge className="bg-blue-100 text-blue-800 font-bold">
                          {nextProgrammedShips.length}
                        </Badge>
                      </div>
                    </div>
                  </div>
                  <div className="mt-4 p-3 bg-blue-100 rounded-lg border border-blue-300">
                    <div className="flex items-center justify-between">
                      <span className="font-semibold text-blue-800">NAVIOS NA BARRA:</span>
                      <Badge className="bg-blue-600 text-white font-bold text-lg px-3 py-1">
                        {totalBarShipsCounter}
                      </Badge>
                    </div>
                    <p className="text-xs text-blue-600 mt-1">
                      Soma: {shipsWithoutInstructions.length} (Sem Instr.) + {allShipsAtBarWithInstructions.length} (Com Instr.) + {nextProgrammedShips.length} (Próximos) = {totalBarShipsCounter}
                    </p>
                  </div>
                </div>
                
                {/* Lista dos próximos 5 navios */}
                <div className="space-y-3">
                  <h4 className="font-semibold text-red-600 bg-green-100 p-2 rounded uppercase">PRÓXIMO NAVIO A ATRACAR:</h4>
                  {nextShips.slice(0, 1).map((ship: any) => (
                    <Card key={ship.id} className="hover:shadow-md transition-shadow cursor-pointer" onClick={() => handleShipClick(ship)}>
                      <CardContent className="p-4">
                        <div className="flex justify-between items-start">
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-2">
                              <Ship className="w-4 h-4" />
                              <h4 className="font-semibold">{ship.name}</h4>
                              <Badge variant="outline">#{ship.countermark}</Badge>
                              <Badge className={getOperationTypeColor(ship.operationType)}>
                                {ship.operationType}
                              </Badge>
                            </div>
                            <div className="text-sm text-gray-600">
                              <p>Agente: {ship.shipAgent}</p>
                              <p>Carga: {ship.cargoType}</p>
                            </div>
                          </div>
                          <div className="text-right">
                            <Badge className={getStatusColor(ship.status)}>
                              {getStatusLabel(ship.status, ship.hasDischargeInstructions)}
                            </Badge>
                            <Button
                              variant="ghost"
                              size="sm"
                              className="mt-2"
                              onClick={(e) => {
                                e.stopPropagation();
                                handleShipClick(ship);
                              }}
                            >
                              <Info className="w-4 h-4" />
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                  {nextShips.length === 0 && (
                    <div className="text-center py-8 text-gray-500">
                      <Ship className="w-12 h-12 mx-auto mb-4 text-gray-300" />
                      <p className="font-medium">Nenhum navio próximo a atracar</p>
                    </div>
                  )}
                </div>
              </div>
            )}

          {activeTab === 'with-instructions' && (
            <div className="space-y-3">
            {shipsWithInstructions.map((ship: any) => (
              <Card key={ship.id} className="hover:shadow-md transition-shadow cursor-pointer" onClick={() => handleShipClick(ship)}>
                <CardContent className="p-4">
                  <div className="flex justify-between items-start">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <Ship className="w-4 h-4" />
                        <h4 className="font-semibold">{ship.name}</h4>
                        <Badge variant="outline">#{ship.countermark}</Badge>
                        <Badge className="bg-green-100 text-green-800">
                          Com Instrução
                        </Badge>
                      </div>
                      <div className="text-sm text-gray-600">
                        <p>Agente: {ship.shipAgent}</p>
                        <p>Carga: {ship.cargoType}</p>
                      </div>
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleShipClick(ship);
                      }}
                    >
                      <Info className="w-4 h-4" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
                ))}
                {shipsWithInstructions.length === 0 && (
                  <div className="text-center py-8 text-gray-500">
                    <Ship className="w-12 h-12 mx-auto mb-4 text-gray-300" />
                    <p className="font-medium">Nenhum navio com instruções</p>
                  </div>
                )}
              </div>
            )}

            {activeTab === 'without-instructions' && (
              <div className="space-y-3">
                {shipsWithoutInstructions.map((ship: any) => (
              <Card key={ship.id} className="hover:shadow-md transition-shadow cursor-pointer p-4" onClick={() => handleShipClick(ship)}>
                <div className="flex justify-between items-start">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <Ship className="w-4 h-4" />
                      <h4 className="font-semibold">{ship.name}</h4>
                      <Badge variant="outline">#{ship.countermark}</Badge>
                      <Badge className="bg-yellow-100 text-yellow-800">
                        Sem Instrução
                      </Badge>
                    </div>
                    <div className="text-sm text-gray-600">
                      <p>Agente: {ship.shipAgent}</p>
                      <p>Carga: {ship.cargoType}</p>
                    </div>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={(e) => {
                      e.stopPropagation();
                      handleShipClick(ship);
                    }}
                  >
                    <Info className="w-4 h-4" />
                  </Button>
                </div>
              </Card>
                ))}
                {shipsWithoutInstructions.length === 0 && (
                  <div className="text-center py-8 text-gray-500">
                    <Ship className="w-12 h-12 mx-auto mb-4 text-gray-300" />
                    <p className="font-medium">Nenhum navio sem instruções</p>
                  </div>
                )}
              </div>
            )}

            {activeTab === 'expected' && (
              <div className="space-y-3">
                {expectedArrivals.map((ship: any) => (
                <Card key={ship.id} className="mb-3 hover:shadow-md transition-shadow cursor-pointer bg-white/70" onClick={() => handleShipClick(ship)}>
                  <CardContent className="p-4">
                    <div className="flex justify-between items-start">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <Ship className="w-4 h-4" />
                          <h4 className="font-semibold">{ship.name}</h4>
                          <Badge variant="outline">#{ship.countermark}</Badge>
                          <Badge className="bg-orange-100 text-orange-800">
                            Esperado
                          </Badge>
                        </div>
                        <div className="text-sm text-gray-600">
                          <p>Agente: {ship.shipAgent}</p>
                          <p>Carga: {ship.cargoType}</p>
                        </div>
                      </div>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={(e) => {
                          e.stopPropagation();
                          handleShipClick(ship);
                        }}
                      >
                        <Info className="w-4 h-4" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
                ))}
                {expectedArrivals.length === 0 && (
                  <div className="text-center py-8 text-gray-500">
                    <Ship className="w-12 h-12 mx-auto mb-4 text-gray-300" />
                    <p className="font-medium">Nenhuma chegada esperada</p>
                  </div>
                )}
              </div>
            )}

            {activeTab === 'departed' && (
              <div className="space-y-3">
                {departedShips.map((ship: any) => (
              <Card key={ship.id} className="hover:shadow-md transition-shadow cursor-pointer opacity-75" onClick={() => handleShipClick(ship)}>
                <CardContent className="p-4">
                  <div className="flex justify-between items-start">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <Ship className="w-4 h-4" />
                        <h4 className="font-semibold">{ship.name}</h4>
                        <Badge variant="outline">#{ship.countermark}</Badge>
                        <Badge className="bg-gray-100 text-gray-800">
                          Partido
                        </Badge>
                      </div>
                      <div className="text-sm text-gray-600">
                        <p>Agente: {ship.shipAgent}</p>
                        <p>Carga: {ship.cargoType}</p>
                      </div>
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleShipClick(ship);
                      }}
                    >
                      <Info className="w-4 h-4" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
                ))}
                {departedShips.length === 0 && (
                  <div className="text-center py-8 text-gray-500">
                    <Ship className="w-12 h-12 mx-auto mb-4 text-gray-300" />
                    <p className="font-medium">Nenhum navio partido</p>
                  </div>
                )}
              </div>
            )}

            {activeTab === 'with-instructions' && (
              <div className="space-y-3">
                {shipsWithInstructions.map((ship: any) => (
                  <Card key={ship.id} className="hover:shadow-md transition-shadow cursor-pointer" onClick={() => handleShipClick(ship)}>
                    <CardContent className="p-4">
                      <div className="flex justify-between items-start">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-2">
                            <Ship className="w-4 h-4" />
                            <h4 className="font-semibold">{ship.name}</h4>
                            <Badge variant="outline">#{ship.countermark}</Badge>
                            <Badge className="bg-green-100 text-green-800">
                              Com Instrução
                            </Badge>
                          </div>
                          <div className="text-sm text-gray-600">
                            <p>Agente: {ship.shipAgent}</p>
                            <p>Carga: {ship.cargoType}</p>
                          </div>
                        </div>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={(e) => {
                            e.stopPropagation();
                            handleShipClick(ship);
                          }}
                        >
                          <Info className="w-4 h-4" />
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
                {shipsWithInstructions.length === 0 && (
                  <div className="text-center py-8 text-gray-500">
                    <Ship className="w-12 h-12 mx-auto mb-4 text-gray-300" />
                    <p className="font-medium">Nenhum navio com instruções</p>
                  </div>
                )}
              </div>
            )}

            {activeTab === 'without-instructions' && (
              <div className="space-y-3">
                {shipsWithoutInstructions.map((ship: any) => (
                  <Card key={ship.id} className="hover:shadow-md transition-shadow cursor-pointer" onClick={() => handleShipClick(ship)}>
                    <div className="p-4">
                      <div className="flex justify-between items-start">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-2">
                            <Ship className="w-4 h-4" />
                            <h4 className="font-semibold">{ship.name}</h4>
                            <Badge variant="outline">#{ship.countermark}</Badge>
                            <Badge className="bg-yellow-100 text-yellow-800">
                              Sem Instrução
                            </Badge>
                          </div>
                          <div className="text-sm text-gray-600">
                            <p>Agente: {ship.shipAgent}</p>
                            <p>Carga: {ship.cargoType}</p>
                          </div>
                        </div>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={(e) => {
                            e.stopPropagation();
                            handleShipClick(ship);
                          }}
                        >
                          <Info className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </Card>
                ))}
                {shipsWithoutInstructions.length === 0 && (
                  <div className="text-center py-8 text-gray-500">
                    <Ship className="w-12 h-12 mx-auto mb-4 text-gray-300" />
                    <p className="font-medium">Nenhum navio sem instruções</p>
                  </div>
                )}
              </div>
            )}

            {activeTab === 'expected' && (
              <div className="space-y-3">
                {expectedArrivals.map((ship: any) => (
                  <Card key={ship.id} className="mb-3 hover:shadow-md transition-shadow cursor-pointer bg-white/70" onClick={() => handleShipClick(ship)}>
                    <CardContent className="p-4">
                      <div className="flex justify-between items-start">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-2">
                            <Ship className="w-4 h-4" />
                            <h4 className="font-semibold">{ship.name}</h4>
                            <Badge variant="outline">#{ship.countermark}</Badge>
                            <Badge className="bg-orange-100 text-orange-800">
                              Esperado
                            </Badge>
                          </div>
                          <div className="text-sm text-gray-600">
                            <p>Agente: {ship.shipAgent}</p>
                            <p>Carga: {ship.cargoType}</p>
                          </div>
                        </div>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={(e) => {
                            e.stopPropagation();
                            handleShipClick(ship);
                          }}
                        >
                          <Info className="w-4 h-4" />
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
                {expectedArrivals.length === 0 && (
                  <div className="text-center py-8 text-gray-500">
                    <Ship className="w-12 h-12 mx-auto mb-4 text-gray-300" />
                    <p className="font-medium">Nenhuma chegada esperada</p>
                  </div>
                )}
              </div>
            )}

            {activeTab === 'statistics' && (
              <OperationalStatistics
                ships={safeShips}
                currentShipAtBerth={currentShipAtBerth}
                shipsWithInstructions={shipsWithInstructions}
                shipsWithoutInstructions={shipsWithoutInstructions}
                expectedArrivals={expectedArrivals}
                departedShips={departedShips}
                totalBarShipsCounter={totalBarShipsCounter}
                weatherData={weatherData}
                tideData={tideData}
              />
            )}

            {activeTab === 'departed' && (
              <div className="space-y-3">
                {departedShips.map((ship: any) => (
                  <Card key={ship.id} className="hover:shadow-md transition-shadow cursor-pointer opacity-75" onClick={() => handleShipClick(ship)}>
                    <CardContent className="p-4">
                      <div className="flex justify-between items-start">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-2">
                            <Ship className="w-4 h-4" />
                            <h4 className="font-semibold">{ship.name}</h4>
                            <Badge variant="outline">#{ship.countermark}</Badge>
                            <Badge className="bg-gray-100 text-gray-800">
                              Partido
                            </Badge>
                          </div>
                          <div className="text-sm text-gray-600">
                            <p>Agente: {ship.shipAgent}</p>
                            <p>Carga: {ship.cargoType}</p>
                          </div>
                        </div>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={(e) => {
                            e.stopPropagation();
                            handleShipClick(ship);
                          }}
                        >
                          <Info className="w-4 h-4" />
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
                {departedShips.length === 0 && (
                  <div className="text-center py-8 text-gray-500">
                    <Ship className="w-12 h-12 mx-auto mb-4 text-gray-300" />
                    <p className="font-medium">Nenhum navio partido</p>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>

        {/* Weather and Tide */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Card className="card-hover">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-blue-600">
                <Cloud className="w-5 h-5" />
                Clima Atual
              </CardTitle>
            </CardHeader>
            <CardContent>
              {weatherData ? (
                <div className="space-y-3">
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-gray-600">Temperatura:</span>
                      <span className="font-semibold">{(weatherData as any)?.temperature || 'N/A'}°C</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Umidade:</span>
                      <span className="font-semibold">{(weatherData as any)?.humidity || 'N/A'}%</span>
                    </div>
                  </div>
                  <Button
                    variant="outline"
                    size="sm"
                    className="w-full mt-3"
                    onClick={() => setShowWeatherDetails(true)}
                  >
                    <Info className="w-4 h-4 mr-2" />
                    Ver Detalhes
                  </Button>
                </div>
              ) : (
                <p className="text-gray-500">Carregando dados meteorológicos...</p>
              )}
            </CardContent>
          </Card>

          <Card className="card-hover">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-green-600">
                <Waves className="w-5 h-5" />
                Informações de Maré
              </CardTitle>
            </CardHeader>
            <CardContent>
              {tideData ? (
                <div className="space-y-3">
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-gray-600">Altura Atual:</span>
                      <span className="font-semibold">{(tideData as any)?.currentTide?.toFixed(2) || 'N/A'}m</span>
                    </div>
                    <div className="text-xs text-gray-500">
                      Estado: {(tideData as any)?.currentTide > 2.5 ? 'Enchente' : 'Vazante'}
                    </div>
                  </div>
                  <Button
                    variant="outline"
                    size="sm"
                    className="w-full mt-3"
                    onClick={() => setShowTideDetails(true)}
                  >
                    <Info className="w-4 h-4 mr-2" />
                    Ver Detalhes
                  </Button>
                </div>
              ) : (
                <p className="text-gray-500">Carregando dados de maré...</p>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Floating AI Assistant Button */}
        <Button
          onClick={() => setShowAIAssistant(true)}
          className="fixed bottom-6 right-6 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white rounded-full w-14 h-14 shadow-lg hover:shadow-xl transition-all duration-200 z-40"
          size="lg"
        >
          <MessageSquare className="w-6 h-6" />
        </Button>

        {/* Modals */}
        {showShipInfo && selectedShip && (
          <ShipInfoModal
            isOpen={showShipInfo}
            shipId={selectedShip.id}
            onClose={() => {
              setShowShipInfo(false);
              setSelectedShip(null);
            }}
          />
        )}

        {showShipMovement && (
          <ShipMovementModal
            isOpen={showShipMovement}
            onClose={() => setShowShipMovement(false)}
            shipId={null}
          />
        )}

        {showShipRegistration && (
          <ShipRegistrationModal
            isOpen={showShipRegistration}
            onClose={() => setShowShipRegistration(false)}
            onSuccess={() => {
              queryClient.invalidateQueries({ queryKey: ['/api/ships'] });
              setShowShipRegistration(false);
            }}
          />
        )}

        {/* Berthing Action Modal */}
        {showBerthingModal && (
          <BerthingActionModal
            isOpen={showBerthingModal}
            onClose={() => setShowBerthingModal(false)}
            ships={safeShips}
          />
        )}

        {/* Undocking Action Modal */}
        {showUndockingModal && currentShipAtBerth && (
          <UndockingActionModal
            isOpen={showUndockingModal}
            onClose={() => setShowUndockingModal(false)}
            ship={currentShipAtBerth}
          />
        )}

        {/* Ship Selection Modal for Berthing */}
        {showShipSelection && (
          <ShipSelectionModal
            isOpen={showShipSelection}
            onClose={() => setShowShipSelection(false)}
            ships={safeShips}
          />
        )}

        {showAIAssistant && (
          <GeminiAIAssistant
            isOpen={showAIAssistant}
            onClose={() => setShowAIAssistant(false)}
            userRole={user?.role || 'visitor'}
            language="pt"
          />
        )}

        {/* Berth Ship Info Modal */}
        {showBerthShipInfo && selectedShip && (
          <BerthShipInfoModal
            isOpen={showBerthShipInfo}
            onClose={() => setShowBerthShipInfo(false)}
            ship={selectedShip}
          />
        )}

        {/* Ship Edit Modal */}
        {showShipEdit && selectedShip && (
          <ShipEditModal
            isOpen={showShipEdit}
            onClose={() => setShowShipEdit(false)}
            ship={selectedShip}
          />
        )}

        {/* Weather Details Modal */}
        <WeatherDetailsModal
          isOpen={showWeatherDetails}
          onClose={() => setShowWeatherDetails(false)}
          weatherData={weatherData}
        />

        {/* Tide Details Modal */}
        <TideDetailsModal
          isOpen={showTideDetails}
          onClose={() => setShowTideDetails(false)}
          tideData={tideData}
        />

        {/* Discharge Control Modal */}
        <DischargeControlModal
          isOpen={showDischargeControl}
          onClose={() => setShowDischargeControl(false)}
          ship={ships.find(ship => ship.status === 'at_berth') || null}
        />

        {/* Ship Report Modal */}
        <ShipReportModal
          isOpen={showShipReport}
          onClose={() => setShowShipReport(false)}
          ship={selectedShip}
        />

      </div>
    </div>
  );
}