import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  Ship, Anchor, Waves, ArrowUpDown, Settings, FileText, 
  Users, Cloud 
} from "lucide-react";

interface OperationalStatisticsProps {
  ships: any[];
  currentShipAtBerth: any;
  shipsWithInstructions: any[];
  shipsWithoutInstructions: any[];
  expectedArrivals: any[];
  departedShips: any[];
  totalBarShipsCounter: number;
  weatherData: any;
  tideData: any;
}

export function OperationalStatistics({
  ships,
  currentShipAtBerth,
  shipsWithInstructions,
  shipsWithoutInstructions,
  expectedArrivals,
  departedShips,
  totalBarShipsCounter,
  weatherData,
  tideData
}: OperationalStatisticsProps) {
  const safeShips = ships || [];

  return (
    <div className="space-y-6">
      {/* Título da Seção */}
      <div className="bg-gradient-to-r from-teal-50 to-teal-100 rounded-lg p-4 border border-teal-200">
        <h3 className="font-semibold text-lg text-teal-800 mb-3 flex items-center gap-2">
          <FileText className="w-5 h-5" />
          Estatísticas Operacionais - Terminal da Beira
        </h3>
        <p className="text-sm text-teal-600">
          Análise em tempo real das operações portuárias e indicadores de performance
        </p>
      </div>

      {/* Resumo Geral de Navios */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="bg-blue-50 border-blue-200">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-blue-600 font-medium">Total de Navios</p>
                <p className="text-2xl font-bold text-blue-800">{safeShips.length}</p>
              </div>
              <Ship className="w-8 h-8 text-blue-500" />
            </div>
          </CardContent>
        </Card>
        
        <Card className="bg-green-50 border-green-200">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-green-600 font-medium">No Cais</p>
                <p className="text-2xl font-bold text-green-800">{currentShipAtBerth ? 1 : 0}</p>
              </div>
              <Anchor className="w-8 h-8 text-green-500" />
            </div>
          </CardContent>
        </Card>
        
        <Card className="bg-orange-50 border-orange-200">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-orange-600 font-medium">Na Barra</p>
                <p className="text-2xl font-bold text-orange-800">{totalBarShipsCounter}</p>
              </div>
              <Waves className="w-8 h-8 text-orange-500" />
            </div>
          </CardContent>
        </Card>
        
        <Card className="bg-gray-50 border-gray-200">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600 font-medium">Partidos</p>
                <p className="text-2xl font-bold text-gray-800">{departedShips.length}</p>
              </div>
              <ArrowUpDown className="w-8 h-8 text-gray-500" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Análise por Tipo de Operação */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-teal-700">
            <Settings className="w-5 h-5" />
            Distribuição por Tipo de Operação
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            {['Nacional', 'LPG', 'Trânsito', 'Combinado'].map((type) => {
              const count = safeShips.filter(ship => ship.operationType === type).length;
              const percentage = safeShips.length > 0 ? ((count / safeShips.length) * 100).toFixed(1) : '0';
              return (
                <div key={type} className="bg-gray-50 rounded-lg p-3 border">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm font-medium text-gray-700">{type}</span>
                    <Badge className={
                      type === 'Nacional' ? 'bg-blue-100 text-blue-800' :
                      type === 'LPG' ? 'bg-orange-100 text-orange-800' :
                      type === 'Trânsito' ? 'bg-green-100 text-green-800' :
                      'bg-purple-100 text-purple-800'
                    }>
                      {count}
                    </Badge>
                  </div>
                  <div className="text-xs text-gray-500">
                    {percentage}% do total
                  </div>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {/* Status das Instruções de Descarga */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-teal-700">
            <FileText className="w-5 h-5" />
            Status das Instruções de Descarga
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="bg-green-50 rounded-lg p-4 border border-green-200">
              <h4 className="font-semibold text-green-800 mb-3">Com Instruções</h4>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-sm text-green-600">Navios Prontos:</span>
                  <Badge className="bg-green-100 text-green-800">{shipsWithInstructions.length}</Badge>
                </div>
                <div className="text-xs text-green-600">
                  {shipsWithInstructions.length > 0 ? 
                    `${((shipsWithInstructions.length / Math.max(1, shipsWithInstructions.length + shipsWithoutInstructions.length)) * 100).toFixed(1)}% do total na barra` :
                    'Nenhum navio com instruções'
                  }
                </div>
              </div>
            </div>
            
            <div className="bg-orange-50 rounded-lg p-4 border border-orange-200">
              <h4 className="font-semibold text-orange-800 mb-3">Sem Instruções</h4>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-sm text-orange-600">Aguardando:</span>
                  <Badge className="bg-orange-100 text-orange-800">{shipsWithoutInstructions.length}</Badge>
                </div>
                <div className="text-xs text-orange-600">
                  {shipsWithoutInstructions.length > 0 ? 
                    `${((shipsWithoutInstructions.length / Math.max(1, shipsWithInstructions.length + shipsWithoutInstructions.length)) * 100).toFixed(1)}% do total na barra` :
                    'Todos os navios têm instruções'
                  }
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Capacidade Operacional */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-teal-700">
            <Users className="w-5 h-5" />
            Capacidade Operacional do Terminal
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-blue-50 rounded-lg p-4 border border-blue-200">
              <h4 className="font-semibold text-blue-800 mb-2">Status do Cais</h4>
              <div className="flex items-center gap-2">
                <div className={`w-3 h-3 rounded-full ${currentShipAtBerth ? 'bg-red-500' : 'bg-green-500'}`}></div>
                <span className="text-sm font-medium">
                  {currentShipAtBerth ? 'OCUPADO' : 'DISPONÍVEL'}
                </span>
              </div>
              {currentShipAtBerth && (
                <p className="text-xs text-blue-600 mt-1">
                  Navio: {currentShipAtBerth.name}
                </p>
              )}
            </div>
            
            <div className="bg-purple-50 rounded-lg p-4 border border-purple-200">
              <h4 className="font-semibold text-purple-800 mb-2">Fila de Espera</h4>
              <div className="text-2xl font-bold text-purple-800">{totalBarShipsCounter}</div>
              <p className="text-xs text-purple-600">navios aguardando</p>
            </div>
            
            <div className="bg-gray-50 rounded-lg p-4 border border-gray-200">
              <h4 className="font-semibold text-gray-800 mb-2">Previsões</h4>
              <div className="text-2xl font-bold text-gray-800">{expectedArrivals.length}</div>
              <p className="text-xs text-gray-600">navios esperados</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Informações Ambientais */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-teal-700">
            <Cloud className="w-5 h-5" />
            Condições Operacionais
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-blue-50 rounded-lg p-4 border border-blue-200">
              <h4 className="font-semibold text-blue-800 mb-2">Condições Meteorológicas</h4>
              {weatherData ? (
                <div className="space-y-1 text-sm">
                  <div className="flex justify-between">
                    <span>Temperatura:</span>
                    <span className="font-medium">{(weatherData as any)?.temperature}°C</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Umidade:</span>
                    <span className="font-medium">{(weatherData as any)?.humidity}%</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Pressão:</span>
                    <span className="font-medium">{(weatherData as any)?.pressure} hPa</span>
                  </div>
                </div>
              ) : (
                <p className="text-sm text-gray-500">Carregando...</p>
              )}
            </div>
            
            <div className="bg-teal-50 rounded-lg p-4 border border-teal-200">
              <h4 className="font-semibold text-teal-800 mb-2">Condições de Maré</h4>
              {tideData ? (
                <div className="space-y-1 text-sm">
                  <div className="flex justify-between">
                    <span>Altura Atual:</span>
                    <span className="font-medium">{(tideData as any)?.currentTide?.toFixed(2)}m</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Estado:</span>
                    <span className="font-medium">
                      {(tideData as any)?.currentTide > 2.5 ? 'Enchente' : 'Vazante'}
                    </span>
                  </div>
                </div>
              ) : (
                <p className="text-sm text-gray-500">Carregando...</p>
              )}
            </div>
            
            <div className="bg-green-50 rounded-lg p-4 border border-green-200">
              <h4 className="font-semibold text-green-800 mb-2">Status Operacional</h4>
              <div className="space-y-1 text-sm">
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-green-500"></div>
                  <span>Terminal Operacional</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-green-500"></div>
                  <span>Sistemas Online</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-green-500"></div>
                  <span>Comunicações Ativas</span>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}