import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Shield, AlertTriangle } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";

interface AdminConfirmationModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: () => void;
  title: string;
  description: string;
  actionText: string;
}

export function AdminConfirmationModal({
  isOpen,
  onClose,
  onConfirm,
  title,
  description,
  actionText,
}: AdminConfirmationModalProps) {
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");

  const verifyPasswordMutation = useMutation({
    mutationFn: async (adminPassword: string) => {
      const response = await apiRequest('/api/admin/verify-password', 'POST', { password: adminPassword });
      return await response.json();
    },
    onSuccess: () => {
      setError("");
      setPassword("");
      onConfirm();
      onClose();
    },
    onError: (error: any) => {
      setError(error.message || "Senha administrativa incorreta");
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!password.trim()) {
      setError("Digite a senha administrativa");
      return;
    }
    verifyPasswordMutation.mutate(password);
  };

  const handleClose = () => {
    setPassword("");
    setError("");
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-orange-700">
            <Shield className="w-5 h-5" />
            {title}
          </DialogTitle>
          <DialogDescription className="text-gray-600">
            {description}
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <Alert className="border-orange-200 bg-orange-50">
            <AlertTriangle className="h-4 w-4 text-orange-600" />
            <AlertDescription className="text-orange-800">
              Esta ação requer autorização administrativa. Digite a senha para continuar.
            </AlertDescription>
          </Alert>

          <div className="space-y-2">
            <Label htmlFor="admin-password" className="text-sm font-medium">
              Senha Administrativa
            </Label>
            <Input
              id="admin-password"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Digite a senha do administrador"
              className="w-full"
              autoFocus
            />
          </div>

          {error && (
            <Alert className="border-red-200 bg-red-50">
              <AlertDescription className="text-red-800">
                {error}
              </AlertDescription>
            </Alert>
          )}

          <div className="flex justify-end gap-2 pt-4">
            <Button
              type="button"
              variant="outline"
              onClick={handleClose}
              disabled={verifyPasswordMutation.isPending}
            >
              Cancelar
            </Button>
            <Button
              type="submit"
              disabled={verifyPasswordMutation.isPending}
              className="bg-orange-600 hover:bg-orange-700"
            >
              {verifyPasswordMutation.isPending ? "Verificando..." : actionText}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}