import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { Plus, Edit, Trash2, Users, Mail, Phone, Building } from "lucide-react";

interface CargoAgent {
  id: number;
  shipId: number;
  name: string;
  email?: string;
  phone?: string;
  company?: string;
  isPrimary: boolean;
  createdAt: string;
  updatedAt: string;
}

interface CargoAgentsManagerProps {
  shipId: number;
  shipName: string;
  shipStatus?: string;
}

export function CargoAgentsManager({ shipId, shipName, shipStatus }: CargoAgentsManagerProps) {
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [editingAgent, setEditingAgent] = useState<CargoAgent | null>(null);
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    company: "",
    isPrimary: false,
  });

  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: agents = [], isLoading } = useQuery<CargoAgent[]>({
    queryKey: ['/api/ships', shipId, 'cargo-agents'],
    enabled: !!shipId,
  });

  const createAgentMutation = useMutation({
    mutationFn: async (agentData: any) => {
      const response = await fetch(`/api/ships/${shipId}/cargo-agents`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(agentData),
      });
      if (!response.ok) throw new Error('Failed to create cargo agent');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/ships', shipId, 'cargo-agents'] });
      queryClient.invalidateQueries({ queryKey: ['/api/ships'] });
      setIsAddDialogOpen(false);
      setFormData({ name: "", email: "", phone: "", company: "", isPrimary: false });
      toast({ title: "Agente de carga adicionado com sucesso" });
    },
    onError: () => {
      toast({ title: "Erro ao adicionar agente de carga", variant: "destructive" });
    },
  });

  const updateAgentMutation = useMutation({
    mutationFn: async ({ id, ...updates }: any) => {
      const response = await fetch(`/api/cargo-agents/${id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updates),
      });
      if (!response.ok) throw new Error('Failed to update cargo agent');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/ships', shipId, 'cargo-agents'] });
      queryClient.invalidateQueries({ queryKey: ['/api/ships'] });
      setEditingAgent(null);
      toast({ title: "Agente de carga atualizado com sucesso" });
    },
    onError: () => {
      toast({ title: "Erro ao atualizar agente de carga", variant: "destructive" });
    },
  });

  const deleteAgentMutation = useMutation({
    mutationFn: async (agentId: number) => {
      const response = await fetch(`/api/cargo-agents/${agentId}`, {
        method: 'DELETE',
      });
      if (!response.ok) throw new Error('Failed to delete cargo agent');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/ships', shipId, 'cargo-agents'] });
      queryClient.invalidateQueries({ queryKey: ['/api/ships'] });
      toast({ title: "Agente de carga removido com sucesso" });
    },
    onError: () => {
      toast({ title: "Erro ao remover agente de carga", variant: "destructive" });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name.trim()) {
      toast({ title: "Nome do agente é obrigatório", variant: "destructive" });
      return;
    }

    if (editingAgent) {
      updateAgentMutation.mutate({ id: editingAgent.id, ...formData });
    } else {
      createAgentMutation.mutate(formData);
    }
  };

  const handleEdit = (agent: CargoAgent) => {
    setEditingAgent(agent);
    setFormData({
      name: agent.name,
      email: agent.email || "",
      phone: agent.phone || "",
      company: agent.company || "",
      isPrimary: agent.isPrimary,
    });
    setIsAddDialogOpen(true);
  };

  const handleDelete = (agentId: number) => {
    if (confirm("Tem certeza que deseja remover este agente de carga?")) {
      deleteAgentMutation.mutate(agentId);
    }
  };

  const resetForm = () => {
    setFormData({ name: "", email: "", phone: "", company: "", isPrimary: false });
    setEditingAgent(null);
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center p-4">
        <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  const isDeparted = shipStatus === 'departed';

  return (
    <div className="space-y-4">

      
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Users className="w-5 h-5 text-blue-600" />
          <h3 className="text-lg font-semibold text-gray-800">Agentes de Carga</h3>
          <Badge variant="secondary">{agents.length}</Badge>
        </div>
        
        <Dialog open={isAddDialogOpen} onOpenChange={(open) => {
          setIsAddDialogOpen(open);
          if (!open) resetForm();
        }}>
          <DialogTrigger asChild>
            <Button size="sm" className="flex items-center gap-2">
              <Plus className="w-4 h-4" />
              Adicionar Agente
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>
                {editingAgent ? "Editar Agente de Carga" : "Adicionar Agente de Carga"}
              </DialogTitle>
            </DialogHeader>
            
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <Label htmlFor="name">Nome do Agente *</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  placeholder="Ex: João Silva"
                  required
                />
              </div>
              
              <div>
                <Label htmlFor="company">Empresa</Label>
                <Input
                  id="company"
                  value={formData.company}
                  onChange={(e) => setFormData({ ...formData, company: e.target.value })}
                  placeholder="Ex: Barloworld Logistics"
                />
              </div>
              
              <div>
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  placeholder="Ex: agente@empresa.com"
                />
              </div>
              
              <div>
                <Label htmlFor="phone">Telefone</Label>
                <Input
                  id="phone"
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  placeholder="Ex: +258 84 123 4567"
                />
              </div>
              
              <div className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  id="isPrimary"
                  checked={formData.isPrimary}
                  onChange={(e) => setFormData({ ...formData, isPrimary: e.target.checked })}
                  className="rounded border-gray-300"
                />
                <Label htmlFor="isPrimary">Agente Principal</Label>
              </div>
              
              <div className="flex gap-2 pt-4">
                <Button type="submit" className="flex-1" disabled={createAgentMutation.isPending || updateAgentMutation.isPending}>
                  {editingAgent ? "Atualizar" : "Adicionar"}
                </Button>
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => setIsAddDialogOpen(false)}
                  className="flex-1"
                >
                  Cancelar
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="space-y-3">
        {agents.length === 0 ? (
          <Card>
            <CardContent className="p-6 text-center text-gray-500">
              <Users className="w-8 h-8 mx-auto mb-2 text-gray-400" />
              <p>Nenhum agente de carga adicionado</p>
              <p className="text-sm">Clique em "Adicionar Agente" para começar</p>
            </CardContent>
          </Card>
        ) : (
          agents.map((agent) => (
            <Card key={agent.id} className="relative">
              <CardContent className="p-4">
                <div className="flex items-start justify-between">
                  <div className="space-y-2 flex-1">
                    <div className="flex items-center gap-2">
                      <h4 className="font-medium text-gray-900">{agent.name}</h4>
                      {agent.isPrimary && (
                        <Badge variant="default" className="text-xs">Principal</Badge>
                      )}
                    </div>
                    
                    {agent.company && (
                      <div className="flex items-center gap-2 text-sm text-gray-600">
                        <Building className="w-4 h-4" />
                        <span>{agent.company}</span>
                      </div>
                    )}
                    
                    {agent.email && (
                      <div className="flex items-center gap-2 text-sm text-gray-600">
                        <Mail className="w-4 h-4" />
                        <span>{agent.email}</span>
                      </div>
                    )}
                    
                    {agent.phone && (
                      <div className="flex items-center gap-2 text-sm text-gray-600">
                        <Phone className="w-4 h-4" />
                        <span>{agent.phone}</span>
                      </div>
                    )}
                  </div>
                  
                  <div className="flex gap-1 ml-4">
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => handleEdit(agent)}
                      className="h-8 w-8 p-0"
                    >
                      <Edit className="w-4 h-4" />
                    </Button>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => handleDelete(agent.id)}
                      className="h-8 w-8 p-0 text-red-600 hover:text-red-800"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>
    </div>
  );
}