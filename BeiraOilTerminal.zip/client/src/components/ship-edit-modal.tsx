import { useState, useEffect } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { X, Save, Plus, Trash2, Package, Ship } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

interface ShipEditModalProps {
  isOpen: boolean;
  onClose: () => void;
  ship: any;
}

export function ShipEditModal({ isOpen, onClose, ship }: ShipEditModalProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  // Ship form data
  const [shipData, setShipData] = useState({
    name: "",
    countermark: "",
    draft: "",
    shipAgent: "",
    shipAgentEmail: "",
    cargoAgent: "",
    cargoAgentEmail: "",
    shipowner: "",
    cargoType: "",
    cargoDestination: "",
    operationType: "Nacional"
  });

  // Cargo parcels data
  const [parcels, setParcels] = useState<any[]>([]);
  const [editingParcel, setEditingParcel] = useState<number | null>(null);

  // Load ship data when modal opens
  useEffect(() => {
    if (ship && isOpen) {
      setShipData({
        name: ship.name || "",
        countermark: ship.countermark || "",
        draft: ship.draft || "",
        shipAgent: ship.shipAgent || "",
        shipAgentEmail: ship.shipAgentEmail || "",
        cargoAgent: ship.cargoAgent || "",
        cargoAgentEmail: ship.cargoAgentEmail || "",
        shipowner: ship.shipowner || "",
        cargoType: ship.cargoType || "",
        cargoDestination: ship.cargoDestination || "",
        operationType: ship.operationType || "Nacional"
      });
    }
  }, [ship, isOpen]);

  // Use main ships query for all data including parcels
  const { data: allShipsData, refetch: refetchShips } = useQuery({
    queryKey: ['/api/ships'],
    enabled: !!ship?.id && isOpen,
    staleTime: 0,
    refetchOnMount: true,
    refetchOnWindowFocus: false,
  });

  // Initialize parcels state from ships data
  useEffect(() => {
    if (allShipsData && Array.isArray(allShipsData) && ship?.id) {
      const currentShip = allShipsData.find((s: any) => s.id === ship.id);
      if (currentShip?.parcels && Array.isArray(currentShip.parcels)) {
        console.log('Loading parcels from ships endpoint:', currentShip.parcels.length, 'parcels');
        console.log('Parcel details:', currentShip.parcels.map((p: any) => ({ id: p.id, number: p.parcelNumber, product: p.product })));
        setParcels(currentShip.parcels);
      } else {
        console.log('No parcels found in ships data for ship', ship.id);
        setParcels([]);
      }
    } else if (ship?.parcels && Array.isArray(ship.parcels)) {
      console.log('Loading parcels from ship prop fallback:', ship.parcels.length, 'parcels');
      setParcels(ship.parcels);
    }
  }, [allShipsData, ship?.parcels, ship?.id]);

  // Reset parcels when modal opens
  useEffect(() => {
    if (isOpen && ship?.id) {
      console.log('Modal opened for ship:', ship.id);
      refetchShips();
    }
  }, [isOpen, ship?.id, refetchShips]);

  // Update ship mutation
  const updateShipMutation = useMutation({
    mutationFn: async (data: any) => {
      return await apiRequest(`/api/ships/${ship.id}`, {
        method: 'PUT',
        body: JSON.stringify(data),
        headers: { 'Content-Type': 'application/json' }
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/ships'] });
      queryClient.invalidateQueries({ queryKey: ['/api/ships', ship.id] });
      queryClient.invalidateQueries({ queryKey: ['/api/ships', ship.id, 'parcels'] });
      
      toast({
        title: "Sucesso",
        description: "Informações do navio atualizadas com sucesso",
      });
      
      // Close modal after successful save
      onClose();
    },
    onError: (error: any) => {
      console.error('Ship update error:', error);
      toast({
        title: "Erro",
        description: error.message || "Erro ao atualizar navio",
        variant: "destructive",
      });
    }
  });

  // Update parcel mutation
  const updateParcelMutation = useMutation({
    mutationFn: async ({ parcelId, data }: { parcelId: number, data: any }) => {
      console.log('Updating parcel:', parcelId, data);
      return await apiRequest(`/api/ships/${ship.id}/parcels/${parcelId}`, {
        method: 'PUT',
        body: JSON.stringify(data),
        headers: { 'Content-Type': 'application/json' }
      });
    },
    onSuccess: (updatedParcel: any) => {
      console.log('Parcel updated successfully:', updatedParcel);
      
      queryClient.invalidateQueries({ queryKey: ['/api/ships', ship.id, 'parcels'] });
      queryClient.invalidateQueries({ queryKey: ['/api/ships'] });
      
      toast({
        title: "Sucesso",
        description: "Parcela atualizada com sucesso",
      });
      
      setEditingParcel(null);
    },
    onError: (error: any) => {
      console.error('Parcel update error:', error);
      toast({
        title: "Erro",
        description: error.message || "Erro ao atualizar parcela",
        variant: "destructive",
      });
    }
  });

  // Add parcel mutation
  const addParcelMutation = useMutation({
    mutationFn: async (data: any) => {
      console.log('Adding parcel with data:', data);
      const response = await fetch(`/api/ships/${ship.id}/parcels`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
      });
      
      if (!response.ok) {
        const errorData = await response.text();
        console.error('API Error:', response.status, errorData);
        throw new Error(`Erro ${response.status}: ${errorData || 'Falha ao adicionar parcela'}`);
      }
      
      return await response.json();
    },
    onSuccess: async (newParcel) => {
      console.log('Parcel added successfully:', newParcel);
      
      // Add to local state immediately to show in UI
      setParcels(prev => {
        const updated = [...prev, newParcel];
        console.log('Updated local parcels state:', updated.length, 'parcels');
        console.log('All parcels now:', updated.map(p => p.parcelNumber));
        return updated;
      });
      
      // Refresh ships data to get updated parcels
      await refetchShips();
      
      console.log('Ships data refreshed after parcel addition');
      
      toast({
        title: "Sucesso",
        description: `Parcela ${newParcel.parcelNumber} adicionada com sucesso`,
      });
    },
    onError: (error: any) => {
      console.error('Add parcel error:', error);
      toast({
        title: "Erro",
        description: error.message || "Erro ao adicionar parcela",
        variant: "destructive",
      });
    }
  });

  // Delete parcel mutation
  const deleteParcelMutation = useMutation({
    mutationFn: async (parcelId: number) => {
      return await apiRequest(`/api/ships/${ship.id}/parcels/${parcelId}`, {
        method: 'DELETE'
      });
    },
    onSuccess: (_, deletedParcelId) => {
      queryClient.invalidateQueries({ queryKey: ['/api/ships', ship.id, 'parcels'] });
      queryClient.invalidateQueries({ queryKey: ['/api/ships'] });
      // Update local state immediately to remove the deleted parcel
      setParcels(prev => prev.filter(p => p.id !== deletedParcelId));
      toast({
        title: "Sucesso",
        description: "Parcela removida com sucesso",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Erro",
        description: error.message || "Erro ao remover parcela",
        variant: "destructive",
      });
    }
  });

  const handleSaveShip = () => {
    console.log('handleSaveShip called');
    console.log('Current shipData:', shipData);
    console.log('Current parcels:', parcels);
    
    // Prepare complete ship data with parcels
    const completeShipData = {
      ...shipData,
      parcels: parcels.map(parcel => ({
        parcelNumber: parcel.parcelNumber || '',
        product: parcel.product || '',
        volumeMT: parcel.volumeMT || '',
        volumeM3: parcel.volumeM3 || '',
        density15C: parcel.density15C || '',
        receiver: parcel.receiver || '',
        owner: parcel.owner || '',
        status: parcel.status || 'pending'
      }))
    };
    
    console.log('Saving ship with complete data:', completeShipData);
    updateShipMutation.mutate(completeShipData);
  };

  const handleUpdateParcel = (parcelId: number, newData: any) => {
    updateParcelMutation.mutate({ parcelId, data: newData });
  };

  const handleAddParcel = () => {
    // Generate next parcel number sequentially
    const existingNumbers = parcels
      .map(p => parseInt(p.parcelNumber?.replace('P', '') || '0'))
      .filter(n => !isNaN(n));
    const nextNumber = existingNumbers.length > 0 ? Math.max(...existingNumbers) + 1 : 1;
    const parcelNumber = `P${String(nextNumber).padStart(3, '0')}`;
    
    const newParcel = {
      parcelNumber,
      product: "Gasolina", // Default product
      volumeMT: null,
      volumeM3: null,
      density15C: null,
      receiver: "",
      owner: ""
    };
    
    console.log('Adding new parcel:', newParcel);
    addParcelMutation.mutate(newParcel);
  };

  const handleDeleteParcel = (parcelId: number) => {
    if (!parcelId) {
      toast({
        title: "Erro",
        description: "ID da parcela não encontrado",
        variant: "destructive",
      });
      return;
    }
    deleteParcelMutation.mutate(parcelId);
  };

  const handleInputChange = (field: string, value: string) => {
    setShipData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleParcelChange = (index: number, field: string, value: any) => {
    const updatedParcels = [...parcels];
    const parcel = { ...updatedParcels[index] };
    
    // Update the specific field
    parcel[field] = value;
    
    // Product changes do not automatically update density - operators must input real data
    
    // Auto-calculate volumes based on density changes
    if (field === 'density15C' && value > 0) {
      const density = parseFloat(value);
      // If we have volume in MT, calculate m³
      if (parcel.volumeMT && parseFloat(parcel.volumeMT) > 0) {
        parcel.volumeM3 = (parseFloat(parcel.volumeMT) / density).toFixed(2);
      }
      // If we have volume in m³, calculate MT
      else if (parcel.volumeM3 && parseFloat(parcel.volumeM3) > 0) {
        parcel.volumeMT = (parseFloat(parcel.volumeM3) * density).toFixed(2);
      }
    }
    
    // Auto-calculate when volume MT changes
    if (field === 'volumeMT' && value > 0 && parcel.density15C && parseFloat(parcel.density15C) > 0) {
      const density = parseFloat(parcel.density15C);
      parcel.volumeM3 = (parseFloat(value) / density).toFixed(2);
    }
    
    // Auto-calculate when volume m³ changes
    if (field === 'volumeM3' && value > 0 && parcel.density15C && parseFloat(parcel.density15C) > 0) {
      const density = parseFloat(parcel.density15C);
      parcel.volumeMT = (parseFloat(value) * density).toFixed(2);
    }
    
    updatedParcels[index] = parcel;
    setParcels(updatedParcels);
  };

  const saveParcel = (index: number) => {
    console.log('saveParcel called with index:', index);
    
    const parcel = parcels[index];
    console.log('Parcel to save:', parcel);
    
    if (!parcel) {
      console.error('No parcel found at index:', index);
      toast({
        title: "Erro",
        description: "Parcela não encontrada",
        variant: "destructive",
      });
      return;
    }
    
    // Simply exit edit mode - no API calls
    // The changes are already in the local state
    setEditingParcel(null);
    
    toast({
      title: "Sucesso",
      description: "Alterações salvas. Use 'Salvar Alterações' para persistir no servidor.",
    });
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader className="flex flex-row items-center justify-between">
          <DialogTitle className="flex items-center gap-2 text-xl font-bold text-blue-700">
            <Ship className="w-6 h-6" />
            Editar Informações do Navio
          </DialogTitle>
          <Button
            onClick={onClose}
            variant="ghost"
            size="sm"
            className="h-8 w-8 p-0"
          >
            <X className="h-4 w-4" />
          </Button>
        </DialogHeader>

        <div className="space-y-6">
          {/* Ship Information Section */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg text-blue-600">Informações Básicas do Navio</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="name">Nome do Navio</Label>
                  <Input
                    id="name"
                    value={shipData.name}
                    onChange={(e) => handleInputChange('name', e.target.value)}
                    placeholder="Nome do navio"
                  />
                </div>
                <div>
                  <Label htmlFor="countermark">Contramarcha</Label>
                  <Input
                    id="countermark"
                    value={shipData.countermark}
                    onChange={(e) => handleInputChange('countermark', e.target.value)}
                    placeholder="Contramarcha"
                  />
                </div>
                <div>
                  <Label htmlFor="draft">Calado (m)</Label>
                  <Input
                    id="draft"
                    value={shipData.draft}
                    onChange={(e) => handleInputChange('draft', e.target.value)}
                    placeholder="Calado em metros"
                  />
                </div>
                <div>
                  <Label htmlFor="operationType">Tipo de Operação</Label>
                  <Select value={shipData.operationType} onValueChange={(value) => handleInputChange('operationType', value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione o tipo" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Nacional">🇲🇿 Nacional</SelectItem>
                      <SelectItem value="LPG">⛽ LPG</SelectItem>
                      <SelectItem value="Trânsito">🚢 Trânsito</SelectItem>
                      <SelectItem value="Combinado">🔄 Combinado</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="shipowner">Armador</Label>
                  <Input
                    id="shipowner"
                    value={shipData.shipowner}
                    onChange={(e) => handleInputChange('shipowner', e.target.value)}
                    placeholder="Nome do armador"
                  />
                </div>
                <div>
                  <Label htmlFor="cargoDestination">Destino da Carga</Label>
                  <Input
                    id="cargoDestination"
                    value={shipData.cargoDestination}
                    onChange={(e) => handleInputChange('cargoDestination', e.target.value)}
                    placeholder="Destino da carga"
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Agents Information */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg text-green-600">Informações dos Agentes</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="shipAgent">Agente do Navio</Label>
                  <Input
                    id="shipAgent"
                    value={shipData.shipAgent}
                    onChange={(e) => handleInputChange('shipAgent', e.target.value)}
                    placeholder="Nome do agente do navio"
                  />
                </div>
                <div>
                  <Label htmlFor="shipAgentEmail">Email do Agente do Navio</Label>
                  <Input
                    id="shipAgentEmail"
                    type="email"
                    value={shipData.shipAgentEmail}
                    onChange={(e) => handleInputChange('shipAgentEmail', e.target.value)}
                    placeholder="email@agente-navio.com"
                  />
                </div>
                <div>
                  <Label htmlFor="cargoAgent">Agente da Carga</Label>
                  <Input
                    id="cargoAgent"
                    value={shipData.cargoAgent}
                    onChange={(e) => handleInputChange('cargoAgent', e.target.value)}
                    placeholder="Nome do agente da carga"
                  />
                </div>
                <div>
                  <Label htmlFor="cargoAgentEmail">Email do Agente da Carga</Label>
                  <Input
                    id="cargoAgentEmail"
                    type="email"
                    value={shipData.cargoAgentEmail}
                    onChange={(e) => handleInputChange('cargoAgentEmail', e.target.value)}
                    placeholder="email@agente-carga.com"
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Cargo Parcels Section */}
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle className="text-lg text-purple-600 flex items-center gap-2">
                <Package className="w-5 h-5" />
                Parcelas de Carga
              </CardTitle>
              <Button
                onClick={handleAddParcel}
                size="sm"
                className="bg-green-600 hover:bg-green-700"
                disabled={addParcelMutation.isPending}
              >
                <Plus className="w-4 h-4 mr-2" />
                Adicionar Parcela
              </Button>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {parcels.map((parcel, index) => (
                  <div key={parcel.id || index} className="border rounded-lg p-4 bg-gray-50">
                    <div className="flex items-center justify-between mb-3">
                      <Badge variant="outline" className="bg-purple-100 text-purple-800">
                        Parcela {index + 1}
                      </Badge>
                      <div className="flex gap-2">
                        {editingParcel === index ? (
                          <Button
                            onClick={() => saveParcel(index)}
                            size="sm"
                            className="bg-green-600 hover:bg-green-700"
                            disabled={updateParcelMutation.isPending}
                          >
                            <Save className="w-4 h-4" />
                          </Button>
                        ) : (
                          <Button
                            onClick={() => setEditingParcel(index)}
                            size="sm"
                            variant="outline"
                          >
                            Editar
                          </Button>
                        )}
                        <Button
                          onClick={() => handleDeleteParcel(parcel.id)}
                          size="sm"
                          variant="destructive"
                          disabled={deleteParcelMutation.isPending}
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                    
                    {editingParcel === index ? (
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                        <div>
                          <Label>Produto</Label>
                          <Select 
                            value={parcel.product} 
                            onValueChange={(value) => handleParcelChange(index, 'product', value)}
                          >
                            <SelectTrigger>
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="Gasolina">Gasolina</SelectItem>
                              <SelectItem value="Diesel">Diesel</SelectItem>
                              <SelectItem value="Jet A1">Jet A1</SelectItem>
                              <SelectItem value="LPG">LPG</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        <div>
                          <Label>Volume (MT)</Label>
                          <Input
                            type="number"
                            value={parcel.volumeMT || ''}
                            onChange={(e) => handleParcelChange(index, 'volumeMT', e.target.value)}
                            placeholder="Volume em toneladas métricas"
                            className="bg-blue-50 border-blue-200 focus:border-blue-400"
                          />
                          <div className="text-xs text-gray-500 mt-1">
                            Calcula m³ automaticamente
                          </div>
                        </div>
                        <div>
                          <Label>Volume (m³)</Label>
                          <Input
                            type="number"
                            value={parcel.volumeM3 || ''}
                            onChange={(e) => handleParcelChange(index, 'volumeM3', e.target.value)}
                            placeholder="Volume em metros cúbicos"
                            className="bg-green-50 border-green-200 focus:border-green-400"
                          />
                          <div className="text-xs text-gray-500 mt-1">
                            Calcula MT automaticamente
                          </div>
                        </div>
                        <div>
                          <Label>Densidade (kg/L)</Label>
                          <Input
                            type="number"
                            step="0.01"
                            value={parcel.density15C || ''}
                            onChange={(e) => handleParcelChange(index, 'density15C', e.target.value)}
                            placeholder="Introduza densidade real"
                            className="bg-yellow-50 border-yellow-200 focus:border-yellow-400"
                          />
                          <div className="text-xs text-gray-500 mt-1">
                            ⚠️ Introduza dados reais obtidos do laboratório
                          </div>
                        </div>
                        <div>
                          <Label>Recebedor</Label>
                          <Input
                            value={parcel.receiver}
                            onChange={(e) => handleParcelChange(index, 'receiver', e.target.value)}
                          />
                        </div>
                        <div>
                          <Label>Proprietário</Label>
                          <Input
                            value={parcel.owner}
                            onChange={(e) => handleParcelChange(index, 'owner', e.target.value)}
                          />
                        </div>
                      </div>
                    ) : (
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-sm">
                        <div>
                          <span className="text-gray-600">Produto:</span>
                          <span className="font-medium ml-2">{parcel.product}</span>
                        </div>
                        <div>
                          <span className="text-gray-600">Volume:</span>
                          <span className="font-medium ml-2">{parcel.volumeMT || 0} MT</span>
                        </div>
                        <div>
                          <span className="text-gray-600">Volume m³:</span>
                          <span className="font-medium ml-2">{parcel.volumeM3 || 0} m³</span>
                        </div>
                        <div>
                          <span className="text-gray-600">Densidade:</span>
                          <span className="font-medium ml-2">{parcel.density15C || 'N/A'}</span>
                        </div>
                        <div>
                          <span className="text-gray-600">Recebedor:</span>
                          <span className="font-medium ml-2">{parcel.receiver}</span>
                        </div>
                        <div>
                          <span className="text-gray-600">Proprietário:</span>
                          <span className="font-medium ml-2">{parcel.owner}</span>
                        </div>
                      </div>
                    )}
                  </div>
                ))}
                {parcels.length === 0 && (
                  <div className="text-center py-8 text-gray-500">
                    <Package className="w-12 h-12 mx-auto mb-4 text-gray-300" />
                    <p className="font-medium">Nenhuma parcela cadastrada</p>
                    <p className="text-sm">Clique em "Adicionar Parcela" para começar</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Action Buttons */}
          <div className="flex justify-end gap-3 pt-4 border-t">
            <Button
              onClick={onClose}
              variant="outline"
            >
              Cancelar
            </Button>
            <Button
              onClick={handleSaveShip}
              className="bg-blue-600 hover:bg-blue-700"
              disabled={updateShipMutation.isPending}
            >
              <Save className="w-4 h-4 mr-2" />
              Salvar Alterações
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}