import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Clock, Play, Pause, Calculator, AlertTriangle, TrendingUp, FileDown, Plus } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";

interface AdvancedDischargeModalProps {
  isOpen: boolean;
  onClose: () => void;
  shipId: number;
  shipName: string;
}

interface DischargeData {
  parcelId: number;
  dischargeStartTime: string;
  currentRate: number;
  totalDischargedThisHour: number;
  remainingThisParcel: number;
  pressure: number;
  stopType?: string;
  stopTimestamp?: string;
}

interface HourlyUpdate {
  timestamp: string;
  pressure: number;
  rate: number;
  discharged: number;
}

export function AdvancedDischargeModal({ isOpen, onClose, shipId, shipName }: AdvancedDischargeModalProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const [selectedParcel, setSelectedParcel] = useState<number | null>(null);
  const [dischargeData, setDischargeData] = useState<DischargeData>({
    parcelId: 0,
    dischargeStartTime: "",
    currentRate: 0,
    totalDischargedThisHour: 0,
    remainingThisParcel: 0,
    pressure: 0,
  });
  const [stopType, setStopType] = useState<string>("");
  const [hourlyUpdates, setHourlyUpdates] = useState<HourlyUpdate[]>([]);
  const [currentUpdate, setCurrentUpdate] = useState<HourlyUpdate>({
    timestamp: "",
    pressure: 0,
    rate: 0,
    discharged: 0,
  });

  // Buscar dados do navio e parcelas
  const { data: ship } = useQuery<{
    id: number;
    name: string;
    parcels: Array<{
      id: number;
      product: string;
      volumeM3: string;
      volumeMt: string;
      density15C: string;
      receiver: string;
      owner: string;
      status: string;
    }>;
  }>({
    queryKey: [`/api/ships/${shipId}`],
    enabled: isOpen && shipId > 0,
  });

  // Calcular previsão de término
  const calculateEstimatedCompletion = () => {
    if (dischargeData.currentRate > 0 && dischargeData.remainingThisParcel > 0) {
      const hoursToComplete = dischargeData.remainingThisParcel / dischargeData.currentRate;
      const completionTime = new Date(Date.now() + hoursToComplete * 60 * 60 * 1000);
      return format(completionTime, "dd/MM/yyyy HH:mm", { locale: ptBR });
    }
    return "Não calculado";
  };

  // Mutation para iniciar descarga
  const startDischargeMutation = useMutation({
    mutationFn: async (data: DischargeData) => {
      return apiRequest(`/api/ships/${shipId}/discharge-progress`, "POST", {
        discharged: data.totalDischargedThisHour,
        remaining: data.remainingThisParcel,
        percentage: ((data.totalDischargedThisHour / (data.totalDischargedThisHour + data.remainingThisParcel)) * 100),
      });
    },
    onSuccess: () => {
      toast({
        title: "Descarga Iniciada",
        description: "Dados de descarga registrados com sucesso",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/ships"] });
    },
    onError: () => {
      toast({
        title: "Erro",
        description: "Falha ao registrar dados de descarga",
        variant: "destructive",
      });
    },
  });

  // Atualizar dados quando parcela é selecionada
  useEffect(() => {
    if (selectedParcel && ship?.parcels) {
      const parcel = ship.parcels.find(p => p.id === selectedParcel);
      if (parcel) {
        setDischargeData(prev => ({
          ...prev,
          parcelId: selectedParcel,
          remainingThisParcel: parseFloat(parcel.volumeM3),
        }));
      }
    }
  }, [selectedParcel, ship]);

  const handleStartDischarge = () => {
    if (!selectedParcel || dischargeData.currentRate <= 0) {
      toast({
        title: "Dados Incompletos",
        description: "Selecione uma parcela e defina a taxa de descarga",
        variant: "destructive",
      });
      return;
    }

    startDischargeMutation.mutate(dischargeData);
  };

  const handleAddHourlyUpdate = () => {
    if (!currentUpdate.timestamp || currentUpdate.pressure <= 0 || currentUpdate.rate <= 0) {
      toast({
        title: "Dados Incompletos",
        description: "Preencha todos os campos da atualização horária",
        variant: "destructive",
      });
      return;
    }

    setHourlyUpdates(prev => [...prev, currentUpdate]);
    setCurrentUpdate({
      timestamp: "",
      pressure: 0,
      rate: 0,
      discharged: 0,
    });
    
    toast({
      title: "Atualização Adicionada",
      description: `Dados registrados para ${format(new Date(currentUpdate.timestamp), "HH:mm", { locale: ptBR })}`,
    });
  };

  const generateDischargePDF = async () => {
    try {
      const html2canvas = (await import('html2canvas')).default;
      const jsPDF = (await import('jspdf')).default;

      // Criar elemento HTML com dados da descarga
      const reportElement = document.createElement('div');
      reportElement.innerHTML = `
        <div style="padding: 20px; font-family: Arial, sans-serif;">
          <h1 style="text-align: center; color: #1e40af;">Relatório de Descarga</h1>
          <h2 style="text-align: center; margin-bottom: 30px;">${shipName}</h2>
          
          <div style="margin-bottom: 20px;">
            <h3>Informações Gerais</h3>
            <p><strong>Parcela:</strong> ${ship?.parcels?.find(p => p.id === selectedParcel)?.product || 'N/A'}</p>
            <p><strong>Volume Total:</strong> ${ship?.parcels?.find(p => p.id === selectedParcel)?.volumeM3 || 'N/A'} m³</p>
            <p><strong>Início da Descarga:</strong> ${dischargeData.dischargeStartTime ? format(new Date(dischargeData.dischargeStartTime), "dd/MM/yyyy HH:mm", { locale: ptBR }) : 'N/A'}</p>
          </div>

          <div style="margin-bottom: 20px;">
            <h3>Atualizações Horárias</h3>
            <table style="width: 100%; border-collapse: collapse; border: 1px solid #ddd;">
              <thead style="background-color: #f5f5f5;">
                <tr>
                  <th style="border: 1px solid #ddd; padding: 8px;">Hora</th>
                  <th style="border: 1px solid #ddd; padding: 8px;">Pressão (bar)</th>
                  <th style="border: 1px solid #ddd; padding: 8px;">Rate (m³/h)</th>
                  <th style="border: 1px solid #ddd; padding: 8px;">Descarregado (m³)</th>
                </tr>
              </thead>
              <tbody>
                ${hourlyUpdates.map(update => `
                  <tr>
                    <td style="border: 1px solid #ddd; padding: 8px;">${format(new Date(update.timestamp), "HH:mm", { locale: ptBR })}</td>
                    <td style="border: 1px solid #ddd; padding: 8px;">${update.pressure}</td>
                    <td style="border: 1px solid #ddd; padding: 8px;">${update.rate}</td>
                    <td style="border: 1px solid #ddd; padding: 8px;">${update.discharged}</td>
                  </tr>
                `).join('')}
              </tbody>
            </table>
          </div>

          <div style="margin-top: 30px;">
            <p><strong>Relatório gerado em:</strong> ${format(new Date(), "dd/MM/yyyy HH:mm", { locale: ptBR })}</p>
            <p><strong>Terminal:</strong> Beira Oil Terminal - CFM-EP</p>
          </div>
        </div>
      `;

      document.body.appendChild(reportElement);

      const canvas = await html2canvas(reportElement, {
        scale: 2,
        useCORS: true,
      });

      document.body.removeChild(reportElement);

      const pdf = new jsPDF('p', 'mm', 'a4');
      const imgData = canvas.toDataURL('image/png');
      const imgWidth = 210;
      const pageHeight = 295;
      const imgHeight = (canvas.height * imgWidth) / canvas.width;
      let heightLeft = imgHeight;

      let position = 0;

      pdf.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight);
      heightLeft -= pageHeight;

      while (heightLeft >= 0) {
        position = heightLeft - imgHeight;
        pdf.addPage();
        pdf.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight);
        heightLeft -= pageHeight;
      }

      pdf.save(`Descarga_${shipName}_${format(new Date(), "ddMMyyyy_HHmm", { locale: ptBR })}.pdf`);
      
      toast({
        title: "PDF Gerado",
        description: "Relatório de descarga salvo com sucesso",
      });
    } catch (error) {
      console.error('Error generating PDF:', error);
      toast({
        title: "Erro",
        description: "Falha ao gerar PDF do relatório",
        variant: "destructive",
      });
    }
  };

  const getStopTypeLabel = (type: string) => {
    switch (type) {
      case "line_displacement": return "Line Displacement";
      case "parcel_change": return "Troca de Parcelas";
      case "completion": return "Completar Descarga";
      default: return type;
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <TrendingUp className="w-5 h-5" />
            Controle Avançado de Descarga - {shipName}
          </DialogTitle>
        </DialogHeader>

        {/* Seção Principal de Atualização */}
        <Card className="mb-6 border-2 border-blue-200 bg-blue-50">
          <CardHeader>
            <CardTitle className="text-xl text-blue-800">Atualização Horária da Descarga</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div>
                <Label className="font-semibold">Data/Hora</Label>
                <Input
                  type="datetime-local"
                  value={currentUpdate.timestamp}
                  onChange={(e) => setCurrentUpdate(prev => ({ ...prev, timestamp: e.target.value }))}
                  className="border-2"
                />
              </div>

              <div>
                <Label className="font-semibold text-red-700">Pressão (bar)</Label>
                <Input
                  type="number"
                  step="0.1"
                  value={currentUpdate.pressure || ""}
                  onChange={(e) => setCurrentUpdate(prev => ({ ...prev, pressure: parseFloat(e.target.value) || 0 }))}
                  placeholder="Ex: 2.5"
                  className="border-2 border-red-300"
                />
              </div>

              <div>
                <Label className="font-semibold text-green-700">Rate (m³/h)</Label>
                <Input
                  type="number"
                  step="0.01"
                  value={currentUpdate.rate || ""}
                  onChange={(e) => setCurrentUpdate(prev => ({ ...prev, rate: parseFloat(e.target.value) || 0 }))}
                  placeholder="Ex: 250.50"
                  className="border-2 border-green-300"
                />
              </div>

              <div>
                <Label className="font-semibold text-purple-700">Descarregado (m³)</Label>
                <Input
                  type="number"
                  step="0.01"
                  value={currentUpdate.discharged || ""}
                  onChange={(e) => setCurrentUpdate(prev => ({ ...prev, discharged: parseFloat(e.target.value) || 0 }))}
                  placeholder="Ex: 180.75"
                  className="border-2 border-purple-300"
                />
              </div>
            </div>
            
            <div className="mt-4">
              <Button 
                onClick={handleAddHourlyUpdate}
                className="w-full bg-blue-600 hover:bg-blue-700 text-lg py-3"
                disabled={!currentUpdate.timestamp || currentUpdate.pressure <= 0 || currentUpdate.rate <= 0}
              >
                <Plus className="w-5 h-5 mr-2" />
                Registrar Dados da Hora
              </Button>
            </div>
          </CardContent>
        </Card>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Seleção de Parcela */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Selecionar Parcela</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label>Parcela de Carga</Label>
                <Select value={selectedParcel?.toString() || ""} onValueChange={(value) => setSelectedParcel(parseInt(value))}>
                  <SelectTrigger>
                    <SelectValue placeholder="Selecione uma parcela..." />
                  </SelectTrigger>
                  <SelectContent>
                    {ship?.parcels?.map((parcel) => (
                      <SelectItem key={parcel.id} value={parcel.id.toString()}>
                        {parcel.product} - {parcel.volumeM3} m³ ({parcel.receiver})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {selectedParcel && (
                <div className="p-3 bg-blue-50 rounded-lg">
                  <h4 className="font-medium mb-2">Detalhes da Parcela</h4>
                  {ship?.parcels?.filter(p => p.id === selectedParcel).map((parcel) => (
                    <div key={parcel.id} className="space-y-1 text-sm">
                      <div><strong>Produto:</strong> {parcel.product}</div>
                      <div><strong>Volume:</strong> {parcel.volumeM3} m³ ({parcel.volumeMt} MT)</div>
                      <div><strong>Densidade:</strong> {parcel.density15C}</div>
                      <div><strong>Recebedor:</strong> {parcel.receiver}</div>
                      <div><strong>Dono:</strong> {parcel.owner}</div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Resumo da Parcela Selecionada */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Resumo da Parcela</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {selectedParcel && ship?.parcels?.filter(p => p.id === selectedParcel).map((parcel) => (
                <div key={parcel.id} className="space-y-2">
                  <div className="p-3 bg-gray-50 rounded-lg">
                    <div className="grid grid-cols-2 gap-2 text-sm">
                      <div><strong>Produto:</strong> {parcel.product}</div>
                      <div><strong>Volume:</strong> {parcel.volumeM3} m³</div>
                      <div><strong>Densidade:</strong> {parcel.density15C}</div>
                      <div><strong>Recebedor:</strong> {parcel.receiver}</div>
                    </div>
                  </div>
                </div>
              )) || (
                <div className="text-center py-4 text-gray-500">
                  <p>Selecione uma parcela para ver os detalhes</p>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Dados Históricos da Descarga */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Dados da Descarga</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {hourlyUpdates.length > 0 ? (
                <div className="space-y-3">
                  <div className="max-h-60 overflow-y-auto">
                    {hourlyUpdates.map((update, index) => (
                      <div key={index} className="p-3 bg-gray-50 rounded-lg border">
                        <div className="grid grid-cols-2 gap-2 text-sm">
                          <div><strong>Hora:</strong> {format(new Date(update.timestamp), "HH:mm", { locale: ptBR })}</div>
                          <div><strong>Pressão:</strong> {update.pressure} bar</div>
                          <div><strong>Rate:</strong> {update.rate} m³/h</div>
                          <div><strong>Descarregado:</strong> {update.discharged} m³</div>
                        </div>
                      </div>
                    ))}
                  </div>
                  
                  <div className="p-3 bg-blue-50 rounded-lg border">
                    <h4 className="font-medium mb-2">Resumo Total</h4>
                    <div className="grid grid-cols-2 gap-2 text-sm">
                      <div><strong>Total Descarregado:</strong> {hourlyUpdates.reduce((sum, update) => sum + update.discharged, 0).toFixed(2)} m³</div>
                      <div><strong>Rate Médio:</strong> {hourlyUpdates.length > 0 ? (hourlyUpdates.reduce((sum, update) => sum + update.rate, 0) / hourlyUpdates.length).toFixed(2) : 0} m³/h</div>
                      <div><strong>Pressão Média:</strong> {hourlyUpdates.length > 0 ? (hourlyUpdates.reduce((sum, update) => sum + update.pressure, 0) / hourlyUpdates.length).toFixed(1) : 0} bar</div>
                      <div><strong>Atualizações:</strong> {hourlyUpdates.length}</div>
                    </div>
                  </div>

                  <Button 
                    onClick={generateDischargePDF}
                    className="w-full bg-purple-600 hover:bg-purple-700"
                  >
                    <FileDown className="w-4 h-4 mr-2" />
                    Gerar PDF da Descarga
                  </Button>
                </div>
              ) : (
                <div className="text-center py-8 text-gray-500">
                  <Clock className="w-12 h-12 mx-auto mb-4 text-gray-300" />
                  <p>Nenhuma atualização registrada</p>
                  <p className="text-sm">Adicione atualizações horárias para visualizar os dados</p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Seção de Paradas Operacionais - Largura Total */}
        <Card className="mt-6">
          <CardHeader>
            <CardTitle className="text-lg">Paradas Operacionais</CardTitle>
          </CardHeader>
          <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label>Tipo de Parada</Label>
              <Select value={stopType} onValueChange={setStopType}>
                <SelectTrigger>
                  <SelectValue placeholder="Selecione tipo de parada..." />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="line_displacement">Line Displacement</SelectItem>
                  <SelectItem value="parcel_change">Troca de Parcelas</SelectItem>
                  <SelectItem value="completion">Completar Descarga</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="flex items-end">
              <Button 
                variant="outline" 
                className="w-full"
                disabled={!stopType}
                onClick={() => {
                  toast({
                    title: "Parada Registrada",
                    description: `${getStopTypeLabel(stopType)} - ${format(new Date(), "HH:mm", { locale: ptBR })}`,
                  });
                  setStopType("");
                }}
              >
                <Pause className="w-4 h-4 mr-2" />
                Registrar Parada
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Cálculos e Previsões */}
        <Card className="mt-6">
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2">
              <Calculator className="w-5 h-5" />
              Cálculos Automáticos
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="p-3 bg-green-50 rounded-lg">
              <div className="font-medium text-green-800 mb-2">Dados em Tempo Real</div>
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div><strong>Total de Atualizações:</strong> {hourlyUpdates.length}</div>
                <div><strong>Última Atualização:</strong> {hourlyUpdates.length > 0 ? format(new Date(hourlyUpdates[hourlyUpdates.length - 1].timestamp), "HH:mm", { locale: ptBR }) : "N/A"}</div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Separator />

        <div className="flex gap-2 justify-end">
          <Button variant="outline" onClick={onClose}>
            Fechar
          </Button>
          <Button 
            onClick={handleAddHourlyUpdate}
            disabled={!currentUpdate.timestamp || currentUpdate.pressure <= 0 || currentUpdate.rate <= 0}
            className="flex items-center gap-2"
          >
            <Plus className="w-4 h-4" />
            Salvar Dados
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}