import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { X, Download, FileText, Ship, BarChart3 } from 'lucide-react';
import { useQuery } from '@tanstack/react-query';

interface ShipsReportModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function ShipsReportModal({ isOpen, onClose }: ShipsReportModalProps) {
  const [isDownloading, setIsDownloading] = useState(false);

  // Fetch ships data for report
  const { data: ships, isLoading } = useQuery({
    queryKey: ['/api/ships'],
    enabled: isOpen,
  });

  const downloadPDF = async () => {
    setIsDownloading(true);
    try {
      const response = await fetch('/api/reports/ships/pdf');
      if (!response.ok) throw new Error('Failed to download PDF');
      
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `ships-report-${new Date().toISOString().split('T')[0]}.pdf`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
    } catch (error) {
      console.error('Error downloading PDF:', error);
    } finally {
      setIsDownloading(false);
    }
  };

  // Calculate summary statistics from ships data
  const shipsArray = Array.isArray(ships) ? ships : [];
  const totalShips = shipsArray.length;
  const totalParcels = shipsArray.reduce((sum: number, ship: any) => sum + (ship.parcels?.length || 0), 0);
  const totalVolume = shipsArray.reduce((sum: number, ship: any) => {
    const shipVolume = ship.parcels?.reduce((pSum: number, p: any) => pSum + (parseFloat(p.volumeMT) || 0), 0) || 0;
    return sum + shipVolume;
  }, 0);

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-5xl max-h-[90vh] overflow-hidden">
        <DialogHeader className="flex flex-row items-center justify-between space-y-0 pb-4">
          <DialogTitle className="flex items-center gap-2 text-xl font-bold text-blue-800">
            <FileText className="h-6 w-6" />
            Relatório de Navios - Terminal da Beira
          </DialogTitle>
          <div className="flex items-center gap-2">
            <Button
              onClick={downloadPDF}
              disabled={isDownloading}
              className="bg-blue-600 hover:bg-blue-700 text-white"
            >
              <Download className="h-4 w-4 mr-2" />
              {isDownloading ? 'Baixando...' : 'Download PDF'}
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={onClose}
              className="h-8 w-8 p-0"
            >
              <X className="h-4 w-4" />
            </Button>
          </div>
        </DialogHeader>

        <div className="overflow-y-auto">
          {isLoading ? (
            <div className="flex items-center justify-center p-8">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
              <p className="ml-3 text-gray-600">Carregando dados...</p>
            </div>
          ) : (
            <div className="space-y-6">
              {/* Summary Cards */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                  <div className="flex items-center gap-3">
                    <Ship className="h-8 w-8 text-blue-600" />
                    <div>
                      <p className="text-sm text-blue-600 font-medium">Total de Navios</p>
                      <p className="text-2xl font-bold text-blue-800">{totalShips}</p>
                    </div>
                  </div>
                </div>

                <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                  <div className="flex items-center gap-3">
                    <BarChart3 className="h-8 w-8 text-green-600" />
                    <div>
                      <p className="text-sm text-green-600 font-medium">Parcelas de Carga</p>
                      <p className="text-2xl font-bold text-green-800">{totalParcels}</p>
                    </div>
                  </div>
                </div>

                <div className="bg-orange-50 border border-orange-200 rounded-lg p-4">
                  <div className="flex items-center gap-3">
                    <FileText className="h-8 w-8 text-orange-600" />
                    <div>
                      <p className="text-sm text-orange-600 font-medium">Volume Total</p>
                      <p className="text-2xl font-bold text-orange-800">{totalVolume.toLocaleString()} MT</p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Ships Summary by Status */}
              <div className="bg-white border border-gray-200 rounded-lg overflow-hidden">
                <div className="bg-gray-50 px-6 py-4 border-b border-gray-200">
                  <h3 className="text-lg font-semibold text-gray-800">Resumo por Status</h3>
                </div>
                
                <div className="p-6">
                  <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
                    {[
                      { status: 'expected', label: 'Previstos', color: 'purple' },
                      { status: 'at_bar', label: 'Na Barra', color: 'blue' },
                      { status: 'next_to_berth', label: 'Próximos', color: 'yellow' },
                      { status: 'at_berth', label: 'No Cais', color: 'green' },
                      { status: 'departed', label: 'Partidos', color: 'gray' }
                    ].map(({ status, label, color }) => {
                      const count = shipsArray.filter((ship: any) => ship.status === status).length;
                      return (
                        <div key={status} className={`bg-${color}-50 border border-${color}-200 rounded-lg p-3 text-center`}>
                          <p className={`text-sm text-${color}-600 font-medium`}>{label}</p>
                          <p className={`text-xl font-bold text-${color}-800`}>{count}</p>
                        </div>
                      );
                    })}
                  </div>
                </div>
              </div>

              {/* Ships List */}
              <div className="bg-white border border-gray-200 rounded-lg overflow-hidden">
                <div className="bg-gray-50 px-6 py-4 border-b border-gray-200">
                  <h3 className="text-lg font-semibold text-gray-800">Lista de Navios</h3>
                </div>
                
                <div className="overflow-x-auto">
                  <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Navio
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Status
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Parcelas
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Volume Total
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Operação
                        </th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      {shipsArray.map((ship: any, index: number) => {
                        const shipVolume = ship.parcels?.reduce((sum: number, p: any) => sum + (parseFloat(p.volumeMT) || 0), 0) || 0;
                        
                        return (
                          <tr key={index} className="hover:bg-gray-50">
                            <td className="px-6 py-4 whitespace-nowrap">
                              <div className="flex items-center">
                                <Ship className="h-5 w-5 text-blue-500 mr-3" />
                                <div>
                                  <div className="text-sm font-medium text-gray-900">{ship.name}</div>
                                  <div className="text-sm text-gray-500">{ship.countermark}</div>
                                </div>
                              </div>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap">
                              <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${
                                ship.status === 'at_berth' ? 'bg-green-100 text-green-800' :
                                ship.status === 'next_to_berth' ? 'bg-yellow-100 text-yellow-800' :
                                ship.status === 'at_bar' ? 'bg-blue-100 text-blue-800' :
                                ship.status === 'departed' ? 'bg-gray-100 text-gray-800' :
                                'bg-purple-100 text-purple-800'
                              }`}>
                                {ship.status === 'at_berth' ? 'No Cais' :
                                 ship.status === 'next_to_berth' ? 'Próximo' :
                                 ship.status === 'at_bar' ? 'Na Barra' :
                                 ship.status === 'departed' ? 'Partiu' :
                                 'Previsto'}
                              </span>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                              {ship.parcels?.length || 0}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                              {shipVolume.toLocaleString()} MT
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                              {ship.operationType || 'N/A'}
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Footer */}
              <div className="text-center text-sm text-gray-500 py-4 border-t border-gray-200">
                <p>Relatório gerado em {new Date().toLocaleDateString('pt-BR')} às {new Date().toLocaleTimeString('pt-BR')}</p>
                <p>Terminal da Beira - Sistema de Gestão de Navios</p>
              </div>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}