import React, { useState, useRef, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { 
  MessageCircle, 
  Send, 
  Bot,
  User,
  X,
  Clock,
  Brain
} from 'lucide-react';
import { useTranslation } from '@/contexts/LanguageContext';

interface BasicChatMessage {
  id: string;
  content: string;
  role: 'user' | 'assistant';
  timestamp: Date;
  confidence?: number;
  suggestions?: string[];
}

interface BasicAIAssistantProps {
  user?: any;
  isOpen: boolean;
  onClose: () => void;
}

export function BasicAIAssistant({ user, isOpen, onClose }: BasicAIAssistantProps) {
  const { t, language } = useTranslation();
  const [messages, setMessages] = useState<BasicChatMessage[]>([]);
  const [currentMessage, setCurrentMessage] = useState('');
  const [sessionId, setSessionId] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Auto scroll to bottom
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // Create session when component opens
  useEffect(() => {
    if (isOpen && !sessionId) {
      createSession();
    }
  }, [isOpen]);

  const createSession = async () => {
    try {
      setIsLoading(true);
      const response = await fetch('/api/basic-ai/session', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userRole: user?.role || 'visitor',
          language: language
        }),
      });

      if (response.ok) {
        const data = await response.json();
        setSessionId(data.sessionId);
        console.log('[BasicAI] Session created:', data.sessionId);
        
        // Add welcome message
        const welcomeMessage: BasicChatMessage = {
          id: 'welcome',
          content: language === 'en' ? 
            'Hello! I\'m your Basic AI Assistant for the Beira Oil Terminal. I can help you with ship information, terminal status, and general navigation. What would you like to know?' :
            'Olá! Sou seu Assistente IA Básico do Terminal Petrolífero da Beira. Posso ajudar com informações de navios, status do terminal e navegação geral. O que gostaria de saber?',
          role: 'assistant',
          timestamp: new Date(),
          confidence: 1.0,
          suggestions: language === 'en' ? [
            'Show current ships',
            'Terminal status',
            'Help me navigate'
          ] : [
            'Mostrar navios atuais',
            'Status do terminal',
            'Ajudar na navegação'
          ]
        };
        setMessages([welcomeMessage]);
      } else {
        throw new Error('Failed to create session');
      }
    } catch (error) {
      console.error('[BasicAI] Session creation failed:', error);
      const errorMessage: BasicChatMessage = {
        id: 'error',
        content: language === 'en' ? 
          'Unable to start AI assistant. Please try again.' :
          'Não foi possível iniciar o assistente IA. Tente novamente.',
        role: 'assistant',
        timestamp: new Date(),
        confidence: 0.1
      };
      setMessages([errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  const sendMessage = async (messageText?: string, suggestion?: boolean) => {
    const text = messageText || currentMessage.trim();
    if (!text || !sessionId || isLoading) return;

    const userMessage: BasicChatMessage = {
      id: Date.now().toString(),
      content: text,
      role: 'user',
      timestamp: new Date(),
    };

    setMessages(prev => [...prev, userMessage]);
    if (!suggestion) setCurrentMessage('');
    setIsLoading(true);

    try {
      const response = await fetch('/api/basic-ai/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          sessionId,
          message: text,
          userRole: user?.role || 'visitor',
          language: language,
        }),
      });

      if (response.ok) {
        const data = await response.json();
        
        const assistantMessage: BasicChatMessage = {
          id: (Date.now() + 1).toString(),
          content: data.response,
          role: 'assistant',
          timestamp: new Date(),
          confidence: data.confidence,
          suggestions: data.suggestions
        };

        setMessages(prev => [...prev, assistantMessage]);
      } else {
        throw new Error('Failed to get response');
      }
    } catch (error) {
      console.error('[BasicAI] Message failed:', error);
      const errorMessage: BasicChatMessage = {
        id: (Date.now() + 1).toString(),
        content: language === 'en' ? 
          'I\'m having trouble processing your request. Please try again.' :
          'Estou com dificuldades para processar sua solicitação. Tente novamente.',
        role: 'assistant',
        timestamp: new Date(),
        confidence: 0.3,
      };
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleClose = () => {
    setMessages([]);
    setSessionId(null);
    setCurrentMessage('');
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50 p-4">
      <Card className="w-full max-w-4xl h-[700px] flex flex-col shadow-2xl bg-white rounded-xl overflow-hidden">
        {/* Header */}
        <CardHeader className="flex flex-row items-center justify-between space-y-0 p-6 bg-gradient-to-r from-green-600 to-blue-600 text-white">
          <CardTitle className="flex items-center gap-4">
            <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center">
              <Brain className="h-7 w-7" />
            </div>
            <div>
              <div className="text-xl font-semibold">
                {language === 'en' ? 'Basic AI Assistant' : 'Assistente IA Básico'}
              </div>
              <div className="text-sm text-white/80">
                {language === 'en' ? 'Terminal Information & Support' : 'Informações e Suporte do Terminal'}
              </div>
            </div>
          </CardTitle>
          <div className="flex items-center gap-3">
            <Badge variant="secondary" className="bg-white/20 text-white border-white/30 px-3 py-1">
              {language === 'en' ? 'Interactive' : 'Interativo'}
            </Badge>
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={handleClose} 
              className="text-white hover:bg-white/20 hover:bg-red-500/20 p-2 rounded-full transition-colors"
              title={language === 'en' ? 'Close Assistant' : 'Fechar Assistente'}
            >
              <X className="h-5 w-5" />
            </Button>
          </div>
        </CardHeader>

        {/* Chat Area */}
        <CardContent className="flex-1 flex flex-col p-0 bg-gray-50">
          <div className="flex-1 overflow-y-auto p-6 space-y-6">
            {messages.map((message) => (
              <div
                key={message.id}
                className={`flex gap-4 ${
                  message.role === 'user' ? 'flex-row-reverse' : ''
                }`}
              >
                {/* Avatar */}
                <div className={`w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0 shadow-md ${
                  message.role === 'user' 
                    ? 'bg-blue-500 text-white' 
                    : 'bg-gradient-to-br from-green-600 to-blue-600 text-white'
                }`}>
                  {message.role === 'user' ? <User className="h-5 w-5" /> : <Brain className="h-5 w-5" />}
                </div>
                
                {/* Message Bubble */}
                <div className={`flex-1 max-w-[80%] ${message.role === 'user' ? 'flex justify-end' : ''}`}>
                  <div className={`p-4 rounded-2xl shadow-sm ${
                    message.role === 'user'
                      ? 'bg-blue-500 text-white rounded-br-md'
                      : 'bg-white border border-gray-200 rounded-bl-md'
                  }`}>
                    <p className="text-sm leading-relaxed whitespace-pre-line">{message.content}</p>
                    
                    {/* Assistant extras */}
                    {message.role === 'assistant' && (
                      <div className="mt-4 space-y-3">
                        {/* Confidence indicator */}
                        {message.confidence !== undefined && (
                          <div className="flex items-center gap-2 text-xs text-gray-500 bg-gray-50 px-3 py-2 rounded-lg">
                            <Clock className="h-3 w-3" />
                            <span>
                              {language === 'en' ? 'Confidence' : 'Confiança'}: 
                              <span className={`ml-1 font-medium ${
                                message.confidence >= 0.8 ? 'text-green-600' : 
                                message.confidence >= 0.6 ? 'text-yellow-600' : 'text-red-600'
                              }`}>
                                {Math.round(message.confidence * 100)}%
                              </span>
                            </span>
                          </div>
                        )}

                        {/* Suggestions */}
                        {message.suggestions && message.suggestions.length > 0 && (
                          <div className="space-y-3">
                            <p className="text-xs text-gray-600 font-medium border-l-2 border-green-500 pl-3">
                              {language === 'en' ? 'Try asking:' : 'Experimente perguntar:'}
                            </p>
                            <div className="grid grid-cols-1 gap-2">
                              {message.suggestions.map((suggestion, index) => (
                                <Button
                                  key={index}
                                  variant="outline"
                                  size="sm"
                                  onClick={() => sendMessage(suggestion, true)}
                                  className="text-xs h-8 px-3 bg-green-50 border-green-200 hover:bg-green-100 text-green-700 rounded-lg justify-start"
                                >
                                  <MessageCircle className="h-3 w-3 mr-2" />
                                  {suggestion}
                                </Button>
                              ))}
                            </div>
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            ))}
            
            {/* Loading indicator */}
            {isLoading && (
              <div className="flex gap-4">
                <div className="w-10 h-10 bg-gradient-to-br from-green-600 to-blue-600 rounded-full flex items-center justify-center shadow-md">
                  <Brain className="h-5 w-5 text-white" />
                </div>
                <div className="bg-white border border-gray-200 p-4 rounded-2xl rounded-bl-md shadow-sm">
                  <div className="flex items-center space-x-2">
                    <div className="w-2 h-2 bg-green-500 rounded-full animate-bounce" />
                    <div className="w-2 h-2 bg-green-500 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }} />
                    <div className="w-2 h-2 bg-green-500 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }} />
                    <span className="text-sm text-gray-500 ml-2">
                      {language === 'en' ? 'Thinking...' : 'Pensando...'}
                    </span>
                  </div>
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Input section */}
          <div className="border-t border-gray-200 p-6 bg-white">
            <div className="flex gap-3 items-end">
              <div className="flex-1">
                <Input
                  placeholder={language === 'en' ? 
                    'Digite sua pergunta sobre navios, terminal ou operações...' : 
                    'Digite sua pergunta sobre navios, terminal ou operações...'}
                  value={currentMessage}
                  onChange={(e) => setCurrentMessage(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && !e.shiftKey && sendMessage()}
                  disabled={isLoading}
                  className="h-12 text-sm border-gray-300 focus:border-green-500 focus:ring-green-500 rounded-xl"
                />
              </div>
              <Button 
                onClick={() => sendMessage()} 
                disabled={!currentMessage.trim() || isLoading}
                className="h-12 px-6 bg-gradient-to-r from-green-600 to-blue-600 hover:from-green-700 hover:to-blue-700 rounded-xl shadow-md"
              >
                <Send className="h-4 w-4" />
              </Button>
            </div>
            
            {/* Footer info */}
            <div className="mt-3 flex items-center justify-center gap-2 text-xs text-gray-500">
              <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
              <span>
                {language === 'en' ? 
                  'Basic AI Assistant - Interactive terminal support' :
                  'Assistente IA Básico - Suporte interativo do terminal'}
              </span>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}