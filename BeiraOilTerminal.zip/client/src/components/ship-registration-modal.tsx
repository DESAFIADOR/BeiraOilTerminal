import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { isUnauthorizedError } from "@/lib/authUtils";
import { Plus, Trash2 } from "lucide-react";

interface CargoParcel {
  parcelNumber: string;
  product: string;
  volumeMT: string;
  volumeM3: string;
  density15C: string;
  receiver: string;
  owner: string;
}

interface ShipRegistrationModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
  initialLocation?: 'at_bar' | 'expected' | 'next_to_berth' | null;
}

export function ShipRegistrationModal({ isOpen, onClose, onSuccess, initialLocation }: ShipRegistrationModalProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const [formData, setFormData] = useState<{
    arrivalDateTime: string;
    name: string;
    countermark: string;
    draft: string;
    shipAgent: string;
    shipAgentEmail: string;
    cargoAgent: string;
    cargoAgentEmail: string;
    shipowner: string;
    cargoType: string;
    cargoDestination: string;
    operationType: string;
    shipLocation: 'at_bar' | 'expected' | 'next_to_berth';
    hasDischargeInstructions: boolean;
  }>({
    arrivalDateTime: "",
    name: "",
    countermark: "",
    draft: "",
    shipAgent: "",
    shipAgentEmail: "",
    cargoAgent: "",
    cargoAgentEmail: "",
    shipowner: "",
    cargoType: "",
    cargoDestination: "",
    operationType: "nacional",
    shipLocation: initialLocation || "at_bar",
    hasDischargeInstructions: false,
  });

  const [parcels, setParcels] = useState<CargoParcel[]>([
    { parcelNumber: "P001", product: "", volumeMT: "", volumeM3: "", density15C: "", receiver: "", owner: "" }
  ]);

  const mutation = useMutation({
    mutationFn: async (data: any) => {
      const response = await fetch("/api/ships", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!response.ok) throw new Error("Failed to register ship");
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Sucesso",
        description: "Navio registrado com sucesso!",
      });
      // Invalidate all ship-related queries immediately
      queryClient.invalidateQueries({ queryKey: ["/api/ships"] });
      // Force refetch with fresh data
      queryClient.refetchQueries({ queryKey: ["/api/ships"] });
      // Dispatch custom event for immediate dashboard update
      window.dispatchEvent(new CustomEvent('shipRegistered'));
      // Also invalidate weather and tide data that might be affected
      queryClient.invalidateQueries({ queryKey: ["/api/weather"] });
      queryClient.invalidateQueries({ queryKey: ["/api/tide"] });
      onSuccess();
      resetForm();
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Erro",
        description: "Falha ao registrar navio. Tente novamente.",
        variant: "destructive",
      });
    },
  });

  const resetForm = () => {
    setFormData({
      arrivalDateTime: "",
      name: "",
      countermark: "",
      draft: "",
      shipAgent: "",
      shipAgentEmail: "",
      cargoAgent: "",
      cargoAgentEmail: "",
      shipowner: "",
      cargoType: "",
      cargoDestination: "",
      operationType: "nacional",
      shipLocation: "at_bar",
      hasDischargeInstructions: false,
    });
    setParcels([{ parcelNumber: "P001", product: "", volumeMT: "", volumeM3: "", density15C: "", receiver: "", owner: "" }]);
  };

  const addParcel = () => {
    const nextNumber = `P${String(parcels.length + 1).padStart(3, "0")}`;
    setParcels([...parcels, { parcelNumber: nextNumber, product: "", volumeMT: "", volumeM3: "", density15C: "", receiver: "", owner: "" }]);
  };

  const removeParcel = (index: number) => {
    if (parcels.length > 1) {
      setParcels(parcels.filter((_, i) => i !== index));
    }
  };

  const updateParcel = (index: number, field: keyof CargoParcel, value: string) => {
    setParcels(prev => 
      prev.map((parcel, i) => {
        if (i !== index) return parcel;
        
        const updatedParcel = { ...parcel, [field]: value };
        
        // Auto-calculate based on density formula: MT = m³ × Density
        const density = parseFloat(updatedParcel.density15C);
        const volumeMT = parseFloat(updatedParcel.volumeMT);
        const volumeM3 = parseFloat(updatedParcel.volumeM3);
        
        if (density > 0) {
          if (field === 'volumeMT' && volumeMT > 0) {
            // Calculate m³ from MT: m³ = MT / Density
            updatedParcel.volumeM3 = (volumeMT / density).toFixed(3);
          } else if (field === 'volumeM3' && volumeM3 > 0) {
            // Calculate MT from m³: MT = m³ × Density
            updatedParcel.volumeMT = (volumeM3 * density).toFixed(3);
          } else if (field === 'density15C' && density > 0) {
            // Recalculate when density changes - prioritize MT if available
            if (volumeMT > 0) {
              updatedParcel.volumeM3 = (volumeMT / density).toFixed(3);
            } else if (volumeM3 > 0) {
              updatedParcel.volumeMT = (volumeM3 * density).toFixed(3);
            }
          }
        }
        
        return updatedParcel;
      })
    );
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Determine initial status based on ship location
    const initialStatus = formData.shipLocation === 'at_bar' ? 'at_bar' : 'expected';
    
    const shipData = {
      ...formData,
      arrivalDateTime: new Date(formData.arrivalDateTime).toISOString(),
      status: initialStatus,
      hasDischargeInstructions: formData.hasDischargeInstructions,
    };

    mutation.mutate({
      ship: shipData,
      parcels: parcels,
    });
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-xl font-bold text-blue-600">
            Registrar Novo Navio
          </DialogTitle>
          <DialogDescription>
            Registre um novo navio com informações detalhadas sobre chegada, agentes e carga.
          </DialogDescription>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Ship Destination Selection */}
          <div className="mb-6 p-4 bg-gray-50 rounded-lg border border-gray-200">
            <div className="space-y-4">
              <div>
                <Label className="text-sm font-medium text-gray-700">Destino do Navio Após Registro *</Label>
                <p className="text-xs text-gray-500 mt-1">Escolha onde o navio deve aparecer após o registro</p>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                <button
                  type="button"
                  onClick={() => {
                    setFormData({ 
                      ...formData, 
                      shipLocation: 'at_bar', 
                      hasDischargeInstructions: true 
                    });
                  }}
                  className={`p-4 border rounded-lg text-left transition-all ${
                    formData.shipLocation === 'at_bar' && formData.hasDischargeInstructions
                      ? 'border-blue-500 bg-blue-50 ring-2 ring-blue-200'
                      : 'border-gray-200 hover:border-gray-300'
                  }`}
                >
                  <div className="flex items-center gap-2 mb-2">
                    <div className="w-3 h-3 rounded-full bg-green-500"></div>
                    <span className="font-medium text-gray-900">Navios com Instrução</span>
                  </div>
                  <p className="text-sm text-gray-600">
                    Navio aparecerá na aba "Com Instrução" - pronto para operações
                  </p>
                </button>
                
                <button
                  type="button"
                  onClick={() => {
                    setFormData({ 
                      ...formData, 
                      shipLocation: 'next_to_berth', 
                      hasDischargeInstructions: true 
                    });
                  }}
                  className={`p-4 border rounded-lg text-left transition-all ${
                    formData.shipLocation === 'next_to_berth' && formData.hasDischargeInstructions
                      ? 'border-blue-500 bg-blue-50 ring-2 ring-blue-200'
                      : 'border-gray-200 hover:border-gray-300'
                  }`}
                >
                  <div className="flex items-center gap-2 mb-2">
                    <div className="w-3 h-3 rounded-full bg-blue-500"></div>
                    <span className="font-medium text-gray-900">Aguardando Instrução</span>
                  </div>
                  <p className="text-sm text-gray-600">
                    Navio aparecerá na aba "Aguardando Instrução" - próximo a atracar
                  </p>
                </button>
                
                <button
                  type="button"
                  onClick={() => {
                    setFormData({ 
                      ...formData, 
                      shipLocation: 'expected', 
                      hasDischargeInstructions: false 
                    });
                  }}
                  className={`p-4 border rounded-lg text-left transition-all ${
                    formData.shipLocation === 'expected'
                      ? 'border-blue-500 bg-blue-50 ring-2 ring-blue-200'
                      : 'border-gray-200 hover:border-gray-300'
                  }`}
                >
                  <div className="flex items-center gap-2 mb-2">
                    <div className="w-3 h-3 rounded-full bg-orange-500"></div>
                    <span className="font-medium text-gray-900">Previstos a Chegar</span>
                  </div>
                  <p className="text-sm text-gray-600">
                    Navio aparecerá na aba "Previstos a Chegar" - aguardando chegada
                  </p>
                </button>
              </div>
              
              {/* Current Selection Display */}
              <div className="mt-3">
                <span className="text-sm font-medium text-gray-700">Selecionado:</span>
                <div className={`ml-2 inline-flex items-center px-3 py-1 rounded-full text-sm font-medium ${
                  formData.shipLocation === 'at_bar' && formData.hasDischargeInstructions
                    ? 'bg-green-100 text-green-800' 
                    : formData.shipLocation === 'next_to_berth' && formData.hasDischargeInstructions
                    ? 'bg-blue-100 text-blue-800'
                    : formData.shipLocation === 'expected'
                    ? 'bg-orange-100 text-orange-800'
                    : 'bg-gray-100 text-gray-800'
                }`}>
                  {formData.shipLocation === 'at_bar' && formData.hasDischargeInstructions 
                    ? '✅ Com Instrução' 
                    : formData.shipLocation === 'next_to_berth' && formData.hasDischargeInstructions
                    ? '🕐 Aguardando Instrução'
                    : formData.shipLocation === 'expected'
                    ? '📅 Previsto a Chegar'
                    : 'Nenhuma seleção'}
                </div>
              </div>
            </div>
          </div>

          {/* Basic Information */}
          <div>
            <h3 className="text-lg font-semibold text-gray-900 mb-4">
              Informações Básicas
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="arrivalDateTime">Previsão de chegada na Barra *</Label>
                <Input
                  id="arrivalDateTime"
                  type="datetime-local"
                  value={formData.arrivalDateTime}
                  onChange={(e) => setFormData({ ...formData, arrivalDateTime: e.target.value })}
                  required
                />
              </div>
              
              <div>
                <Label htmlFor="name">Nome do Navio *</Label>
                <Input
                  id="name"
                  placeholder="Ex: MV Atlantic Dawn"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  required
                />
              </div>
              
              <div>
                <Label htmlFor="countermark">Contra Marca *</Label>
                <Input
                  id="countermark"
                  placeholder="Ex: HMFG-7739"
                  value={formData.countermark}
                  onChange={(e) => setFormData({ ...formData, countermark: e.target.value })}
                  required
                />
              </div>
              
              <div>
                <Label htmlFor="draft">Calado de Chegada (m) *</Label>
                <Input
                  id="draft"
                  type="number"
                  step="0.1"
                  placeholder="Ex: 7.8"
                  value={formData.draft}
                  onChange={(e) => setFormData({ ...formData, draft: e.target.value })}
                  required
                />
              </div>
            </div>
          </div>

          {/* Agents and Cargo */}
          <div>
            <h3 className="text-lg font-semibold text-gray-900 mb-4">
              Agentes e Carga
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="shipAgent">Agente do Navio *</Label>
                <Input
                  id="shipAgent"
                  placeholder="Ex: Maritime Services Ltd"
                  value={formData.shipAgent}
                  onChange={(e) => setFormData({ ...formData, shipAgent: e.target.value })}
                  required
                />
              </div>
              
              <div>
                <Label htmlFor="shipAgentEmail">Email do Agente do Navio *</Label>
                <Input
                  id="shipAgentEmail"
                  type="email"
                  placeholder="Ex: agente@maritime.com"
                  value={formData.shipAgentEmail}
                  onChange={(e) => setFormData({ ...formData, shipAgentEmail: e.target.value })}
                  required
                />
              </div>
              
              <div>
                <Label htmlFor="cargoAgent">Agente da Carga *</Label>
                <Input
                  id="cargoAgent"
                  placeholder="Ex: Barloworld Logistics"
                  value={formData.cargoAgent}
                  onChange={(e) => setFormData({ ...formData, cargoAgent: e.target.value })}
                  required
                />
              </div>
              
              <div>
                <Label htmlFor="cargoAgentEmail">Email do Agente da Carga</Label>
                <Input
                  id="cargoAgentEmail"
                  type="email"
                  placeholder="Ex: carga@barloworld.com"
                  value={formData.cargoAgentEmail}
                  onChange={(e) => setFormData({ ...formData, cargoAgentEmail: e.target.value })}
                />
              </div>
              
              <div>
                <Label htmlFor="shipowner">Armador *</Label>
                <Input
                  id="shipowner"
                  placeholder="Ex: Atlantic Shipping Co"
                  value={formData.shipowner}
                  onChange={(e) => setFormData({ ...formData, shipowner: e.target.value })}
                  required
                />
              </div>
              
              <div>
                <Label htmlFor="cargoType">Tipo de Carga *</Label>
                <Input
                  id="cargoType"
                  placeholder="Ex: Combustível, Diesel, Gasolina, Querosene"
                  value={formData.cargoType}
                  onChange={(e) => setFormData({ ...formData, cargoType: e.target.value })}
                  required
                />
              </div>
              
              <div>
                <Label htmlFor="cargoDestination">Destino da Carga *</Label>
                <Input
                  id="cargoDestination"
                  placeholder="Ex: Depósitos de Maputo"
                  value={formData.cargoDestination}
                  onChange={(e) => setFormData({ ...formData, cargoDestination: e.target.value })}
                  required
                />
              </div>
              
              <div>
                <Label htmlFor="operationType">Tipo de Operação *</Label>
                <Select
                  value={formData.operationType}
                  onValueChange={(value) => setFormData({ ...formData, operationType: value })}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Selecione o tipo de operação" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="nacional">Nacional</SelectItem>
                    <SelectItem value="transito">Trânsito</SelectItem>
                    <SelectItem value="combinado">Combinado</SelectItem>
                    <SelectItem value="LPG">LPG</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>

          {/* Cargo Parcels */}
          <div>
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-gray-900">Parcelas de Carga</h3>
              <Button type="button" onClick={addParcel} size="sm" className="bg-blue-600 hover:bg-blue-700">
                <Plus className="w-4 h-4 mr-1" />
                Adicionar Parcela
              </Button>
            </div>
            
            <div className="space-y-4">
              {parcels.map((parcel, index) => (
                <Card key={index} className="bg-gray-50">
                  <CardContent className="pt-4">
                    <div className="flex items-center justify-between mb-3">
                      <h4 className="font-medium text-gray-900">Parcela {index + 1}</h4>
                      {parcels.length > 1 && (
                        <Button
                          type="button"
                          onClick={() => removeParcel(index)}
                          size="sm"
                          variant="outline"
                          className="text-red-500 hover:text-red-700"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      )}
                    </div>
                    <div className="space-y-4">
                      {/* Product Information */}
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <Label>Produto *</Label>
                          <Input
                            placeholder="Ex: Gasolina, Diesel, Jet A1, LPG"
                            value={parcel.product}
                            onChange={(e) => updateParcel(index, "product", e.target.value)}
                            required
                          />
                        </div>
                        <div>
                          <Label>Densidade a 15°C in air *</Label>
                          <Input
                            type="number"
                            step="0.001"
                            placeholder="Introduza densidade real"
                            value={parcel.density15C}
                            onChange={(e) => updateParcel(index, "density15C", e.target.value)}
                            required
                            className="bg-yellow-50 border-yellow-300 focus:border-yellow-500"
                          />
                          <p className="text-xs text-gray-500 mt-1">⚠️ Introduza dados reais obtidos do laboratório</p>
                        </div>
                      </div>

                      {/* Volume Calculations with Formula Display */}
                      <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
                        <div className="flex items-center justify-between mb-3">
                          <h5 className="font-medium text-blue-900">Cálculos de Volume</h5>
                          <div className="text-xs text-blue-600 bg-blue-100 px-2 py-1 rounded">
                            Fórmula: MT = m³ × Densidade
                          </div>
                        </div>
                        
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div>
                            <Label className="text-blue-800">Volume em MT *</Label>
                            <Input
                              type="number"
                              step="0.001"
                              placeholder="Ex: 3500"
                              value={parcel.volumeMT}
                              onChange={(e) => updateParcel(index, "volumeMT", e.target.value)}
                              required
                              className="border-blue-300 focus:border-blue-500"
                            />
                            <p className="text-xs text-blue-600 mt-1">Inserir MT calculará m³ automaticamente</p>
                          </div>
                          <div>
                            <Label className="text-blue-800">Volume em m³ *</Label>
                            <Input
                              type="number"
                              step="0.001"
                              placeholder="Ex: 4516.129"
                              value={parcel.volumeM3}
                              onChange={(e) => updateParcel(index, "volumeM3", e.target.value)}
                              required
                              className="border-blue-300 focus:border-blue-500"
                            />
                            <p className="text-xs text-blue-600 mt-1">Inserir m³ calculará MT automaticamente</p>
                          </div>
                        </div>

                        {/* Calculation Result Display */}
                        {parcel.density15C && (parcel.volumeMT || parcel.volumeM3) && (
                          <div className="mt-3 p-3 bg-green-50 border border-green-200 rounded">
                            <div className="text-sm text-green-800">
                              <strong>Cálculo Ativo:</strong>
                              {parcel.volumeMT && parcel.volumeM3 && parcel.density15C && (
                                <span className="ml-2">
                                  {parcel.volumeM3} m³ × {parcel.density15C} = {parcel.volumeMT} MT
                                </span>
                              )}
                            </div>
                          </div>
                        )}
                      </div>

                      {/* Recipients Information */}
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <Label>Recebedor *</Label>
                          <Input
                            placeholder="Ex: Petromoc"
                            value={parcel.receiver}
                            onChange={(e) => updateParcel(index, "receiver", e.target.value)}
                            required
                          />
                        </div>
                        <div>
                          <Label>Dono da Parcela *</Label>
                          <Input
                            placeholder="Ex: Total E&P"
                            value={parcel.owner}
                            onChange={(e) => updateParcel(index, "owner", e.target.value)}
                            required
                          />
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
          
          <div className="flex justify-end space-x-4 pt-6 border-t border-gray-200">
            <Button type="button" onClick={onClose} variant="outline">
              Cancelar
            </Button>
            <Button 
              type="submit" 
              disabled={mutation.isPending}
              className="bg-blue-600 hover:bg-blue-700"
            >
              {mutation.isPending ? "Registrando..." : "Registrar Navio"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
