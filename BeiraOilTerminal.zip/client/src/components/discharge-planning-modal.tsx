import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { Ship, Clock, Anchor, Calendar, TrendingUp, AlertTriangle } from "lucide-react";
import { formatDate, formatTime } from "@/lib/utils";

interface DischargePlanningModalProps {
  isOpen: boolean;
  onClose: () => void;
}

interface ShipPlan {
  id: number;
  name: string;
  operationType: string;
  position: number;
  estimatedBerthingTime: string;
  estimatedCompletionTime: string;
  totalDuration: number;
  parcels: Array<{
    product: string;
    volumeMT: string;
    estimatedDuration: number;
  }>;
  priority: {
    level: string;
    reason: string;
    badge: string;
  };
}

interface DischargePlan {
  nextFiveShips: ShipPlan[];
  totalEstimatedDays: number;
  averageDischargeDays: number;
  recommendations: string[];
}

export function DischargePlanningModal({ isOpen, onClose }: DischargePlanningModalProps) {
  const [selectedTimeframe, setSelectedTimeframe] = useState<"5_days" | "10_days" | "full_queue">("5_days");

  const { data: dischargePlan, isLoading } = useQuery<DischargePlan>({
    queryKey: ["/api/discharge-planning/generate"],
    enabled: isOpen,
    refetchInterval: 30000,
  });

  const getPriorityBadge = (priority: { level: string; reason: string; badge: string }) => {
    const { level, reason, badge } = priority;
    
    if (level === "Nacional") {
      return <Badge className="bg-blue-500 text-white text-xs">🇲🇿 {badge}</Badge>;
    }
    if (level === "LPG") {
      return <Badge className="bg-orange-500 text-white text-xs">⛽ {badge}</Badge>;
    }
    if (level === "Trânsito") {
      return <Badge className="bg-green-500 text-white text-xs">{badge}</Badge>;
    }
    if (level === "Combinada") {
      return <Badge className="bg-purple-500 text-white text-xs">{badge}</Badge>;
    }
    
    return <Badge className="bg-gray-500 text-white text-xs">{badge}</Badge>;
  };

  const formatDuration = (hours: number) => {
    if (hours < 24) {
      return `${Math.round(hours)}h`;
    }
    const days = Math.floor(hours / 24);
    const remainingHours = Math.round(hours % 24);
    return remainingHours > 0 ? `${days}d ${remainingHours}h` : `${days}d`;
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-6xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-blue-600" />
            Planejamento Inteligente de Descarga
          </DialogTitle>
        </DialogHeader>

        {isLoading ? (
          <div className="flex items-center justify-center py-12">
            <div className="w-8 h-8 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mr-3"></div>
            <span className="text-gray-600">Calculando plano de descarga...</span>
          </div>
        ) : dischargePlan ? (
          <div className="space-y-6">
            {/* Summary Statistics */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-gray-600">Próximos 5 Navios</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-blue-600">{dischargePlan.nextFiveShips.length}</div>
                  <p className="text-xs text-gray-500">Com instruções de descarga</p>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-gray-600">Tempo Total Estimado</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-green-600">{dischargePlan.totalEstimatedDays.toFixed(1)} dias</div>
                  <p className="text-xs text-gray-500">Para completar fila</p>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-gray-600">Média por Navio</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-purple-600">{dischargePlan.averageDischargeDays.toFixed(1)} dias</div>
                  <p className="text-xs text-gray-500">Tempo médio de descarga</p>
                </CardContent>
              </Card>
            </div>

            {/* Priority Queue with Timeline */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Ship className="w-5 h-5 text-blue-600" />
                  Sequência Prioritária de Atracação
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {dischargePlan.nextFiveShips.map((ship, index) => (
                    <div key={ship.id} className="border rounded-lg p-4 bg-gradient-to-r from-gray-50 to-white">
                      <div className="flex items-start justify-between mb-3">
                        <div className="flex items-center gap-3">
                          <div className="bg-blue-100 text-blue-800 text-sm font-bold px-3 py-1 rounded-full">
                            #{ship.position}
                          </div>
                          <div>
                            <h4 className="font-semibold text-lg text-gray-900">{ship.name}</h4>
                            <div className="flex items-center gap-2 mt-1">
                              {getPriorityBadge(ship.priority)}
                              <span className="text-sm text-gray-600">{ship.priority.reason}</span>
                            </div>
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="text-sm text-gray-600 mb-1">Duração Estimada</div>
                          <div className="text-lg font-semibold text-green-600">
                            {formatDuration(ship.totalDuration)}
                          </div>
                        </div>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                        <div className="flex items-center gap-2 text-sm">
                          <Anchor className="w-4 h-4 text-blue-500" />
                          <span className="text-gray-600">Atracação:</span>
                          <span className="font-medium">
                            {new Date(ship.estimatedBerthingTime).toLocaleDateString('pt-BR', {
                              day: '2-digit',
                              month: '2-digit',
                              year: 'numeric',
                              timeZone: 'Africa/Maputo'
                            })} {new Date(ship.estimatedBerthingTime).toLocaleTimeString('pt-BR', {
                              hour: '2-digit',
                              minute: '2-digit',
                              timeZone: 'Africa/Maputo'
                            })}
                          </span>
                        </div>
                        <div className="flex items-center gap-2 text-sm">
                          <Calendar className="w-4 h-4 text-green-500" />
                          <span className="text-gray-600">Conclusão:</span>
                          <span className="font-medium">
                            {new Date(ship.estimatedCompletionTime).toLocaleDateString('pt-BR', {
                              day: '2-digit',
                              month: '2-digit',
                              year: 'numeric',
                              timeZone: 'Africa/Maputo'
                            })} {new Date(ship.estimatedCompletionTime).toLocaleTimeString('pt-BR', {
                              hour: '2-digit',
                              minute: '2-digit',
                              timeZone: 'Africa/Maputo'
                            })}
                          </span>
                        </div>
                      </div>

                      {/* Cargo Details */}
                      <div className="bg-gray-50 rounded-lg p-3">
                        <h5 className="text-sm font-medium text-gray-700 mb-2">Produtos para Descarga:</h5>
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2">
                          {ship.parcels.map((parcel, idx) => (
                            <div key={idx} className="bg-white rounded px-3 py-2 text-sm">
                              <div className="font-medium text-gray-800">{parcel.product}</div>
                              <div className="text-gray-600">{parcel.volumeMT} MT</div>
                              <div className="text-blue-600 text-xs">{formatDuration(parcel.estimatedDuration)}</div>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Recommendations */}
            {dischargePlan.recommendations.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <AlertTriangle className="w-5 h-5 text-yellow-600" />
                    Recomendações do Sistema
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    {dischargePlan.recommendations.map((recommendation, index) => (
                      <div key={index} className="flex items-start gap-2 p-3 bg-yellow-50 rounded-lg">
                        <div className="w-2 h-2 bg-yellow-500 rounded-full mt-2 flex-shrink-0"></div>
                        <p className="text-sm text-gray-700">{recommendation}</p>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Action Buttons */}
            <div className="flex justify-end gap-3">
              <Button variant="outline" onClick={onClose}>
                Fechar
              </Button>
              <Button 
                onClick={() => window.print()}
                className="bg-blue-600 hover:bg-blue-700"
              >
                Imprimir Plano
              </Button>
            </div>
          </div>
        ) : (
          <div className="text-center py-12">
            <Ship className="w-12 h-12 mx-auto mb-4 text-gray-300" />
            <p className="text-gray-500">Nenhum navio com instruções de descarga encontrado.</p>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}