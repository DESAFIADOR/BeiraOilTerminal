import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { X, Download, FileText, Ship, Calendar, Users, BarChart3 } from 'lucide-react';
import { useQuery } from '@tanstack/react-query';

interface ShipReportModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function ShipReportModal({ isOpen, onClose }: ShipReportModalProps) {
  const [isDownloading, setIsDownloading] = useState(false);

  // Fetch report data
  const { data: reportData, isLoading } = useQuery({
    queryKey: ['/api/reports/ships/data'],
    enabled: isOpen,
  });

  const downloadPDF = async () => {
    setIsDownloading(true);
    try {
      const response = await fetch('/api/reports/ships/pdf');
      if (!response.ok) throw new Error('Failed to download PDF');
      
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `ships-report-${new Date().toISOString().split('T')[0]}.pdf`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
    } catch (error) {
      console.error('Error downloading PDF:', error);
    } finally {
      setIsDownloading(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-6xl max-h-[90vh] overflow-hidden">
        <DialogHeader className="flex flex-row items-center justify-between space-y-0 pb-4">
          <DialogTitle className="flex items-center gap-2 text-xl font-bold text-blue-800">
            <FileText className="h-6 w-6" />
            Relatório de Navios - Terminal da Beira
          </DialogTitle>
          <div className="flex items-center gap-2">
            <Button
              onClick={downloadPDF}
              disabled={isDownloading}
              className="bg-blue-600 hover:bg-blue-700 text-white"
            >
              <Download className="h-4 w-4 mr-2" />
              {isDownloading ? 'Baixando...' : 'Download PDF'}
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={onClose}
              className="h-8 w-8 p-0"
            >
              <X className="h-4 w-4" />
            </Button>
          </div>
        </DialogHeader>

        <div className="overflow-y-auto">
          {isLoading ? (
            <div className="flex items-center justify-center p-8">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
              <p className="ml-3 text-gray-600">Carregando relatório...</p>
            </div>
          ) : reportData ? (
            <div className="space-y-6">
              {/* Summary Cards */}
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                  <div className="flex items-center gap-3">
                    <Ship className="h-8 w-8 text-blue-600" />
                    <div>
                      <p className="text-sm text-blue-600 font-medium">Total de Navios</p>
                      <p className="text-2xl font-bold text-blue-800">{reportData?.totalShips || 0}</p>
                    </div>
                  </div>
                </div>

                <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                  <div className="flex items-center gap-3">
                    <BarChart3 className="h-8 w-8 text-green-600" />
                    <div>
                      <p className="text-sm text-green-600 font-medium">Parcelas de Carga</p>
                      <p className="text-2xl font-bold text-green-800">{reportData?.totalParcels || 0}</p>
                    </div>
                  </div>
                </div>

                <div className="bg-purple-50 border border-purple-200 rounded-lg p-4">
                  <div className="flex items-center gap-3">
                    <Users className="h-8 w-8 text-purple-600" />
                    <div>
                      <p className="text-sm text-purple-600 font-medium">Receptores</p>
                      <p className="text-2xl font-bold text-purple-800">{reportData?.uniqueReceivers || 0}</p>
                    </div>
                  </div>
                </div>

                <div className="bg-orange-50 border border-orange-200 rounded-lg p-4">
                  <div className="flex items-center gap-3">
                    <Calendar className="h-8 w-8 text-orange-600" />
                    <div>
                      <p className="text-sm text-orange-600 font-medium">Volume Total</p>
                      <p className="text-2xl font-bold text-orange-800">{reportData?.totalVolume || '0 MT'}</p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Ships Detail Table */}
              <div className="bg-white border border-gray-200 rounded-lg overflow-hidden">
                <div className="bg-gray-50 px-6 py-4 border-b border-gray-200">
                  <h3 className="text-lg font-semibold text-gray-800">Detalhes dos Navios</h3>
                </div>
                
                <div className="overflow-x-auto">
                  <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Navio
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Contramarca
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Status
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Parcelas
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Volume Total
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Receptores
                        </th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      {reportData?.shipDetails?.map((ship: any, index: number) => (
                        <tr key={index} className="hover:bg-gray-50">
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="flex items-center">
                              <Ship className="h-5 w-5 text-blue-500 mr-3" />
                              <div>
                                <div className="text-sm font-medium text-gray-900">{ship.name}</div>
                              </div>
                            </div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                            {ship.countermark}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${
                              ship.status === 'at_berth' ? 'bg-green-100 text-green-800' :
                              ship.status === 'next_to_berth' ? 'bg-yellow-100 text-yellow-800' :
                              ship.status === 'at_bar' ? 'bg-blue-100 text-blue-800' :
                              ship.status === 'departed' ? 'bg-gray-100 text-gray-800' :
                              'bg-purple-100 text-purple-800'
                            }`}>
                              {ship.status === 'at_berth' ? 'No Cais' :
                               ship.status === 'next_to_berth' ? 'Próximo' :
                               ship.status === 'at_bar' ? 'Na Barra' :
                               ship.status === 'departed' ? 'Partiu' :
                               'Previsto'}
                            </span>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                            {ship.parcels}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                            {ship.totalVolume}
                          </td>
                          <td className="px-6 py-4 text-sm text-gray-900">
                            <div className="max-w-xs">
                              {ship.receivers.slice(0, 3).join(', ')}
                              {ship.receivers.length > 3 && ` +${ship.receivers.length - 3} mais`}
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Footer */}
              <div className="text-center text-sm text-gray-500 py-4 border-t border-gray-200">
                <p>Relatório gerado em {new Date().toLocaleDateString('pt-BR')} às {new Date().toLocaleTimeString('pt-BR')}</p>
                <p>Terminal da Beira - Sistema de Gestão de Navios</p>
              </div>
            </div>
          ) : (
            <div className="text-center p-8 text-gray-500">
              <FileText className="h-12 w-12 mx-auto mb-4 text-gray-400" />
              <p>Não foi possível carregar os dados do relatório</p>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}