import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Ship, Anchor, ArrowRight } from 'lucide-react';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { AdvancedBerthingModal } from './advanced-berthing-modal';

interface BerthingActionModalProps {
  isOpen: boolean;
  onClose: () => void;
  ships: any[];
}

export function BerthingActionModal({ isOpen, onClose, ships }: BerthingActionModalProps) {
  const [selectedShip, setSelectedShip] = useState<any>(null);
  const [showBerthingConfirmation, setShowBerthingConfirmation] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Filter ships that can be berthed (at bar with instructions OR next to berth)
  const availableShips = ships.filter((ship: any) => {
    return (ship.status === 'at_bar' && ship.hasDischargeInstructions === true) || 
           ship.status === 'next_to_berth';
  });

  const handleShipSelect = (ship: any) => {
    setSelectedShip(ship);
    setShowBerthingConfirmation(true);
  };

  if (showBerthingConfirmation && selectedShip) {
    return (
      <AdvancedBerthingModal
        isOpen={true}
        onClose={() => {
          setShowBerthingConfirmation(false);
          setSelectedShip(null);
          onClose();
        }}
        ship={selectedShip}
      />
    );
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-hidden flex flex-col">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Anchor className="w-5 h-5 text-blue-600" />
            Atracar Navio
          </DialogTitle>
        </DialogHeader>

        <div className="flex-1 overflow-y-auto">
          <div className="space-y-4">
            {/* Ships at bar with instructions */}
            {availableShips.filter(ship => ship.status === 'at_bar').length > 0 && (
              <div>
                <h3 className="text-lg font-semibold mb-3 flex items-center gap-2">
                  <Ship className="w-4 h-4" />
                  Navios na Barra (Com Instrução)
                </h3>
                <div className="grid gap-3">
                  {availableShips
                    .filter(ship => ship.status === 'at_bar')
                    .map((ship) => (
                      <Card 
                        key={ship.id} 
                        className="cursor-pointer transition-all hover:shadow-md hover:bg-blue-50"
                        onClick={() => handleShipSelect(ship)}
                      >
                        <CardContent className="p-4">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-3">
                              <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                                <Ship className="w-6 h-6 text-blue-600" />
                              </div>
                              <div>
                                <h4 className="font-semibold text-lg">{ship.name}</h4>
                                <p className="text-sm text-gray-600">Distintivo: {ship.countermark}</p>
                              </div>
                            </div>
                            <div className="flex flex-col gap-2">
                              <Badge className="bg-blue-100 text-blue-800">
                                {ship.operationType || 'N/A'}
                              </Badge>
                              <Badge variant="outline" className="bg-green-50 text-green-700">
                                Com Instrução
                              </Badge>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                </div>
              </div>
            )}

            {/* Ships next to berth */}
            {availableShips.filter(ship => ship.status === 'next_to_berth').length > 0 && (
              <div>
                <h3 className="text-lg font-semibold mb-3 flex items-center gap-2">
                  <Anchor className="w-4 h-4" />
                  Próximos a Atracar
                </h3>
                <div className="grid gap-3">
                  {availableShips
                    .filter(ship => ship.status === 'next_to_berth')
                    .map((ship) => (
                      <Card 
                        key={ship.id} 
                        className="cursor-pointer transition-all hover:shadow-md hover:bg-purple-50"
                        onClick={() => handleShipSelect(ship)}
                      >
                        <CardContent className="p-4">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-3">
                              <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center">
                                <Anchor className="w-6 h-6 text-purple-600" />
                              </div>
                              <div>
                                <h4 className="font-semibold text-lg">{ship.name}</h4>
                                <p className="text-sm text-gray-600">Distintivo: {ship.countermark}</p>
                              </div>
                            </div>
                            <div className="flex flex-col gap-2">
                              <Badge className="bg-purple-100 text-purple-800">
                                {ship.operationType || 'N/A'}
                              </Badge>
                              <Badge variant="outline" className="bg-purple-50 text-purple-700">
                                Próximo
                              </Badge>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                </div>
              </div>
            )}

            {availableShips.length === 0 && (
              <div className="text-center py-8">
                <Ship className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">
                  Nenhum navio disponível
                </h3>
                <p className="text-gray-600">
                  Não há navios prontos para atracação no momento.
                </p>
              </div>
            )}
          </div>
        </div>

        <div className="flex justify-end gap-3 pt-4 border-t border-gray-200">
          <Button variant="outline" onClick={onClose}>
            Cancelar
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}