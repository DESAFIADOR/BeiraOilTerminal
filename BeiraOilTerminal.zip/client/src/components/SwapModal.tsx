import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";

interface SwapModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function SwapModal({ isOpen, onClose }: SwapModalProps) {
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Operação SWAP</DialogTitle>
        </DialogHeader>
        <div className="p-4">
          <p>Componente de operação SWAP</p>
        </div>
      </DialogContent>
    </Dialog>
  );
}