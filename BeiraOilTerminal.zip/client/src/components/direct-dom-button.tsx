import React, { useEffect, useState } from 'react';
import { VirtualAssistant } from './virtual-assistant';

export function DirectDOMButton({ user }: { user?: any }) {
  const [isAssistantOpen, setIsAssistantOpen] = useState(false);

  useEffect(() => {
    const addButton = () => {
      // Remove existing button
      const existing = document.getElementById('direct-assistant-btn');
      if (existing) {
        existing.remove();
      }

      // Create new button
      const button = document.createElement('div');
      button.id = 'direct-assistant-btn';
      button.innerHTML = '🤖 AI';
      
      // Apply styles directly
      Object.assign(button.style, {
        position: 'fixed',
        bottom: '140px',
        right: '20px',
        width: '70px',
        height: '70px',
        backgroundColor: '#3b82f6',
        color: 'white',
        borderRadius: '50%',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        cursor: 'pointer',
        fontSize: '14px',
        fontWeight: 'bold',
        zIndex: '999999',
        boxShadow: '0 8px 25px rgba(0,0,0,0.3)',
        border: '2px solid white',
        transition: 'all 0.3s ease'
      });

      // Add click handler
      button.onclick = () => {
        console.log('Assistant button clicked!');
        setIsAssistantOpen(true);
      };

      // Add hover effects
      button.onmouseenter = () => {
        button.style.transform = 'scale(1.1)';
        button.style.backgroundColor = '#1d4ed8';
      };
      
      button.onmouseleave = () => {
        button.style.transform = 'scale(1)';
        button.style.backgroundColor = '#3b82f6';
      };

      // Append to body
      document.body.appendChild(button);
      console.log('Direct DOM assistant button added');
    };

    // Add button immediately and after a delay
    addButton();
    const timer = setTimeout(addButton, 2000);

    return () => {
      clearTimeout(timer);
      const button = document.getElementById('direct-assistant-btn');
      if (button) {
        button.remove();
      }
    };
  }, []);

  return (
    <>
      <VirtualAssistant
        user={user}
        isOpen={isAssistantOpen}
        onClose={() => setIsAssistantOpen(false)}
      />
    </>
  );
}