import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Anchor, Clock, Calendar, Ship } from 'lucide-react';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';

interface BerthingConfirmationModalProps {
  isOpen: boolean;
  onClose: () => void;
  ship: any;
}

export function BerthingConfirmationModal({ isOpen, onClose, ship }: BerthingConfirmationModalProps) {
  const [firstRopeDate, setFirstRopeDate] = useState('');
  const [firstRopeTime, setFirstRopeTime] = useState('');
  const [lastRopeDate, setLastRopeDate] = useState('');
  const [lastRopeTime, setLastRopeTime] = useState('');
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Debug logging
  console.log('BerthingConfirmationModal render:', { isOpen, ship: ship?.name });

  const confirmBerthingMutation = useMutation({
    mutationFn: async (berthingData: any) => {
      // Record berthing data first
      const berthingResponse = await apiRequest('/api/berthing-records', 'POST', berthingData);
      
      // Then automatically move ship to berth (at_berth status)
      await apiRequest(`/api/ships/${ship.id}`, 'PATCH', { status: 'at_berth' });
      
      return berthingResponse;
    },
    onSuccess: () => {
      toast({
        title: "Atracação Confirmada",
        description: `${ship.name} movido automaticamente para o Cais 12 após confirmação da última corda`,
      });
      queryClient.invalidateQueries({ queryKey: ['/api/ships'] });
      queryClient.invalidateQueries({ queryKey: ['/api/berthing-records'] });
      onClose();
      resetForm();
    },
    onError: (error: any) => {
      toast({
        title: "Erro na Atracação",
        description: error.message || "Erro ao confirmar atracação",
        variant: "destructive",
      });
    }
  });

  const resetForm = () => {
    setFirstRopeDate('');
    setFirstRopeTime('');
    setLastRopeDate('');
    setLastRopeTime('');
  };

  const formatDateTime = (date: string, time: string) => {
    if (!date || !time) return null;
    return new Date(`${date}T${time}:00`).toISOString();
  };

  const handleConfirmBerthing = () => {
    if (!firstRopeDate || !firstRopeTime || !lastRopeDate || !lastRopeTime) {
      toast({
        title: "Dados Incompletos",
        description: "Por favor, preencha todas as datas e horários",
        variant: "destructive",
      });
      return;
    }

    const berthingData = {
      shipId: ship.id,
      firstRopeTime: formatDateTime(firstRopeDate, firstRopeTime),
      lastRopeTime: formatDateTime(lastRopeDate, lastRopeTime),
      berthNumber: '12',
      operatorId: 1, // Will be updated with actual user ID
      notes: `Atracação confirmada - ${ship.name}`
    };

    confirmBerthingMutation.mutate(berthingData);
  };

  const formatShipInfo = () => {
    const totalCargo = ship.parcels?.reduce((sum: number, p: any) => sum + (p.volumeMT || 0), 0) || 0;
    return {
      name: ship.name,
      countermark: ship.countermark,
      operationType: ship.operationType || 'Trânsito',
      totalCargo: totalCargo.toLocaleString(),
      arrivalDate: ship.arrivalDate ? new Date(ship.arrivalDate).toLocaleDateString('pt-PT', {
        day: '2-digit',
        month: '2-digit',
        year: 'numeric',
        timeZone: 'Africa/Maputo'
      }) : 'N/A'
    };
  };

  const shipInfo = formatShipInfo();

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Anchor className="w-5 h-5 text-purple-600" />
            Confirmação de Atracação - Cais 12
          </DialogTitle>
          <DialogDescription>
            Registre os horários de primeira e última corda. O navio será automaticamente movido para o cais após confirmação.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6">
          {/* Ship Information Card */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-lg">
                <Ship className="w-5 h-5 text-blue-600" />
                Informações do Navio
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <span className="text-gray-500">Nome:</span>
                  <span className="ml-2 font-medium">{shipInfo.name}</span>
                </div>
                <div>
                  <span className="text-gray-500">Contramarcha:</span>
                  <span className="ml-2 font-medium">{shipInfo.countermark}</span>
                </div>
                <div>
                  <span className="text-gray-500">Tipo de Operação:</span>
                  <span className="ml-2 font-medium">{shipInfo.operationType}</span>
                </div>
                <div>
                  <span className="text-gray-500">Carga Total:</span>
                  <span className="ml-2 font-medium">{shipInfo.totalCargo} MT</span>
                </div>
                <div>
                  <span className="text-gray-500">Chegada na Barra:</span>
                  <span className="ml-2 font-medium">{shipInfo.arrivalDate}</span>
                </div>
                <div>
                  <span className="text-gray-500">Status:</span>
                  <span className="ml-2 font-medium text-purple-600">Próximo a Atracar</span>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Berthing Times Form */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-lg">
                <Clock className="w-5 h-5 text-green-600" />
                Horários de Atracação
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* First Rope */}
              <div className="space-y-2">
                <Label className="text-base font-medium text-green-700">Primeira Corda</Label>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <Label htmlFor="firstRopeDate" className="text-sm">Data</Label>
                    <Input
                      id="firstRopeDate"
                      type="date"
                      value={firstRopeDate}
                      onChange={(e) => setFirstRopeDate(e.target.value)}
                      className="mt-1"
                    />
                  </div>
                  <div>
                    <Label htmlFor="firstRopeTime" className="text-sm">Hora</Label>
                    <Input
                      id="firstRopeTime"
                      type="time"
                      value={firstRopeTime}
                      onChange={(e) => setFirstRopeTime(e.target.value)}
                      className="mt-1"
                    />
                  </div>
                </div>
              </div>

              {/* Last Rope */}
              <div className="space-y-2">
                <Label className="text-base font-medium text-blue-700">Última Corda</Label>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <Label htmlFor="lastRopeDate" className="text-sm">Data</Label>
                    <Input
                      id="lastRopeDate"
                      type="date"
                      value={lastRopeDate}
                      onChange={(e) => setLastRopeDate(e.target.value)}
                      className="mt-1"
                    />
                  </div>
                  <div>
                    <Label htmlFor="lastRopeTime" className="text-sm">Hora</Label>
                    <Input
                      id="lastRopeTime"
                      type="time"
                      value={lastRopeTime}
                      onChange={(e) => setLastRopeTime(e.target.value)}
                      className="mt-1"
                    />
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Action Buttons */}
          <div className="flex gap-3 pt-4 border-t">
            <Button
              onClick={handleConfirmBerthing}
              disabled={confirmBerthingMutation.isPending}
              className="flex-1 bg-purple-600 hover:bg-purple-700"
            >
              {confirmBerthingMutation.isPending ? (
                <>
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
                  Confirmando...
                </>
              ) : (
                <>
                  <Anchor className="w-4 h-4 mr-2" />
                  Confirmar Atracação
                </>
              )}
            </Button>
            <Button
              onClick={() => {
                resetForm();
                onClose();
              }}
              variant="outline"
              className="px-8"
            >
              Cancelar
            </Button>
          </div>

          {/* Automatic Movement Note */}
          <div className="bg-green-50 border border-green-200 rounded-lg p-4">
            <div className="flex items-start gap-2">
              <Anchor className="w-5 h-5 text-green-600 mt-0.5" />
              <div>
                <h4 className="font-medium text-green-800">Movimento Automático</h4>
                <p className="text-sm text-green-700 mt-1">
                  Após confirmar a última corda, o navio será automaticamente movido para o Cais 12.
                  Os dados serão integrados ao Ship Report com horários de chegada na barra e informações do piloto.
                </p>
              </div>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}