import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { X } from "lucide-react";

interface ShipPredictionModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function ShipPredictionModal({ isOpen, onClose }: ShipPredictionModalProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const [formData, setFormData] = useState({
    shipName: "",
    voyNumber: "",
    arrivalDraft: "",
    imoNumber: "",
    portOfRegistry: "",
    summerDwt: "",
    registeredGrt: "",
    produto: "",
    quantidadeLastPort: "",
    portOfLoading: "",
    arrivalNotice: null as File | null
  });

  const createPredictionMutation = useMutation({
    mutationFn: async (data: any) => {
      const formDataToSend = new FormData();
      Object.keys(data).forEach(key => {
        if (key === 'arrivalNotice' && data[key]) {
          formDataToSend.append(key, data[key]);
        } else if (key !== 'arrivalNotice') {
          formDataToSend.append(key, data[key]);
        }
      });
      
      return await apiRequest('/api/agents/predictions', {
        method: 'POST',
        body: formDataToSend
      });
    },
    onSuccess: () => {
      toast({
        title: "Sucesso",
        description: "Previsão de chegada registrada com sucesso!",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/agents/predictions'] });
      onClose();
      setFormData({
        shipName: "",
        voyNumber: "",
        arrivalDraft: "",
        imoNumber: "",
        portOfRegistry: "",
        summerDwt: "",
        registeredGrt: "",
        produto: "",
        quantidadeLastPort: "",
        portOfLoading: "",
        arrivalNotice: null
      });
    },
    onError: (error) => {
      toast({
        title: "Erro",
        description: "Falha ao registrar previsão de chegada.",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    createPredictionMutation.mutate(formData);
  };

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0] || null;
    setFormData(prev => ({ ...prev, arrivalNotice: file }));
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center justify-between">
            Nova Previsão de Chegada
            <Button
              variant="ghost"
              size="sm"
              onClick={onClose}
              className="h-6 w-6 p-0"
            >
              <X className="h-4 w-4" />
            </Button>
          </DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="shipName">Nome do Navio</Label>
              <Input
                id="shipName"
                value={formData.shipName}
                onChange={(e) => handleInputChange('shipName', e.target.value)}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="voyNumber">Número da Viagem</Label>
              <Input
                id="voyNumber"
                value={formData.voyNumber}
                onChange={(e) => handleInputChange('voyNumber', e.target.value)}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="arrivalDraft">Calado de Chegada (m)</Label>
              <Input
                id="arrivalDraft"
                type="number"
                step="0.1"
                value={formData.arrivalDraft}
                onChange={(e) => handleInputChange('arrivalDraft', e.target.value)}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="imoNumber">Número IMO</Label>
              <Input
                id="imoNumber"
                value={formData.imoNumber}
                onChange={(e) => handleInputChange('imoNumber', e.target.value)}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="portOfRegistry">Porto de Registo</Label>
              <Input
                id="portOfRegistry"
                value={formData.portOfRegistry}
                onChange={(e) => handleInputChange('portOfRegistry', e.target.value)}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="summerDwt">Summer DWT (MT)</Label>
              <Input
                id="summerDwt"
                type="number"
                value={formData.summerDwt}
                onChange={(e) => handleInputChange('summerDwt', e.target.value)}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="registeredGrt">GRT Registrado</Label>
              <Input
                id="registeredGrt"
                type="number"
                value={formData.registeredGrt}
                onChange={(e) => handleInputChange('registeredGrt', e.target.value)}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="produto">Produto</Label>
              <Select onValueChange={(value) => handleInputChange('produto', value)}>
                <SelectTrigger>
                  <SelectValue placeholder="Selecione o produto" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Gasolina">Gasolina</SelectItem>
                  <SelectItem value="Diesel">Diesel</SelectItem>
                  <SelectItem value="Jet A1">Jet A1</SelectItem>
                  <SelectItem value="LPG">LPG</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="quantidadeLastPort">Quantidade Last Port (MT)</Label>
              <Input
                id="quantidadeLastPort"
                type="number"
                value={formData.quantidadeLastPort}
                onChange={(e) => handleInputChange('quantidadeLastPort', e.target.value)}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="portOfLoading">Porto de Carregamento</Label>
              <Input
                id="portOfLoading"
                value={formData.portOfLoading}
                onChange={(e) => handleInputChange('portOfLoading', e.target.value)}
                required
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="arrivalNotice">Anexo - Aviso de Chegada</Label>
            <Input
              id="arrivalNotice"
              type="file"
              accept=".pdf,.doc,.docx,.jpg,.jpeg,.png"
              onChange={handleFileChange}
              className="cursor-pointer"
            />
          </div>

          <div className="flex justify-end space-x-2">
            <Button type="button" variant="outline" onClick={onClose}>
              Cancelar
            </Button>
            <Button 
              type="submit" 
              disabled={createPredictionMutation.isPending}
            >
              {createPredictionMutation.isPending ? "Registrando..." : "Registrar Previsão"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}