import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Trash2, Plus, Edit, Save } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

interface CargoParcel {
  parcelNumber: string;
  volume: string;
  receiver: string;
  owner: string;
  status: "pending" | "loading" | "completed";
}

interface EditShipFormData {
  name: string;
  countermark: string;
  draft: string;
  shipAgent: string;
  cargoAgent: string;
  cargoType: string;
  operationType: "nacional" | "transito" | "combinado";
  arrivalDateTime: string;
  status: "expected" | "at_bar" | "next_to_berth" | "at_berth";
  parcels: CargoParcel[];
}

const editShipSchema = z.object({
  name: z.string().min(1, "Nome do navio é obrigatório"),
  countermark: z.string().min(1, "Contra marca é obrigatória"),
  draft: z.string().min(1, "Calado é obrigatório"),
  shipAgent: z.string().min(1, "Agente do navio é obrigatório"),
  cargoAgent: z.string().min(1, "Agente da carga é obrigatório"),
  cargoType: z.string().min(1, "Tipo de carga é obrigatório"),
  operationType: z.enum(["nacional", "transito", "combinado"]),
  arrivalDateTime: z.string().min(1, "Data de chegada é obrigatória"),
  status: z.enum(["expected", "at_bar", "next_to_berth", "at_berth"]),
  parcels: z.array(z.object({
    parcelNumber: z.string().min(1, "Número da parcela é obrigatório"),
    volume: z.string().min(1, "Volume é obrigatório"),
    receiver: z.string().min(1, "Recebedor é obrigatório"),
    owner: z.string().min(1, "Dono da parcela é obrigatório"),
    status: z.enum(["pending", "loading", "completed"]),
  })).min(1, "Pelo menos uma parcela é obrigatória"),
});

interface ShipEditFormProps {
  ship: any;
  onSuccess?: () => void;
}

export function ShipEditForm({ ship, onSuccess }: ShipEditFormProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const [parcels, setParcels] = useState<CargoParcel[]>(
    ship.parcels?.map((parcel: any) => ({
      parcelNumber: parcel.parcelNumber || "",
      volume: parcel.volume || "",
      receiver: parcel.receiver || "",
      owner: parcel.owner || "",
      status: (parcel.status as "pending" | "loading" | "completed") || "pending",
    })) || [{ parcelNumber: "", volume: "", receiver: "", owner: "", status: "pending" }]
  );

  const editForm = useForm<EditShipFormData>({
    resolver: zodResolver(editShipSchema),
    defaultValues: {
      name: ship.name || "",
      countermark: ship.countermark || "",
      draft: ship.draft || "",
      shipAgent: ship.shipAgent || "",
      cargoAgent: ship.cargoAgent || "",
      cargoType: ship.cargoType || "",
      operationType: (ship.operationType as "nacional" | "transito" | "combinado") || "nacional",
      arrivalDateTime: ship.arrivalDateTime ? 
        new Date(ship.arrivalDateTime).toISOString().slice(0, 16) : "",
      status: ship.status as "expected" | "at_bar" | "next_to_berth" | "at_berth",
      parcels: parcels,
    },
  });

  const updateShipMutation = useMutation({
    mutationFn: async (data: EditShipFormData) => {
      const response = await apiRequest(`/api/ships/${ship.id}`, 'PUT', {
        ...data,
        arrivalDateTime: new Date(data.arrivalDateTime).toISOString(),
        parcels: parcels
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/ships'] });
      queryClient.invalidateQueries({ queryKey: ['/api/ships', ship.id] });
      toast({
        title: "Sucesso!",
        description: "Informações do navio atualizadas com sucesso.",
      });
      // NÃO chama onSuccess para evitar fechar o modal automaticamente
    },
    onError: (error: any) => {
      toast({
        title: "Erro",
        description: error.message || "Erro ao atualizar informações do navio.",
        variant: "destructive",
      });
    },
  });

  const addParcel = () => {
    const newParcel = { parcelNumber: "", volume: "", receiver: "", owner: "", status: "pending" as const };
    setParcels([...parcels, newParcel]);
    editForm.setValue("parcels", [...parcels, newParcel]);
  };

  const removeParcel = (index: number) => {
    const updatedParcels = parcels.filter((_, i) => i !== index);
    setParcels(updatedParcels);
    editForm.setValue("parcels", updatedParcels);
  };

  const updateParcel = (index: number, field: keyof CargoParcel, value: string) => {
    const updatedParcels = [...parcels];
    updatedParcels[index] = { ...updatedParcels[index], [field]: value };
    setParcels(updatedParcels);
    editForm.setValue("parcels", updatedParcels);
  };

  const isEditingDisabled = ship.status === 'departed';

  return (
    <div className="space-y-6">
      {isEditingDisabled && (
        <div className="bg-red-50 border border-red-200 rounded-lg p-4">
          <p className="text-red-700 text-sm">
            Edição não permitida. Este navio já foi desatracado.
          </p>
        </div>
      )}

      <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
        <div className="flex items-center">
          <Edit className="w-5 h-5 text-yellow-600 mr-2" />
          <h3 className="font-semibold text-yellow-800">Edição de Informações do Navio</h3>
        </div>
        <p className="text-sm text-yellow-700 mt-1">
          Esta funcionalidade permite editar todas as informações do navio. 
          Disponível apenas para operadores e navios não desatracados.
        </p>
      </div>

      <Form {...editForm}>
        <form onSubmit={editForm.handleSubmit((data) => updateShipMutation.mutate(data))} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <FormField
              control={editForm.control}
              name="name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Nome do Navio</FormLabel>
                  <FormControl>
                    <Input placeholder="Ex: HANSA OSLO" {...field} disabled={isEditingDisabled} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={editForm.control}
              name="countermark"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Contra Marca</FormLabel>
                  <FormControl>
                    <Input placeholder="Ex: 158-25" {...field} disabled={isEditingDisabled} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={editForm.control}
              name="draft"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Calado (metros)</FormLabel>
                  <FormControl>
                    <Input placeholder="Ex: 7.5" {...field} disabled={isEditingDisabled} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={editForm.control}
              name="status"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Status do Navio</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value} disabled={isEditingDisabled}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Selecione o status" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="expected">Esperado</SelectItem>
                      <SelectItem value="at_bar">Na Barra</SelectItem>
                      <SelectItem value="next_to_berth">Próximo do Cais</SelectItem>
                      <SelectItem value="at_berth">No Cais</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={editForm.control}
              name="cargoType"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Tipo de Carga</FormLabel>
                  <FormControl>
                    <Input placeholder="Ex: Crude Oil" {...field} disabled={isEditingDisabled} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={editForm.control}
              name="operationType"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Tipo de Operação</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value} disabled={isEditingDisabled}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Selecione o tipo de operação" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="nacional">Nacional</SelectItem>
                      <SelectItem value="transito">Trânsito</SelectItem>
                      <SelectItem value="combinado">Combinado</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={editForm.control}
              name="arrivalDateTime"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Data e Hora de Chegada</FormLabel>
                  <FormControl>
                    <Input type="datetime-local" {...field} disabled={isEditingDisabled} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={editForm.control}
              name="shipAgent"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Agente do Navio</FormLabel>
                  <FormControl>
                    <Input placeholder="Ex: GRINDROD" {...field} disabled={isEditingDisabled} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={editForm.control}
              name="cargoAgent"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Agente da Carga</FormLabel>
                  <FormControl>
                    <Input placeholder="Ex: PETROMOC" {...field} disabled={isEditingDisabled} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>

          {/* Parcelas de Carga */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <span>Parcelas de Carga</span>
                {!isEditingDisabled && (
                  <Button type="button" onClick={addParcel} size="sm" variant="outline">
                    <Plus className="w-4 h-4 mr-2" />
                    Adicionar Parcela
                  </Button>
                )}
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {parcels.map((parcel, index) => (
                <Card key={index} className="p-4">
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div>
                      <label className="text-sm font-medium">Número da Parcela</label>
                      <Input
                        value={parcel.parcelNumber}
                        onChange={(e) => updateParcel(index, "parcelNumber", e.target.value)}
                        placeholder="Ex: 001"
                        disabled={isEditingDisabled}
                      />
                    </div>
                    <div>
                      <label className="text-sm font-medium">Volume (MT)</label>
                      <Input
                        value={parcel.volume}
                        onChange={(e) => updateParcel(index, "volume", e.target.value)}
                        placeholder="Ex: 1500"
                        disabled={isEditingDisabled}
                      />
                    </div>
                    <div>
                      <label className="text-sm font-medium">Recebedor</label>
                      <Input
                        value={parcel.receiver}
                        onChange={(e) => updateParcel(index, "receiver", e.target.value)}
                        placeholder="Ex: PETROMOC"
                        disabled={isEditingDisabled}
                      />
                    </div>
                    <div>
                      <label className="text-sm font-medium">Dono da Parcela</label>
                      <Input
                        value={parcel.owner}
                        onChange={(e) => updateParcel(index, "owner", e.target.value)}
                        placeholder="Ex: PETROMOC"
                        disabled={isEditingDisabled}
                      />
                    </div>
                    <div>
                      <label className="text-sm font-medium">Status da Parcela</label>
                      <Select
                        value={parcel.status}
                        onValueChange={(value: "pending" | "loading" | "completed") => 
                          updateParcel(index, "status", value)
                        }
                        disabled={isEditingDisabled}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="pending">Aguardando Descarga</SelectItem>
                          <SelectItem value="loading">Em Descarga</SelectItem>
                          <SelectItem value="completed">Descarga Concluída</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="flex items-end">
                      {!isEditingDisabled && parcels.length > 1 && (
                        <Button
                          type="button"
                          onClick={() => removeParcel(index)}
                          variant="destructive"
                          size="sm"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      )}
                    </div>
                  </div>
                </Card>
              ))}
            </CardContent>
          </Card>

          {!isEditingDisabled && (
            <div className="flex justify-end space-x-4">
              <Button
                type="submit"
                disabled={updateShipMutation.isPending}
                className="flex items-center gap-2"
              >
                <Save className="w-4 h-4" />
                {updateShipMutation.isPending ? "Salvando..." : "Salvar Alterações"}
              </Button>
            </div>
          )}
        </form>
      </Form>
    </div>
  );
}