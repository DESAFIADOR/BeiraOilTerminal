import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Ship, Anchor, ArrowRight } from 'lucide-react';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { AdvancedBerthingModal } from './advanced-berthing-modal';

interface ShipSelectionModalProps {
  isOpen: boolean;
  onClose: () => void;
  ships: any[];
}

export function ShipSelectionModal({ isOpen, onClose, ships }: ShipSelectionModalProps) {
  const [selectedShip, setSelectedShip] = useState<any>(null);
  const [showBerthingConfirmation, setShowBerthingConfirmation] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Filter ships that can be berthed (at bar with instructions OR next to berth)
  const availableShips = ships.filter((ship: any) => {
    const canBerth = (ship.status === 'at_bar' && ship.hasDischargeInstructions === true) || 
                     ship.status === 'next_to_berth';
    return canBerth;
  });

  const moveToNextMutation = useMutation({
    mutationFn: async (shipId: number) => {
      return await apiRequest(`/api/ships/${shipId}`, 'PATCH', { status: 'next_to_berth' });
    },
    onSuccess: () => {
      toast({
        title: "Navio Movido",
        description: "Navio movido para próximo a atracar com sucesso",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/ships'] });
      onClose();
      setSelectedShip(null);
    },
    onError: (error: any) => {
      toast({
        title: "Erro",
        description: error.message || "Erro ao mover navio",
        variant: "destructive",
      });
    }
  });

  const getOperationTypeColor = (type: string) => {
    switch (type) {
      case 'Nacional': return 'bg-blue-100 text-blue-800';
      case 'Trânsito': return 'bg-purple-100 text-purple-800';
      case 'Combinado': return 'bg-green-100 text-green-800';
      case 'LPG': return 'bg-orange-100 text-orange-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('pt-PT', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      timeZone: 'Africa/Maputo'
    });
  };

  const handleShipSelect = (ship: any) => {
    setSelectedShip(ship);
    if (ship.status === 'next_to_berth') {
      setShowBerthingConfirmation(true);
    }
  };

  const handleMoveToNext = () => {
    if (selectedShip) {
      moveToNextMutation.mutate(selectedShip.id);
    }
  };

  if (showBerthingConfirmation && selectedShip) {
    return (
      <AdvancedBerthingModal
        isOpen={true}
        onClose={() => {
          setShowBerthingConfirmation(false);
          setSelectedShip(null);
          onClose();
        }}
        ship={selectedShip}
      />
    );
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-hidden flex flex-col">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Ship className="w-5 h-5 text-blue-600" />
            Selecionar Navio para Atracação
          </DialogTitle>
          <DialogDescription>
            Selecione um navio da lista abaixo para proceder com a atracação
          </DialogDescription>
        </DialogHeader>

        <div className="flex-1 overflow-y-auto">
          <div className="space-y-4">
            {/* Ships at bar with instructions */}
            {availableShips.filter(ship => ship.status === 'at_bar').length > 0 && (
              <div>
                <h3 className="text-lg font-semibold mb-3 flex items-center gap-2">
                  <Ship className="w-4 h-4" />
                  Navios na Barra (Com Instrução)
                </h3>
                <div className="grid gap-3">
                  {availableShips
                    .filter(ship => ship.status === 'at_bar')
                    .map((ship) => (
                      <Card 
                        key={ship.id} 
                        className={`cursor-pointer transition-all hover:shadow-md ${
                          selectedShip?.id === ship.id ? 'ring-2 ring-blue-500 bg-blue-50' : ''
                        }`}
                        onClick={() => handleShipSelect(ship)}
                      >
                        <CardContent className="p-4">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-3">
                              <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                                <Ship className="w-6 h-6 text-blue-600" />
                              </div>
                              <div>
                                <h4 className="font-semibold text-lg">{ship.name}</h4>
                                <p className="text-sm text-gray-600">Distintivo: {ship.countermark}</p>
                                <p className="text-sm text-gray-600">
                                  Chegada: {formatDate(ship.expectedArrival)}
                                </p>
                              </div>
                            </div>
                            <div className="flex flex-col gap-2">
                              <Badge className={getOperationTypeColor(ship.operationType)}>
                                {ship.operationType}
                              </Badge>
                              <Badge variant="outline" className="bg-green-50 text-green-700">
                                Com Instrução
                              </Badge>
                            </div>
                          </div>
                          {selectedShip?.id === ship.id && (
                            <div className="mt-4 pt-4 border-t border-gray-200">
                              <div className="flex items-center justify-between">
                                <span className="text-sm text-gray-600">
                                  Ação: Mover para próximo a atracar
                                </span>
                                <Button 
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    handleMoveToNext();
                                  }}
                                  className="bg-blue-600 hover:bg-blue-700"
                                  disabled={moveToNextMutation.isPending}
                                >
                                  <ArrowRight className="w-4 h-4 mr-2" />
                                  Mover
                                </Button>
                              </div>
                            </div>
                          )}
                        </CardContent>
                      </Card>
                    ))}
                </div>
              </div>
            )}

            {/* Ships next to berth */}
            {availableShips.filter(ship => ship.status === 'next_to_berth').length > 0 && (
              <div>
                <h3 className="text-lg font-semibold mb-3 flex items-center gap-2">
                  <Anchor className="w-4 h-4" />
                  Próximos 5 Navios a Atracar
                </h3>
                <div className="grid gap-3">
                  {availableShips
                    .filter(ship => ship.status === 'next_to_berth')
                    .map((ship) => (
                      <Card 
                        key={ship.id} 
                        className={`cursor-pointer transition-all hover:shadow-md ${
                          selectedShip?.id === ship.id ? 'ring-2 ring-purple-500 bg-purple-50' : ''
                        }`}
                        onClick={() => handleShipSelect(ship)}
                      >
                        <CardContent className="p-4">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-3">
                              <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center">
                                <Anchor className="w-6 h-6 text-purple-600" />
                              </div>
                              <div>
                                <h4 className="font-semibold text-lg">{ship.name}</h4>
                                <p className="text-sm text-gray-600">Distintivo: {ship.countermark}</p>
                                <p className="text-sm text-gray-600">
                                  Chegada: {formatDate(ship.expectedArrival)}
                                </p>
                              </div>
                            </div>
                            <div className="flex flex-col gap-2">
                              <Badge className={getOperationTypeColor(ship.operationType)}>
                                {ship.operationType}
                              </Badge>
                              <Badge variant="outline" className="bg-purple-50 text-purple-700">
                                Próximo
                              </Badge>
                            </div>
                          </div>
                          {selectedShip?.id === ship.id && (
                            <div className="mt-4 pt-4 border-t border-gray-200">
                              <div className="flex items-center justify-between">
                                <span className="text-sm text-gray-600">
                                  Ação: Registrar atracação
                                </span>
                                <Button 
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    setShowBerthingConfirmation(true);
                                  }}
                                  className="bg-purple-600 hover:bg-purple-700"
                                >
                                  <Anchor className="w-4 h-4 mr-2" />
                                  Atracar
                                </Button>
                              </div>
                            </div>
                          )}
                        </CardContent>
                      </Card>
                    ))}
                </div>
              </div>
            )}

            {availableShips.length === 0 && (
              <div className="text-center py-8">
                <Ship className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">
                  Nenhum navio disponível
                </h3>
                <p className="text-gray-600">
                  Não há navios prontos para atracação no momento.
                </p>
              </div>
            )}
          </div>
        </div>

        <div className="flex justify-end gap-3 pt-4 border-t border-gray-200">
          <Button variant="outline" onClick={onClose}>
            Cancelar
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}