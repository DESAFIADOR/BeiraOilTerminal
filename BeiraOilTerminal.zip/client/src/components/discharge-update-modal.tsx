import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { isUnauthorizedError } from "@/lib/authUtils";

interface DischargeUpdateModalProps {
  isOpen: boolean;
  shipId: number;
  onClose: () => void;
  onSuccess: () => void;
}

export function DischargeUpdateModal({ isOpen, shipId, onClose, onSuccess }: DischargeUpdateModalProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const [discharged, setDischarged] = useState("");
  const [remaining, setRemaining] = useState("");

  const { data: ship, isLoading } = useQuery({
    queryKey: [`/api/ships/${shipId}`],
    enabled: isOpen && !!shipId,
  });

  const mutation = useMutation({
    mutationFn: async (data: { discharged: string; remaining: string }) => {
      await apiRequest(`/api/ships/${shipId}/discharge`, "POST", data);
    },
    onSuccess: () => {
      toast({
        title: "Sucesso",
        description: "Progresso de descarga atualizado com sucesso!",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/ships"] });
      queryClient.invalidateQueries({ queryKey: [`/api/ships/${shipId}`] });
      onSuccess();
      setDischarged("");
      setRemaining("");
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Erro",
        description: "Falha ao atualizar descarga. Tente novamente.",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!discharged || !remaining) {
      toast({
        title: "Erro",
        description: "Preencha todos os campos obrigatórios.",
        variant: "destructive",
      });
      return;
    }

    mutation.mutate({ discharged, remaining });
  };

  if (isLoading) {
    return (
      <Dialog open={isOpen} onOpenChange={onClose}>
        <DialogContent className="max-w-2xl">
          <div className="text-center py-8">
            <div className="w-8 h-8 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
            <p className="text-gray-600">Carregando dados do navio...</p>
          </div>
        </DialogContent>
      </Dialog>
    );
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle className="text-xl font-bold text-teal-600">
            Atualizar Descarga
          </DialogTitle>
          <DialogDescription>
            Atualize o progresso da descarga com as quantidades descarregadas e remanescentes.
          </DialogDescription>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <h3 className="text-lg font-semibold text-gray-900 mb-2">
              {(ship as any)?.name || "Navio"}
            </h3>
            <p className="text-sm text-gray-600">Atualização horária de descarga</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <Label htmlFor="discharged">Quantidade Descarregada (m³) *</Label>
              <Input
                id="discharged"
                type="number"
                step="0.01"
                placeholder="Ex: 7200"
                value={discharged}
                onChange={(e) => setDischarged(e.target.value)}
                required
              />
            </div>
            
            <div>
              <Label htmlFor="remaining">Quantidade Remanescente (m³) *</Label>
              <Input
                id="remaining"
                type="number"
                step="0.01"
                placeholder="Ex: 2800"
                value={remaining}
                onChange={(e) => setRemaining(e.target.value)}
                required
              />
            </div>
          </div>
          
          <div className="p-4 bg-blue-50 rounded-lg">
            <h4 className="font-medium text-blue-900 mb-2">Cálculos Automáticos</h4>
            <div className="text-sm text-blue-800 space-y-1">
              <p>• Percentual concluído será calculado automaticamente</p>
              <p>• Previsão de término baseada no fluxo horário atual</p>
              <p>• Horas restantes estimadas pelo sistema</p>
            </div>
          </div>
          
          <div className="flex justify-end space-x-4 pt-6 border-t border-gray-200">
            <Button type="button" onClick={onClose} variant="outline">
              Cancelar
            </Button>
            <Button 
              type="submit" 
              disabled={mutation.isPending}
              className="bg-teal-600 hover:bg-teal-700"
            >
              {mutation.isPending ? "Atualizando..." : "Atualizar Descarga"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
