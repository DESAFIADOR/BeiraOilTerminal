import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogTrigger } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Waves, TrendingUp, TrendingDown, Clock, Calendar, AlertTriangle, Info } from "lucide-react";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";

interface TideData {
  currentTide: number;
  tideTime: Date;
  nextHighTide: {
    height: number;
    time: Date;
  };
  nextLowTide: {
    height: number;
    time: Date;
  };
  tideStatus: 'rising' | 'falling';
  prediction24h: Array<{
    time: Date;
    height: number;
    type: 'high' | 'low';
  }>;
}

interface TidePrediction {
  time: Date;
  height: number;
  type?: 'high' | 'low';
}

export function TideInfoCard() {
  const [showDetails, setShowDetails] = useState(false);

  // Fetch current tide data
  const { data: tideData, isLoading: tideLoading } = useQuery<TideData>({
    queryKey: ['/api/tides/current'],
    refetchInterval: 5 * 60 * 1000, // Update every 5 minutes
    staleTime: 3 * 60 * 1000, // Consider data stale after 3 minutes
  });

  // Fetch 3-day predictions
  const { data: predictions = [], isLoading: predictionsLoading } = useQuery<TidePrediction[]>({
    queryKey: ['/api/tides/predictions'],
    staleTime: 30 * 60 * 1000, // Predictions are valid for 30 minutes
  });

  const getTideStatusIcon = (status: 'rising' | 'falling') => {
    return status === 'rising' ? (
      <TrendingUp className="w-4 h-4 text-green-600" />
    ) : (
      <TrendingDown className="w-4 h-4 text-blue-600" />
    );
  };

  const getTideStatusText = (status: 'rising' | 'falling') => {
    return status === 'rising' ? 'Enchente' : 'Vazante';
  };

  const getTideStatusColor = (status: 'rising' | 'falling') => {
    return status === 'rising' ? 'bg-green-100 text-green-800' : 'bg-blue-100 text-blue-800';
  };

  const formatTideHeight = (height: number) => {
    return `${height.toFixed(2)}m`;
  };

  const formatTideTime = (date: Date) => {
    return format(new Date(date), "HH:mm", { locale: ptBR });
  };

  const formatTideDate = (date: Date) => {
    return format(new Date(date), "dd/MM HH:mm", { locale: ptBR });
  };

  const getTimeUntil = (targetTime: Date) => {
    const now = new Date();
    const diff = new Date(targetTime).getTime() - now.getTime();
    const hours = Math.floor(diff / (1000 * 60 * 60));
    const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
    
    if (hours > 0) {
      return `em ${hours}h ${minutes}min`;
    } else {
      return `em ${minutes}min`;
    }
  };

  const getMaxDraft = (channelDepth: number, currentTide: number, tolerance: number) => {
    return channelDepth + currentTide - tolerance;
  };

  if (tideLoading) {
    return (
      <Card className="shadow-sm hover:shadow-md transition-shadow border-0">
        <CardContent className="p-4 sm:p-6">
          <div className="animate-pulse">
            <div className="h-4 bg-gray-200 rounded w-3/4 mb-2"></div>
            <div className="h-6 bg-gray-200 rounded w-1/2"></div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <>
      <Card className="shadow-sm hover:shadow-md transition-shadow border-0">
        <CardContent className="p-4 sm:p-6">
          <div className="flex items-center justify-between mb-3 sm:mb-4">
            <h3 className="text-base sm:text-lg font-semibold flex items-center">
              <Waves className="mr-2 h-4 w-4 sm:h-5 sm:w-5 text-blue-600" />
              <span className="hidden sm:inline">Maré - Porto da Beira</span>
              <span className="sm:hidden">Maré Atual</span>
            </h3>
            <Dialog open={showDetails} onOpenChange={setShowDetails}>
              <DialogTrigger asChild>
                <Button variant="ghost" size="sm" className="text-blue-600 hover:text-blue-800 p-2">
                  <Info className="w-4 h-4" />
                  <span className="sr-only">Ver tabela de marés</span>
                </Button>
              </DialogTrigger>
            </Dialog>
          </div>

          {tideData && (
            <div className="space-y-3">
              {/* Current tide */}
              <div className="flex justify-between items-center">
                <span className="text-xs sm:text-sm text-gray-600">Altura Atual:</span>
                <div className="flex items-center space-x-2">
                  <span className="font-bold text-lg sm:text-xl text-blue-600">
                    {formatTideHeight(tideData.currentTide)}
                  </span>
                  {getTideStatusIcon(tideData.tideStatus)}
                </div>
              </div>

              {/* Tide status */}
              <div className="flex justify-between items-center">
                <span className="text-xs sm:text-sm text-gray-600">Status:</span>
                <Badge className={getTideStatusColor(tideData.tideStatus)}>
                  {getTideStatusText(tideData.tideStatus)}
                </Badge>
              </div>

              {/* Next high tide */}
              <div className="flex justify-between items-center">
                <span className="text-xs sm:text-sm text-gray-600">Próxima Preamar:</span>
                <div className="text-right">
                  <div className="font-medium text-sm">
                    {formatTideHeight(tideData.nextHighTide.height)}
                  </div>
                  <div className="text-xs text-gray-500">
                    {getTimeUntil(tideData.nextHighTide.time)}
                  </div>
                </div>
              </div>

              {/* Next low tide */}
              <div className="flex justify-between items-center">
                <span className="text-xs sm:text-sm text-gray-600">Próxima Baixamar:</span>
                <div className="text-right">
                  <div className="font-medium text-sm">
                    {formatTideHeight(tideData.nextLowTide.height)}
                  </div>
                  <div className="text-xs text-gray-500">
                    {getTimeUntil(tideData.nextLowTide.time)}
                  </div>
                </div>
              </div>

              {/* Last update */}
              <div className="text-xs text-gray-400 text-center pt-2 border-t">
                Atualizado: {formatTideTime(new Date(tideData.tideTime))}
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Detailed Tide Information Dialog */}
      <Dialog open={showDetails} onOpenChange={setShowDetails}>
        <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center">
              <Waves className="mr-2 h-5 w-5 text-blue-600" />
              Tabela de Marés - Porto da Beira
            </DialogTitle>
            <DialogDescription>
              Informações detalhadas sobre marés atuais, previsões e tendências para o porto da Beira.
            </DialogDescription>
          </DialogHeader>

          <Tabs defaultValue="current" className="w-full">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="current">Atual</TabsTrigger>
              <TabsTrigger value="predictions">Previsões</TabsTrigger>
              <TabsTrigger value="chart">Gráfico</TabsTrigger>
            </TabsList>

            <TabsContent value="current" className="space-y-4">
              {tideData && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {/* Current status */}
                  <Card>
                    <CardHeader className="pb-3">
                      <CardTitle className="text-lg">Status Atual</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-gray-600">Altura:</span>
                        <span className="font-bold text-xl text-blue-600">
                          {formatTideHeight(tideData.currentTide)}
                        </span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-gray-600">Tendência:</span>
                        <div className="flex items-center space-x-2">
                          {getTideStatusIcon(tideData.tideStatus)}
                          <span className="font-medium">
                            {getTideStatusText(tideData.tideStatus)}
                          </span>
                        </div>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-gray-600">Horário:</span>
                        <span className="font-medium">
                          {formatTideTime(new Date(tideData.tideTime))}
                        </span>
                      </div>
                    </CardContent>
                  </Card>

                  {/* Next tides */}
                  <Card>
                    <CardHeader className="pb-3">
                      <CardTitle className="text-lg">Próximas Marés</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-gray-600">Preamar:</span>
                        <div className="text-right">
                          <div className="font-bold text-green-600">
                            {formatTideHeight(tideData.nextHighTide.height)}
                          </div>
                          <div className="text-xs text-gray-500">
                            {formatTideDate(tideData.nextHighTide.time)}
                          </div>
                        </div>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-gray-600">Baixamar:</span>
                        <div className="text-right">
                          <div className="font-bold text-blue-600">
                            {formatTideHeight(tideData.nextLowTide.height)}
                          </div>
                          <div className="text-xs text-gray-500">
                            {formatTideDate(tideData.nextLowTide.time)}
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              )}
            </TabsContent>

            <TabsContent value="predictions" className="space-y-4">
              <div className="space-y-4">
                <div className="flex items-center space-x-2 text-sm text-gray-600">
                  <Clock className="w-4 h-4" />
                  <span>Previsões para os próximos 3 dias</span>
                </div>

                {tideData && tideData.prediction24h.length > 0 && (
                  <div className="grid gap-2">
                    {tideData.prediction24h.map((prediction, index) => (
                      <div
                        key={index}
                        className="flex justify-between items-center p-3 rounded-lg border bg-gray-50"
                      >
                        <div className="flex items-center space-x-3">
                          <div className={`w-2 h-2 rounded-full ${
                            prediction.type === 'high' ? 'bg-green-500' : 'bg-blue-500'
                          }`} />
                          <span className="font-medium">
                            {prediction.type === 'high' ? 'Preamar' : 'Baixamar'}
                          </span>
                        </div>
                        <div className="text-right">
                          <div className="font-bold">
                            {formatTideHeight(prediction.height)}
                          </div>
                          <div className="text-xs text-gray-500">
                            {formatTideDate(prediction.time)}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}

                {!predictionsLoading && predictions.length > 0 && (
                  <div className="mt-6">
                    <h4 className="font-medium mb-3">Previsões Horárias</h4>
                    <div className="max-h-60 overflow-y-auto space-y-1">
                      {predictions.slice(0, 24).map((pred, index) => (
                        <div
                          key={index}
                          className="flex justify-between items-center text-sm py-1"
                        >
                          <span className="text-gray-600">
                            {formatTideDate(pred.time)}
                          </span>
                          <span className="font-medium">
                            {formatTideHeight(pred.height)}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </TabsContent>

            <TabsContent value="chart" className="space-y-4">
              <div className="text-center py-8">
                <Calendar className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-500">
                  Gráfico de marés será implementado em breve
                </p>
                <p className="text-xs text-gray-400 mt-2">
                  Visualização gráfica das previsões de maré para melhor planejamento
                </p>
              </div>
            </TabsContent>
          </Tabs>

          {/* Information footer */}
          <div className="mt-6 p-4 bg-blue-50 rounded-lg">
            <div className="flex items-start space-x-2">
              <AlertTriangle className="w-4 h-4 text-blue-600 mt-0.5 flex-shrink-0" />
              <div className="text-sm">
                <p className="font-medium text-blue-800">Informação Importante</p>
                <p className="text-blue-700 mt-1">
                  Os dados de maré são baseados em análise harmônica para o Porto da Beira. 
                  Para operações críticas, confirme sempre com as autoridades portuárias.
                </p>
              </div>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}