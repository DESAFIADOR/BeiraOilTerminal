import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Ship, ArrowRight, Mail, AlertCircle } from "lucide-react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface InstructionModalProps {
  isOpen: boolean;
  onClose: () => void;
  ships: any[];
}

export function InstructionModal({ isOpen, onClose, ships }: InstructionModalProps) {
  const [selectedShipId, setSelectedShipId] = useState<number | null>(null);
  const [actionType, setActionType] = useState<'manual' | 'email' | null>(null);
  const queryClient = useQueryClient();
  const { toast } = useToast();

  // Filter ships that need instruction (at bar without instruction)
  const shipsNeedingInstruction = (ships || []).filter(ship => 
    ship.status === 'at_bar' && !ship.hasDischargeInstructions
  );

  const moveInstructionMutation = useMutation({
    mutationFn: async ({ shipId, type }: { shipId: number; type: 'manual' | 'email' }) => {
      if (type === 'manual') {
        // Manual move instruction
        return await apiRequest(`/api/ships/${shipId}/instruction`, "PATCH", {
          hasDischargeInstructions: true
        });
      } else {
        // Send email for instruction confirmation
        return await apiRequest(`/api/ships/${shipId}/send-instruction-email`, "POST", {});
      }
    },
    onSuccess: (_, variables) => {
      // Force complete cache invalidation and refresh
      queryClient.invalidateQueries({ queryKey: ["/api/ships"] });
      queryClient.removeQueries({ queryKey: ["/api/ships"] });
      queryClient.refetchQueries({ queryKey: ["/api/ships"] });
      
      if (variables.type === 'manual') {
        toast({
          title: "Instrução Movida",
          description: "A instrução foi adicionada manualmente ao navio.",
        });
      } else {
        toast({
          title: "Email Enviado",
          description: "Email de confirmação enviado aos agentes do navio.",
        });
      }
      onClose();
      setSelectedShipId(null);
      setActionType(null);
    },
    onError: (error: any) => {
      toast({
        title: "Erro",
        description: error.message || "Erro ao processar instrução.",
        variant: "destructive",
      });
    },
  });

  const handleMoveInstruction = () => {
    if (!selectedShipId || !actionType) return;
    
    moveInstructionMutation.mutate({
      shipId: selectedShipId,
      type: actionType
    });
  };

  const selectedShip = shipsNeedingInstruction.find(ship => ship.id === selectedShipId);

  if (shipsNeedingInstruction.length === 0) {
    return (
      <Dialog open={isOpen} onOpenChange={onClose}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <ArrowRight className="h-5 w-5 text-purple-600" />
              Mover Instrução
            </DialogTitle>
          </DialogHeader>
          <div className="text-center py-8">
            <AlertCircle className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <p className="text-gray-600">
              Não há navios na barra sem instrução de descarga.
            </p>
          </div>
        </DialogContent>
      </Dialog>
    );
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-2xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <ArrowRight className="h-5 w-5 text-purple-600" />
            Mover Instrução de Descarga
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Ship Selection */}
          <div>
            <h3 className="text-sm font-medium text-gray-700 mb-3">
              Selecionar Navio na Barra (sem instrução)
            </h3>
            <div className="space-y-2 max-h-60 overflow-y-auto">
              {shipsNeedingInstruction.map((ship) => (
                <Card
                  key={ship.id}
                  className={`cursor-pointer transition-all ${
                    selectedShipId === ship.id
                      ? 'ring-2 ring-purple-500 bg-purple-50'
                      : 'hover:bg-gray-50'
                  }`}
                  onClick={() => setSelectedShipId(ship.id)}
                >
                  <CardContent className="p-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <Ship className="h-4 w-4 text-blue-600" />
                        <div>
                          <p className="font-medium text-gray-900">{ship.name}</p>
                          <p className="text-sm text-gray-500">
                            Contra Marca: {ship.countermark}
                          </p>
                        </div>
                      </div>
                      <Badge variant="secondary" className="bg-red-100 text-red-800">
                        Sem Instrução
                      </Badge>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          {/* Action Type Selection */}
          {selectedShipId && (
            <div>
              <h3 className="text-sm font-medium text-gray-700 mb-3">
                Como deseja proceder com a instrução?
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <Card
                  className={`cursor-pointer transition-all ${
                    actionType === 'manual'
                      ? 'ring-2 ring-purple-500 bg-purple-50'
                      : 'hover:bg-gray-50'
                  }`}
                  onClick={() => setActionType('manual')}
                >
                  <CardContent className="p-4 text-center">
                    <ArrowRight className="h-6 w-6 text-purple-600 mx-auto mb-2" />
                    <h4 className="font-medium text-gray-900">Manual</h4>
                    <p className="text-sm text-gray-500 mt-1">
                      Adicionar instrução imediatamente
                    </p>
                  </CardContent>
                </Card>

                <Card
                  className={`cursor-pointer transition-all ${
                    actionType === 'email'
                      ? 'ring-2 ring-purple-500 bg-purple-50'
                      : 'hover:bg-gray-50'
                  }`}
                  onClick={() => setActionType('email')}
                >
                  <CardContent className="p-4 text-center">
                    <Mail className="h-6 w-6 text-blue-600 mx-auto mb-2" />
                    <h4 className="font-medium text-gray-900">Por Email</h4>
                    <p className="text-sm text-gray-500 mt-1">
                      Enviar para confirmação dos agentes
                    </p>
                  </CardContent>
                </Card>
              </div>
            </div>
          )}

          {/* Ship Details and Confirmation */}
          {selectedShip && actionType && (
            <div className="bg-gray-50 p-4 rounded-lg">
              <h4 className="font-medium text-gray-900 mb-2">Confirmação</h4>
              <div className="space-y-2 text-sm">
                <p><span className="font-medium">Navio:</span> {selectedShip.name}</p>
                <p><span className="font-medium">Agente do Navio:</span> {selectedShip.shipAgent}</p>
                <p><span className="font-medium">Agente da Carga:</span> {selectedShip.cargoAgent}</p>
                {actionType === 'email' && selectedShip.shipAgentEmail && (
                  <p><span className="font-medium">Email do Agente:</span> {selectedShip.shipAgentEmail}</p>
                )}
                <p className="text-purple-600 font-medium">
                  {actionType === 'manual' 
                    ? 'A instrução será adicionada imediatamente'
                    : 'Um email será enviado solicitando confirmação'
                  }
                </p>
              </div>
            </div>
          )}
        </div>

        {/* Action Buttons */}
        <div className="flex justify-end gap-3 pt-4 border-t">
          <Button variant="outline" onClick={onClose}>
            Cancelar
          </Button>
          <Button
            onClick={handleMoveInstruction}
            disabled={!selectedShipId || !actionType || moveInstructionMutation.isPending}
            className="bg-purple-600 hover:bg-purple-700"
          >
            {moveInstructionMutation.isPending ? (
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                Processando...
              </div>
            ) : (
              <>
                {actionType === 'manual' ? (
                  <>
                    <ArrowRight className="w-4 h-4 mr-2" />
                    Mover Instrução
                  </>
                ) : (
                  <>
                    <Mail className="w-4 h-4 mr-2" />
                    Enviar Email
                  </>
                )}
              </>
            )}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}