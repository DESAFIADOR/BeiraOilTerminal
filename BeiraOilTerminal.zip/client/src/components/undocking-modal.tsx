import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Navigation, Clock } from "lucide-react";

const undockingSchema = z.object({
  firstRopeTime: z.string().min(1, "Horário da primeira corda é obrigatório"),
  lastRopeTime: z.string().min(1, "Horário da última corda é obrigatório"),
});

type UndockingFormData = z.infer<typeof undockingSchema>;

interface UndockingModalProps {
  isOpen: boolean;
  onClose: () => void;
  shipId: number;
  shipName: string;
  onSuccess: () => void;
}

export function UndockingModal({
  isOpen,
  onClose,
  shipId,
  shipName,
  onSuccess,
}: UndockingModalProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [lastRopeSubmitted, setLastRopeSubmitted] = useState(false);

  const form = useForm<UndockingFormData>({
    resolver: zodResolver(undockingSchema),
    defaultValues: {
      firstRopeTime: "",
      lastRopeTime: "",
    },
  });

  const mutation = useMutation({
    mutationFn: async (data: UndockingFormData) => {
      // First register the undocking times
      await apiRequest("/api/ships/undocking", "POST", {
        shipId,
        firstRopeTime: data.firstRopeTime,
        lastRopeTime: data.lastRopeTime,
      });
      
      // Then automatically move the ship to departed status
      await apiRequest(`/api/ships/${shipId}/status`, "PATCH", {
        status: "departed"
      });
    },
    onSuccess: () => {
      toast({
        title: "Sucesso",
        description: "Desatracação registrada e navio movido para navios desatracados.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/ships"] });
      form.reset();
      onSuccess();
      onClose();
    },
    onError: (error: Error) => {
      toast({
        title: "Erro",
        description: error.message || "Falha ao registrar desatracação.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: UndockingFormData) => {
    mutation.mutate(data);
  };

  const handleLastRopeKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && form.getValues('lastRopeTime').trim() !== '') {
      e.preventDefault();
      setLastRopeSubmitted(true);
      form.handleSubmit(onSubmit)();
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Navigation className="w-5 h-5 text-red-600" />
            Registro de Desatracação
          </DialogTitle>
          <DialogDescription>
            Registre os horários das cordas para o navio <strong>{shipName}</strong>
          </DialogDescription>
        </DialogHeader>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="firstRopeTime"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="flex items-center gap-2">
                    <Clock className="w-4 h-4" />
                    Primeira Corda
                  </FormLabel>
                  <FormControl>
                    <Input
                      type="datetime-local"
                      placeholder="Selecione data e hora"
                      {...field}
                      className="w-full"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="lastRopeTime"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="flex items-center gap-2">
                    <Clock className="w-4 h-4" />
                    Última Corda
                  </FormLabel>
                  <FormControl>
                    <Input
                      type="datetime-local"
                      placeholder="Selecione data e hora"
                      {...field}
                      className="w-full"
                      onKeyDown={handleLastRopeKeyDown}
                    />
                  </FormControl>
                  <FormMessage />
                  <p className="text-xs text-gray-500">
                    Pressione Enter após preencher para desatracar automaticamente
                  </p>
                </FormItem>
              )}
            />

            <div className="flex justify-end space-x-3 pt-4">
              <Button
                type="button"
                variant="outline"
                onClick={onClose}
                disabled={mutation.isPending}
              >
                Cancelar
              </Button>
              <Button
                type="submit"
                disabled={mutation.isPending}
                className="bg-red-600 hover:bg-red-700"
              >
                {mutation.isPending ? (
                  <>
                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
                    Desatracando...
                  </>
                ) : (
                  <>
                    <Navigation className="w-4 h-4 mr-2" />
                    Desatracar Navio
                  </>
                )}
              </Button>
            </div>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}