import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Mail, 
  MessageSquare, 
  Phone, 
  Send, 
  CheckCircle, 
  XCircle,
  Clock,
  AlertCircle,
  RefreshCw,
  Settings
} from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface CommunicationPanelProps {
  isOpen: boolean;
  onClose: () => void;
  userRole: string;
}

export function CommunicationPanel({ isOpen, onClose, userRole }: CommunicationPanelProps) {
  const [emailForm, setEmailForm] = useState({
    to: '',
    subject: '',
    content: ''
  });
  
  const [whatsappForm, setWhatsappForm] = useState({
    phoneNumber: '',
    message: ''
  });
  
  const [smsForm, setSmsForm] = useState({
    phoneNumber: '',
    message: ''
  });

  const [tokenForm, setTokenForm] = useState({
    phoneNumber: '',
    purpose: 'verification'
  });

  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Get communication logs
  const { data: communicationLogs, isLoading: logsLoading } = useQuery({
    queryKey: ['/api/communication/logs'],
    enabled: isOpen && (userRole === 'operator' || userRole === 'admin')
  });

  // Get service status
  const { data: serviceStatus, isLoading: statusLoading } = useQuery({
    queryKey: ['/api/communication/status'],
    enabled: isOpen && (userRole === 'operator' || userRole === 'admin')
  });

  // Get communication stats
  const { data: commStats } = useQuery({
    queryKey: ['/api/communication/stats'],
    enabled: isOpen && (userRole === 'operator' || userRole === 'admin')
  });

  // Send email mutation
  const sendEmailMutation = useMutation({
    mutationFn: async (data: typeof emailForm) => {
      return await apiRequest('/api/communication/email/send', {
        method: 'POST',
        body: JSON.stringify(data)
      });
    },
    onSuccess: () => {
      toast({
        title: "Email Enviado",
        description: "Email enviado com sucesso!",
      });
      setEmailForm({ to: '', subject: '', content: '' });
      queryClient.invalidateQueries({ queryKey: ['/api/communication/logs'] });
    },
    onError: (error: any) => {
      toast({
        title: "Erro ao Enviar Email",
        description: error.message || "Falha ao enviar email",
        variant: "destructive",
      });
    }
  });

  // Send WhatsApp mutation
  const sendWhatsAppMutation = useMutation({
    mutationFn: async (data: typeof whatsappForm) => {
      return await apiRequest('/api/communication/whatsapp/send', {
        method: 'POST',
        body: JSON.stringify(data)
      });
    },
    onSuccess: () => {
      toast({
        title: "WhatsApp Enviado",
        description: "Mensagem WhatsApp enviada com sucesso!",
      });
      setWhatsappForm({ phoneNumber: '', message: '' });
      queryClient.invalidateQueries({ queryKey: ['/api/communication/logs'] });
    },
    onError: (error: any) => {
      toast({
        title: "Erro ao Enviar WhatsApp",
        description: error.message || "Falha ao enviar WhatsApp",
        variant: "destructive",
      });
    }
  });

  // Send SMS mutation
  const sendSMSMutation = useMutation({
    mutationFn: async (data: typeof smsForm) => {
      return await apiRequest('/api/communication/sms/send', {
        method: 'POST',
        body: JSON.stringify(data)
      });
    },
    onSuccess: () => {
      toast({
        title: "SMS Enviado",
        description: "SMS enviado com sucesso!",
      });
      setSmsForm({ phoneNumber: '', message: '' });
      queryClient.invalidateQueries({ queryKey: ['/api/communication/logs'] });
    },
    onError: (error: any) => {
      toast({
        title: "Erro ao Enviar SMS",
        description: error.message || "Falha ao enviar SMS",
        variant: "destructive",
      });
    }
  });

  // Generate token mutation
  const generateTokenMutation = useMutation({
    mutationFn: async (data: typeof tokenForm) => {
      return await apiRequest('/api/communication/token/generate', {
        method: 'POST',
        body: JSON.stringify(data)
      });
    },
    onSuccess: () => {
      toast({
        title: "Token Gerado",
        description: "Token de validação enviado por SMS!",
      });
      setTokenForm({ phoneNumber: '', purpose: 'verification' });
    },
    onError: (error: any) => {
      toast({
        title: "Erro ao Gerar Token",
        description: error.message || "Falha ao gerar token",
        variant: "destructive",
      });
    }
  });

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg shadow-xl max-w-6xl w-full max-h-[90vh] overflow-y-auto">
        <div className="p-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-bold text-gray-800 flex items-center gap-3">
              <MessageSquare className="w-6 h-6 text-blue-500" />
              Sistema de Comunicação Automatizada
            </h2>
            <Button 
              variant="outline" 
              size="sm"
              onClick={onClose}
            >
              ✕
            </Button>
          </div>

          {/* Service Status */}
          {serviceStatus && (
            <div className="mb-6">
              <h3 className="text-lg font-semibold mb-3">Status dos Serviços</h3>
              <div className="grid grid-cols-3 gap-4">
                <Card className="p-4">
                  <div className="flex items-center gap-2">
                    <Mail className="w-5 h-5" />
                    <span className="font-medium">Email</span>
                    {serviceStatus.services?.email ? (
                      <CheckCircle className="w-4 h-4 text-green-500" />
                    ) : (
                      <XCircle className="w-4 h-4 text-red-500" />
                    )}
                  </div>
                  <Badge variant={serviceStatus.services?.email ? "default" : "destructive"}>
                    {serviceStatus.services?.email ? "Ativo" : "Inativo"}
                  </Badge>
                </Card>
                
                <Card className="p-4">
                  <div className="flex items-center gap-2">
                    <MessageSquare className="w-5 h-5" />
                    <span className="font-medium">WhatsApp</span>
                    {serviceStatus.services?.whatsapp ? (
                      <CheckCircle className="w-4 h-4 text-green-500" />
                    ) : (
                      <XCircle className="w-4 h-4 text-red-500" />
                    )}
                  </div>
                  <Badge variant={serviceStatus.services?.whatsapp ? "default" : "destructive"}>
                    {serviceStatus.services?.whatsapp ? "Ativo" : "Inativo"}
                  </Badge>
                </Card>
                
                <Card className="p-4">
                  <div className="flex items-center gap-2">
                    <Phone className="w-5 h-5" />
                    <span className="font-medium">SMS</span>
                    {serviceStatus.services?.sms ? (
                      <CheckCircle className="w-4 h-4 text-green-500" />
                    ) : (
                      <XCircle className="w-4 h-4 text-red-500" />
                    )}
                  </div>
                  <Badge variant={serviceStatus.services?.sms ? "default" : "destructive"}>
                    {serviceStatus.services?.sms ? "Ativo" : "Inativo"}
                  </Badge>
                </Card>
              </div>
            </div>
          )}

          <Tabs defaultValue="email" className="w-full">
            <TabsList className="grid w-full grid-cols-5">
              <TabsTrigger value="email">📧 Email</TabsTrigger>
              <TabsTrigger value="whatsapp">💬 WhatsApp</TabsTrigger>
              <TabsTrigger value="sms">📱 SMS</TabsTrigger>
              <TabsTrigger value="tokens">🔐 Tokens</TabsTrigger>
              <TabsTrigger value="logs">📊 Logs</TabsTrigger>
            </TabsList>

            {/* Email Tab */}
            <TabsContent value="email" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Mail className="w-5 h-5" />
                    Enviar Email
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-3 mb-4">
                    <p className="text-sm text-yellow-700">
                      <strong>Modo Demonstração:</strong> Sistema configurado em modo sandbox. 
                      Emails são processados mas não entregues para teste de funcionalidade.
                    </p>
                    <p className="text-xs text-yellow-600 mt-1">
                      Para entrega real, é necessário verificar domínio no SendGrid.
                    </p>
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1">Destinatário</label>
                    <Input
                      type="email"
                      placeholder="exemplo@email.com"
                      value={emailForm.to}
                      onChange={(e) => setEmailForm({...emailForm, to: e.target.value})}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1">Assunto</label>
                    <Input
                      placeholder="Assunto do email"
                      value={emailForm.subject}
                      onChange={(e) => setEmailForm({...emailForm, subject: e.target.value})}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1">Conteúdo</label>
                    <Textarea
                      placeholder="Digite sua mensagem aqui..."
                      rows={6}
                      value={emailForm.content}
                      onChange={(e) => setEmailForm({...emailForm, content: e.target.value})}
                    />
                    <div className="text-xs text-gray-500 mt-1">
                      Suporte para HTML e texto simples
                    </div>
                  </div>
                  <Button 
                    onClick={() => sendEmailMutation.mutate(emailForm)}
                    disabled={sendEmailMutation.isPending || !emailForm.to || !emailForm.subject || !emailForm.content}
                    className="w-full"
                  >
                    {sendEmailMutation.isPending ? (
                      <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                    ) : (
                      <Send className="w-4 h-4 mr-2" />
                    )}
                    Enviar Email
                  </Button>
                </CardContent>
              </Card>
            </TabsContent>

            {/* WhatsApp Tab */}
            <TabsContent value="whatsapp" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <MessageSquare className="w-5 h-5" />
                    Enviar WhatsApp
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium mb-1">Número de Telefone</label>
                    <Input
                      placeholder="+258XXXXXXXXX"
                      value={whatsappForm.phoneNumber}
                      onChange={(e) => setWhatsappForm({...whatsappForm, phoneNumber: e.target.value})}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1">Mensagem</label>
                    <Textarea
                      placeholder="Mensagem WhatsApp..."
                      rows={6}
                      value={whatsappForm.message}
                      onChange={(e) => setWhatsappForm({...whatsappForm, message: e.target.value})}
                    />
                  </div>
                  <Button 
                    onClick={() => sendWhatsAppMutation.mutate(whatsappForm)}
                    disabled={sendWhatsAppMutation.isPending || !whatsappForm.phoneNumber || !whatsappForm.message}
                    className="w-full"
                  >
                    {sendWhatsAppMutation.isPending ? (
                      <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                    ) : (
                      <Send className="w-4 h-4 mr-2" />
                    )}
                    Enviar WhatsApp
                  </Button>
                </CardContent>
              </Card>
            </TabsContent>

            {/* SMS Tab */}
            <TabsContent value="sms" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Phone className="w-5 h-5" />
                    Enviar SMS
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium mb-1">Número de Telefone</label>
                    <Input
                      placeholder="+258XXXXXXXXX"
                      value={smsForm.phoneNumber}
                      onChange={(e) => setSmsForm({...smsForm, phoneNumber: e.target.value})}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1">Mensagem</label>
                    <Textarea
                      placeholder="Mensagem SMS..."
                      rows={4}
                      value={smsForm.message}
                      onChange={(e) => setSmsForm({...smsForm, message: e.target.value})}
                    />
                  </div>
                  <Button 
                    onClick={() => sendSMSMutation.mutate(smsForm)}
                    disabled={sendSMSMutation.isPending || !smsForm.phoneNumber || !smsForm.message}
                    className="w-full"
                  >
                    {sendSMSMutation.isPending ? (
                      <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                    ) : (
                      <Send className="w-4 h-4 mr-2" />
                    )}
                    Enviar SMS
                  </Button>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Tokens Tab */}
            <TabsContent value="tokens" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <AlertCircle className="w-5 h-5" />
                    Gerar Token de Validação
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium mb-1">Número de Telefone</label>
                    <Input
                      placeholder="+258XXXXXXXXX"
                      value={tokenForm.phoneNumber}
                      onChange={(e) => setTokenForm({...tokenForm, phoneNumber: e.target.value})}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1">Propósito</label>
                    <select 
                      className="w-full p-2 border rounded"
                      value={tokenForm.purpose}
                      onChange={(e) => setTokenForm({...tokenForm, purpose: e.target.value})}
                    >
                      <option value="verification">Verificação</option>
                      <option value="reset_password">Reset de Senha</option>
                      <option value="ship_confirmation">Confirmação de Navio</option>
                    </select>
                  </div>
                  <Button 
                    onClick={() => generateTokenMutation.mutate(tokenForm)}
                    disabled={generateTokenMutation.isPending || !tokenForm.phoneNumber}
                    className="w-full"
                  >
                    {generateTokenMutation.isPending ? (
                      <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                    ) : (
                      <Send className="w-4 h-4 mr-2" />
                    )}
                    Gerar e Enviar Token
                  </Button>
                  <div className="text-sm text-gray-600 bg-blue-50 p-3 rounded">
                    <AlertCircle className="w-4 h-4 inline mr-2" />
                    O token será enviado por SMS e válido por 10 minutos.
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Logs Tab */}
            <TabsContent value="logs" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Clock className="w-5 h-5" />
                    Logs de Comunicação
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {logsLoading ? (
                    <div className="text-center py-4">Carregando logs...</div>
                  ) : communicationLogs && communicationLogs.length > 0 ? (
                    <div className="space-y-2 max-h-96 overflow-y-auto">
                      {communicationLogs.map((log: any) => (
                        <div key={log.id} className="flex items-center justify-between p-3 bg-gray-50 rounded">
                          <div className="flex items-center gap-3">
                            {log.type === 'email' && <Mail className="w-4 h-4" />}
                            {log.type === 'whatsapp' && <MessageSquare className="w-4 h-4" />}
                            {log.type === 'sms' && <Phone className="w-4 h-4" />}
                            <div>
                              <div className="font-medium">{log.recipient}</div>
                              <div className="text-sm text-gray-600">{log.subject || log.content?.substring(0, 50)}...</div>
                            </div>
                          </div>
                          <div className="flex items-center gap-2">
                            <Badge variant={log.status === 'sent' ? 'default' : 'destructive'}>
                              {log.status === 'sent' ? 'Enviado' : 'Falhou'}
                            </Badge>
                            <span className="text-xs text-gray-500">
                              {new Date(log.sentAt).toLocaleString('pt-PT')}
                            </span>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-8 text-gray-500">
                      Nenhum log de comunicação encontrado
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Statistics */}
              {commStats && (
                <Card>
                  <CardHeader>
                    <CardTitle>Estatísticas de Comunicação (7 dias)</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-3 gap-4">
                      <div className="text-center">
                        <div className="text-2xl font-bold text-blue-600">{commStats.stats?.email?.sent || 0}</div>
                        <div className="text-sm text-gray-600">Emails Enviados</div>
                      </div>
                      <div className="text-center">
                        <div className="text-2xl font-bold text-green-600">{commStats.stats?.whatsapp?.sent || 0}</div>
                        <div className="text-sm text-gray-600">WhatsApp Enviados</div>
                      </div>
                      <div className="text-center">
                        <div className="text-2xl font-bold text-purple-600">{commStats.stats?.sms?.sent || 0}</div>
                        <div className="text-sm text-gray-600">SMS Enviados</div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )}
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
}