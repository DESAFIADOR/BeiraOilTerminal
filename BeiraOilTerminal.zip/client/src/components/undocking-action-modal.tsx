import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent } from '@/components/ui/card';
import { Ship, ArrowUpDown } from 'lucide-react';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';

interface UndockingActionModalProps {
  isOpen: boolean;
  onClose: () => void;
  ship: any;
}

export function UndockingActionModal({ isOpen, onClose, ship }: UndockingActionModalProps) {
  const [firstRopeTime, setFirstRopeTime] = useState('');
  const [lastRopeTime, setLastRopeTime] = useState('');
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const undockingMutation = useMutation({
    mutationFn: async () => {
      // Register undocking times
      try {
        await fetch(`/api/ships/${ship.id}/undocking`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            firstRopeTime: new Date(firstRopeTime).toISOString(),
            lastRopeTime: new Date(lastRopeTime).toISOString(),
          }),
        });
      } catch (error) {
        console.log('Undocking endpoint not available, proceeding with status update');
      }

      // Update ship status to departed
      const response = await fetch(`/api/ships/${ship.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: 'departed' }),
      });
      
      if (!response.ok) throw new Error('Failed to update ship status');
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Navio Desatracado",
        description: `${ship.name} foi desatracado com sucesso`,
      });
      queryClient.invalidateQueries({ queryKey: ['/api/ships'] });
      onClose();
    },
    onError: (error: any) => {
      toast({
        title: "Erro",
        description: error.message || "Erro ao desatracar navio",
        variant: "destructive",
      });
    }
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!firstRopeTime || !lastRopeTime) {
      toast({
        title: "Erro",
        description: "Por favor, preencha todos os campos",
        variant: "destructive",
      });
      return;
    }
    undockingMutation.mutate();
  };

  if (!ship) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <ArrowUpDown className="w-5 h-5 text-red-600" />
            Desatracar Navio
          </DialogTitle>
        </DialogHeader>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-12 h-12 bg-red-100 rounded-full flex items-center justify-center">
                <Ship className="w-6 h-6 text-red-600" />
              </div>
              <div>
                <h4 className="font-semibold text-lg">{ship.name}</h4>
                <p className="text-sm text-gray-600">Distintivo: {ship.countermark}</p>
              </div>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <Label htmlFor="firstRope">Tempo da Primeira Corda</Label>
                <Input
                  id="firstRope"
                  type="datetime-local"
                  value={firstRopeTime}
                  onChange={(e) => setFirstRopeTime(e.target.value)}
                  required
                />
              </div>

              <div>
                <Label htmlFor="lastRope">Tempo da Última Corda</Label>
                <Input
                  id="lastRope"
                  type="datetime-local"
                  value={lastRopeTime}
                  onChange={(e) => setLastRopeTime(e.target.value)}
                  required
                />
              </div>

              <div className="flex justify-end gap-3 pt-4">
                <Button variant="outline" onClick={onClose} type="button">
                  Cancelar
                </Button>
                <Button 
                  type="submit" 
                  className="bg-red-600 hover:bg-red-700"
                  disabled={undockingMutation.isPending}
                >
                  {undockingMutation.isPending ? 'Processando...' : 'Confirmar Desatracação'}
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      </DialogContent>
    </Dialog>
  );
}