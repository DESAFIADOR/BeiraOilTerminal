import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogTrigger } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { CheckCircle, Clock, List, Ship, Waves, ArrowRight, ArrowUp, Mail, FileText, Info, Edit, X, RefreshCw } from "lucide-react";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import { EnhancedShipCard } from "./enhanced-ship-card";
import { ShipEditForm } from "./ship-edit-form";
import { ShipInfoModal } from "./ship-info-modal";
import { useTranslation } from "@/contexts/LanguageContext";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import { apiRequest } from "@/lib/queryClient";





interface Ship {
  id: number;
  name: string;
  draft: string;
  arrivalDateTime: string | Date;
  shipAgent: string;
  cargoAgent: string;
  operationType: string;
  status: string;
  hasDischargeInstructions: boolean | null;
  departedAt?: string | Date | null | undefined;
}

interface ShipsQueueProps {
  shipsWithInstructions: Ship[];
  shipsWithoutInstructions: Ship[];
  expectedArrivals: Ship[];
  departedShips: Ship[];
  onMoveToBar?: (shipId: number) => void;
  onMoveToNext?: (shipId: number) => void;
  onSendConfirmation?: (shipId: number) => void;
  onAddInstructions?: (shipId: number) => void;
  onSendInstructionEmail?: (shipId: number) => void;
  isOperator?: boolean;
}

// Component for clickable ship name that shows ship info dialog
const ClickableShipName = ({ shipId, shipName, statusLabel }: { shipId: number; shipName: string; statusLabel: string }) => {
  const [isOpen, setIsOpen] = useState(false);
  
  const { data: shipDetails, isLoading } = useQuery({
    queryKey: ['/api/ships', shipId],
    queryFn: async () => {
      const response = await fetch(`/api/ships/${shipId}`);
      if (!response.ok) throw new Error('Erro ao buscar navio');
      return response.json();
    },
    enabled: isOpen, // Only fetch when dialog is opened
  });

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <button className="font-medium text-gray-900 hover:text-blue-600 hover:underline cursor-pointer text-left">
          {shipName}
        </button>
      </DialogTrigger>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Ship className="w-5 h-5 text-blue-600" />
            Informações do Navio: {shipName}
          </DialogTitle>
          <DialogDescription>
            Detalhes completos do navio e sua carga
          </DialogDescription>
        </DialogHeader>
        {isLoading ? (
          <div className="text-center py-8">
            <div className="w-8 h-8 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
            <p className="text-gray-600">Carregando informações do navio...</p>
          </div>
        ) : shipDetails ? (
          <EnhancedShipCard
            ship={shipDetails as any}
            title="Detalhes do Navio"
            statusBadge={statusLabel}
            statusColor="blue"
            showProgress={true}
          />
        ) : (
          <div className="text-center py-8">
            <p className="text-gray-600">Não foi possível carregar as informações do navio.</p>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
};

export function ShipsQueue({ 
  shipsWithInstructions, 
  shipsWithoutInstructions, 
  expectedArrivals, 
  departedShips,
  onMoveToBar,
  onMoveToNext,
  onSendConfirmation,
  onAddInstructions,
  onSendInstructionEmail,
  isOperator
}: ShipsQueueProps) {
  const { t } = useTranslation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { user } = useAuth();
  const canEdit = user?.role === "operator" || user?.role === "admin";
  const [infoDialogOpen, setInfoDialogOpen] = useState(false);
  const [infoShipId, setInfoShipId] = useState<number | null>(null);

  // Mutation para alternar tipo de operação
  const toggleOperationTypeMutation = useMutation({
    mutationFn: async ({ shipId, newType }: { shipId: number; newType: string }) => {
      const response = await apiRequest(`/api/ships/${shipId}`, 'PATCH', {
        operationType: newType
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/ships'] });
      toast({
        title: "Sucesso!",
        description: "Tipo de operação atualizado com sucesso.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Erro",
        description: error.message || "Erro ao atualizar tipo de operação.",
        variant: "destructive",
      });
    },
  });

  // Função para alternar tipo de operação
  const getNextOperationType = (currentType: string) => {
    switch (currentType) {
      case 'nacional': return 'transito';
      case 'transito': return 'combinado';
      case 'combinado': return 'LPG';
      case 'LPG': return 'nacional';
      default: return 'nacional';
    }
  };

  const handleToggleOperationType = (shipId: number, currentType: string) => {
    if (!canEdit) {
      toast({
        title: "Acesso Negado",
        description: "Você não tem permissão para editar informações do navio.",
        variant: "destructive",
      });
      return;
    }
    const nextType = getNextOperationType(currentType);
    toggleOperationTypeMutation.mutate({ shipId, newType: nextType });
  };

  // Componente interno para exibir informações do navio
  const ShipInfoContent = ({ shipId }: { shipId: number }) => {
    const { data: ship, isLoading } = useQuery({
      queryKey: ['/api/ships', shipId],
      queryFn: () => fetch(`/api/ships/${shipId}`).then(res => res.json()),
    });

    if (isLoading) {
      return (
        <div className="flex items-center justify-center py-8">
          <div className="w-8 h-8 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mr-3"></div>
          <span className="text-gray-600">Carregando informações do navio...</span>
        </div>
      );
    }

    if (!ship) {
      return (
        <div className="text-center py-8 text-red-600">
          <p>Erro ao carregar informações do navio</p>
        </div>
      );
    }

    // Renderizar informações do navio com abas incluindo edição
    return (
      <Tabs defaultValue="info" className="w-full">
        <TabsList className={`grid w-full ${canEdit ? 'grid-cols-2' : 'grid-cols-1'}`}>
          <TabsTrigger value="info" className="flex items-center gap-2">
            <Info className="h-4 w-4" />
            Informações
          </TabsTrigger>
          {canEdit && (
            <TabsTrigger value="edit" className="flex items-center gap-2">
              <Edit className="h-4 w-4" />
              Editar
            </TabsTrigger>
          )}
        </TabsList>

        <TabsContent value="info" className="space-y-6 mt-6">
          {/* Informações Gerais */}
          <div className="bg-gray-50 p-4 rounded-lg">
            <h3 className="text-lg font-semibold text-gray-800 mb-3">Informações Gerais</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <span className="text-sm font-medium text-gray-600 block">Nome do Navio</span>
                <p className="text-gray-900">{ship.name}</p>
              </div>
              <div>
                <span className="text-sm font-medium text-gray-600 block">Contra Marca</span>
                <p className="text-gray-900">{ship.countermark}</p>
              </div>
              <div>
                <span className="text-sm font-medium text-gray-600 block">Calado</span>
                <p className="text-gray-900">{ship.draft}m</p>
              </div>
              <div>
                <span className="text-sm font-medium text-gray-600 block">Tipo de Carga</span>
                <p className="text-gray-900">{ship.cargoType}</p>
              </div>
            </div>
          </div>

          {/* Agentes */}
          <div className="bg-gray-50 p-4 rounded-lg">
            <h3 className="text-lg font-semibold text-gray-800 mb-3">Agentes</h3>
            <div className="space-y-4">
              <div>
                <span className="text-sm font-medium text-gray-600 block">Agente do Navio</span>
                <p className="text-gray-900">{ship.shipAgent}</p>
              </div>
              <div>
                <span className="text-sm font-medium text-gray-600 block">Agente da Carga</span>
                <p className="text-gray-900">{ship.cargoAgent}</p>
              </div>
            </div>
          </div>

          {/* Parcelas de Carga */}
          {ship.parcels && ship.parcels.length > 0 && (
            <div className="bg-gray-50 p-4 rounded-lg">
              <h3 className="text-lg font-semibold text-gray-800 mb-3">Parcelas de Carga</h3>
              <div className="space-y-3">
                {ship.parcels.map((parcel: any, index: number) => (
                  <div key={index} className="bg-white p-3 rounded border">
                    <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
                      <div>
                        <span className="text-xs font-medium text-gray-600 block">Número</span>
                        <p className="text-sm">{parcel.parcelNumber}</p>
                      </div>
                      <div>
                        <span className="text-xs font-medium text-gray-600 block">Volume</span>
                        <p className="text-sm">{parcel.volume} MT</p>
                      </div>
                      <div>
                        <span className="text-xs font-medium text-gray-600 block">Recebedor</span>
                        <p className="text-sm">{parcel.receiver}</p>
                      </div>
                      <div>
                        <span className="text-xs font-medium text-gray-600 block">Dono</span>
                        <p className="text-sm">{parcel.owner}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Data de Chegada */}
          <div className="bg-gray-50 p-4 rounded-lg">
            <h3 className="text-lg font-semibold text-gray-800 mb-3">Data de Chegada na Barra</h3>
            <p className="text-gray-900">{ship.arrivalDateTime ? format(new Date(ship.arrivalDateTime), "dd/MM/yyyy HH:mm", { locale: ptBR }) : "Data não informada"}</p>
          </div>
        </TabsContent>

        <TabsContent value="edit" className="mt-6">
          <ShipEditForm ship={ship} />
        </TabsContent>
      </Tabs>
    );
  };

  const formatDateTime = (dateString: string | Date) => {
    try {
      const date = typeof dateString === 'string' ? new Date(dateString) : dateString;
      return format(date, "dd/MM HH:mm", { locale: ptBR });
    } catch {
      return typeof dateString === 'string' ? dateString : dateString.toString();
    }
  };

  const formatDate = (dateString: string | Date) => {
    try {
      const date = typeof dateString === 'string' ? new Date(dateString) : dateString;
      return format(date, "dd/MM/yyyy", { locale: ptBR });
    } catch {
      return typeof dateString === 'string' ? dateString : dateString.toString();
    }
  };



  const ShipRow = ({ ship, statusLabel, statusClass, timeLabel, timeValue, showMoveButton = false, showBarActions = false, showInstructionActions = false }: {
    ship: Ship;
    statusLabel: string;
    statusClass: string;
    timeLabel: string;
    timeValue: string;
    showMoveButton?: boolean;
    showBarActions?: boolean;
    showInstructionActions?: boolean;
  }) => (
    <div className="p-4 bg-white rounded-lg border border-gray-200 hover:shadow-sm transition-all">
      <div className="flex items-start justify-between mb-3">
        <div className="flex-1 min-w-0">
          <div className="flex items-start justify-between mb-2 gap-2">
            <div className="flex-1 min-w-0">
              <ClickableShipName shipId={ship.id} shipName={ship.name} statusLabel={statusLabel} />
            </div>
            <div className="flex-shrink-0">
              <Button
                variant="ghost"
                size="sm"
                className="text-blue-600 hover:text-blue-800 p-1 h-auto min-w-[32px]"
                title="Ver detalhes do navio"
                onClick={() => {
                  setInfoShipId(ship.id);
                  setInfoDialogOpen(true);
                }}
              >
                <Info className="w-4 h-4" />
              </Button>
            </div>
          </div>
          <div className="flex flex-wrap items-center gap-1 sm:gap-2 mb-2">
            <Badge className={statusClass} variant="outline">
              {statusLabel}
            </Badge>
            {ship.cargoAgent?.toUpperCase().includes('IMOPETRO') && (
              <Badge className="bg-red-100 text-red-800 text-xs">
                🚨 PRIORIDADE
              </Badge>
            )}
            {ship.operationType && (
              <Badge 
                className={`text-xs ${canEdit ? 'cursor-pointer transition-all hover:scale-105' : 'cursor-default'} ${
                  ship.operationType === 'nacional' ? 'bg-blue-100 text-blue-800' : 
                  ship.operationType === 'combinado' ? 'bg-purple-100 text-purple-800' : 
                  ship.operationType === 'LPG' ? 'bg-orange-100 text-orange-800' :
                  'bg-green-100 text-green-800'
                } ${canEdit ? (ship.operationType === 'nacional' ? 'hover:bg-blue-200' : 
                  ship.operationType === 'combinado' ? 'hover:bg-purple-200' : 
                  ship.operationType === 'LPG' ? 'hover:bg-orange-200' : 'hover:bg-green-200') : ''} 
                ${canEdit ? 'border-2 border-dashed' : ''}`}
                onClick={() => canEdit && handleToggleOperationType(ship.id, ship.operationType)}
                title={canEdit ? `Clique para alternar tipo (atual: ${ship.operationType === 'nacional' ? 'Nacional' : ship.operationType === 'combinado' ? 'Combinado' : ship.operationType === 'LPG' ? 'LPG' : 'Trânsito'})` : ''}
              >
                {ship.operationType === 'nacional' ? 'NACIONAL' : 
                 ship.operationType === 'combinado' ? 'COMBINADO' : 
                 ship.operationType === 'LPG' ? 'LPG' : 'TRÂNSITO'}
                {canEdit && <RefreshCw className="w-3 h-3 ml-1" />}
              </Badge>
            )}
          </div>
          <div className="space-y-1">
            <p className="text-sm text-gray-600">
              Calado: {ship.draft}m | {timeLabel}: {timeValue}
            </p>
            <p className="text-xs text-gray-500">
              Agente: {ship.shipAgent} | Tipo: {
                ship.operationType === 'nacional' ? 'Nacional' :
                ship.operationType === 'combinado' ? 'Combinado' :
                ship.operationType === 'transito' ? 'Trânsito' : 
                ship.operationType || 'Não informado'
              }
            </p>
          </div>
        </div>
      </div>
      
      {/* Action Buttons Section - Only show for users with edit permissions */}
      {canEdit && (
        <div className="mt-3 pt-3 border-t border-gray-100">
          {showMoveButton && onMoveToBar && (
            <div className="flex justify-end">
              <Button
                onClick={() => onMoveToBar(ship.id)}
                size="sm"
                className="bg-blue-600 hover:bg-blue-700 text-white min-w-[140px]"
              >
                <Waves className="w-3 h-3 mr-2" />
                Mover para Barra
              </Button>
            </div>
          )}
          
          {showBarActions && (
            <div className="flex justify-end">
              <Button
                onClick={() => onMoveToNext && onMoveToNext(ship.id)}
                size="sm"
                className="bg-green-600 hover:bg-green-700 text-white min-w-[100px]"
              >
                <ArrowUp className="w-3 h-3 mr-2" />
                Próximo
              </Button>
            </div>
          )}
          
          {showInstructionActions && (
            <div className="flex flex-col sm:flex-row gap-2">
              <Button
                onClick={() => onSendInstructionEmail && onSendInstructionEmail(ship.id)}
                size="sm"
                variant="outline"
                className="border-green-600 text-green-600 hover:bg-green-50 flex-1 min-w-[160px]"
              >
                <Mail className="w-3 h-3 mr-2" />
                Solicitar por Email
              </Button>
              <Button
                onClick={() => onMoveToNext && onMoveToNext(ship.id)}
                size="sm"
                className="bg-purple-600 hover:bg-purple-700 text-white flex-1 min-w-[200px]"
              >
                <ArrowUp className="w-3 h-3 mr-2" />
                Mover para Instrução de Descarga
              </Button>
            </div>
          )}
        </div>
      )}
    </div>
  );

  return (
    <Card className="overflow-hidden">
      <div className="bg-teal-50 border-b border-teal-200 px-6 py-4">
        <h3 className="text-lg font-semibold text-teal-800 flex items-center">
          <List className="mr-2" />
          Fila de Navios
        </h3>
      </div>
      
      <div className="divide-y divide-gray-200">
        {/* Ships with Discharge Instructions */}
        <div className="p-4">
          <h4 className="font-medium text-gray-700 mb-3 flex items-center">
            <CheckCircle className="mr-2 text-green-500" />
            Com Instrução de Descarga ({shipsWithInstructions.length})
          </h4>
          <div className="space-y-3">
            {shipsWithInstructions.length > 0 ? (
              shipsWithInstructions.map((ship) => (
                <ShipRow
                  key={ship.id}
                  ship={ship}
                  statusLabel="Pronto"
                  statusClass="bg-green-100 text-green-800 border-green-200"
                  timeLabel="Na Barra"
                  timeValue={formatDateTime(ship.arrivalDateTime)}
                  showBarActions={true}
                />
              ))
            ) : (
              <div className="text-center py-8 text-gray-500">
                <Ship className="w-8 h-8 mx-auto mb-2 text-gray-400" />
                <p>Nenhum navio com instrução de descarga</p>
              </div>
            )}
          </div>
        </div>

        {/* Ships without Discharge Instructions */}
        <div className="p-4">
          <h4 className="font-medium text-gray-700 mb-3 flex items-center">
            <Clock className="mr-2 text-orange-500" />
            Sem Instrução de Descarga ({shipsWithoutInstructions.length})
          </h4>
          <div className="space-y-3">
            {shipsWithoutInstructions.length > 0 ? (
              shipsWithoutInstructions.map((ship) => (
                <ShipRow
                  key={ship.id}
                  ship={ship}
                  statusLabel="Aguardando"
                  statusClass="bg-orange-100 text-orange-800 border-orange-200"
                  timeLabel="Na Barra desde"
                  timeValue={formatDateTime(ship.arrivalDateTime)}
                  showInstructionActions={true}
                />
              ))
            ) : (
              <div className="text-center py-8 text-gray-500">
                <Clock className="w-8 h-8 mx-auto mb-2 text-gray-400" />
                <p>Nenhum navio sem instrução de descarga</p>
              </div>
            )}
          </div>
        </div>

        {/* Expected Arrivals */}
        <div className="p-4">
          <h4 className="font-medium text-gray-700 mb-3 flex items-center">
            <Clock className="mr-2 text-blue-500" />
            Previstos para Chegar ({expectedArrivals.length})
          </h4>
          <div className="space-y-3">
            {expectedArrivals.length > 0 ? (
              expectedArrivals.map((ship) => (
                <ShipRow
                  key={ship.id}
                  ship={ship}
                  statusLabel="Previsto"
                  statusClass="bg-blue-100 text-blue-800 border-blue-200"
                  timeLabel="ETA"
                  timeValue={formatDateTime(ship.arrivalDateTime)}
                  showMoveButton={isOperator}
                />
              ))
            ) : (
              <div className="text-center py-8 text-gray-500">
                <Ship className="w-8 h-8 mx-auto mb-2 text-gray-400" />
                <p>Nenhum navio previsto</p>
              </div>
            )}
          </div>
        </div>

        {/* Recently Departed Ships */}
        <div className="p-4">
          <h4 className="font-medium text-gray-700 mb-3 flex items-center">
            <Ship className="mr-2 text-gray-500" />
            Desatracados Recentemente ({departedShips.slice(0, 5).length})
          </h4>
          <div className="space-y-3">
            {departedShips.slice(0, 5).length > 0 ? (
              departedShips.slice(0, 5).map((ship) => (
                <div
                  key={ship.id}
                  className="flex items-center justify-between p-3 bg-gray-50 rounded-lg border border-gray-200"
                >
                  <div className="flex-1">
                    <p className="font-medium text-gray-700">{ship.name}</p>
                    <p className="text-sm text-gray-500">
                      Desatracou: {ship.departedAt ? formatDate(ship.departedAt) : "Data não informada"}
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    <Button
                      variant="ghost"
                      size="sm"
                      className="text-blue-600 hover:text-blue-800 p-1 h-auto"
                      title="Ver histórico completo do navio"
                      onClick={() => {
                        setInfoShipId(ship.id);
                        setInfoDialogOpen(true);
                      }}
                    >
                      <Info className="w-4 h-4" />
                    </Button>
                    <Badge className="bg-gray-100 text-gray-600 border-gray-200" variant="outline">
                      Saído
                    </Badge>
                  </div>
                </div>
              ))
            ) : (
              <div className="text-center py-8 text-gray-500">
                <Ship className="w-8 h-8 mx-auto mb-2 text-gray-400" />
                <p>Nenhum navio desatracado recentemente</p>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Modal de Detalhes do Navio */}
      <ShipInfoModal
        isOpen={infoDialogOpen}
        shipId={infoShipId}
        onClose={() => setInfoDialogOpen(false)}
      />
    </Card>
  );
}
