import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { MessageCircle, Bot } from 'lucide-react';
import { VirtualAssistant } from './virtual-assistant';
import { useTranslation } from '@/contexts/LanguageContext';

interface AssistantChatButtonProps {
  user?: any;
}

export function AssistantChatButton({ user }: AssistantChatButtonProps) {
  const [isAssistantOpen, setIsAssistantOpen] = useState(false);
  const { t } = useTranslation();

  return (
    <>
      {/* Floating Chat Button */}
      <div className="fixed bottom-6 right-6 z-50">
        <Button
          onClick={() => setIsAssistantOpen(true)}
          className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white rounded-full w-16 h-16 shadow-2xl hover:shadow-3xl transition-all duration-300 animate-bounce"
          size="lg"
        >
          <div className="flex flex-col items-center">
            <Bot className="w-8 h-8" />
            <span className="text-xs mt-1">AI</span>
          </div>
        </Button>
        
        {/* Tooltip */}
        <div className="absolute bottom-20 right-0 bg-black text-white text-sm px-3 py-2 rounded-lg whitespace-nowrap shadow-lg transform translate-x-1/2 pointer-events-none">
          <div className="text-center">
            <div className="font-semibold">{t("Assistente Virtual") || "Virtual Assistant"}</div>
            <div className="text-xs opacity-75">Chat • Voz • Multilíngue</div>
          </div>
          {/* Arrow */}
          <div className="absolute top-full right-1/2 transform translate-x-1/2 w-0 h-0 border-l-4 border-r-4 border-t-4 border-transparent border-t-black"></div>
        </div>
      </div>

      {/* Virtual Assistant Modal */}
      <VirtualAssistant
        user={user}
        isOpen={isAssistantOpen}
        onClose={() => setIsAssistantOpen(false)}
      />
    </>
  );
}