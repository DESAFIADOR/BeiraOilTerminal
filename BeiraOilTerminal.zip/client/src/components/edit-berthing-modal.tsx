import { useState, useEffect } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Edit, Clock } from "lucide-react";

const editBerthingSchema = z.object({
  firstRopeTime: z.string().min(1, "Horário da primeira corda é obrigatório"),
  lastRopeTime: z.string().min(1, "Horário da última corda é obrigatório"),
});

type EditBerthingFormData = z.infer<typeof editBerthingSchema>;

interface EditBerthingModalProps {
  isOpen: boolean;
  onClose: () => void;
  shipId: number;
  shipName: string;
  currentBerthing?: {
    firstRopeTime: string;
    lastRopeTime: string;
  };
}

export function EditBerthingModal({ 
  isOpen, 
  onClose, 
  shipId, 
  shipName,
  currentBerthing 
}: EditBerthingModalProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const form = useForm<EditBerthingFormData>({
    resolver: zodResolver(editBerthingSchema),
    defaultValues: {
      firstRopeTime: "",
      lastRopeTime: "",
    }
  });

  // Reset form when currentBerthing data changes
  useEffect(() => {
    if (currentBerthing?.firstRopeTime && currentBerthing?.lastRopeTime) {
      // Extract date-time string directly without timezone conversion
      const firstTime = currentBerthing.firstRopeTime.slice(0, 16);
      const lastTime = currentBerthing.lastRopeTime.slice(0, 16);
      
      form.reset({
        firstRopeTime: firstTime,
        lastRopeTime: lastTime,
      });
    }
  }, [currentBerthing, form]);

  const mutation = useMutation({
    mutationFn: async (data: EditBerthingFormData) => {
      console.log("Enviando dados para backend:", {
        firstRopeTime: data.firstRopeTime,
        lastRopeTime: data.lastRopeTime,
      });
      
      await apiRequest(`/api/ships/${shipId}/berthing`, "PATCH", {
        firstRopeTime: data.firstRopeTime,
        lastRopeTime: data.lastRopeTime,
      });
    },
    onSuccess: () => {
      toast({
        title: "Sucesso",
        description: "Dados de atracação atualizados com sucesso.",
      });
      // Force refresh of berthing data by removing and refetching
      queryClient.removeQueries({ queryKey: [`/api/ships/${shipId}/berthing`] });
      queryClient.invalidateQueries({ queryKey: [`/api/ships/${shipId}/berthing`] });
      // Also invalidate ship data in case it includes berthing info
      queryClient.invalidateQueries({ queryKey: ["/api/ships"] });
      queryClient.invalidateQueries({ queryKey: [`/api/ships/${shipId}`] });
      onClose();
    },
    onError: (error: Error) => {
      toast({
        title: "Erro",
        description: error.message || "Falha ao atualizar dados de atracação.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: EditBerthingFormData) => {
    mutation.mutate(data);
  };

  const handleClose = () => {
    form.reset();
    onClose();
  };

  console.log("EditBerthingModal render", { isOpen, shipId, shipName, currentBerthing });

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[9999] bg-black bg-opacity-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-lg shadow-xl max-w-md w-full max-h-[90vh] overflow-y-auto">
        <div className="p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold flex items-center gap-2">
              <Edit className="w-5 h-5 text-blue-600" />
              Editar Dados de Atracação
            </h2>
            <button 
              onClick={handleClose}
              className="text-gray-400 hover:text-gray-600 text-xl font-bold"
            >
              ×
            </button>
          </div>
          <p className="text-sm text-gray-600 mb-6">
            Editando dados de atracação para: <strong>{shipName}</strong>
          </p>

          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <div>
              <label className="flex items-center gap-2 text-sm font-medium text-gray-700 mb-2">
                <Clock className="w-4 h-4" />
                Horário da Primeira Corda
              </label>
              <input
                type="datetime-local"
                {...form.register("firstRopeTime")}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
              {form.formState.errors.firstRopeTime && (
                <p className="text-red-500 text-sm mt-1">{form.formState.errors.firstRopeTime.message}</p>
              )}
            </div>

            <div>
              <label className="flex items-center gap-2 text-sm font-medium text-gray-700 mb-2">
                <Clock className="w-4 h-4" />
                Horário da Última Corda
              </label>
              <input
                type="datetime-local"
                {...form.register("lastRopeTime")}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
              {form.formState.errors.lastRopeTime && (
                <p className="text-red-500 text-sm mt-1">{form.formState.errors.lastRopeTime.message}</p>
              )}
            </div>

            <div className="flex gap-3 pt-4">
              <button
                type="button"
                onClick={handleClose}
                disabled={mutation.isPending}
                className="flex-1 px-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-blue-500 disabled:opacity-50"
              >
                Cancelar
              </button>
              <button
                type="submit"
                disabled={mutation.isPending}
                className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 disabled:opacity-50"
              >
                {mutation.isPending ? "Salvando..." : "Salvar"}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}