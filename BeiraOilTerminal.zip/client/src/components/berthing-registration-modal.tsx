import { useState } from "react";
import * as React from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Anchor, Clock } from "lucide-react";

const berthingSchema = z.object({
  shipId: z.number().min(1, "Selecione um navio"),
  firstRopeTime: z.string().min(1, "Horário da primeira corda é obrigatório"),
  lastRopeTime: z.string().min(1, "Horário da última corda é obrigatório"),
});

type BerthingFormData = z.infer<typeof berthingSchema>;

interface BerthingRegistrationModalProps {
  isOpen: boolean;
  onClose: () => void;
  shipId?: number | null;
}

export function BerthingRegistrationModal({ isOpen, onClose, shipId }: BerthingRegistrationModalProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Get ships that are at berth or next to berth
  const { data: ships = [] } = useQuery({
    queryKey: ["/api/ships"],
    enabled: isOpen,
  });

  const eligibleShips = (ships as any[] || []).filter((ship: any) => 
    ship.status === "next_to_berth"
  );

  // Use the shipId passed as prop or the first eligible ship
  const selectedShipId = shipId || (eligibleShips.length > 0 ? eligibleShips[0].id : null);
  const { data: berthingData } = useQuery({
    queryKey: ["/api/ships", selectedShipId, "berthing"],
    enabled: isOpen && selectedShipId !== null,
  });

  // Check if berthing data already exists and is complete
  const hasBerthingData = berthingData && (berthingData as any).firstRopeTime && (berthingData as any).lastRopeTime;

  const form = useForm<BerthingFormData>({
    resolver: zodResolver(berthingSchema),
    defaultValues: {
      shipId: eligibleShips.length > 0 ? eligibleShips[0].id : undefined,
      firstRopeTime: "",
      lastRopeTime: "",
    },
  });

  const mutation = useMutation({
    mutationFn: async (data: BerthingFormData) => {
      // First register the berthing
      await apiRequest("/api/ships/berthing", "POST", data);
      
      // Then automatically move the ship to at_berth status
      await apiRequest(`/api/ships/${data.shipId}/status`, "PATCH", {
        status: "at_berth"
      });
    },
    onSuccess: (_, data) => {
      toast({
        title: "Sucesso",
        description: "Atracação registrada e navio movido para o cais com sucesso.",
      });
      // Invalidate all ship data to refresh general info
      queryClient.invalidateQueries({ queryKey: ["/api/ships"] });
      // Invalidate specific berthing record for the registered ship
      queryClient.invalidateQueries({ queryKey: ["/api/ships", data.shipId, "berthing"] });
      // Invalidate all berthing records to ensure complete sync
      queryClient.invalidateQueries({ queryKey: ["/api/ships", "berthing"] });
      form.reset({
        shipId: eligibleShips.length > 0 ? eligibleShips[0].id : undefined,
        firstRopeTime: "",
        lastRopeTime: "",
      });
      onSuccess();
      onClose();
    },
    onError: (error: Error) => {
      toast({
        title: "Erro",
        description: error.message || "Falha ao registrar atracação.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: BerthingFormData) => {
    mutation.mutate(data);
  };

  const handleClose = () => {
    form.reset({
      shipId: eligibleShips.length > 0 ? eligibleShips[0].id : undefined,
      firstRopeTime: "",
      lastRopeTime: "",
    });
    onClose();
  };

  // If berthing data already exists, show simplified confirmation view
  if (hasBerthingData && eligibleShips.length > 0) {
    const selectedShip = eligibleShips[0];
    return (
      <Dialog open={isOpen} onOpenChange={handleClose}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Anchor className="w-5 h-5 text-green-600" />
              Confirmação de Atracação
            </DialogTitle>
            <DialogDescription>
              Dados de atracação já registrados para este navio.
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4">
            {/* Ship Information */}
            <div className="bg-green-50 p-4 rounded-lg border border-green-200">
              <h3 className="font-semibold text-green-800 mb-2">{selectedShip.name}</h3>
              <p className="text-sm text-green-700">Contra Marca: {selectedShip.countermark}</p>
            </div>

            {/* Berthing Data Summary */}
            <div className="bg-gray-50 p-4 rounded-lg space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-sm font-medium text-gray-600">Primeira Corda:</span>
                <span className="text-sm text-gray-900">
                  {new Date((berthingData as any).firstRopeTime).toLocaleDateString('pt-BR', {
                    day: '2-digit',
                    month: '2-digit',
                    year: 'numeric',
                    timeZone: 'Africa/Maputo'
                  })} {new Date((berthingData as any).firstRopeTime).toLocaleTimeString('pt-BR', {
                    hour: '2-digit',
                    minute: '2-digit',
                    timeZone: 'Africa/Maputo'
                  })}
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm font-medium text-gray-600">Última Corda:</span>
                <span className="text-sm text-gray-900">
                  {new Date((berthingData as any).lastRopeTime).toLocaleDateString('pt-BR', {
                    day: '2-digit',
                    month: '2-digit',
                    year: 'numeric',
                    timeZone: 'Africa/Maputo'
                  })} {new Date((berthingData as any).lastRopeTime).toLocaleTimeString('pt-BR', {
                    hour: '2-digit',
                    minute: '2-digit',
                    timeZone: 'Africa/Maputo'
                  })}
                </span>
              </div>
            </div>

            <div className="flex gap-3 pt-4">
              <Button
                type="button"
                onClick={handleClose}
                className="flex-1"
              >
                Fechar
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    );
  }

  // Normal registration form when no berthing data exists
  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Anchor className="w-5 h-5 text-orange-600" />
            Atracação do Navio
          </DialogTitle>
          <DialogDescription>
            Registre os horários da primeira e última corda para documentar oficialmente a atracação do navio.
          </DialogDescription>
        </DialogHeader>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="shipId"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Navio</FormLabel>
                  <Select onValueChange={(value) => field.onChange(parseInt(value))}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Selecione um navio" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {eligibleShips.map((ship: any) => (
                        <SelectItem key={ship.id} value={ship.id.toString()}>
                          {ship.name} - {ship.countermark}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="firstRopeTime"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="flex items-center gap-2">
                    <Clock className="w-4 h-4" />
                    Horário da Primeira Corda
                  </FormLabel>
                  <FormControl>
                    <Input
                      type="datetime-local"
                      {...field}
                      className="w-full"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="lastRopeTime"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="flex items-center gap-2">
                    <Clock className="w-4 h-4" />
                    Horário da Última Corda
                  </FormLabel>
                  <FormControl>
                    <Input
                      type="datetime-local"
                      {...field}
                      className="w-full"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="flex gap-3 pt-4">
              <Button
                type="button"
                variant="outline"
                onClick={handleClose}
                className="flex-1"
              >
                Cancelar
              </Button>
              <Button
                type="submit"
                disabled={mutation.isPending}
                className="flex-1 bg-orange-600 hover:bg-orange-700"
              >
                {mutation.isPending ? "Registrando..." : "Registrar Atracação"}
              </Button>
            </div>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}