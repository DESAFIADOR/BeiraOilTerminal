import React, { useEffect } from 'react';

export function EmergencyDiagnostic() {
  useEffect(() => {
    console.log('🚨 DIAGNÓSTICO RADICAL - BOTÕES NÃO FUNCIONAM!');
    
    // Teste 1: Verificar se eventos estão sendo bloqueados globalmente
    const testEventBlocking = () => {
      console.log('TESTE 1: Verificando bloqueio de eventos...');
      
      document.addEventListener('click', (e) => {
        console.log('EVENTO CLICK GLOBAL DETECTADO:', e.target);
      }, true); // Capture phase
      
      document.addEventListener('mousedown', (e) => {
        console.log('EVENTO MOUSEDOWN GLOBAL DETECTADO:', e.target);
      }, true);
    };
    
    // Teste 2: Criar elemento simples com inline handlers
    const testInlineHandlers = () => {
      console.log('TESTE 2: Criando elemento com handlers inline...');
      
      const div = document.createElement('div');
      div.innerHTML = `
        <button 
          onclick="console.log('INLINE ONCLICK FUNCIONOU!'); alert('INLINE OK!')"
          onmousedown="console.log('INLINE MOUSEDOWN FUNCIONOU!')"
          style="position:fixed; top:100px; left:100px; z-index:999999; background:green; color:white; padding:20px; font-size:18px; border:3px solid white; cursor:pointer;"
        >
          TESTE INLINE
        </button>
      `;
      document.body.appendChild(div);
    };
    
    // Teste 3: Verificar se há overlay invisible bloqueando eventos
    const testInvisibleOverlay = () => {
      console.log('TESTE 3: Verificando overlays invisíveis...');
      
      const elements = document.elementsFromPoint(window.innerWidth/2, window.innerHeight/2);
      console.log('ELEMENTOS NO CENTRO DA TELA:', elements);
      
      // Verificar z-index de todos os elementos
      elements.forEach((el, index) => {
        const style = window.getComputedStyle(el);
        console.log(`Elemento ${index}:`, {
          tag: el.tagName,
          id: el.id,
          className: el.className,
          zIndex: style.zIndex,
          pointerEvents: style.pointerEvents,
          position: style.position
        });
      });
    };
    
    // Teste 4: Forçar eventos programaticamente
    const testProgrammaticEvents = () => {
      console.log('TESTE 4: Testando eventos programáticos...');
      
      setTimeout(() => {
        const btn = document.createElement('button');
        btn.innerHTML = 'TESTE PROGRAMÁTICO';
        btn.style.cssText = `
          position: fixed;
          top: 150px;
          left: 150px;
          z-index: 999999;
          background: purple;
          color: white;
          padding: 20px;
          font-size: 18px;
        `;
        
        btn.addEventListener('click', () => {
          console.log('EVENTO PROGRAMÁTICO DETECTADO!');
          alert('PROGRAMÁTICO OK!');
        });
        
        document.body.appendChild(btn);
        
        // Simular clique automático
        setTimeout(() => {
          console.log('SIMULANDO CLIQUE AUTOMÁTICO...');
          btn.click();
        }, 1000);
        
      }, 500);
    };
    
    // Teste 5: Verificar se há preventDefault sendo chamado globalmente
    const testPreventDefault = () => {
      console.log('TESTE 5: Verificando preventDefault global...');
      
      const originalPreventDefault = Event.prototype.preventDefault;
      Event.prototype.preventDefault = function() {
        console.log('PREVENTDEFAULT CHAMADO EM:', this.type, this.target);
        return originalPreventDefault.call(this);
      };
    };
    
    // Executar todos os testes
    testEventBlocking();
    testInlineHandlers();
    testInvisibleOverlay();
    testProgrammaticEvents();
    testPreventDefault();
    
  }, []);

  return null; // Componente invisível
}