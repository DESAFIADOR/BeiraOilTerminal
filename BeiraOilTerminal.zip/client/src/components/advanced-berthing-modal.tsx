import { useState, useEffect, useRef } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent } from '@/components/ui/card';
import { Anchor, Clock, Calendar, Ship, X } from 'lucide-react';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';

interface AdvancedBerthingModalProps {
  isOpen: boolean;
  onClose: () => void;
  ship: any;
}

export function AdvancedBerthingModal({ isOpen, onClose, ship }: AdvancedBerthingModalProps) {
  const [firstRopeDate, setFirstRopeDate] = useState('');
  const [firstRopeTime, setFirstRopeTime] = useState('');
  const [lastRopeDate, setLastRopeDate] = useState('');
  const [lastRopeTime, setLastRopeTime] = useState('');
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const modalRef = useRef<HTMLDivElement>(null);

  // Set default date to today
  useEffect(() => {
    if (isOpen && !firstRopeDate) {
      const today = new Date();
      const dateStr = today.toISOString().split('T')[0];
      setFirstRopeDate(dateStr);
      setLastRopeDate(dateStr);
    }
  }, [isOpen, firstRopeDate]);

  const confirmBerthingMutation = useMutation({
    mutationFn: async (berthingData: any) => {
      console.log('Submitting berthing data:', berthingData);
      
      // Record berthing data using the correct endpoint
      const response = await fetch('/api/ships/berthing', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify(berthingData),
      });
      
      if (!response.ok) {
        const errorData = await response.json();
        if (errorData.error === 'BERTH_OCCUPIED') {
          throw new Error(errorData.message || 'Berço ocupado por outro navio');
        }
        throw new Error(errorData.message || 'Failed to register berthing');
      }
      
      const berthingResponse = await response.json();
      console.log('Berthing recorded:', berthingResponse);
      
      return berthingResponse;
    },
    onSuccess: () => {
      toast({
        title: "Atracação Confirmada",
        description: `${ship.name} movido automaticamente para o Cais 12 após confirmação da última corda`,
      });
      queryClient.invalidateQueries({ queryKey: ['/api/ships'] });
      queryClient.invalidateQueries({ queryKey: ['/api/berthing-records'] });
      onClose();
      resetForm();
    },
    onError: (error: any) => {
      console.error('Berthing confirmation error:', error);
      toast({
        title: "Erro na Confirmação",
        description: error.message || "Erro ao confirmar atracação",
        variant: "destructive",
      });
    },
  });

  const handleConfirm = (e: React.FormEvent) => {
    e.preventDefault();
    e.stopPropagation();
    
    console.log('handleConfirm called');
    console.log('Form data:', { firstRopeDate, firstRopeTime, lastRopeDate, lastRopeTime });

    if (!firstRopeDate || !firstRopeTime || !lastRopeDate || !lastRopeTime) {
      toast({
        title: "Campos Obrigatórios",
        description: "Preencha todos os campos de data e hora",
        variant: "destructive",
      });
      return;
    }

    // Combine date and time for both ropes
    const firstRopeDateTime = new Date(`${firstRopeDate}T${firstRopeTime}`);
    const lastRopeDateTime = new Date(`${lastRopeDate}T${lastRopeTime}`);

    if (lastRopeDateTime <= firstRopeDateTime) {
      toast({
        title: "Erro de Data",
        description: "A última corda deve ser após a primeira corda",
        variant: "destructive",
      });
      return;
    }

    const berthingData = {
      shipId: ship.id,
      firstRopeTime: firstRopeDateTime.toISOString(),
      lastRopeTime: lastRopeDateTime.toISOString(),
    };

    console.log('Submitting berthing data:', berthingData);
    confirmBerthingMutation.mutate(berthingData);
  };

  const resetForm = () => {
    setFirstRopeDate('');
    setFirstRopeTime('');
    setLastRopeDate('');
    setLastRopeTime('');
  };

  const handleClose = () => {
    resetForm();
    onClose();
  };

  if (!ship) return null;

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent 
        ref={modalRef}
        className="sm:max-w-[500px] max-h-[90vh] overflow-y-auto"
        onPointerDownOutside={(e) => e.preventDefault()}
        onEscapeKeyDown={(e) => e.preventDefault()}
      >
        <DialogHeader className="space-y-3">
          <div className="flex items-center justify-between">
            <DialogTitle className="flex items-center gap-2 text-xl font-bold text-purple-700">
              <Anchor className="w-6 h-6" />
              Confirmação de Atracação
            </DialogTitle>
            <Button
              variant="ghost"
              size="sm"
              onClick={handleClose}
              className="h-8 w-8 p-0 hover:bg-gray-100"
            >
              <X className="h-4 w-4" />
            </Button>
          </div>
          
          <Card className="bg-blue-50 border-blue-200">
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <Ship className="w-8 h-8 text-blue-600" />
                <div>
                  <h3 className="font-semibold text-blue-900">{ship.name}</h3>
                  <p className="text-sm text-blue-700">Contramatrícula: {ship.countermark}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </DialogHeader>

        <form onSubmit={handleConfirm} className="space-y-6">
          {/* First Rope Section */}
          <Card className="border-green-200">
            <CardContent className="p-4 space-y-4">
              <div className="flex items-center gap-2 text-green-700 font-medium">
                <Clock className="w-5 h-5" />
                Primeira Corda
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="firstRopeDate" className="text-sm font-medium">Data</Label>
                  <div className="relative">
                    <Calendar className="absolute left-3 top-3 w-4 h-4 text-gray-400" />
                    <Input
                      id="firstRopeDate"
                      type="date"
                      value={firstRopeDate}
                      onChange={(e) => setFirstRopeDate(e.target.value)}
                      className="pl-10"
                      required
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="firstRopeTime" className="text-sm font-medium">Hora</Label>
                  <div className="relative">
                    <Clock className="absolute left-3 top-3 w-4 h-4 text-gray-400" />
                    <Input
                      id="firstRopeTime"
                      type="time"
                      value={firstRopeTime}
                      onChange={(e) => setFirstRopeTime(e.target.value)}
                      className="pl-10"
                      required
                    />
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Last Rope Section */}
          <Card className="border-red-200">
            <CardContent className="p-4 space-y-4">
              <div className="flex items-center gap-2 text-red-700 font-medium">
                <Clock className="w-5 h-5" />
                Última Corda
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="lastRopeDate" className="text-sm font-medium">Data</Label>
                  <div className="relative">
                    <Calendar className="absolute left-3 top-3 w-4 h-4 text-gray-400" />
                    <Input
                      id="lastRopeDate"
                      type="date"
                      value={lastRopeDate}
                      onChange={(e) => setLastRopeDate(e.target.value)}
                      className="pl-10"
                      required
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="lastRopeTime" className="text-sm font-medium">Hora</Label>
                  <div className="relative">
                    <Clock className="absolute left-3 top-3 w-4 h-4 text-gray-400" />
                    <Input
                      id="lastRopeTime"
                      type="time"
                      value={lastRopeTime}
                      onChange={(e) => setLastRopeTime(e.target.value)}
                      className="pl-10"
                      required
                    />
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Action Buttons */}
          <div className="flex gap-3 pt-4">
            <Button
              type="button"
              variant="outline"
              onClick={handleClose}
              className="flex-1"
              disabled={confirmBerthingMutation.isPending}
            >
              Cancelar
            </Button>
            <Button
              type="submit"
              className="flex-1 bg-purple-600 hover:bg-purple-700"
              disabled={confirmBerthingMutation.isPending}
            >
              {confirmBerthingMutation.isPending ? (
                <>
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
                  Confirmando...
                </>
              ) : (
                <>
                  <Anchor className="w-4 h-4 mr-2" />
                  Confirmar Atracação
                </>
              )}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}