import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  Cloud, Thermometer, Droplets, Wind, Eye, Gauge, 
  Sun, CloudRain, AlertTriangle 
} from "lucide-react";

interface WeatherDetailsModalProps {
  isOpen: boolean;
  onClose: () => void;
  weatherData: any;
}

export function WeatherDetailsModal({ isOpen, onClose, weatherData }: WeatherDetailsModalProps) {
  if (!weatherData) return null;

  const getWeatherIcon = (description: string) => {
    const desc = description?.toLowerCase() || '';
    if (desc.includes('rain') || desc.includes('chuva')) return <CloudRain className="w-6 h-6" />;
    if (desc.includes('cloud') || desc.includes('nuvem')) return <Cloud className="w-6 h-6" />;
    return <Sun className="w-6 h-6" />;
  };

  const getWindDirection = (degrees: number) => {
    const directions = ['N', 'NNE', 'NE', 'ENE', 'E', 'ESE', 'SE', 'SSE', 'S', 'SSW', 'SW', 'WSW', 'W', 'WNW', 'NW', 'NNW'];
    return directions[Math.round(degrees / 22.5) % 16];
  };

  const getVisibilityStatus = (visibility: number) => {
    if (visibility >= 10) return { text: 'Excelente', color: 'bg-green-100 text-green-800' };
    if (visibility >= 5) return { text: 'Boa', color: 'bg-blue-100 text-blue-800' };
    if (visibility >= 2) return { text: 'Moderada', color: 'bg-yellow-100 text-yellow-800' };
    return { text: 'Limitada', color: 'bg-red-100 text-red-800' };
  };

  const getWindAlert = (speed: number) => {
    if (speed >= 25) return { text: 'Vento Forte - Operações com Cuidado', color: 'bg-red-100 text-red-800', show: true };
    if (speed >= 15) return { text: 'Vento Moderado - Monitorar Condições', color: 'bg-yellow-100 text-yellow-800', show: true };
    return { show: false };
  };

  const visibilityStatus = getVisibilityStatus(weatherData.visibility / 1000);
  const windAlert = getWindAlert(weatherData.windSpeed);

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-xl">
            <Cloud className="w-6 h-6 text-blue-600" />
            Condições Meteorológicas Detalhadas - Porto da Beira
          </DialogTitle>
        </DialogHeader>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mt-4">
          {/* Temperatura */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-sm">
                <Thermometer className="w-4 h-4 text-red-500" />
                Temperatura
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <div className="text-2xl font-bold text-center">
                  {weatherData.temperature}°C
                </div>
                <div className="text-sm text-gray-600 space-y-1">
                  <div className="flex justify-between">
                    <span>Sensação Térmica:</span>
                    <span className="font-semibold">{weatherData.feelsLike || 'N/A'}°C</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Máxima:</span>
                    <span className="font-semibold">{weatherData.tempMax || 'N/A'}°C</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Mínima:</span>
                    <span className="font-semibold">{weatherData.tempMin || 'N/A'}°C</span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Umidade e Pressão */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-sm">
                <Droplets className="w-4 h-4 text-blue-500" />
                Umidade e Pressão
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Droplets className="w-4 h-4 text-blue-400" />
                    <span className="text-sm">Umidade:</span>
                  </div>
                  <span className="font-semibold">{weatherData.humidity}%</span>
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Gauge className="w-4 h-4 text-gray-500" />
                    <span className="text-sm">Pressão:</span>
                  </div>
                  <span className="font-semibold">{weatherData.pressure} hPa</span>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Vento */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-sm">
                <Wind className="w-4 h-4 text-green-500" />
                Condições do Vento
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <div className="text-lg font-bold text-center">
                  {weatherData.windSpeed} nós
                </div>
                <div className="text-sm text-gray-600 space-y-1">
                  <div className="flex justify-between">
                    <span>Direção:</span>
                    <span className="font-semibold">
                      {getWindDirection(weatherData.windDirection)} ({weatherData.windDirection}°)
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span>Rajadas:</span>
                    <span className="font-semibold">{weatherData.windGust || 'N/A'} nós</span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Visibilidade */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-sm">
                <Eye className="w-4 h-4 text-purple-500" />
                Visibilidade
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="text-lg font-bold text-center">
                  {(weatherData.visibility / 1000).toFixed(1)} km
                </div>
                <Badge className={`w-full justify-center ${visibilityStatus.color}`}>
                  {visibilityStatus.text}
                </Badge>
              </div>
            </CardContent>
          </Card>

          {/* Condições Gerais */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-sm">
                {getWeatherIcon(weatherData.description)}
                Condições Atuais
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <div className="text-sm font-semibold text-center">
                  {weatherData.description || 'Condições Normais'}
                </div>
                <div className="text-xs text-gray-500 text-center">
                  Última atualização: {new Date().toLocaleTimeString('pt-BR')}
                </div>
              </div>
            </CardContent>
          </Card>

          {/* UV Index */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-sm">
                <Sun className="w-4 h-4 text-yellow-500" />
                Índice UV
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <div className="text-lg font-bold text-center">
                  {weatherData.uvIndex || 'N/A'}
                </div>
                <div className="text-xs text-gray-500 text-center">
                  {weatherData.uvIndex <= 2 ? 'Baixo' : 
                   weatherData.uvIndex <= 5 ? 'Moderado' : 
                   weatherData.uvIndex <= 7 ? 'Alto' : 
                   weatherData.uvIndex <= 10 ? 'Muito Alto' : 'Extremo'}
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Alertas */}
        {windAlert.show && (
          <div className="mt-4">
            <div className={`p-3 rounded-lg flex items-center gap-2 ${windAlert.color}`}>
              <AlertTriangle className="w-5 h-5" />
              <span className="font-semibold">{windAlert.text}</span>
            </div>
          </div>
        )}

        {/* Informações Operacionais */}
        <Card className="mt-4">
          <CardHeader>
            <CardTitle className="text-sm">Recomendações Operacionais</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2 text-sm">
              <div className="flex items-start gap-2">
                <span className="font-semibold">•</span>
                <span>
                  {weatherData.windSpeed >= 25 
                    ? "Condições de vento forte. Considere suspender operações de atracação."
                    : weatherData.windSpeed >= 15
                    ? "Vento moderado. Monitorar condições durante operações."
                    : "Condições de vento favoráveis para operações portuárias."}
                </span>
              </div>
              <div className="flex items-start gap-2">
                <span className="font-semibold">•</span>
                <span>
                  {weatherData.visibility < 2000
                    ? "Visibilidade limitada. Extrema precaução durante navegação."
                    : weatherData.visibility < 5000
                    ? "Visibilidade moderada. Atenção redobrada durante manobras."
                    : "Visibilidade adequada para operações normais."}
                </span>
              </div>
            </div>
          </CardContent>
        </Card>
      </DialogContent>
    </Dialog>
  );
}