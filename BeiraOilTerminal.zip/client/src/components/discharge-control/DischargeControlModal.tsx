import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Anchor, Clock, AlertTriangle, Play, Pause, Square, BarChart3, Users, FileText } from "lucide-react";
import { format } from "date-fns";

interface DischargeControlModalProps {
  isOpen: boolean;
  onClose: () => void;
  ship: any;
}

export function DischargeControlModal({ isOpen, onClose, ship }: DischargeControlModalProps) {
  // All hooks must be called unconditionally at the top level
  const [activeTab, setActiveTab] = useState("events");
  const queryClient = useQueryClient();

  // Data queries - must be called unconditionally
  const { data: events = [] } = useQuery({
    queryKey: ['/api/ships', ship?.id, 'discharge-events'],
    enabled: isOpen && !!ship?.id
  });

  const { data: parcelControls = [] } = useQuery({
    queryKey: ['/api/ships', ship?.id, 'parcel-controls'],
    enabled: isOpen && !!ship?.id
  });

  const { data: hourlyRecords = [] } = useQuery({
    queryKey: ['/api/ships', ship?.id, 'hourly-records'],
    enabled: isOpen && !!ship?.id
  });

  const { data: stoppages = [] } = useQuery({
    queryKey: ['/api/ships', ship?.id, 'stoppages'],
    enabled: isOpen && !!ship?.id
  });

  const { data: waitingTimes = [] } = useQuery({
    queryKey: ['/api/ships', ship?.id, 'waiting-times'],
    enabled: isOpen && !!ship?.id
  });

  const { data: dischargeReport } = useQuery({
    queryKey: ['/api/ships', ship?.id, 'discharge-report'],
    enabled: isOpen && !!ship?.id
  });

  // Conditional rendering after all hooks
  if (!ship) {
    return (
      <Dialog open={isOpen} onOpenChange={onClose}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Anchor className="w-6 h-6" />
              Controlo de Descarga
            </DialogTitle>
          </DialogHeader>
          <div className="p-8 text-center">
            <div className="mb-6">
              <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Anchor className="w-8 h-8 text-gray-400" />
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">
                Nenhum Navio no Cais
              </h3>
              <p className="text-gray-600">
                O sistema de controlo de descarga está disponível quando há um navio atracado no cais. 
                Aguarde até que um navio seja movido para o cais para aceder às funcionalidades de descarga.
              </p>
            </div>
            <div className="space-y-4">
              <div className="flex items-center justify-center gap-4 text-sm text-gray-500">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                  <span>Sistema Operacional</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 bg-blue-500 rounded-full"></div>
                  <span>Aguardando Navio</span>
                </div>
              </div>
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <p className="text-sm text-blue-800">
                  <strong>Funcionalidades disponíveis:</strong><br />
                  • Eventos de descarga<br />
                  • Controlo de parcelas<br />
                  • Registos horários<br />
                  • Gestão de paragens<br />
                  • Controlo de tempos de espera<br />
                  • Relatórios de descarga
                </p>
              </div>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    );
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-7xl h-[800px] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Anchor className="w-6 h-6" />
            Controlo de Descarga - {ship.name}
          </DialogTitle>
        </DialogHeader>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-6">
            <TabsTrigger value="events" className="flex items-center gap-1">
              <Clock className="h-4 w-4" />
              Eventos
            </TabsTrigger>
            <TabsTrigger value="parcels" className="flex items-center gap-1">
              <BarChart3 className="h-4 w-4" />
              Parcelas
            </TabsTrigger>
            <TabsTrigger value="hourly" className="flex items-center gap-1">
              <Clock className="h-4 w-4" />
              Registos Horários
            </TabsTrigger>
            <TabsTrigger value="stoppages" className="flex items-center gap-1">
              <AlertTriangle className="h-4 w-4" />
              Paragens
            </TabsTrigger>
            <TabsTrigger value="waiting" className="flex items-center gap-1">
              <Users className="h-4 w-4" />
              Esperas
            </TabsTrigger>
            <TabsTrigger value="report" className="flex items-center gap-1">
              <FileText className="h-4 w-4" />
              Relatório
            </TabsTrigger>
          </TabsList>

          <TabsContent value="events" className="space-y-4">
            <DischargeEventsTab shipId={ship.id} events={events} />
          </TabsContent>

          <TabsContent value="parcels" className="space-y-4">
            <ParcelControlTab shipId={ship.id} controls={parcelControls} />
          </TabsContent>

          <TabsContent value="hourly" className="space-y-4">
            <HourlyRecordsTab shipId={ship.id} records={hourlyRecords} />
          </TabsContent>

          <TabsContent value="stoppages" className="space-y-4">
            <StoppagesTab shipId={ship.id} stoppages={stoppages} />
          </TabsContent>

          <TabsContent value="waiting" className="space-y-4">
            <WaitingTimesTab shipId={ship.id} waitingTimes={waitingTimes} />
          </TabsContent>

          <TabsContent value="report" className="space-y-4">
            <DischargeReportTab report={dischargeReport} />
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}

// Tab Components with default implementations to prevent crashes
function DischargeEventsTab({ shipId, events }: { shipId: number; events: any[] }) {
  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle>Eventos de Descarga</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-gray-600">Sistema de eventos de descarga disponível.</p>
          {events.length > 0 ? (
            <div className="space-y-2">
              {events.map((event: any, index: number) => (
                <div key={index} className="border rounded p-2">
                  <p>{event.description || 'Evento de descarga'}</p>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-sm text-gray-500">Nenhum evento registado.</p>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

function ParcelControlTab({ shipId, controls }: { shipId: number; controls: any[] }) {
  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle>Controlo de Parcelas</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-gray-600">Sistema de controlo de parcelas disponível.</p>
          {controls.length > 0 ? (
            <div className="space-y-2">
              {controls.map((control: any, index: number) => (
                <div key={index} className="border rounded p-2">
                  <p>{control.description || 'Controlo de parcela'}</p>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-sm text-gray-500">Nenhum controlo registado.</p>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

function HourlyRecordsTab({ shipId, records }: { shipId: number; records: any[] }) {
  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle>Registos Horários</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-gray-600">Sistema de registos horários disponível.</p>
          {records.length > 0 ? (
            <div className="space-y-2">
              {records.map((record: any, index: number) => (
                <div key={index} className="border rounded p-2">
                  <p>{record.description || 'Registo horário'}</p>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-sm text-gray-500">Nenhum registo disponível.</p>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

function StoppagesTab({ shipId, stoppages }: { shipId: number; stoppages: any[] }) {
  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle>Gestão de Paragens</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-gray-600">Sistema de gestão de paragens disponível.</p>
          {stoppages.length > 0 ? (
            <div className="space-y-2">
              {stoppages.map((stoppage: any, index: number) => (
                <div key={index} className="border rounded p-2">
                  <p>{stoppage.description || 'Paragem registada'}</p>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-sm text-gray-500">Nenhuma paragem registada.</p>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

function WaitingTimesTab({ shipId, waitingTimes }: { shipId: number; waitingTimes: any[] }) {
  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle>Controlo de Tempos de Espera</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-gray-600">Sistema de controlo de tempos de espera disponível.</p>
          {waitingTimes.length > 0 ? (
            <div className="space-y-2">
              {waitingTimes.map((waitTime: any, index: number) => (
                <div key={index} className="border rounded p-2">
                  <p>{waitTime.description || 'Tempo de espera'}</p>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-sm text-gray-500">Nenhum tempo de espera registado.</p>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

function DischargeReportTab({ report }: { report: any }) {
  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle>Relatório de Descarga</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-gray-600">Sistema de relatórios de descarga disponível.</p>
          {report ? (
            <div className="space-y-2">
              <p>{report.summary || 'Relatório de descarga disponível'}</p>
            </div>
          ) : (
            <p className="text-sm text-gray-500">Nenhum relatório disponível.</p>
          )}
        </CardContent>
      </Card>
    </div>
  );
}