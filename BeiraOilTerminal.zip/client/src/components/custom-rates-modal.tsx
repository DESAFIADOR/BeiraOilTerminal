import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { 
  Settings, Save, RefreshCw, Package, Clock, TrendingUp, 
  Edit, Check, X, AlertTriangle, Calculator, Info
} from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { Ship, CargoParcel } from "@shared/schema";

interface CustomRatesModalProps {
  isOpen: boolean;
  onClose: () => void;
}

interface ParcelRateConfig {
  parcelId: number;
  product: string;
  receiver: string;
  volumeM3: number;
  defaultRate: number;
  customRate?: number;
  estimatedDuration: number;
  notes?: string;
}

interface ShipRateConfig {
  shipId: number;
  shipName: string;
  parcels: ParcelRateConfig[];
}

export function CustomRatesModal({ isOpen, onClose }: CustomRatesModalProps) {
  const [editingParcel, setEditingParcel] = useState<number | null>(null);
  const [tempRates, setTempRates] = useState<Record<number, { rate: string; notes: string }>>({});
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Default rates by product type
  const defaultRates = {
    'Gasolina': 400,
    'Diesel': 350,
    'Jet A1': 300,
    'LPG': 250,
    'Gasóleo': 350,
    'Fuel Oil': 200,
    'default': 300
  };

  // Get ships with parcels for rate configuration
  const { data: ships = [], isLoading, refetch } = useQuery<any[]>({
    queryKey: ['/api/ships'],
    enabled: isOpen,
  });

  // Get existing custom rates
  const { data: customRates = [] } = useQuery<any[]>({
    queryKey: ['/api/custom-rates'],
    enabled: isOpen,
  });

  // Save custom rates mutation
  const saveRatesMutation = useMutation({
    mutationFn: async (rateData: any) => {
      return await apiRequest('/api/custom-rates', 'POST', rateData);
    },
    onSuccess: () => {
      toast({
        title: "Rates salvos com sucesso",
        description: "Os rates customizados foram aplicados ao planejamento",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/custom-rates'] });
      queryClient.invalidateQueries({ queryKey: ['/api/discharge-plan'] });
      setEditingParcel(null);
      setTempRates({});
    },
    onError: (error) => {
      toast({
        title: "Erro ao salvar rates",
        description: "Não foi possível salvar os rates customizados",
        variant: "destructive",
      });
    },
  });

  // Prepare ship configurations
  const shipConfigurations: ShipRateConfig[] = ships
    .filter((ship: any) => ship.status === 'at_bar' || ship.status === 'next_to_berth')
    .filter((ship: any) => ship.hasDischargeInstructions)
    .slice(0, 5) // Next 5 ships
    .map((ship: any) => ({
      shipId: ship.id,
      shipName: ship.name,
      parcels: ship.parcels?.map((parcel: any) => {
        const defaultRate = defaultRates[parcel.product as keyof typeof defaultRates] || defaultRates.default;
        const existingCustomRate = customRates.find((cr: any) => cr.parcelId === parcel.id);
        
        return {
          parcelId: parcel.id,
          product: parcel.product,
          receiver: parcel.receiver,
          volumeM3: parcel.volumeM3,
          defaultRate,
          customRate: existingCustomRate?.customRate ? parseFloat(existingCustomRate.customRate) : undefined,
          estimatedDuration: parcel.volumeM3 / (existingCustomRate?.customRate ? parseFloat(existingCustomRate.customRate) : defaultRate),
          notes: existingCustomRate?.notes || '',
        };
      }) || []
    }));

  const handleEditRate = (parcelId: number, currentRate?: number, currentNotes?: string) => {
    setEditingParcel(parcelId);
    setTempRates({
      ...tempRates,
      [parcelId]: {
        rate: currentRate?.toString() || '',
        notes: currentNotes || ''
      }
    });
  };

  const handleSaveRate = async (shipId: number, parcel: ParcelRateConfig) => {
    const tempData = tempRates[parcel.parcelId];
    if (!tempData || !tempData.rate) return;

    const customRate = parseFloat(tempData.rate);
    if (customRate <= 0) {
      toast({
        title: "Rate inválido",
        description: "O rate deve ser maior que zero",
        variant: "destructive",
      });
      return;
    }

    const rateData = {
      shipId,
      parcelId: parcel.parcelId,
      product: parcel.product,
      receiver: parcel.receiver,
      customRate,
      estimatedDuration: parcel.volumeM3 / customRate,
      notes: tempData.notes,
    };

    saveRatesMutation.mutate(rateData);
  };

  const handleCancelEdit = () => {
    setEditingParcel(null);
    setTempRates({});
  };

  const formatDuration = (hours: number) => {
    const h = Math.floor(hours);
    const m = Math.floor((hours - h) * 60);
    return `${h}h ${m}min`;
  };

  const getProductColor = (product: string) => {
    const colors = {
      'Gasolina': 'bg-red-100 text-red-800',
      'Diesel': 'bg-blue-100 text-blue-800',
      'Jet A1': 'bg-green-100 text-green-800',
      'LPG': 'bg-purple-100 text-purple-800',
      'Gasóleo': 'bg-orange-100 text-orange-800',
      'Fuel Oil': 'bg-gray-100 text-gray-800',
    };
    return colors[product as keyof typeof colors] || 'bg-gray-100 text-gray-800';
  };

  if (isLoading) {
    return (
      <Dialog open={isOpen} onOpenChange={onClose}>
        <DialogContent className="max-w-6xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Settings className="w-5 h-5" />
              Configuração de Rates Customizados
            </DialogTitle>
          </DialogHeader>
          <div className="flex items-center justify-center py-8">
            <RefreshCw className="w-6 h-6 animate-spin mr-2" />
            <span>Carregando configurações...</span>
          </div>
        </DialogContent>
      </Dialog>
    );
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-7xl max-h-[95vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-xl">
            <Settings className="w-6 h-6" />
            Configuração de Rates Customizados
            <Button
              variant="outline"
              size="sm"
              onClick={() => refetch()}
              className="ml-auto"
            >
              <RefreshCw className="w-4 h-4 mr-1" />
              Atualizar
            </Button>
          </DialogTitle>
        </DialogHeader>

        {/* Informações Gerais */}
        <Card className="mb-6 border-2 border-blue-200 bg-blue-50">
          <CardHeader>
            <CardTitle className="text-lg text-blue-800">Instruções</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2 text-sm text-blue-700">
              <div className="flex items-center gap-2">
                <Info className="w-4 h-4" />
                <span>Configure rates personalizados baseados na experiência com recebedores específicos</span>
              </div>
              <div className="flex items-center gap-2">
                <Calculator className="w-4 h-4" />
                <span>O sistema calculará automaticamente a duração estimada (Volume ÷ Rate)</span>
              </div>
              <div className="flex items-center gap-2">
                <TrendingUp className="w-4 h-4" />
                <span>Rates personalizados serão usados no planejamento automático de descarga</span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Configuração por Navio */}
        <div className="space-y-6">
          {shipConfigurations.length > 0 ? (
            shipConfigurations.map((shipConfig) => (
              <Card key={shipConfig.shipId} className="border-l-4 border-l-blue-500">
                <CardHeader>
                  <CardTitle className="flex items-center gap-3">
                    <Package className="w-5 h-5" />
                    {shipConfig.shipName}
                    <Badge variant="outline" className="ml-2">
                      {shipConfig.parcels.length} parcela{shipConfig.parcels.length !== 1 ? 's' : ''}
                    </Badge>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {shipConfig.parcels.map((parcel) => (
                      <div key={parcel.parcelId} className="bg-gray-50 p-4 rounded-lg">
                        <div className="flex items-center justify-between mb-3">
                          <div className="flex items-center gap-3">
                            <Badge className={getProductColor(parcel.product)}>
                              {parcel.product}
                            </Badge>
                            <span className="font-medium">{parcel.receiver}</span>
                            <span className="text-sm text-gray-600">
                              {parcel.volumeM3.toFixed(0)} m³
                            </span>
                          </div>
                          {editingParcel !== parcel.parcelId && (
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => handleEditRate(parcel.parcelId, parcel.customRate, parcel.notes)}
                            >
                              <Edit className="w-3 h-3 mr-1" />
                              Configurar
                            </Button>
                          )}
                        </div>

                        {editingParcel === parcel.parcelId ? (
                          // Modo de Edição
                          <div className="space-y-3 border border-blue-200 p-3 rounded-lg bg-blue-50">
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                              <div>
                                <Label className="text-sm font-semibold">Rate Customizado (m³/h)</Label>
                                <Input
                                  type="number"
                                  step="0.01"
                                  value={tempRates[parcel.parcelId]?.rate || ''}
                                  onChange={(e) => setTempRates({
                                    ...tempRates,
                                    [parcel.parcelId]: {
                                      ...tempRates[parcel.parcelId],
                                      rate: e.target.value
                                    }
                                  })}
                                  placeholder={`Padrão: ${parcel.defaultRate}`}
                                  className="border-blue-300"
                                />
                              </div>
                              <div>
                                <Label className="text-sm font-semibold">Duração Estimada</Label>
                                <Input
                                  value={tempRates[parcel.parcelId]?.rate ? 
                                    formatDuration(parcel.volumeM3 / parseFloat(tempRates[parcel.parcelId].rate)) : 
                                    formatDuration(parcel.estimatedDuration)
                                  }
                                  readOnly
                                  className="bg-gray-100"
                                />
                              </div>
                            </div>
                            <div>
                              <Label className="text-sm font-semibold">Observações</Label>
                              <Textarea
                                value={tempRates[parcel.parcelId]?.notes || ''}
                                onChange={(e) => setTempRates({
                                  ...tempRates,
                                  [parcel.parcelId]: {
                                    ...tempRates[parcel.parcelId],
                                    notes: e.target.value
                                  }
                                })}
                                placeholder="Ex: Recebedor tem equipamento mais lento, considerar paragens adicionais..."
                                rows={2}
                                className="border-blue-300"
                              />
                            </div>
                            <div className="flex gap-2">
                              <Button
                                size="sm"
                                onClick={() => handleSaveRate(shipConfig.shipId, parcel)}
                                disabled={saveRatesMutation.isPending}
                                className="bg-green-600 hover:bg-green-700"
                              >
                                <Check className="w-3 h-3 mr-1" />
                                Salvar
                              </Button>
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={handleCancelEdit}
                              >
                                <X className="w-3 h-3 mr-1" />
                                Cancelar
                              </Button>
                            </div>
                          </div>
                        ) : (
                          // Modo de Visualização
                          <div className="grid grid-cols-1 md:grid-cols-4 gap-3 text-sm">
                            <div>
                              <span className="text-gray-500">Rate Padrão:</span>
                              <div className="font-medium">{parcel.defaultRate} m³/h</div>
                            </div>
                            <div>
                              <span className="text-gray-500">Rate Customizado:</span>
                              <div className="font-medium">
                                {parcel.customRate ? (
                                  <span className="text-blue-600">{parcel.customRate} m³/h</span>
                                ) : (
                                  <span className="text-gray-400">Não configurado</span>
                                )}
                              </div>
                            </div>
                            <div>
                              <span className="text-gray-500">Duração Estimada:</span>
                              <div className="font-medium flex items-center gap-1">
                                <Clock className="w-3 h-3" />
                                {formatDuration(parcel.estimatedDuration)}
                              </div>
                            </div>
                            <div>
                              <span className="text-gray-500">Observações:</span>
                              <div className="font-medium">
                                {parcel.notes ? (
                                  <span className="text-sm">{parcel.notes}</span>
                                ) : (
                                  <span className="text-gray-400">Nenhuma</span>
                                )}
                              </div>
                            </div>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            ))
          ) : (
            <Card>
              <CardContent className="text-center py-8">
                <AlertTriangle className="w-12 h-12 mx-auto text-gray-400 mb-4" />
                <p className="text-gray-600">Nenhum navio encontrado para configuração</p>
                <p className="text-sm text-gray-500 mt-2">
                  Certifique-se de que há navios com instruções de descarga na fila
                </p>
              </CardContent>
            </Card>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}