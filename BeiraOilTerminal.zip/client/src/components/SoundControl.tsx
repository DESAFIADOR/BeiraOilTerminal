import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Volume2, VolumeX } from 'lucide-react';
import { soundPreferences } from '@/hooks/useSoundEffects';

export function SoundControl() {
  const [isEnabled, setIsEnabled] = useState(soundPreferences.enabled);

  useEffect(() => {
    soundPreferences.load();
    setIsEnabled(soundPreferences.enabled);
  }, []);

  const toggleSound = () => {
    soundPreferences.toggle();
    setIsEnabled(soundPreferences.enabled);
  };

  return (
    <Button
      variant="ghost"
      size="sm"
      onClick={toggleSound}
      className="p-2 h-8 w-8 rounded-full hover:bg-blue-100 transition-colors"
      title={isEnabled ? "Desativar efeitos sonoros" : "Ativar efeitos sonoros"}
    >
      {isEnabled ? (
        <Volume2 className="h-4 w-4 text-blue-600" />
      ) : (
        <VolumeX className="h-4 w-4 text-gray-400" />
      )}
    </Button>
  );
}