import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Users, UserCheck, UserX, Shield, Settings } from "lucide-react";

interface User {
  id: number;
  username: string;
  email: string;
  role: string;
  status: string;
  isActive: boolean;
  createdAt: string;
  lastLogin?: string;
}

export default function UserManagement() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [selectedUser, setSelectedUser] = useState<User | null>(null);
  const [newUserData, setNewUserData] = useState({
    username: '',
    email: '',
    password: '',
    role: 'user'
  });

  // Buscar todos os usuários
  const { data: users = [], isLoading } = useQuery({
    queryKey: ['/api/users'],
  });

  // Buscar usuários pendentes
  const { data: pendingUsers = [] } = useQuery({
    queryKey: ['/api/users/pending'],
  });

  // Mutation para aprovar usuário
  const approveUserMutation = useMutation({
    mutationFn: async (userId: number) => {
      console.log('Admin UserManagement: Approving user:', userId);
      const response = await fetch(`/api/users/${userId}/approve`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
        },
        credentials: 'include',
        body: JSON.stringify({ adminPassword: 'BeiraTerm2025!' })
      });
      
      console.log('Admin UserManagement: Response status:', response.status);
      const responseText = await response.text();
      console.log('Admin UserManagement: Response:', responseText);
      
      if (!response.ok) {
        throw new Error(`${response.status}: ${responseText}`);
      }
      
      return JSON.parse(responseText);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/users'] });
      queryClient.invalidateQueries({ queryKey: ['/api/users/pending'] });
      toast({
        title: "Usuário aprovado",
        description: "O usuário foi aprovado com sucesso",
      });
    },
    onError: () => {
      toast({
        title: "Erro",
        description: "Falha ao aprovar usuário",
        variant: "destructive",
      });
    },
  });

  // Mutation para alterar role do usuário
  const updateRoleMutation = useMutation({
    mutationFn: async ({ userId, role }: { userId: number; role: string }) => {
      await apiRequest(`/api/users/${userId}/role`, {
        method: 'PATCH',
        body: JSON.stringify({ role }),
        headers: { 'Content-Type': 'application/json' }
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/users'] });
      toast({
        title: "Role atualizado",
        description: "O nível de acesso do usuário foi alterado",
      });
      setSelectedUser(null);
    },
    onError: () => {
      toast({
        title: "Erro",
        description: "Falha ao atualizar role do usuário",
        variant: "destructive",
      });
    },
  });

  // Mutation para ativar/desativar usuário
  const toggleUserStatusMutation = useMutation({
    mutationFn: async ({ userId, isActive }: { userId: number; isActive: boolean }) => {
      await apiRequest(`/api/users/${userId}/status`, {
        method: 'PATCH',
        body: JSON.stringify({ isActive }),
        headers: { 'Content-Type': 'application/json' }
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/users'] });
      toast({
        title: "Status atualizado",
        description: "Status do usuário foi alterado",
      });
    },
    onError: () => {
      toast({
        title: "Erro",
        description: "Falha ao alterar status do usuário",
        variant: "destructive",
      });
    },
  });

  // Mutation para criar novo usuário
  const createUserMutation = useMutation({
    mutationFn: async (userData: typeof newUserData) => {
      await apiRequest('/api/users', {
        method: 'POST',
        body: JSON.stringify(userData),
        headers: { 'Content-Type': 'application/json' }
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/users'] });
      toast({
        title: "Usuário criado",
        description: "Novo usuário foi criado com sucesso",
      });
      setNewUserData({ username: '', email: '', password: '', role: 'user' });
    },
    onError: () => {
      toast({
        title: "Erro",
        description: "Falha ao criar usuário",
        variant: "destructive",
      });
    },
  });

  const getRoleBadge = (role: string) => {
    switch (role) {
      case 'admin':
        return <Badge variant="destructive" className="bg-red-600"><Shield className="w-3 h-3 mr-1" />Administrador</Badge>;
      case 'operator':
        return <Badge variant="secondary" className="bg-blue-600 text-white"><Settings className="w-3 h-3 mr-1" />Operador</Badge>;
      default:
        return <Badge variant="outline"><Users className="w-3 h-3 mr-1" />Público</Badge>;
    }
  };

  const getStatusBadge = (isActive: boolean) => {
    return isActive 
      ? <Badge variant="default" className="bg-green-600"><UserCheck className="w-3 h-3 mr-1" />Ativo</Badge>
      : <Badge variant="outline"><UserX className="w-3 h-3 mr-1" />Inativo</Badge>;
  };

  if (isLoading) {
    return (
      <Card>
        <CardContent className="p-6">
          <div className="text-center">Carregando usuários...</div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {/* Usuários Pendentes */}
      {pendingUsers.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <UserCheck className="w-5 h-5" />
              Usuários Pendentes de Aprovação
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid gap-4">
              {pendingUsers.map((user: User) => (
                <div key={user.id} className="flex items-center justify-between p-4 border rounded-lg">
                  <div>
                    <div className="font-medium">{user.username}</div>
                    <div className="text-sm text-gray-600">{user.email}</div>
                    <div className="text-xs text-gray-500">Solicitado em: {new Date(user.createdAt).toLocaleDateString('pt-BR')}</div>
                  </div>
                  <div className="flex gap-2">
                    {getRoleBadge(user.role)}
                    <Button
                      size="sm"
                      onClick={() => approveUserMutation.mutate(user.id)}
                      disabled={approveUserMutation.isPending}
                    >
                      Aprovar
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Criar Novo Usuário */}
      <Card>
        <CardHeader>
          <CardTitle>Criar Novo Usuário</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="username">Usuário</Label>
              <Input
                id="username"
                value={newUserData.username}
                onChange={(e) => setNewUserData({ ...newUserData, username: e.target.value })}
                placeholder="Nome de usuário"
              />
            </div>
            <div>
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                type="email"
                value={newUserData.email}
                onChange={(e) => setNewUserData({ ...newUserData, email: e.target.value })}
                placeholder="email@exemplo.com"
              />
            </div>
            <div>
              <Label htmlFor="password">Senha</Label>
              <Input
                id="password"
                type="password"
                value={newUserData.password}
                onChange={(e) => setNewUserData({ ...newUserData, password: e.target.value })}
                placeholder="Senha"
              />
            </div>
            <div>
              <Label htmlFor="role">Nível de Acesso</Label>
              <Select 
                value={newUserData.role} 
                onValueChange={(value) => setNewUserData({ ...newUserData, role: value })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="user">Público (Visualização)</SelectItem>
                  <SelectItem value="operator">Operador (Permissões Limitadas)</SelectItem>
                  <SelectItem value="admin">Administrador (Plenos Poderes)</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="mt-4">
            <Button 
              onClick={() => createUserMutation.mutate(newUserData)}
              disabled={createUserMutation.isPending || !newUserData.username || !newUserData.email || !newUserData.password}
            >
              Criar Usuário
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Lista de Usuários */}
      <Card>
        <CardHeader>
          <CardTitle>Gerenciar Usuários ({users.length})</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4">
            {users.map((user: User) => (
              <div key={user.id} className="flex items-center justify-between p-4 border rounded-lg">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-2">
                    <div className="font-medium">{user.username}</div>
                    {getRoleBadge(user.role)}
                    {getStatusBadge(user.isActive)}
                  </div>
                  <div className="text-sm text-gray-600">{user.email}</div>
                  <div className="text-xs text-gray-500">
                    Criado em: {new Date(user.createdAt).toLocaleDateString('pt-BR')}
                    {user.lastLogin && ` • Último acesso: ${new Date(user.lastLogin).toLocaleDateString('pt-BR')}`}
                  </div>
                </div>
                <div className="flex gap-2">
                  <Dialog>
                    <DialogTrigger asChild>
                      <Button variant="outline" size="sm" onClick={() => setSelectedUser(user)}>
                        Editar
                      </Button>
                    </DialogTrigger>
                    <DialogContent>
                      <DialogHeader>
                        <DialogTitle>Editar Usuário: {user.username}</DialogTitle>
                      </DialogHeader>
                      <div className="space-y-4">
                        <div>
                          <Label>Nível de Acesso</Label>
                          <Select 
                            value={user.role} 
                            onValueChange={(role) => updateRoleMutation.mutate({ userId: user.id, role })}
                          >
                            <SelectTrigger>
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="user">Público (Visualização)</SelectItem>
                              <SelectItem value="operator">Operador (Permissões Limitadas)</SelectItem>
                              <SelectItem value="admin">Administrador (Plenos Poderes)</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        <div className="flex gap-2">
                          <Button
                            variant={user.isActive ? "destructive" : "default"}
                            onClick={() => toggleUserStatusMutation.mutate({ 
                              userId: user.id, 
                              isActive: !user.isActive 
                            })}
                            disabled={toggleUserStatusMutation.isPending}
                          >
                            {user.isActive ? "Desativar" : "Ativar"}
                          </Button>
                        </div>
                      </div>
                    </DialogContent>
                  </Dialog>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}