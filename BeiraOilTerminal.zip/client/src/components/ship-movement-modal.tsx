import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Ship, ArrowRight, Anchor, MapPin, FileText, Calendar, Target } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import { useSoundEffects } from "@/hooks/useSoundEffects";

interface ShipMovementModalProps {
  isOpen: boolean;
  onClose: () => void;
  shipId?: number | null;
}

interface ShipData {
  id: number;
  name: string;
  countermark: string;
  status: string;
  hasDischargeInstructions: boolean | null;
  arrivalDateTime: string | Date;
  operationType: string;
  parcels: any[];
}

const getStatusDisplay = (status: string, hasInstructions: boolean | null) => {
  switch (status) {
    case "expected":
      return { label: "Previstos a Chegar", color: "bg-blue-100 text-blue-800" };
    case "at_bar":
      if (hasInstructions) {
        return { label: "Com Instrução", color: "bg-green-100 text-green-800" };
      } else {
        return { label: "Sem Instrução", color: "bg-yellow-100 text-yellow-800" };
      }
    case "next_to_berth":
      return { label: "Próximo a Atracar", color: "bg-purple-100 text-purple-800" };
    case "at_berth":
      return { label: "No Cais", color: "bg-orange-100 text-orange-800" };
    case "departed":
      return { label: "Partidos", color: "bg-gray-100 text-gray-800" };
    default:
      return { label: "Desconhecido", color: "bg-gray-100 text-gray-800" };
  }
};

const getOperationTypeBadge = (operationType: string) => {
  switch (operationType?.toLowerCase()) {
    case "nacional":
      return <Badge className="bg-blue-500 text-white">🇲🇿 Nacional</Badge>;
    case "transito":
      return <Badge className="bg-green-500 text-white">🚢 Trânsito</Badge>;
    case "combinado":
      return <Badge className="bg-purple-500 text-white">🔄 Combinado</Badge>;
    default:
      return <Badge variant="outline">{operationType}</Badge>;
  }
};

export function ShipMovementModal({ isOpen, onClose, shipId }: ShipMovementModalProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const soundEffects = useSoundEffects();
  const [selectedTab, setSelectedTab] = useState("to-bar");
  const [selectedDestination, setSelectedDestination] = useState<string>("");
  const [showDestinationSelector, setShowDestinationSelector] = useState(false);
  const [selectedShipForMove, setSelectedShipForMove] = useState<ShipData | null>(null);

  const { data: ships = [], refetch } = useQuery<ShipData[]>({
    queryKey: ["/api/ships"],
    retry: false,
    enabled: isOpen,
  });

  const moveShipMutation = useMutation({
    mutationFn: async ({ shipId, status, hasInstructions }: { 
      shipId: number; 
      status: string; 
      hasInstructions?: boolean 
    }) => {
      const updateData: any = { status };
      if (hasInstructions !== undefined) {
        updateData.hasDischargeInstructions = hasInstructions;
      }
      
      return apiRequest(`/api/ships/${shipId}/status`, {
        method: "PATCH",
        body: JSON.stringify(updateData),
        headers: {
          'Content-Type': 'application/json',
        },
      });
    },
    onSuccess: (_, variables) => {
      // Play appropriate sound effect based on ship movement type
      const { status } = variables;
      if (status === "at_berth") {
        soundEffects.shipBerthing();
      } else if (status === "departed") {
        soundEffects.shipDeparture();
      } else {
        soundEffects.shipMovement();
      }
      
      soundEffects.confirmation();
      
      toast({
        title: "Sucesso",
        description: "Navio movido com sucesso!",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/ships"] });
      refetch();
      onClose(); // Close modal after successful movement
    },
    onError: (error: any) => {
      toast({
        title: "Erro",
        description: error.message || "Falha ao mover navio.",
        variant: "destructive",
      });
    },
  });

  const getDestinationOptions = () => {
    return [
      { value: "expected", label: "Para Barra - Previstos a Chegar" },
      { value: "at_bar_no_instruction", label: "Sem Instrução - Na Barra" },
      { value: "at_bar_with_instruction", label: "Com Instrução - Na Barra" },
      { value: "next_to_berth", label: "Próximo - Próximo a Atracar" },
      { value: "at_berth", label: "Para o Cais - No Cais 12" }
    ];
  };

  const handleShipSelect = (ship: ShipData) => {
    setSelectedShipForMove(ship);
    setShowDestinationSelector(true);
    setSelectedDestination("");
  };

  const handleMoveShip = () => {
    if (!selectedShipForMove || !selectedDestination) return;

    let targetStatus = "";
    let hasInstructions: boolean | undefined = undefined;

    switch (selectedDestination) {
      case "at_bar_no_instruction":
        targetStatus = "at_bar";
        hasInstructions = false;
        break;
      case "at_bar_with_instruction":
        targetStatus = "at_bar";
        hasInstructions = true;
        break;
      case "next_to_berth":
        targetStatus = "next_to_berth";
        break;
      case "at_berth":
        targetStatus = "at_berth";
        break;
      case "expected":
        targetStatus = "expected";
        hasInstructions = false;
        break;
    }

    // Se movendo para o cais, salvar dados para abrir modal de atracação
    const isMovingToBerth = selectedDestination === "at_berth";
    const shipForBerthing = isMovingToBerth ? selectedShipForMove : null;

    moveShipMutation.mutate({ 
      shipId: selectedShipForMove.id, 
      status: targetStatus, 
      hasInstructions 
    }, {
      onSuccess: () => {
        // Reset selection
        setSelectedShipForMove(null);
        setShowDestinationSelector(false);
        setSelectedDestination("");
        
        // Se foi movido para o cais, abrir modal de atracação
        if (isMovingToBerth && shipForBerthing) {
          // Fechar este modal primeiro
          onClose();
          // Abrir modal de atracação (será implementado)
          window.dispatchEvent(new CustomEvent('openBerthingModal', { 
            detail: { shipId: shipForBerthing.id, shipName: shipForBerthing.name } 
          }));
        }
      }
    });
  };

  const cancelMove = () => {
    setSelectedShipForMove(null);
    setShowDestinationSelector(false);
    setSelectedDestination("");
  };

  // Filtrar navios baseado na aba selecionada
  const getEligibleShips = (targetAction: string) => {
    switch (targetAction) {
      case "to-bar":
        // Navios previstos a chegar
        return ships.filter(ship => ship.status === "expected");
      
      case "to-no-instruction":
        // Navios na barra SEM instrução de descarga
        return ships.filter(ship => 
          ship.status === "at_bar" && ship.hasDischargeInstructions === false
        );
      
      case "to-instruction":
        // Navios na barra COM instrução de descarga
        return ships.filter(ship => 
          ship.status === "at_bar" && ship.hasDischargeInstructions === true
        );
      
      case "to-next":
        // Navios próximos a atracar
        return ships.filter(ship => 
          ship.status === "next_to_berth"
        );
      
      default:
        return [];
    }
  };

  const renderShipCard = (ship: ShipData) => {
    const statusInfo = getStatusDisplay(ship.status, ship.hasDischargeInstructions);

    return (
      <Card key={ship.id} className="mb-3 hover:shadow-md transition-shadow">
        <CardContent className="p-3 lg:p-4">
          <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-3">
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 mb-2 flex-wrap">
                <Ship className="w-3 h-3 lg:w-4 lg:h-4 flex-shrink-0" />
                <span className="font-semibold text-sm lg:text-base truncate">{ship.name}</span>
                <Badge variant="outline" className="text-xs">#{ship.countermark}</Badge>
                {getOperationTypeBadge && getOperationTypeBadge(ship.operationType)}
              </div>
              
              <div className="flex flex-col lg:flex-row lg:items-center gap-2 lg:gap-4 text-xs lg:text-sm text-gray-600 mb-2">
                <div className="flex items-center gap-1">
                  <Calendar className="w-3 h-3 flex-shrink-0" />
                  <span className="truncate">
                    {format(new Date(ship.arrivalDateTime), "dd/MM/yyyy HH:mm", { locale: ptBR })}
                  </span>
                </div>
                <Badge className={`${statusInfo.color} text-xs`}>{statusInfo.label}</Badge>
              </div>
              
              <div className="text-xs text-gray-500">
                {ship.parcels?.length || 0} parcelas de carga
              </div>
            </div>
            
            <Button
              onClick={() => handleShipSelect(ship)}
              disabled={moveShipMutation.isPending}
              className="w-full lg:w-auto lg:ml-4"
              size="sm"
            >
              <Target className="w-3 h-3 lg:w-4 lg:h-4 mr-1" />
              <span className="text-xs lg:text-sm">Selecionar Destino</span>
            </Button>
          </div>
        </CardContent>
      </Card>
    );
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[95vh] lg:max-h-[90vh] overflow-hidden">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Ship className="w-4 h-4 lg:w-5 lg:h-5" />
            <span className="text-base lg:text-lg">Movimentação de Navios</span>
          </DialogTitle>
        </DialogHeader>

        <Tabs value={selectedTab} onValueChange={setSelectedTab} className="flex-1">
          {/* Mobile Horizontal Scroll Tabs */}
          <div className="border-b border-gray-200 overflow-x-auto lg:overflow-x-visible">
            <div className="flex lg:grid lg:grid-cols-4 min-w-max lg:min-w-0">
              <button
                onClick={() => setSelectedTab('to-bar')}
                className={`flex items-center gap-1 px-3 py-2 text-xs lg:text-sm font-medium border-b-2 whitespace-nowrap transition-colors ${
                  selectedTab === 'to-bar'
                    ? 'border-blue-500 text-blue-600 bg-blue-50'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:bg-gray-50'
                }`}
              >
                <Anchor className="w-3 h-3 lg:w-4 lg:h-4" />
                <span className="lg:hidden">BARRA</span>
                <span className="hidden lg:inline">Para Barra</span>
              </button>
              
              <button
                onClick={() => setSelectedTab('to-no-instruction')}
                className={`flex items-center gap-1 px-3 py-2 text-xs lg:text-sm font-medium border-b-2 whitespace-nowrap transition-colors ${
                  selectedTab === 'to-no-instruction'
                    ? 'border-orange-500 text-orange-600 bg-orange-50'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:bg-gray-50'
                }`}
              >
                <FileText className="w-3 h-3 lg:w-4 lg:h-4" />
                <span className="lg:hidden">SEM INSTR.</span>
                <span className="hidden lg:inline">Sem Instrução</span>
              </button>
              
              <button
                onClick={() => setSelectedTab('to-instruction')}
                className={`flex items-center gap-1 px-3 py-2 text-xs lg:text-sm font-medium border-b-2 whitespace-nowrap transition-colors ${
                  selectedTab === 'to-instruction'
                    ? 'border-green-500 text-green-600 bg-green-50'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:bg-gray-50'
                }`}
              >
                <FileText className="w-3 h-3 lg:w-4 lg:h-4" />
                <span className="lg:hidden">COM INSTR.</span>
                <span className="hidden lg:inline">Com Instrução</span>
              </button>
              
              <button
                onClick={() => setSelectedTab('to-next')}
                className={`flex items-center gap-1 px-3 py-2 text-xs lg:text-sm font-medium border-b-2 whitespace-nowrap transition-colors ${
                  selectedTab === 'to-next'
                    ? 'border-purple-500 text-purple-600 bg-purple-50'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:bg-gray-50'
                }`}
              >
                <MapPin className="w-3 h-3 lg:w-4 lg:h-4" />
                <span className="lg:hidden">PRÓXIMO</span>
                <span className="hidden lg:inline">Próximo</span>
              </button>
            </div>
          </div>

          <div className="mt-4 max-h-[60vh] overflow-y-auto">
            {/* Tab Content - Para Barra */}
            {selectedTab === 'to-bar' && (
              <div className="space-y-4">
                <div className="mb-4">
                  <h3 className="font-semibold text-base lg:text-lg mb-2 flex items-center gap-2">
                    <Anchor className="w-4 h-4 text-blue-600" />
                    Previstos a Chegar
                  </h3>
                  <p className="text-xs lg:text-sm text-gray-600 mb-4">
                    Navios que estão previstos a chegar:
                  </p>
                </div>
              
                {getEligibleShips("to-bar").length === 0 ? (
                  <div className="text-center py-8 text-gray-500">
                    <Ship className="w-8 lg:w-12 h-8 lg:h-12 mx-auto mb-2 opacity-50" />
                    <p className="text-sm">Nenhum navio previsto a chegar</p>
                  </div>
                ) : (
                  getEligibleShips("to-bar").map(ship => renderShipCard(ship))
                )}
              </div>
            )}

            {/* Tab Content - Sem Instrução */}
            {selectedTab === 'to-no-instruction' && (
              <div className="space-y-4">
                <div className="mb-4">
                  <h3 className="font-semibold text-base lg:text-lg mb-2 flex items-center gap-2">
                    <FileText className="w-4 h-4 text-orange-600" />
                    Sem Instrução
                  </h3>
                  <p className="text-xs lg:text-sm text-gray-600 mb-4">
                    Navios na barra sem instrução de descarga:
                  </p>
                </div>
                
                {getEligibleShips("to-no-instruction").length === 0 ? (
                  <div className="text-center py-8 text-gray-500">
                    <FileText className="w-8 lg:w-12 h-8 lg:h-12 mx-auto mb-2 opacity-50" />
                    <p className="text-sm">Nenhum navio sem instrução</p>
                  </div>
                ) : (
                  getEligibleShips("to-no-instruction").map(ship => renderShipCard(ship))
                )}
              </div>
            )}

            {/* Tab Content - Com Instrução */}
            {selectedTab === 'to-instruction' && (
              <div className="space-y-4">
                <div className="mb-4">
                  <h3 className="font-semibold text-base lg:text-lg mb-2 flex items-center gap-2">
                    <FileText className="w-4 h-4 text-green-600" />
                    Com Instrução
                  </h3>
                  <p className="text-xs lg:text-sm text-gray-600 mb-4">
                    Navios na barra com instrução de descarga:
                  </p>
                </div>
                
                {getEligibleShips("to-instruction").length === 0 ? (
                  <div className="text-center py-8 text-gray-500">
                    <FileText className="w-8 lg:w-12 h-8 lg:h-12 mx-auto mb-2 opacity-50" />
                    <p className="text-sm">Nenhum navio com instrução</p>
                  </div>
                ) : (
                  getEligibleShips("to-instruction").map(ship => renderShipCard(ship))
                )}
              </div>
            )}

            {/* Tab Content - Próximo */}
            {selectedTab === 'to-next' && (
              <div className="space-y-4">
                <div className="mb-4">
                  <h3 className="font-semibold text-base lg:text-lg mb-2 flex items-center gap-2">
                    <MapPin className="w-4 h-4 text-purple-600" />
                    Próximo a Atracar
                  </h3>
                  <p className="text-xs lg:text-sm text-gray-600 mb-4">
                    Navios próximos a atracar:
                  </p>
                </div>
                
                {getEligibleShips("to-next").length === 0 ? (
                  <div className="text-center py-8 text-gray-500">
                    <MapPin className="w-8 lg:w-12 h-8 lg:h-12 mx-auto mb-2 opacity-50" />
                    <p className="text-sm">Nenhum navio próximo a atracar</p>
                  </div>
                ) : (
                  getEligibleShips("to-next").map(ship => renderShipCard(ship))
                )}
              </div>
            )}
          </div>
        </Tabs>

        <div className="flex justify-end pt-4 border-t">
          <Button variant="outline" onClick={onClose}>
            Fechar
          </Button>
        </div>
      </DialogContent>

      {/* Destination Selection Dialog */}
      <Dialog open={showDestinationSelector} onOpenChange={() => setShowDestinationSelector(false)}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Target className="w-5 h-5" />
              Selecionar Destino para {selectedShipForMove?.name}
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-4">
            <div className="p-3 bg-gray-50 rounded-lg">
              <div className="flex items-center gap-2 mb-1">
                <Ship className="w-4 h-4" />
                <span className="font-medium">{selectedShipForMove?.name}</span>
                <Badge variant="outline">#{selectedShipForMove?.countermark}</Badge>
              </div>
              <div className="text-sm text-gray-600">
                Status atual: {getStatusDisplay(selectedShipForMove?.status || "", selectedShipForMove?.hasDischargeInstructions ?? false).label}
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium">Destino:</label>
              <Select value={selectedDestination} onValueChange={setSelectedDestination}>
                <SelectTrigger>
                  <SelectValue placeholder="Selecione o destino..." />
                </SelectTrigger>
                <SelectContent>
                  {getDestinationOptions().map((option) => (
                    <SelectItem key={option.value} value={option.value}>
                      {option.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="flex gap-2 pt-4">
              <Button
                onClick={handleMoveShip}
                disabled={!selectedDestination || moveShipMutation.isPending}
                className="flex-1"
              >
                <ArrowRight className="w-4 h-4 mr-1" />
                {moveShipMutation.isPending ? "Movendo..." : "Confirmar Movimento"}
              </Button>
              <Button
                variant="outline"
                onClick={cancelMove}
                disabled={moveShipMutation.isPending}
              >
                Cancelar
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </Dialog>
  );
}