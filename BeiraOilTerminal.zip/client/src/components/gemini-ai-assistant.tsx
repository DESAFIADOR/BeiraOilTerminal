import React, { useState, useRef, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { X, Send, User, Sparkles, Clock, Zap, Brain, Mic, MicOff, Volume2, VolumeX, MessageCircle } from 'lucide-react';
import { apiRequest } from '@/lib/queryClient';

interface Message {
  id: string;
  sessionId: string;
  content: string;
  role: 'user' | 'assistant';
  timestamp: Date;
  confidence?: number;
  requiresEscalation?: boolean;
  responseTimeMs?: number;
  suggestions?: string[];
}

interface GeminiAIAssistantProps {
  isOpen: boolean;
  onClose: () => void;
  userRole: string;
  language: string;
}

export function GeminiAIAssistant({ isOpen, onClose, userRole, language }: GeminiAIAssistantProps) {
  const [messages, setMessages] = useState<Message[]>([]);
  const [currentMessage, setCurrentMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [sessionId, setSessionId] = useState<string | null>(null);
  const [sessionStatus, setSessionStatus] = useState<'connecting' | 'active' | 'offline'>('offline');
  const [isRecording, setIsRecording] = useState(false);
  const [audioEnabled, setAudioEnabled] = useState(true);
  const [mediaRecorder, setMediaRecorder] = useState<MediaRecorder | null>(null);
  const [audioChunks, setAudioChunks] = useState<Blob[]>([]);
  const [voiceMode, setVoiceMode] = useState(false);
  const [isPlayingAudio, setIsPlayingAudio] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    if (messages.length > 0) {
      scrollToBottom();
    }
  }, [messages]);

  useEffect(() => {
    if (isOpen && !sessionId) {
      initializeSession();
    }
  }, [isOpen]);

  // Voice recording functions
  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ 
        audio: {
          sampleRate: 16000,
          channelCount: 1,
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true
        } 
      });
      
      // Use webm with opus codec for better compression
      const options = { mimeType: 'audio/webm;codecs=opus' };
      let recorder;
      
      if (MediaRecorder.isTypeSupported(options.mimeType)) {
        recorder = new MediaRecorder(stream, options);
      } else {
        recorder = new MediaRecorder(stream);
      }
      
      const chunks: Blob[] = [];
      
      recorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          chunks.push(event.data);
        }
      };

      recorder.onstop = async () => {
        const audioBlob = new Blob(chunks, { type: recorder.mimeType });
        console.log('Áudio gravado:', { size: audioBlob.size, type: audioBlob.type });
        await processVoiceInput(audioBlob);
        stream.getTracks().forEach(track => track.stop());
      };

      setMediaRecorder(recorder);
      recorder.start(1000); // Collect data every second
      setIsRecording(true);
    } catch (error) {
      console.error('Error starting recording:', error);
      alert('Erro ao acessar microfone. Verifique as permissões do navegador.');
    }
  };

  const stopRecording = () => {
    if (mediaRecorder && isRecording) {
      mediaRecorder.stop();
      setIsRecording(false);
      setMediaRecorder(null);
    }
  };

  const processVoiceInput = async (audioBlob: Blob) => {
    if (!sessionId) return;

    try {
      setIsLoading(true);
      
      // Convert audio blob to base64 using FileReader
      const reader = new FileReader();
      reader.readAsDataURL(audioBlob);
      
      const base64Audio = await new Promise<string>((resolve, reject) => {
        reader.onload = () => {
          const result = reader.result as string;
          // Remove data URL prefix (data:audio/wav;base64,)
          const base64 = result.split(',')[1];
          resolve(base64);
        };
        reader.onerror = reject;
      });

      console.log('Enviando áudio para transcrição...', { 
        size: audioBlob.size, 
        type: audioBlob.type,
        base64Length: base64Audio.length,
        base64Preview: base64Audio.substring(0, 50) + '...'
      });

      // Send to speech-to-text endpoint
      const response = await fetch('/api/gemini-ai/speech-to-text', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          audioData: base64Audio,
          language: language
        })
      });

      if (!response.ok) {
        const errorData = await response.json();
        console.error('Erro na transcrição:', errorData);
        throw new Error(`Erro na transcrição: ${errorData.message}`);
      }

      const result = await response.json();
      console.log('Resultado da transcrição:', result);
      
      if (result.text && result.text.trim()) {
        // Send the transcribed text as a message
        await sendMessage(result.text.trim());
      } else {
        console.log('Nenhum texto foi detectado na gravação');
        // Show feedback to user
        const noTextMessage = language === 'en' ? 
          'No speech detected. Please try again.' :
          'Nenhuma fala detectada. Tente novamente.';
        
        const errorMessage: Message = {
          id: (Date.now() + 1).toString(),
          sessionId,
          content: noTextMessage,
          role: 'assistant',
          timestamp: new Date(),
          confidence: 0.1
        };
        setMessages(prev => [...prev, errorMessage]);
      }
    } catch (error) {
      console.error('Error processing voice input:', error);
      
      // Show error to user
      const errorMessage: Message = {
        id: (Date.now() + 1).toString(),
        sessionId,
        content: language === 'en' ? 
          'Voice processing error. Please try again.' :
          'Erro no processamento de voz. Tente novamente.',
        role: 'assistant',
        timestamp: new Date(),
        confidence: 0.1
      };
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  const playAudio = async (text: string) => {
    if (!audioEnabled) return;

    try {
      setIsPlayingAudio(true);
      console.log('Gerando áudio para:', text.substring(0, 50) + '...');
      
      const response = await fetch('/api/gemini-ai/text-to-speech', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          text: text,
          language: language
        })
      });

      if (!response.ok) {
        console.error('Erro ao gerar áudio:', response.status);
        setIsPlayingAudio(false);
        return;
      }

      const result = await response.json();
      console.log('Resposta do áudio:', result);
      
      if (result.audioUrl) {
        const audio = new Audio(result.audioUrl);
        
        audio.onloadstart = () => console.log('Carregando áudio...');
        audio.oncanplay = () => console.log('Áudio pronto para reproduzir');
        audio.onplay = () => console.log('Reproduzindo áudio...');
        
        audio.onended = () => {
          console.log('Áudio terminou');
          setIsPlayingAudio(false);
          // Auto-start recording in voice mode after audio finishes
          if (voiceMode && !isRecording) {
            setTimeout(() => {
              console.log('Iniciando próxima gravação...');
              startRecording();
            }, 500);
          }
        };
        
        audio.onerror = (e) => {
          console.error('Erro ao reproduzir áudio:', e);
          setIsPlayingAudio(false);
        };
        
        await audio.play();
      } else {
        console.log('Nenhum áudio retornado pelo servidor');
        setIsPlayingAudio(false);
        // If no audio, still auto-start recording in voice mode
        if (voiceMode && !isRecording) {
          setTimeout(() => {
            console.log('Iniciando gravação sem áudio...');
            startRecording();
          }, 500);
        }
      }
    } catch (error) {
      console.error('Error playing audio:', error);
      setIsPlayingAudio(false);
    }
  };

  const toggleVoiceMode = () => {
    const newVoiceMode = !voiceMode;
    setVoiceMode(newVoiceMode);
    
    if (newVoiceMode) {
      // When entering voice mode, auto-enable audio and start recording
      setAudioEnabled(true);
      if (!isRecording && !isLoading && !isPlayingAudio) {
        setTimeout(() => {
          startRecording();
        }, 500);
      }
    } else {
      // When exiting voice mode, stop recording if active
      if (isRecording) {
        stopRecording();
      }
    }
  };

  const initializeSession = async () => {
    console.log('🚀 Inicializando sessão do assistente...', { userRole, language });
    setSessionStatus('connecting');
    
    try {
      const response = await fetch('/api/gemini-ai/session', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          userRole,
          language
        })
      });

      console.log('📡 Resposta da inicialização:', { status: response.status, ok: response.ok });

      if (!response.ok) {
        const errorText = await response.text();
        console.error('❌ Erro na inicialização:', { status: response.status, error: errorText });
        throw new Error(`HTTP error! status: ${response.status}, error: ${errorText}`);
      }

      const result = await response.json();
      console.log('✅ Sessão criada com sucesso:', { sessionId: result.sessionId });
      
      setSessionId(result.sessionId);
      setSessionStatus('active');
      
      // Add welcome message
      const welcomeMessage: Message = {
        id: Date.now().toString(),
        sessionId: result.sessionId,
        content: language === 'en' ? 
          'Hello! I\'m your Gemini AI Assistant for Beira Oil Terminal. I can help you with ship information, terminal operations, analytics, and more. How can I assist you today?' :
          'Olá! Sou seu Assistente IA Gemini para o Terminal Petrolífero da Beira. Posso ajudar com informações de navios, operações do terminal, análises e muito mais. Como posso ajudá-lo hoje?',
        role: 'assistant',
        timestamp: new Date(),
        confidence: 1.0,
        suggestions: language === 'en' ? [
          'Show current ships',
          'Terminal status',
          'Weather conditions'
        ] : [
          'Mostrar navios atuais',
          'Status do terminal',
          'Condições meteorológicas'
        ]
      };

      setMessages([welcomeMessage]);
      console.log('💬 Mensagem de boas-vindas adicionada, assistente pronto para comunicação');
    } catch (error) {
      console.error('❌ Falha ao inicializar sessão:', error);
      setSessionStatus('offline');
      
      // Add error message for user
      const errorMessage: Message = {
        id: Date.now().toString(),
        sessionId: 'error',
        content: language === 'en' ? 
          'Failed to connect to assistant. Please try refreshing the page.' :
          'Falha ao conectar com o assistente. Recarregue a página e tente novamente.',
        role: 'assistant',
        timestamp: new Date(),
        confidence: 0.1
      };
      setMessages([errorMessage]);
    }
  };

  const sendMessage = async (messageText?: string, isSuggestion = false) => {
    const textToSend = messageText || currentMessage.trim();
    console.log('Enviando mensagem:', { textToSend, sessionId, userRole, language, isLoading });
    
    if (!textToSend || !sessionId || isLoading) {
      console.log('Mensagem bloqueada:', { 
        hasText: !!textToSend, 
        hasSession: !!sessionId, 
        isLoading 
      });
      return;
    }

    const userMessage: Message = {
      id: Date.now().toString(),
      sessionId,
      content: textToSend,
      role: 'user',
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    if (!isSuggestion) setCurrentMessage('');
    setIsLoading(true);

    try {
      console.log('Fazendo request para API:', {
        url: '/api/gemini-ai/message',
        body: { sessionId, message: textToSend, userRole, language }
      });

      const response = await fetch('/api/gemini-ai/message', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          sessionId,
          message: textToSend,
          userRole,
          language
        })
      });

      console.log('Resposta da API:', { status: response.status, ok: response.ok });

      if (!response.ok) {
        const errorData = await response.text();
        console.error('Erro HTTP:', { status: response.status, data: errorData });
        throw new Error(`HTTP error! status: ${response.status}, data: ${errorData}`);
      }

      const result = await response.json();
      console.log('Resultado processado:', {
        hasResponse: !!result.response,
        responseLength: result.response?.length,
        confidence: result.confidence,
        suggestions: result.suggestions?.length
      });

      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        sessionId,
        content: result.response,
        role: 'assistant',
        timestamp: new Date(),
        confidence: result.confidence,
        requiresEscalation: result.requiresEscalation,
        responseTimeMs: result.responseTimeMs,
        suggestions: result.suggestions
      };

      setMessages(prev => [...prev, assistantMessage]);
      console.log('Mensagem do assistente adicionada, total de mensagens:', messages.length + 2);
      
      // Play audio response if audio is enabled
      if (audioEnabled && result.response) {
        console.log('Reproduzindo áudio da resposta');
        await playAudio(result.response);
      } else if (voiceMode && !audioEnabled) {
        console.log('Modo voz ativo sem áudio, iniciando gravação');
        // In voice mode, auto-start recording even without audio
        setTimeout(() => {
          if (!isRecording) {
            startRecording();
          }
        }, 1000);
      }
    } catch (error) {
      console.error('Erro ao enviar mensagem:', error);
      const errorMessage: Message = {
        id: (Date.now() + 1).toString(),
        sessionId,
        content: language === 'en' ? 
          'Sorry, I couldn\'t process your message. Please try again.' :
          'Desculpe, não consegui processar sua mensagem. Tente novamente.',
        role: 'assistant',
        timestamp: new Date(),
        confidence: 0.1
      };
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleClose = async () => {
    if (sessionId) {
      try {
        await apiRequest(`/api/gemini-ai/session/${sessionId}`, {
          method: 'DELETE',
          headers: {
            'Content-Type': 'application/json'
          }
        });
      } catch (error) {
        console.error('Failed to end session:', error);
      }
    }
    
    setSessionId(null);
    setMessages([]);
    setSessionStatus('offline');
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/60 flex items-start justify-center z-50 p-2 md:p-4 pt-8 md:pt-16">
      <Card className="w-full max-w-5xl h-[92vh] md:h-[85vh] flex flex-col shadow-2xl bg-white rounded-xl overflow-hidden relative">
        {/* Header - Positioned Lower for Better Reading Zone */}
        <CardHeader className="flex flex-row items-center justify-between space-y-0 p-3 md:p-4 bg-gradient-to-r from-emerald-600 via-teal-600 to-cyan-600 text-white flex-shrink-0">
          <CardTitle className="flex items-center gap-2 md:gap-4 min-w-0">
            <div className="w-8 h-8 md:w-10 md:h-10 bg-white rounded-full flex items-center justify-center shadow-lg flex-shrink-0">
              <div className="w-6 h-6 md:w-8 md:h-8 bg-gradient-to-br from-purple-100 to-pink-100 rounded-full flex items-center justify-center">
                <div className="relative">
                  <div className="w-5 h-5 md:w-6 md:h-6 bg-gradient-to-br from-amber-200 to-orange-200 rounded-full relative">
                    <div className="absolute top-1 md:top-1.5 left-1 md:left-1.5 w-0.5 md:w-1 h-0.5 md:h-1 bg-slate-700 rounded-full"></div>
                    <div className="absolute top-1 md:top-1.5 right-1 md:right-1.5 w-0.5 md:w-1 h-0.5 md:h-1 bg-slate-700 rounded-full"></div>
                    <div className="absolute bottom-1 md:bottom-1.5 left-1/2 transform -translate-x-1/2 w-2 md:w-2.5 h-0.5 bg-pink-400 rounded-full"></div>
                    <div className="absolute -top-0.5 md:-top-1 left-0 right-0 h-1.5 md:h-2 bg-gradient-to-br from-slate-600 to-slate-700 rounded-t-full"></div>
                  </div>
                </div>
              </div>
            </div>
            <div className="min-w-0 flex-1">
              <div className="text-base md:text-lg font-semibold flex items-center gap-2">
                <span className="truncate">{language === 'en' ? 'Assistente Virtual' : 'Assistente Virtual'}</span>
                <Brain className="h-4 w-4 md:h-5 md:w-5 flex-shrink-0" />
              </div>
              <div className="text-xs md:text-sm text-white/80 truncate">
                {language === 'en' ? 'AI • Terminal Expert' : 'IA • Especialista Terminal'}
              </div>
            </div>
          </CardTitle>
          <div className="flex items-center gap-2 md:gap-3 flex-shrink-0">
            <Badge variant="secondary" className="bg-white/20 text-white border-white/30 px-1.5 py-0.5 text-xs md:px-2 md:py-1 md:text-sm">
              {sessionStatus === 'active' ? (language === 'en' ? 'Ativo' : 'Ativo') : 
               sessionStatus === 'connecting' ? (language === 'en' ? 'Conectando' : 'Conectando') : 
               (language === 'en' ? 'Offline' : 'Offline')}
            </Badge>
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={handleClose} 
              className="text-white hover:bg-white/20 hover:bg-red-500/20 p-1 md:p-1.5 rounded-full transition-colors flex-shrink-0"
              title={language === 'en' ? 'Close Assistant' : 'Fechar Assistente'}
            >
              <X className="h-4 w-4 md:h-5 md:w-5" />
            </Button>
          </div>
        </CardHeader>

        {/* Chat Area - Maximized for Reading */}
        <CardContent className="flex-1 flex flex-col p-0 bg-gradient-to-b from-purple-50 to-white overflow-hidden">
          <div className="flex-1 overflow-y-auto p-2 md:p-4 space-y-2 md:space-y-4 scrollbar-thin scrollbar-thumb-purple-300 scrollbar-track-purple-100">
            {messages.map((message) => (
              <div
                key={message.id}
                className={`flex gap-4 ${
                  message.role === 'user' ? 'flex-row-reverse' : ''
                }`}
              >
                {/* Avatar */}
                <div className={`w-11 h-11 rounded-full flex items-center justify-center flex-shrink-0 shadow-md ${
                  message.role === 'user' 
                    ? 'bg-blue-500 text-white' 
                    : 'bg-gradient-to-br from-purple-600 via-pink-600 to-blue-600 text-white'
                }`}>
                  {message.role === 'user' ? <User className="h-5 w-5" /> : <Sparkles className="h-5 w-5" />}
                </div>
                
                {/* Message Bubble */}
                <div className={`flex-1 max-w-[80%] ${message.role === 'user' ? 'flex justify-end' : ''}`}>
                  <div className={`p-4 rounded-2xl shadow-sm ${
                    message.role === 'user'
                      ? 'bg-blue-500 text-white rounded-br-md'
                      : 'bg-white border border-purple-200 rounded-bl-md'
                  }`}>
                    <p className="text-base font-medium leading-relaxed whitespace-pre-line antialiased">{message.content}</p>
                    
                    {/* Assistant extras */}
                    {message.role === 'assistant' && (
                      <div className="mt-4 space-y-3">
                        {/* Metrics */}
                        {(message.confidence !== undefined || message.responseTimeMs !== undefined) && (
                          <div className="flex items-center gap-4 text-xs text-gray-500 bg-purple-50 px-4 py-2 rounded-xl">
                            {message.confidence !== undefined && (
                              <div className="flex items-center gap-2">
                                <Zap className="h-3 w-3" />
                                <span>
                                  {language === 'en' ? 'Confidence' : 'Confiança'}: 
                                  <span className={`ml-1 font-medium ${
                                    message.confidence >= 0.8 ? 'text-green-600' : 
                                    message.confidence >= 0.6 ? 'text-yellow-600' : 'text-red-600'
                                  }`}>
                                    {Math.round(message.confidence * 100)}%
                                  </span>
                                </span>
                              </div>
                            )}
                            {message.responseTimeMs !== undefined && (
                              <div className="flex items-center gap-2">
                                <Clock className="h-3 w-3" />
                                <span>{message.responseTimeMs}ms</span>
                              </div>
                            )}
                            {message.requiresEscalation && (
                              <div className="flex items-center gap-2 text-orange-600">
                                <span className="w-2 h-2 bg-orange-500 rounded-full animate-pulse" />
                                <span>{language === 'en' ? 'May need human assistance' : 'Pode precisar assistência humana'}</span>
                              </div>
                            )}
                          </div>
                        )}

                        {/* Suggestions */}
                        {message.suggestions && message.suggestions.length > 0 && (
                          <div className="space-y-3">
                            <p className="text-xs text-gray-600 font-medium border-l-2 border-purple-500 pl-3">
                              {language === 'en' ? 'Suggested questions:' : 'Perguntas sugeridas:'}
                            </p>
                            <div className="grid grid-cols-1 gap-1 md:gap-2">
                              {message.suggestions.map((suggestion, index) => (
                                <Button
                                  key={index}
                                  variant="outline"
                                  size="sm"
                                  onClick={() => sendMessage(suggestion, true)}
                                  className="text-xs h-8 md:h-9 px-2 md:px-3 bg-purple-50 border-purple-200 hover:bg-purple-100 text-purple-700 rounded-md md:rounded-lg justify-start"
                                >
                                  <Sparkles className="h-3 w-3 mr-1 md:mr-2 flex-shrink-0" />
                                  <span className="truncate">{suggestion}</span>
                                </Button>
                              ))}
                            </div>
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            ))}
            
            {/* Session and Voice status indicators */}
            <div className="border-b border-purple-200 bg-gradient-to-r from-purple-50 to-pink-50">
              {/* Session status */}
              <div className="flex justify-center items-center p-2">
                <div className="flex items-center gap-2">
                  {sessionStatus === 'connecting' && (
                    <>
                      <div className="w-2 h-2 bg-yellow-500 rounded-full animate-pulse" />
                      <span className="text-xs text-yellow-700">Conectando...</span>
                    </>
                  )}
                  {sessionStatus === 'active' && (
                    <>
                      <div className="w-2 h-2 bg-green-500 rounded-full" />
                      <span className="text-xs text-green-700">Assistente conectado</span>
                    </>
                  )}
                  {sessionStatus === 'offline' && (
                    <>
                      <div className="w-2 h-2 bg-red-500 rounded-full" />
                      <span className="text-xs text-red-700">Desconectado</span>
                    </>
                  )}
                </div>
              </div>

              {/* Voice status */}
              {(isRecording || isPlayingAudio || voiceMode) && (
                <div className="flex justify-center items-center p-2 border-t border-emerald-200">
                  <div className="flex items-center gap-3">
                    {isRecording && (
                      <div className="flex items-center gap-2 text-red-600">
                        <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse" />
                        <Mic className="h-3 w-3 animate-pulse" />
                        <span className="text-xs font-medium">Gravando...</span>
                      </div>
                    )}
                    {isPlayingAudio && (
                      <div className="flex items-center gap-2 text-blue-600">
                        <div className="w-2 h-2 bg-blue-500 rounded-full animate-pulse" />
                        <Volume2 className="h-3 w-3 animate-pulse" />
                        <span className="text-xs font-medium">Reproduzindo áudio...</span>
                      </div>
                    )}
                    {voiceMode && !isRecording && !isPlayingAudio && (
                      <div className="flex items-center gap-2 text-emerald-600">
                        <div className="w-2 h-2 bg-emerald-500 rounded-full animate-ping" />
                        <MessageCircle className="h-3 w-3" />
                        <span className="text-xs font-medium">Modo conversa ativo</span>
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>

            {/* Loading indicator */}
            {isLoading && (
              <div className="flex gap-4">
                <div className="w-11 h-11 bg-gradient-to-br from-emerald-500 via-teal-500 to-cyan-500 rounded-full flex items-center justify-center shadow-md">
                  <div className="w-8 h-8 bg-white rounded-full flex items-center justify-center overflow-hidden">
                    <div className="w-full h-full bg-gradient-to-br from-purple-100 to-pink-100 flex items-center justify-center">
                      <div className="relative animate-pulse">
                        <div className="w-6 h-6 bg-gradient-to-br from-amber-200 to-orange-200 rounded-full relative">
                          <div className="absolute top-1.5 left-1 w-1 h-1 bg-slate-700 rounded-full animate-pulse"></div>
                          <div className="absolute top-1.5 right-1 w-1 h-1 bg-slate-700 rounded-full animate-pulse"></div>
                          <div className="absolute bottom-1 left-1/2 transform -translate-x-1/2 w-2 h-0.5 bg-pink-400 rounded-full"></div>
                          <div className="absolute -top-0.5 left-0 right-0 h-2 bg-gradient-to-br from-slate-600 to-slate-700 rounded-t-full"></div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="bg-white border border-purple-200 p-5 rounded-2xl rounded-bl-md shadow-sm">
                  <div className="flex items-center space-x-2">
                    <div className="w-2 h-2 bg-purple-500 rounded-full animate-bounce" />
                    <div className="w-2 h-2 bg-pink-500 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }} />
                    <div className="w-2 h-2 bg-blue-500 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }} />
                    <span className="text-sm text-gray-500 ml-2">
                      {language === 'en' ? 'Assistente pensando...' : 'Assistente pensando...'}
                    </span>
                  </div>
                </div>
              </div>
            )}
            <div ref={messagesEndRef} className="h-4" />
          </div>

          {/* Input section - Ultra Compact */}
          <div className="flex-shrink-0 border-t border-purple-200 p-2 bg-gradient-to-r from-purple-50 to-pink-50">
            <div className="flex gap-2 items-center">
              <div className="flex-1">
                <Input
                  placeholder="Digite sua pergunta sobre navios, operações..."
                  value={currentMessage}
                  onChange={(e) => setCurrentMessage(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && !e.shiftKey && sendMessage()}
                  disabled={isLoading || sessionStatus !== 'active'}
                  className="h-9 text-sm border-purple-300 focus:border-purple-500 focus:ring-purple-500 rounded-lg bg-white"
                />
              </div>

              {/* Voice controls - minimal inline */}
              <div className="flex gap-0.5">
                <Button 
                  onClick={isRecording ? stopRecording : startRecording}
                  disabled={isLoading || sessionStatus !== 'active'}
                  size="sm"
                  className={`h-6 w-6 p-0 rounded-md transition-all ${
                    isRecording 
                      ? 'bg-red-500 hover:bg-red-600 animate-pulse' 
                      : 'bg-green-500 hover:bg-green-600'
                  }`}
                  title={isRecording ? 'Parar gravação' : 'Gravar mensagem de voz'}
                >
                  {isRecording ? <MicOff className="h-2.5 w-2.5" /> : <Mic className="h-2.5 w-2.5" />}
                </Button>

                <Button 
                  onClick={() => setAudioEnabled(!audioEnabled)}
                  size="sm"
                  className={`h-6 w-6 p-0 rounded-md ${
                    audioEnabled 
                      ? 'bg-blue-500 hover:bg-blue-600' 
                      : 'bg-gray-400 hover:bg-gray-500'
                  }`}
                  title={audioEnabled ? 'Desativar áudio' : 'Ativar áudio'}
                >
                  {audioEnabled ? <Volume2 className="h-2.5 w-2.5" /> : <VolumeX className="h-2.5 w-2.5" />}
                </Button>

                <Button
                  onClick={toggleVoiceMode}
                  disabled={sessionStatus !== 'active'}
                  size="sm"
                  className={`h-6 w-6 p-0 rounded-md transition-all ${
                    voiceMode
                      ? 'bg-emerald-500 hover:bg-emerald-600 animate-pulse'
                      : 'bg-purple-500 hover:bg-purple-600'
                  }`}
                  title={voiceMode ? 'Sair do modo conversa de voz' : 'Ativar modo conversa de voz'}
                >
                  <MessageCircle className="h-2.5 w-2.5" />
                </Button>
              </div>

              {/* Send button */}
              <Button 
                onClick={() => sendMessage()} 
                disabled={!currentMessage.trim() || isLoading || sessionStatus !== 'active'}
                className="h-9 px-3 bg-gradient-to-r from-purple-600 via-pink-600 to-blue-600 hover:from-purple-700 hover:via-pink-700 hover:to-blue-700 rounded-lg shadow-md"
              >
                <Send className="h-3.5 w-3.5" />
              </Button>
            </div>
            
            {/* Status indicators - ultra minimal */}
            <div className="mt-1 flex items-center justify-center gap-1 text-xs text-gray-400">
              <div className={`w-1 h-1 rounded-full ${
                sessionStatus === 'active' ? 'bg-green-500' : 
                sessionStatus === 'connecting' ? 'bg-yellow-500 animate-pulse' : 'bg-gray-400'
              }`} />
              {voiceMode && <div className="w-1 h-1 rounded-full bg-emerald-500 animate-ping" />}
              {audioEnabled && <div className="w-1 h-1 rounded-full bg-blue-500" />}
              <span className="text-xs opacity-40">AI</span>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}