import React, { useEffect } from 'react';
import { createPortal } from 'react-dom';

export function PortalButton() {
  useEffect(() => {
    // Create button element
    const button = document.createElement('div');
    button.id = 'portal-assistant-button';
    button.innerHTML = `
      <div style="
        position: fixed;
        bottom: 30px;
        right: 30px;
        width: 70px;
        height: 70px;
        background: linear-gradient(45deg, #3b82f6, #8b5cf6);
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        color: white;
        font-size: 12px;
        font-weight: bold;
        z-index: 999999;
        box-shadow: 0 8px 25px rgba(0,0,0,0.3);
        transition: all 0.3s ease;
        animation: bounce 2s infinite;
      ">
        🤖 AI
      </div>
      <style>
        @keyframes bounce {
          0%, 20%, 50%, 80%, 100% { transform: translateY(0); }
          40% { transform: translateY(-10px); }
          60% { transform: translateY(-5px); }
        }
      </style>
    `;
    
    button.onclick = () => {
      alert('Assistente Virtual clicado via Portal!');
    };
    
    document.body.appendChild(button);
    
    return () => {
      const existingButton = document.getElementById('portal-assistant-button');
      if (existingButton) {
        document.body.removeChild(existingButton);
      }
    };
  }, []);

  return null; // This component doesn't render anything in the React tree
}