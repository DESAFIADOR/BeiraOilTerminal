import React, { useState, useEffect } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useMutation, useQueryClient, useQuery } from '@tanstack/react-query';
import { 
  Ship, 
  Anchor, 
  Gauge, 
  Package, 
  User, 
  Clock, 
  Calendar,
  Edit,
  Save,
  X,
  Activity,
  TrendingUp
} from 'lucide-react';

interface BerthShipInfoModalProps {
  ship: any;
  isOpen: boolean;
  onClose: () => void;
  parcels: any[];
}

export function BerthShipInfoModal({ ship, isOpen, onClose, parcels }: BerthShipInfoModalProps) {
  const [isEditingRate, setIsEditingRate] = useState(false);
  const [agreedRate, setAgreedRate] = useState(150);
  const [estimatedCompletion, setEstimatedCompletion] = useState<string>('');
  const queryClient = useQueryClient();

  // Fetch operational status in real-time
  const { data: operationalStatus, isLoading: isLoadingOperational } = useQuery({
    queryKey: ['/api/ships', ship?.id, 'operational-status'],
    enabled: isOpen && !!ship?.id,
    refetchInterval: 30000, // Refresh every 30 seconds
  });

  // Calculate total volume and main product
  const totalVolume = (parcels || []).reduce((sum, parcel) => 
    sum + parseFloat(parcel.volumeMT || 0), 0
  );

  const mainProduct = (parcels || []).map((p: any) => p.product).filter((v, i, a) => a.indexOf(v) === i).join(', ') || 'N/A';

  // Use real operational data when available
  const dischargeProgress = operationalStatus?.dischargeProgress || ship?.dischargeProgress || 0;
  const currentRate = operationalStatus?.currentRate || 150;
  const pressure = operationalStatus?.pressure || 8.2;
  const lastUpdate = operationalStatus?.lastUpdate;
  const operationalDataStatus = operationalStatus?.operationalStatus || 'unknown';

  const getOperationTypeColor = (type: string) => {
    switch (type?.toLowerCase()) {
      case 'nacional': return 'bg-blue-100 text-blue-800';
      case 'trânsito': return 'bg-green-100 text-green-800';
      case 'combinado': return 'bg-purple-100 text-purple-800';
      case 'lpg': return 'bg-orange-100 text-orange-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  // Handle edit rate
  const handleEditRate = () => {
    setIsEditingRate(true);
  };

  const handleCancelEdit = () => {
    setIsEditingRate(false);
  };

  const handleSaveRate = () => {
    updateRateMutation.mutate(agreedRate);
  };

  // Calculate ETC based on discharge progress and current rate
  useEffect(() => {
    if (dischargeProgress < 100 && currentRate > 0 && totalVolume > 0) {
      const remainingVolume = totalVolume * (1 - dischargeProgress / 100);
      const hoursRemaining = remainingVolume / currentRate;
      const completionTime = new Date();
      completionTime.setHours(completionTime.getHours() + hoursRemaining);
      
      const formattedTime = completionTime.toLocaleString('pt-BR', {
        day: '2-digit',
        month: '2-digit',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
      });
      
      setEstimatedCompletion(formattedTime);
    } else if (dischargeProgress >= 100) {
      setEstimatedCompletion('Concluído');
    } else {
      setEstimatedCompletion('Dados insuficientes');
    }
  }, [dischargeProgress, currentRate, totalVolume]);

  // Mutation for updating agreed discharge rate
  const updateRateMutation = useMutation({
    mutationFn: async (newRate: number) => {
      const response = await fetch(`/api/ships/${ship.id}/agreed-rate`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ agreedRate: newRate }),
      });
      
      if (!response.ok) {
        const errorData = await response.text();
        throw new Error(`Failed to update rate: ${response.status}`);
      }
      
      return response.json();
    },
    onSuccess: () => {
      setIsEditingRate(false);
      queryClient.invalidateQueries({ queryKey: ['/api/ships'] });
    },
    onError: (error) => {
      console.error('Rate update error:', error);
    },
  });

  if (!ship) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-blue-700">
            <Ship className="w-6 h-6 text-blue-600" />
            Navio no Cais 12 - Dados Operacionais
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Basic Information */}
          <Card className="border-blue-200">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-bold text-blue-700">{ship.name}</h3>
                <Badge className={getOperationTypeColor(ship.operationType)}>
                  {ship.operationType || 'N/A'}
                </Badge>
              </div>

              <div className="grid grid-cols-2 gap-4 text-sm">
                <div className="flex items-center gap-2">
                  <Anchor className="w-4 h-4 text-gray-500" />
                  <span className="text-gray-600">Contramarcha:</span>
                  <span className="font-medium">{ship.countermark || 'N/A'}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Gauge className="w-4 h-4 text-gray-500" />
                  <span className="text-gray-600">Calado:</span>
                  <span className="font-medium">{ship.draft || 'N/A'}m</span>
                </div>
                <div className="flex items-center gap-2">
                  <Package className="w-4 h-4 text-gray-500" />
                  <span className="text-gray-600">Produto:</span>
                  <span className="font-medium">{ship.cargoType || 'N/A'}</span>
                </div>
                <div className="flex flex-col gap-2">
                  <div className="flex items-center gap-2">
                    <Ship className="w-4 h-4 text-gray-500" />
                    <span className="text-gray-600">Parcelas Registradas:</span>
                  </div>
                  <div className="ml-6 space-y-1">
                    {(parcels || []).map((parcel: any, index: number) => (
                      <div key={index} className="text-sm flex items-center">
                        <span className="font-bold text-gray-700 w-6">{index + 1}.</span>
                        <span className="font-medium text-blue-600">{parcel.parcelNumber}:</span>
                        <span className="ml-2 font-semibold">{parseFloat(parcel.volumeMT || 0).toLocaleString()} MT</span>
                        <span className="text-gray-500 ml-2">({parcel.product})</span>
                      </div>
                    ))}
                    <div className="border-t pt-1 mt-2">
                      <span className="font-bold text-gray-800">Total: {totalVolume.toLocaleString()} MT</span>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Real-time Operational Data */}
          <Card className="border-orange-200">
            <CardContent className="pt-6">
              <h3 className="font-bold text-orange-700 mb-3 flex items-center gap-2">
                <Activity className="w-4 h-4" />
                Dados Operacionais em Tempo Real
              </h3>
              
              <div className="space-y-4">
                <div className="bg-gray-50 rounded-lg p-4">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm font-medium text-gray-700">Progresso da Descarga</span>
                    <span className="text-lg font-bold text-gray-900">{dischargeProgress.toFixed(1)}%</span>
                  </div>
                  <Progress value={dischargeProgress} className="h-3" />
                </div>

                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <span className="text-gray-600">Status dos Dados:</span>
                    <div className="font-medium mt-1 flex items-center gap-2">
                      {operationalDataStatus === 'active' ? (
                        <>
                          <Activity className="w-3 h-3 text-green-500" />
                          <span className="text-green-700">Tempo Real</span>
                        </>
                      ) : (
                        <>
                          <Activity className="w-3 h-3 text-gray-400" />
                          <span className="text-gray-600">Simulado</span>
                        </>
                      )}
                    </div>
                  </div>
                  
                  <div>
                    <span className="text-gray-600">Taxa Atual:</span>
                    <div className="font-bold text-blue-600 mt-1 flex items-center gap-2">
                      <TrendingUp className="w-4 h-4" />
                      {currentRate} MT/h
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4 text-sm border-t pt-4">
                  <div>
                    <span className="text-gray-600">Pressão Operacional:</span>
                    <div className="font-bold text-orange-600 mt-1 flex items-center gap-2">
                      <Gauge className="w-4 h-4" />
                      {pressure} bar
                    </div>
                  </div>
                  
                  <div>
                    <span className="text-gray-600">Última Atualização:</span>
                    <div className="font-medium text-gray-700 mt-1">
                      {lastUpdate ? 
                        new Date(lastUpdate).toLocaleString('pt-BR') : 
                        'Não disponível'
                      }
                    </div>
                  </div>
                </div>

                {operationalStatus?.discharged && (
                  <div className="bg-blue-50 rounded-lg p-3">
                    <div className="text-sm text-gray-600">Volume Descarregado:</div>
                    <div className="font-bold text-blue-700 text-lg">
                      {parseFloat(operationalStatus.discharged || '0').toLocaleString()} MT
                    </div>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          {/* ETC Information */}
          <Card className="border-purple-200">
            <CardContent className="pt-6">
              <h3 className="font-bold text-purple-700 mb-3 flex items-center gap-2">
                <Clock className="w-4 h-4" />
                Estimativa de Conclusão (ETC)
              </h3>
              
              <div className="bg-purple-50 rounded-lg p-4">
                <div className="flex items-center gap-3">
                  <Calendar className="w-5 h-5 text-purple-600" />
                  <div>
                    <div className="text-sm text-gray-600">Conclusão Estimada</div>
                    <div className="text-lg font-bold text-purple-700">
                      {estimatedCompletion || 'Calculando...'}
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </DialogContent>
    </Dialog>
  );
}