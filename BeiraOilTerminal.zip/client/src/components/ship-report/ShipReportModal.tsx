import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { 
  FileText, 
  Ship, 
  Clock, 
  Package,
  Users,
  MapPin,
  Save,
  Plus,
  Trash2
} from "lucide-react";

interface ShipReportModalProps {
  isOpen: boolean;
  onClose: () => void;
  ship: any;
}

interface OperationEntry {
  id?: number;
  operation: string;
  date: string;
  timeCommenced: string;
  timeCompleted: string;
  notes: string;
  pob: string; // People on Board
}

interface ShipReportData {
  // Ship basic info
  shipName: string;
  countermark: string;
  imo: string;
  loa: string; // Length Overall
  displacement: string;
  dwt: string; // Dead Weight Tonnage
  grossTon: string;
  portOfRegistry: string;
  code: string;
  
  // Times and dates
  arrivalTime: string;
  berthingTime: string;
  deberthingTime: string;
  agent: string;
  lastPort: string;
  
  // Product details
  product: string;
  equipment: string;
  maxPressureAgreed: string;
  density: string;
  weight: string;
  volume: string;
  receivers: string;
  draft: string;
  destination: string;
  client: string;
  portOfLoading: string;
  
  // Operations
  operations: OperationEntry[];
}

export function ShipReportModal({ isOpen, onClose, ship }: ShipReportModalProps) {
  const [reportData, setReportData] = useState<ShipReportData>({
    shipName: '',
    countermark: '',
    imo: '',
    loa: '',
    displacement: '',
    dwt: '',
    grossTon: '',
    portOfRegistry: '',
    code: '',
    arrivalTime: '',
    berthingTime: '',
    deberthingTime: '',
    agent: '',
    lastPort: '',
    product: '',
    equipment: '',
    maxPressureAgreed: '',
    density: '',
    weight: '',
    volume: '',
    receivers: '',
    draft: '',
    destination: '',
    client: '',
    portOfLoading: '',
    operations: []
  });

  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch existing report data
  const { data: existingReport } = useQuery({
    queryKey: ['/api/ships', ship?.id, 'report'],
    enabled: !!ship?.id && isOpen,
  });

  // Save report mutation
  const saveReportMutation = useMutation({
    mutationFn: async (data: ShipReportData) => {
      const response = await fetch(`/api/ships/${ship.id}/report`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          shipId: ship.id,
          reportData: data,
          updatedAt: new Date().toISOString()
        }),
      });
      if (!response.ok) throw new Error('Failed to save report');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/ships', ship?.id, 'report'] });
      toast({
        title: "Sucesso",
        description: "Relatório salvo com sucesso",
      });
    },
    onError: () => {
      toast({
        title: "Erro",
        description: "Erro ao salvar relatório",
        variant: "destructive",
      });
    }
  });

  // Initialize with ship data and existing report
  useEffect(() => {
    if (ship && isOpen) {
      setReportData(prev => ({
        ...prev,
        shipName: ship.name || '',
        countermark: ship.countermark || '',
        agent: ship.shipAgent || '',
        product: ship.cargoType || '',
        arrivalTime: ship.arrivalDateTime ? new Date(ship.arrivalDateTime).toLocaleString('pt-BR', {
          timeZone: 'Africa/Maputo'
        }) : '',
        // Initialize with existing report data if available
        ...(existingReport?.reportData || {})
      }));
    }
  }, [ship, existingReport, isOpen]);

  const handleInputChange = (field: keyof ShipReportData, value: string) => {
    setReportData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const addOperation = () => {
    const newOperation: OperationEntry = {
      operation: '',
      date: new Date().toLocaleDateString('pt-BR'),
      timeCommenced: '',
      timeCompleted: '',
      notes: '',
      pob: ''
    };
    setReportData(prev => ({
      ...prev,
      operations: [...prev.operations, newOperation]
    }));
  };

  const updateOperation = (index: number, field: keyof OperationEntry, value: string) => {
    setReportData(prev => ({
      ...prev,
      operations: prev.operations.map((op, i) => 
        i === index ? { ...op, [field]: value } : op
      )
    }));
  };

  const removeOperation = (index: number) => {
    setReportData(prev => ({
      ...prev,
      operations: prev.operations.filter((_, i) => i !== index)
    }));
  };

  const handleSave = () => {
    saveReportMutation.mutate(reportData);
  };

  if (!ship) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-6xl h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <FileText className="h-5 w-5" />
            Relatório Operacional do Navio - {ship.name}
          </DialogTitle>
        </DialogHeader>

        <Tabs defaultValue="ship-info" className="w-full">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="ship-info" className="flex items-center gap-2">
              <Ship className="h-4 w-4" />
              Informações do Navio
            </TabsTrigger>
            <TabsTrigger value="cargo-info" className="flex items-center gap-2">
              <Package className="h-4 w-4" />
              Informações da Carga
            </TabsTrigger>
            <TabsTrigger value="operations" className="flex items-center gap-2">
              <Clock className="h-4 w-4" />
              Operações
            </TabsTrigger>
            <TabsTrigger value="summary" className="flex items-center gap-2">
              <FileText className="h-4 w-4" />
              Resumo
            </TabsTrigger>
          </TabsList>

          {/* Ship Information Tab */}
          <TabsContent value="ship-info" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Dados Básicos do Navio</CardTitle>
              </CardHeader>
              <CardContent className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="shipName">Nome do Navio</Label>
                  <Input
                    id="shipName"
                    value={reportData.shipName}
                    onChange={(e) => handleInputChange('shipName', e.target.value)}
                  />
                </div>
                <div>
                  <Label htmlFor="countermark">C/M (Countermark)</Label>
                  <Input
                    id="countermark"
                    value={reportData.countermark}
                    onChange={(e) => handleInputChange('countermark', e.target.value)}
                  />
                </div>
                <div>
                  <Label htmlFor="imo">IMO</Label>
                  <Input
                    id="imo"
                    value={reportData.imo}
                    onChange={(e) => handleInputChange('imo', e.target.value)}
                  />
                </div>
                <div>
                  <Label htmlFor="loa">L.O.A. (Length Overall)</Label>
                  <Input
                    id="loa"
                    value={reportData.loa}
                    onChange={(e) => handleInputChange('loa', e.target.value)}
                  />
                </div>
                <div>
                  <Label htmlFor="displacement">Displacement</Label>
                  <Input
                    id="displacement"
                    value={reportData.displacement}
                    onChange={(e) => handleInputChange('displacement', e.target.value)}
                  />
                </div>
                <div>
                  <Label htmlFor="dwt">D.W.T. (Dead Weight Tonnage)</Label>
                  <Input
                    id="dwt"
                    value={reportData.dwt}
                    onChange={(e) => handleInputChange('dwt', e.target.value)}
                  />
                </div>
                <div>
                  <Label htmlFor="grossTon">Gross Tonnage</Label>
                  <Input
                    id="grossTon"
                    value={reportData.grossTon}
                    onChange={(e) => handleInputChange('grossTon', e.target.value)}
                  />
                </div>
                <div>
                  <Label htmlFor="portOfRegistry">Port of Registry</Label>
                  <Input
                    id="portOfRegistry"
                    value={reportData.portOfRegistry}
                    onChange={(e) => handleInputChange('portOfRegistry', e.target.value)}
                  />
                </div>
                <div>
                  <Label htmlFor="code">Code</Label>
                  <Input
                    id="code"
                    value={reportData.code}
                    onChange={(e) => handleInputChange('code', e.target.value)}
                  />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Horários e Agentes</CardTitle>
              </CardHeader>
              <CardContent className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="arrivalTime">Arrival Time</Label>
                  <Input
                    id="arrivalTime"
                    type="datetime-local"
                    value={reportData.arrivalTime}
                    onChange={(e) => handleInputChange('arrivalTime', e.target.value)}
                  />
                </div>
                <div>
                  <Label htmlFor="berthingTime">Berthing Time</Label>
                  <Input
                    id="berthingTime"
                    type="datetime-local"
                    value={reportData.berthingTime}
                    onChange={(e) => handleInputChange('berthingTime', e.target.value)}
                  />
                </div>
                <div>
                  <Label htmlFor="deberthingTime">Deberthing Time</Label>
                  <Input
                    id="deberthingTime"
                    type="datetime-local"
                    value={reportData.deberthingTime}
                    onChange={(e) => handleInputChange('deberthingTime', e.target.value)}
                  />
                </div>
                <div>
                  <Label htmlFor="agent">Agent</Label>
                  <Input
                    id="agent"
                    value={reportData.agent}
                    onChange={(e) => handleInputChange('agent', e.target.value)}
                  />
                </div>
                <div>
                  <Label htmlFor="lastPort">Last Port</Label>
                  <Input
                    id="lastPort"
                    value={reportData.lastPort}
                    onChange={(e) => handleInputChange('lastPort', e.target.value)}
                  />
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Cargo Information Tab */}
          <TabsContent value="cargo-info" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Detalhes do Produto</CardTitle>
              </CardHeader>
              <CardContent className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="product">Product</Label>
                  <Input
                    id="product"
                    value={reportData.product}
                    onChange={(e) => handleInputChange('product', e.target.value)}
                  />
                </div>
                <div>
                  <Label htmlFor="equipment">Equipment</Label>
                  <Input
                    id="equipment"
                    value={reportData.equipment}
                    onChange={(e) => handleInputChange('equipment', e.target.value)}
                  />
                </div>
                <div>
                  <Label htmlFor="maxPressureAgreed">Max. Pressure Agreed</Label>
                  <Input
                    id="maxPressureAgreed"
                    value={reportData.maxPressureAgreed}
                    onChange={(e) => handleInputChange('maxPressureAgreed', e.target.value)}
                  />
                </div>
                <div>
                  <Label htmlFor="density">Density</Label>
                  <Input
                    id="density"
                    value={reportData.density}
                    onChange={(e) => handleInputChange('density', e.target.value)}
                  />
                </div>
                <div>
                  <Label htmlFor="weight">Weight</Label>
                  <Input
                    id="weight"
                    value={reportData.weight}
                    onChange={(e) => handleInputChange('weight', e.target.value)}
                  />
                </div>
                <div>
                  <Label htmlFor="volume">Volume</Label>
                  <Input
                    id="volume"
                    value={reportData.volume}
                    onChange={(e) => handleInputChange('volume', e.target.value)}
                  />
                </div>
                <div className="col-span-2">
                  <Label htmlFor="receivers">Receiver(s)</Label>
                  <Textarea
                    id="receivers"
                    value={reportData.receivers}
                    onChange={(e) => handleInputChange('receivers', e.target.value)}
                  />
                </div>
                <div>
                  <Label htmlFor="draft">Draft</Label>
                  <Input
                    id="draft"
                    value={reportData.draft}
                    onChange={(e) => handleInputChange('draft', e.target.value)}
                  />
                </div>
                <div>
                  <Label htmlFor="destination">Destination</Label>
                  <Input
                    id="destination"
                    value={reportData.destination}
                    onChange={(e) => handleInputChange('destination', e.target.value)}
                  />
                </div>
                <div>
                  <Label htmlFor="client">Client</Label>
                  <Input
                    id="client"
                    value={reportData.client}
                    onChange={(e) => handleInputChange('client', e.target.value)}
                  />
                </div>
                <div>
                  <Label htmlFor="portOfLoading">Port of Loading</Label>
                  <Input
                    id="portOfLoading"
                    value={reportData.portOfLoading}
                    onChange={(e) => handleInputChange('portOfLoading', e.target.value)}
                  />
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Operations Tab */}
          <TabsContent value="operations" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  Registro de Operações
                  <Button onClick={addOperation} size="sm" className="flex items-center gap-2">
                    <Plus className="h-4 w-4" />
                    Adicionar Operação
                  </Button>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {reportData.operations.map((operation, index) => (
                    <div key={index} className="border rounded-lg p-4 space-y-3">
                      <div className="flex items-center justify-between">
                        <h4 className="font-medium">Operação {index + 1}</h4>
                        <Button
                          onClick={() => removeOperation(index)}
                          variant="destructive"
                          size="sm"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                      <div className="grid grid-cols-2 gap-3">
                        <div>
                          <Label>Operation</Label>
                          <Input
                            value={operation.operation}
                            onChange={(e) => updateOperation(index, 'operation', e.target.value)}
                            placeholder="e.g., Commence Discharging"
                          />
                        </div>
                        <div>
                          <Label>Date</Label>
                          <Input
                            type="date"
                            value={operation.date}
                            onChange={(e) => updateOperation(index, 'date', e.target.value)}
                          />
                        </div>
                        <div>
                          <Label>Time Commenced</Label>
                          <Input
                            type="time"
                            value={operation.timeCommenced}
                            onChange={(e) => updateOperation(index, 'timeCommenced', e.target.value)}
                          />
                        </div>
                        <div>
                          <Label>Time Completed</Label>
                          <Input
                            type="time"
                            value={operation.timeCompleted}
                            onChange={(e) => updateOperation(index, 'timeCompleted', e.target.value)}
                          />
                        </div>
                        
                        <div>
                          <Textarea
                            placeholder="Notes"
                            value={operation.notes}
                            onChange={(e) => updateOperation(index, 'notes', e.target.value)}
                            rows={2}
                          />
                        </div>
                      </div>
                    </div>
                  ))}
                  
                  {reportData.operations.length === 0 && (
                    <div className="text-center py-8 text-gray-500">
                      Nenhuma operação registrada. Clique em "Adicionar Operação" para começar.
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Summary Tab */}
          <TabsContent value="summary" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Resumo do Relatório</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div><strong>Navio:</strong> {reportData.shipName}</div>
                    <div><strong>IMO:</strong> {reportData.imo}</div>
                    <div><strong>Produto:</strong> {reportData.product}</div>
                    <div><strong>Agente:</strong> {reportData.agent}</div>
                    <div><strong>Operações Registradas:</strong> {reportData.operations.length}</div>
                  </div>
                  
                  <div className="flex gap-3 pt-4">
                    <Button
                      onClick={handleSave}
                      disabled={saveReportMutation.isPending}
                      className="flex items-center gap-2"
                    >
                      <Save className="h-4 w-4" />
                      {saveReportMutation.isPending ? 'Salvando...' : 'Salvar Relatório'}
                    </Button>
                    <Button variant="outline" onClick={onClose}>
                      Fechar
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}