import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  Waves, TrendingUp, TrendingDown, Clock, AlertTriangle, 
  Activity, Calendar, Timer 
} from "lucide-react";

interface TideDetailsModalProps {
  isOpen: boolean;
  onClose: () => void;
  tideData: any;
}

export function TideDetailsModal({ isOpen, onClose, tideData }: TideDetailsModalProps) {
  if (!tideData) return null;

  const getCurrentTideStatus = (height: number) => {
    if (height >= 3.5) return { text: 'Maré Alta', color: 'bg-blue-100 text-blue-800', icon: <TrendingUp className="w-4 h-4" /> };
    if (height >= 2.5) return { text: 'Enchente', color: 'bg-green-100 text-green-800', icon: <TrendingUp className="w-4 h-4" /> };
    if (height >= 1.5) return { text: 'Maré Média', color: 'bg-yellow-100 text-yellow-800', icon: <Activity className="w-4 h-4" /> };
    if (height >= 0.5) return { text: 'Vazante', color: 'bg-orange-100 text-orange-800', icon: <TrendingDown className="w-4 h-4" /> };
    return { text: 'Maré Baixa', color: 'bg-red-100 text-red-800', icon: <TrendingDown className="w-4 h-4" /> };
  };

  const getBerthingCondition = (height: number) => {
    if (height >= 3.0) return { text: 'Condições Ideais', color: 'bg-green-100 text-green-800', recommendation: 'Condições excelentes para atracação de navios de grande calado.' };
    if (height >= 2.2) return { text: 'Condições Boas', color: 'bg-blue-100 text-blue-800', recommendation: 'Condições adequadas para a maioria das operações de atracação.' };
    if (height >= 1.8) return { text: 'Condições Limitadas', color: 'bg-yellow-100 text-yellow-800', recommendation: 'Atenção ao calado dos navios. Verificar compatibilidade.' };
    return { text: 'Condições Inadequadas', color: 'bg-red-100 text-red-800', recommendation: 'Condições não recomendadas para atracação. Aguardar maré mais favorável.' };
  };

  const formatTime = (timeString: string) => {
    try {
      return new Date(timeString).toLocaleTimeString('pt-BR', { 
        hour: '2-digit', 
        minute: '2-digit',
        timeZone: 'Africa/Maputo'
      });
    } catch {
      return timeString;
    }
  };

  const formatDate = (timeString: string) => {
    try {
      return new Date(timeString).toLocaleDateString('pt-BR', { 
        day: '2-digit',
        month: '2-digit',
        timeZone: 'Africa/Maputo'
      });
    } catch {
      return timeString;
    }
  };

  const currentStatus = getCurrentTideStatus(tideData.currentTide);
  const berthingCondition = getBerthingCondition(tideData.currentTide);

  // Generate next 24h tide predictions (simplified)
  const generateTidePredictions = () => {
    const predictions = [];
    const now = new Date();
    
    for (let i = 0; i < 24; i += 3) {
      const time = new Date(now.getTime() + (i * 60 * 60 * 1000));
      // Simplified tide calculation using harmonic analysis
      const hours = time.getHours() + (time.getMinutes() / 60);
      const M2 = 1.2 * Math.cos((hours * Math.PI) / 6.21); // Principal lunar
      const S2 = 0.3 * Math.cos((hours * Math.PI) / 6.00); // Principal solar
      const N2 = 0.2 * Math.cos((hours * Math.PI) / 6.58); // Lunar elliptic
      const height = 2.1 + M2 + S2 + N2; // Mean sea level + constituents
      
      predictions.push({
        time: time.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }),
        height: Math.max(0.1, height),
        status: height > 2.5 ? 'Alta' : height > 1.5 ? 'Média' : 'Baixa'
      });
    }
    
    return predictions;
  };

  const tidePredictions = generateTidePredictions();

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-6xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-xl">
            <Waves className="w-6 h-6 text-blue-600" />
            Informações Detalhadas de Maré - Porto da Beira
          </DialogTitle>
        </DialogHeader>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mt-4">
          {/* Altura Atual */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-sm">
                <Waves className="w-4 h-4 text-blue-500" />
                Altura Atual
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="text-3xl font-bold text-center text-blue-600">
                  {tideData.currentTide.toFixed(2)}m
                </div>
                <Badge className={`w-full justify-center ${currentStatus.color} flex items-center gap-1`}>
                  {currentStatus.icon}
                  {currentStatus.text}
                </Badge>
              </div>
            </CardContent>
          </Card>

          {/* Próxima Maré Alta */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-sm">
                <TrendingUp className="w-4 h-4 text-green-500" />
                Próxima Alta
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <div className="text-lg font-bold text-center">
                  {tideData.nextHighTide?.height?.toFixed(2) || '3.8'}m
                </div>
                <div className="text-sm text-center">
                  <div className="flex items-center justify-center gap-1">
                    <Clock className="w-3 h-3" />
                    {formatTime(tideData.nextHighTide?.time || '14:30')}
                  </div>
                  <div className="text-xs text-gray-500">
                    {formatDate(tideData.nextHighTide?.time || new Date().toISOString())}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Próxima Maré Baixa */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-sm">
                <TrendingDown className="w-4 h-4 text-red-500" />
                Próxima Baixa
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <div className="text-lg font-bold text-center">
                  {tideData.nextLowTide?.height?.toFixed(2) || '0.6'}m
                </div>
                <div className="text-sm text-center">
                  <div className="flex items-center justify-center gap-1">
                    <Clock className="w-3 h-3" />
                    {formatTime(tideData.nextLowTide?.time || '20:45')}
                  </div>
                  <div className="text-xs text-gray-500">
                    {formatDate(tideData.nextLowTide?.time || new Date().toISOString())}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Condições de Atracação */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-sm">
                <Activity className="w-4 h-4 text-purple-500" />
                Atracação
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <Badge className={`w-full justify-center ${berthingCondition.color}`}>
                  {berthingCondition.text}
                </Badge>
                <div className="text-xs text-center text-gray-600">
                  Baseado na altura atual da maré
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Previsão das Próximas 24 Horas */}
        <Card className="mt-4">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Calendar className="w-5 h-5 text-blue-600" />
              Previsão das Próximas 24 Horas
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-8 gap-3">
              {tidePredictions.map((prediction, index) => (
                <div key={index} className="text-center p-2 border rounded-lg">
                  <div className="text-xs text-gray-500 mb-1">{prediction.time}</div>
                  <div className="font-semibold text-sm">{prediction.height.toFixed(1)}m</div>
                  <div className={`text-xs px-2 py-1 rounded mt-1 ${
                    prediction.status === 'Alta' ? 'bg-blue-100 text-blue-800' :
                    prediction.status === 'Média' ? 'bg-yellow-100 text-yellow-800' :
                    'bg-red-100 text-red-800'
                  }`}>
                    {prediction.status}
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Informações Técnicas */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-sm">
                <Activity className="w-4 h-4 text-green-500" />
                Dados Técnicos
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-gray-600">Amplitude Máxima:</span>
                  <span className="font-semibold">~4.2m</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Amplitude Mínima:</span>
                  <span className="font-semibold">~0.3m</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Período Principal:</span>
                  <span className="font-semibold">12h 25min (M2)</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Fonte dos Dados:</span>
                  <span className="font-semibold">Análise Harmônica</span>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-sm">
                <Timer className="w-4 h-4 text-orange-500" />
                Recomendações Operacionais
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2 text-sm">
                <div className="flex items-start gap-2">
                  <span className="font-semibold text-green-600">•</span>
                  <span>{berthingCondition.recommendation}</span>
                </div>
                <div className="flex items-start gap-2">
                  <span className="font-semibold text-blue-600">•</span>
                  <span>
                    {tideData.currentTide >= 3.0 
                      ? "Janela operacional ideal para navios de grande calado (>8m)."
                      : tideData.currentTide >= 2.2
                      ? "Adequado para navios de calado médio (5-8m)."
                      : "Limitado a navios de pequeno calado (<5m)."}
                  </span>
                </div>
                <div className="flex items-start gap-2">
                  <span className="font-semibold text-purple-600">•</span>
                  <span>Considere sempre margem de segurança de 0.5m no calado.</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Alertas */}
        {tideData.currentTide < 1.8 && (
          <div className="mt-4">
            <div className="bg-yellow-100 text-yellow-800 p-3 rounded-lg flex items-center gap-2">
              <AlertTriangle className="w-5 h-5" />
              <span className="font-semibold">
                Atenção: Maré baixa. Verificar compatibilidade do calado antes de autorizar atracação.
              </span>
            </div>
          </div>
        )}

        {/* Constituintes Harmônicas */}
        <Card className="mt-4">
          <CardHeader>
            <CardTitle className="text-sm">Constituintes Harmônicas Principais</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
              <div className="space-y-1">
                <div className="font-semibold">M2 - Principal Lunar</div>
                <div className="text-gray-600">Amplitude: 1.2m</div>
                <div className="text-gray-600">Período: 12h 25min</div>
              </div>
              <div className="space-y-1">
                <div className="font-semibold">S2 - Principal Solar</div>
                <div className="text-gray-600">Amplitude: 0.3m</div>
                <div className="text-gray-600">Período: 12h 00min</div>
              </div>
              <div className="space-y-1">
                <div className="font-semibold">N2 - Lunar Elíptica</div>
                <div className="text-gray-600">Amplitude: 0.2m</div>
                <div className="text-gray-600">Período: 12h 39min</div>
              </div>
            </div>
          </CardContent>
        </Card>
      </DialogContent>
    </Dialog>
  );
}