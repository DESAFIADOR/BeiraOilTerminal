import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { 
  Settings, Save, Package, Calculator, Info, Edit, Check, X
} from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface RatesConfigurationModalProps {
  isOpen: boolean;
  onClose: () => void;
}

interface ParcelConfig {
  parcelId: number;
  product: string;
  receiver: string;
  volumeM3: number;
  defaultRate: number;
  customRate?: number;
  notes?: string;
}

export function RatesConfigurationModal({ isOpen, onClose }: RatesConfigurationModalProps) {
  const [editingParcel, setEditingParcel] = useState<number | null>(null);
  const [tempRate, setTempRate] = useState("");
  const [tempNotes, setTempNotes] = useState("");
  
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const defaultRates: Record<string, number> = {
    'Gasolina': 400,
    'Diesel': 350,
    'Jet A1': 300,
    'LPG': 250,
    'Gasóleo': 350,
    'Fuel Oil': 200
  };

  const { data: ships = [] } = useQuery<any[]>({
    queryKey: ['/api/ships'],
    enabled: isOpen,
  });

  const { data: customRates = [] } = useQuery<any[]>({
    queryKey: ['/api/custom-rates'],
    enabled: isOpen,
  });

  const saveRateMutation = useMutation({
    mutationFn: async (rateData: any) => {
      const response = await fetch('/api/custom-rates', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(rateData),
      });
      
      if (!response.ok) {
        throw new Error('Failed to save rate');
      }
      
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Rate salvo com sucesso",
        description: "O rate customizado foi aplicado ao planejamento",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/custom-rates'] });
      queryClient.invalidateQueries({ queryKey: ['/api/discharge-plan'] });
      setEditingParcel(null);
      setTempRate("");
      setTempNotes("");
    },
    onError: () => {
      toast({
        title: "Erro ao salvar rate",
        description: "Não foi possível salvar o rate customizado",
        variant: "destructive",
      });
    },
  });

  // Preparar navios para configuração
  const shipsWithParcels = ships
    .filter((ship: any) => ship.status === 'at_bar' || ship.status === 'next_to_berth')
    .filter((ship: any) => ship.hasDischargeInstructions)
    .slice(0, 5)
    .map((ship: any) => ({
      shipId: ship.id,
      shipName: ship.name,
      parcels: ship.parcels?.map((parcel: any) => {
        const defaultRate = defaultRates[parcel.product] || 300;
        const existingCustomRate = customRates.find((cr: any) => cr.parcelId === parcel.id);
        
        return {
          parcelId: parcel.id,
          product: parcel.product,
          receiver: parcel.receiver,
          volumeM3: Number(parcel.volumeM3 || 0),
          defaultRate,
          customRate: existingCustomRate?.customRate ? parseFloat(existingCustomRate.customRate) : undefined,
          notes: existingCustomRate?.notes || '',
        };
      }) || []
    }));

  const handleSaveRate = async (shipId: number, parcel: ParcelConfig) => {
    if (!tempRate || parseFloat(tempRate) <= 0) {
      toast({
        title: "Rate inválido",
        description: "O rate deve ser maior que zero",
        variant: "destructive",
      });
      return;
    }

    const rateData = {
      shipId,
      parcelId: parcel.parcelId,
      product: parcel.product,
      receiver: parcel.receiver,
      customRate: parseFloat(tempRate),
      estimatedDuration: parcel.volumeM3 / parseFloat(tempRate),
      notes: tempNotes,
    };

    saveRateMutation.mutate(rateData);
  };

  const getProductColor = (product: string) => {
    const colors: Record<string, string> = {
      'Gasolina': 'bg-red-100 text-red-800',
      'Diesel': 'bg-blue-100 text-blue-800',
      'Jet A1': 'bg-green-100 text-green-800',
      'LPG': 'bg-purple-100 text-purple-800',
      'Gasóleo': 'bg-orange-100 text-orange-800',
      'Fuel Oil': 'bg-gray-100 text-gray-800',
    };
    return colors[product] || 'bg-gray-100 text-gray-800';
  };

  const formatDuration = (hours: number) => {
    const h = Math.floor(hours);
    const m = Math.floor((hours - h) * 60);
    return `${h}h ${m}min`;
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-6xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-xl">
            <Settings className="w-6 h-6" />
            Configuração de Rates por Recebedor
          </DialogTitle>
        </DialogHeader>

        {/* Instruções */}
        <Card className="mb-6 border-2 border-blue-200 bg-blue-50">
          <CardHeader>
            <CardTitle className="text-lg text-blue-800">Como Usar</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2 text-sm text-blue-700">
              <div className="flex items-center gap-2">
                <Info className="w-4 h-4" />
                <span>Configure rates específicos baseados na experiência com cada recebedor</span>
              </div>
              <div className="flex items-center gap-2">
                <Calculator className="w-4 h-4" />
                <span>O sistema ajustará automaticamente o planejamento de descarga</span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Lista de Navios e Parcelas */}
        <div className="space-y-6">
          {shipsWithParcels.length > 0 ? (
            shipsWithParcels.map((ship: any) => (
              <Card key={ship.shipId} className="border-l-4 border-l-blue-500">
                <CardHeader>
                  <CardTitle className="flex items-center gap-3">
                    <Package className="w-5 h-5" />
                    {ship.shipName}
                    <Badge variant="outline">
                      {ship.parcels.length} parcela{ship.parcels.length !== 1 ? 's' : ''}
                    </Badge>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {ship.parcels.map((parcel: ParcelConfig) => (
                      <div key={parcel.parcelId} className="bg-gray-50 p-4 rounded-lg">
                        <div className="flex items-center justify-between mb-3">
                          <div className="flex items-center gap-3">
                            <Badge className={getProductColor(parcel.product)}>
                              {parcel.product}
                            </Badge>
                            <span className="font-medium">{parcel.receiver}</span>
                            <span className="text-sm text-gray-600">
                              {Number(parcel.volumeM3 || 0).toFixed(0)} m³
                            </span>
                          </div>
                          {editingParcel !== parcel.parcelId && (
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => {
                                setEditingParcel(parcel.parcelId);
                                setTempRate(parcel.customRate?.toString() || '');
                                setTempNotes(parcel.notes || '');
                              }}
                            >
                              <Edit className="w-3 h-3 mr-1" />
                              Configurar
                            </Button>
                          )}
                        </div>

                        {editingParcel === parcel.parcelId ? (
                          // Modo de Edição
                          <div className="space-y-3 border border-blue-200 p-3 rounded-lg bg-blue-50">
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                              <div>
                                <Label className="text-sm font-semibold">Rate Customizado (m³/h)</Label>
                                <Input
                                  type="number"
                                  step="0.01"
                                  value={tempRate}
                                  onChange={(e) => setTempRate(e.target.value)}
                                  placeholder={`Padrão: ${parcel.defaultRate}`}
                                  className="border-blue-300"
                                />
                              </div>
                              <div>
                                <Label className="text-sm font-semibold">Duração Estimada</Label>
                                <Input
                                  value={tempRate ? 
                                    formatDuration(parcel.volumeM3 / parseFloat(tempRate)) : 
                                    formatDuration(parcel.volumeM3 / parcel.defaultRate)
                                  }
                                  readOnly
                                  className="bg-gray-100"
                                />
                              </div>
                            </div>
                            <div>
                              <Label className="text-sm font-semibold">Observações</Label>
                              <Textarea
                                value={tempNotes}
                                onChange={(e) => setTempNotes(e.target.value)}
                                placeholder="Ex: Recebedor tem equipamento mais lento, considerar paragens adicionais..."
                                rows={2}
                                className="border-blue-300"
                              />
                            </div>
                            <div className="flex gap-2">
                              <Button
                                size="sm"
                                onClick={() => handleSaveRate(ship.shipId, parcel)}
                                disabled={saveRateMutation.isPending}
                                className="bg-green-600 hover:bg-green-700"
                              >
                                <Check className="w-3 h-3 mr-1" />
                                Salvar
                              </Button>
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => {
                                  setEditingParcel(null);
                                  setTempRate("");
                                  setTempNotes("");
                                }}
                              >
                                <X className="w-3 h-3 mr-1" />
                                Cancelar
                              </Button>
                            </div>
                          </div>
                        ) : (
                          // Modo de Visualização
                          <div className="grid grid-cols-1 md:grid-cols-4 gap-3 text-sm">
                            <div>
                              <span className="text-gray-500">Rate Padrão:</span>
                              <div className="font-medium">{parcel.defaultRate} m³/h</div>
                            </div>
                            <div>
                              <span className="text-gray-500">Rate Customizado:</span>
                              <div className="font-medium">
                                {parcel.customRate ? (
                                  <span className="text-blue-600">{parcel.customRate} m³/h</span>
                                ) : (
                                  <span className="text-gray-400">Padrão</span>
                                )}
                              </div>
                            </div>
                            <div>
                              <span className="text-gray-500">Duração:</span>
                              <div className="font-medium">
                                {formatDuration(parcel.volumeM3 / (parcel.customRate || parcel.defaultRate))}
                              </div>
                            </div>
                            <div>
                              <span className="text-gray-500">Observações:</span>
                              <div className="font-medium">
                                {parcel.notes ? (
                                  <span className="text-sm">{parcel.notes}</span>
                                ) : (
                                  <span className="text-gray-400">Nenhuma</span>
                                )}
                              </div>
                            </div>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            ))
          ) : (
            <Card>
              <CardContent className="text-center py-8">
                <Package className="w-12 h-12 mx-auto text-gray-400 mb-4" />
                <p className="text-gray-600">Nenhum navio encontrado para configuração</p>
                <p className="text-sm text-gray-500 mt-2">
                  Certifique-se de que há navios com instruções de descarga na fila
                </p>
              </CardContent>
            </Card>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}