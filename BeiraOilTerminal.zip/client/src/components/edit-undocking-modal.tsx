import { useState, useEffect } from "react";
import { useQueryClient, useMutation } from "@tanstack/react-query";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { Clock, Save, X } from "lucide-react";

interface EditUndockingModalProps {
  isOpen: boolean;
  onClose: () => void;
  shipId: number | null;
  shipName: string;
  currentUndocking?: {
    firstRopeTime: string;
    lastRopeTime: string;
  } | null;
}

export function EditUndockingModal({ 
  isOpen, 
  onClose, 
  shipId, 
  shipName, 
  currentUndocking 
}: EditUndockingModalProps) {
  const [firstRopeTime, setFirstRopeTime] = useState("");
  const [lastRopeTime, setLastRopeTime] = useState("");
  const queryClient = useQueryClient();
  const { toast } = useToast();

  console.log("EditUndockingModal render", {
    isOpen,
    shipId,
    shipName,
    currentUndocking
  });

  // Reset form when undocking data changes
  useEffect(() => {
    if (currentUndocking) {
      // Preserve exact values without timezone conversion
      const firstTime = currentUndocking.firstRopeTime ? currentUndocking.firstRopeTime.slice(0, 16) : "";
      const lastTime = currentUndocking.lastRopeTime ? currentUndocking.lastRopeTime.slice(0, 16) : "";
      
      setFirstRopeTime(firstTime);
      setLastRopeTime(lastTime);
    } else {
      setFirstRopeTime("");
      setLastRopeTime("");
    }
  }, [currentUndocking]);

  const updateUndockingMutation = useMutation({
    mutationFn: async (data: { firstRopeTime: string; lastRopeTime: string }) => {
      const response = await fetch(`/api/ships/${shipId}/undocking`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      });
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || 'Failed to update undocking data');
      }
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/ships/${shipId}/undocking`] });
      queryClient.invalidateQueries({ queryKey: [`/api/ships/${shipId}`] });
      queryClient.invalidateQueries({ queryKey: ['/api/ships'] });
      
      toast({
        title: "Sucesso",
        description: "Dados de desatracação atualizados com sucesso"
      });
      onClose();
    },
    onError: (error: Error) => {
      toast({
        title: "Erro",
        description: error.message || "Falha ao atualizar dados de desatracação",
        variant: "destructive"
      });
    }
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!firstRopeTime || !lastRopeTime) {
      toast({
        title: "Erro",
        description: "Por favor, preencha ambos os horários de desatracação",
        variant: "destructive"
      });
      return;
    }

    // Send exact datetime-local values without conversion
    updateUndockingMutation.mutate({
      firstRopeTime,
      lastRopeTime
    });
  };

  if (!isOpen) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Clock className="w-5 h-5 text-red-600" />
            Editar Dados de Desatracação - {shipName}
          </DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="firstRopeTime">Primeira Corda</Label>
            <Input
              id="firstRopeTime"
              type="datetime-local"
              value={firstRopeTime}
              onChange={(e) => setFirstRopeTime(e.target.value)}
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="lastRopeTime">Última Corda</Label>
            <Input
              id="lastRopeTime"
              type="datetime-local"
              value={lastRopeTime}
              onChange={(e) => setLastRopeTime(e.target.value)}
              required
            />
          </div>

          <div className="flex gap-2 pt-4">
            <Button
              type="submit"
              disabled={updateUndockingMutation.isPending}
              className="flex-1 flex items-center gap-2"
            >
              <Save className="w-4 h-4" />
              {updateUndockingMutation.isPending ? "Salvando..." : "Salvar"}
            </Button>
            <Button
              type="button"
              variant="outline"
              onClick={onClose}
              className="flex items-center gap-2"
            >
              <X className="w-4 h-4" />
              Cancelar
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}