import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { isUnauthorizedError } from "@/lib/authUtils";
import { Shield, UserPlus, X, Check } from "lucide-react";

interface User {
  id: number;
  username: string;
  role: string;
  email?: string;
}

interface UserPermission {
  id: number;
  userId: number;
  permission: string;
  grantedAt: string;
  grantedBy?: number;
}

interface PermissionsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const PERMISSION_LABELS = {
  'update_discharge': 'Actualizar a Descarga',
  'confirm_ship': 'Confirmar Navio',
  'move_ship': 'Mover Navio'
};

const PERMISSION_DESCRIPTIONS = {
  'update_discharge': 'Permite atualizar o progresso de descarga dos navios',
  'confirm_ship': 'Permite enviar e confirmar atracação de navios',
  'move_ship': 'Permite mover navios entre diferentes estados no sistema'
};

export function PermissionsModal({ isOpen, onClose }: PermissionsModalProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [selectedUserId, setSelectedUserId] = useState<number | null>(null);
  const [selectedPermission, setSelectedPermission] = useState<string>("");

  // Fetch all users
  const { data: users = [], isLoading: usersLoading } = useQuery<User[]>({
    queryKey: ['/api/users'],
    enabled: isOpen,
  });

  // Fetch permissions for selected user
  const { data: userPermissions = [], isLoading: permissionsLoading, refetch: refetchPermissions } = useQuery<UserPermission[]>({
    queryKey: ['/api/users', selectedUserId, 'permissions'],
    enabled: isOpen && selectedUserId !== null,
  });

  const grantPermissionMutation = useMutation({
    mutationFn: async ({ userId, permission }: { userId: number; permission: string }) => {
      await apiRequest(`/api/users/${userId}/permissions`, "POST", { permission });
    },
    onSuccess: () => {
      toast({
        title: "Permissão Concedida",
        description: "A permissão foi concedida com sucesso.",
      });
      refetchPermissions();
      setSelectedPermission("");
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Acesso Negado",
          description: "Você não tem permissão para conceder credenciais.",
          variant: "destructive",
        });
        return;
      }
      toast({
        title: "Erro",
        description: "Falha ao conceder permissão.",
        variant: "destructive",
      });
    },
  });

  const revokePermissionMutation = useMutation({
    mutationFn: async ({ userId, permission }: { userId: number; permission: string }) => {
      await apiRequest(`/api/users/${userId}/permissions/${permission}`, "DELETE");
    },
    onSuccess: () => {
      toast({
        title: "Permissão Revogada",
        description: "A permissão foi revogada com sucesso.",
      });
      refetchPermissions();
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Acesso Negado",
          description: "Você não tem permissão para revogar credenciais.",
          variant: "destructive",
        });
        return;
      }
      toast({
        title: "Erro",
        description: "Falha ao revogar permissão.",
        variant: "destructive",
      });
    },
  });

  const handleGrantPermission = () => {
    if (!selectedUserId || !selectedPermission) return;

    grantPermissionMutation.mutate({
      userId: selectedUserId,
      permission: selectedPermission,
    });
  };

  const handleRevokePermission = (permission: string) => {
    if (!selectedUserId) return;

    revokePermissionMutation.mutate({
      userId: selectedUserId,
      permission,
    });
  };

  const selectedUser = users.find((user: User) => user.id === selectedUserId);
  const availablePermissions = Object.keys(PERMISSION_LABELS).filter(
    permission => !userPermissions.some((up: UserPermission) => up.permission === permission)
  );

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-xl font-bold text-blue-600 flex items-center gap-2">
            <Shield className="w-6 h-6" />
            Gestão de Credenciais e Permissões
          </DialogTitle>
          <DialogDescription>
            Gerencie permissões dos usuários para controlar acesso às funcionalidades do sistema.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6">
          {/* User Selection */}
          <div>
            <label className="block text-sm font-medium mb-2">Selecionar Utilizador</label>
            <Select
              value={selectedUserId?.toString() || ""}
              onValueChange={(value) => setSelectedUserId(parseInt(value))}
            >
              <SelectTrigger>
                <SelectValue placeholder="Escolha um utilizador..." />
              </SelectTrigger>
              <SelectContent>
                {users.map((user: User) => (
                  <SelectItem key={user.id} value={user.id.toString()}>
                    {user.username} ({user.role})
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {selectedUser && (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* User Info and Grant Permissions */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg text-gray-900 flex items-center gap-2">
                    <UserPlus className="w-5 h-5" />
                    Informações do Utilizador
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <p><strong>Nome:</strong> {selectedUser.username}</p>
                    <p><strong>Função:</strong> {selectedUser.role}</p>
                    {selectedUser.email && <p><strong>Email:</strong> {selectedUser.email}</p>}
                  </div>

                  <div className="space-y-3">
                    <h4 className="font-medium text-gray-900">Conceder Nova Permissão</h4>
                    
                    {availablePermissions.length > 0 ? (
                      <div className="space-y-3">
                        <Select
                          value={selectedPermission}
                          onValueChange={setSelectedPermission}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Escolha uma permissão..." />
                          </SelectTrigger>
                          <SelectContent>
                            {availablePermissions.map((permission) => (
                              <SelectItem key={permission} value={permission}>
                                {PERMISSION_LABELS[permission as keyof typeof PERMISSION_LABELS]}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>

                        {selectedPermission && (
                          <div className="p-3 bg-blue-50 rounded-lg">
                            <p className="text-sm text-blue-800">
                              {PERMISSION_DESCRIPTIONS[selectedPermission as keyof typeof PERMISSION_DESCRIPTIONS]}
                            </p>
                          </div>
                        )}

                        <Button
                          onClick={handleGrantPermission}
                          disabled={!selectedPermission || grantPermissionMutation.isPending}
                          className="w-full bg-green-600 hover:bg-green-700"
                        >
                          <Check className="w-4 h-4 mr-2" />
                          {grantPermissionMutation.isPending ? "Concedendo..." : "Conceder Permissão"}
                        </Button>
                      </div>
                    ) : (
                      <p className="text-sm text-gray-500 italic">
                        Este utilizador já possui todas as permissões disponíveis.
                      </p>
                    )}
                  </div>
                </CardContent>
              </Card>

              {/* Current Permissions */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg text-gray-900">Permissões Atuais</CardTitle>
                </CardHeader>
                <CardContent>
                  {permissionsLoading ? (
                    <p className="text-gray-500">Carregando permissões...</p>
                  ) : userPermissions.length > 0 ? (
                    <div className="space-y-3">
                      {userPermissions.map((permission: UserPermission) => (
                        <div
                          key={permission.id}
                          className="flex items-center justify-between p-3 bg-gray-50 rounded-lg"
                        >
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-1">
                              <Badge variant="secondary">
                                {PERMISSION_LABELS[permission.permission as keyof typeof PERMISSION_LABELS]}
                              </Badge>
                            </div>
                            <p className="text-xs text-gray-600">
                              Concedida em: {new Date(permission.grantedAt).toLocaleString('pt-BR')}
                            </p>
                          </div>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleRevokePermission(permission.permission)}
                            disabled={revokePermissionMutation.isPending}
                            className="text-red-600 border-red-300 hover:bg-red-50"
                          >
                            <X className="w-4 h-4" />
                          </Button>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-gray-500 italic">
                      Este utilizador não possui permissões especiais.
                    </p>
                  )}
                </CardContent>
              </Card>
            </div>
          )}

          {/* Permission Descriptions */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg text-gray-900">Descrição das Permissões</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {Object.entries(PERMISSION_LABELS).map(([key, label]) => (
                  <div key={key} className="p-3 border rounded-lg">
                    <h4 className="font-medium text-blue-600 mb-2">{label}</h4>
                    <p className="text-sm text-gray-600">
                      {PERMISSION_DESCRIPTIONS[key as keyof typeof PERMISSION_DESCRIPTIONS]}
                    </p>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="flex justify-end pt-4">
          <Button variant="outline" onClick={onClose}>
            Fechar
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}