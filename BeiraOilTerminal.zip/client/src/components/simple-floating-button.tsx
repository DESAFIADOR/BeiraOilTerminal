import React from 'react';

export function SimpleFloatingButton() {
  const handleClick = () => {
    alert('Botão funcionando!');
  };

  return (
    <div
      onClick={handleClick}
      style={{
        position: 'fixed',
        bottom: '20px',
        right: '20px',
        width: '80px',
        height: '80px',
        backgroundColor: '#ff0000',
        borderRadius: '50%',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        cursor: 'pointer',
        color: 'white',
        fontSize: '14px',
        fontWeight: 'bold',
        zIndex: 99999,
        boxShadow: '0 4px 12px rgba(0,0,0,0.5)',
        border: '3px solid white'
      }}
    >
      TESTE
    </div>
  );
}

// Add this as a global element to body immediately
setTimeout(() => {
  if (typeof window !== 'undefined' && document.body) {
    const existingButton = document.getElementById('floating-test-button');
    if (!existingButton) {
      const button = document.createElement('div');
      button.id = 'floating-test-button';
      button.style.cssText = `
        position: fixed !important;
        bottom: 20px !important;
        right: 20px !important;
        width: 80px !important;
        height: 80px !important;
        background-color: #ff0000 !important;
        border-radius: 50% !important;
        display: flex !important;
        align-items: center !important;
        justify-content: center !important;
        cursor: pointer !important;
        color: white !important;
        font-size: 14px !important;
        font-weight: bold !important;
        z-index: 999999 !important;
        box-shadow: 0 4px 12px rgba(0,0,0,0.5) !important;
        border: 3px solid white !important;
        visibility: visible !important;
        opacity: 1 !important;
      `;
      button.textContent = 'TESTE';
      button.onclick = () => alert('Botão global funcionando!');
      document.body.appendChild(button);
      console.log('Botão de teste adicionado ao DOM');
    }
  }
}, 1000);