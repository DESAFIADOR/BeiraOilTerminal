import React, { useState, useEffect } from 'react';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Activity, Clock, Zap } from 'lucide-react';

interface PerformanceMetrics {
  responseTime: number;
  accuracy: number;
  satisfactionRating: number;
  totalSessions: number;
  escalationRate: number;
}

export function PerformanceMonitor() {
  const [metrics, setMetrics] = useState<PerformanceMetrics>({
    responseTime: 0,
    accuracy: 0,
    satisfactionRating: 0,
    totalSessions: 0,
    escalationRate: 0
  });

  // Monitor performance in real-time
  useEffect(() => {
    const updateMetrics = () => {
      // Simulate real-time metrics for demo
      setMetrics({
        responseTime: 1.2 + Math.random() * 0.8, // Target: < 2s
        accuracy: 92 + Math.random() * 6, // Target: > 90%
        satisfactionRating: 4.2 + Math.random() * 0.6, // Target: >= 4/5
        totalSessions: Math.floor(Math.random() * 50) + 100,
        escalationRate: 5 + Math.random() * 10 // Lower is better
      });
    };

    updateMetrics();
    const interval = setInterval(updateMetrics, 30000); // Update every 30 seconds

    return () => clearInterval(interval);
  }, []);

  const getPerformanceColor = (metric: string, value: number) => {
    switch (metric) {
      case 'responseTime':
        return value < 2 ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800';
      case 'accuracy':
        return value >= 90 ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800';
      case 'satisfaction':
        return value >= 4 ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800';
      case 'escalation':
        return value < 10 ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <Card className="w-full max-w-md">
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2 text-sm">
          <Activity className="w-4 h-4" />
          Performance Monitor
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="grid grid-cols-2 gap-3 text-xs">
          <div className="space-y-1">
            <div className="flex items-center justify-between">
              <span className="text-gray-600">Response Time</span>
              <Badge className={getPerformanceColor('responseTime', metrics.responseTime)}>
                <Clock className="w-3 h-3 mr-1" />
                {metrics.responseTime.toFixed(1)}s
              </Badge>
            </div>
            
            <div className="flex items-center justify-between">
              <span className="text-gray-600">Accuracy</span>
              <Badge className={getPerformanceColor('accuracy', metrics.accuracy)}>
                <Zap className="w-3 h-3 mr-1" />
                {metrics.accuracy.toFixed(0)}%
              </Badge>
            </div>
          </div>
          
          <div className="space-y-1">
            <div className="flex items-center justify-between">
              <span className="text-gray-600">Satisfaction</span>
              <Badge className={getPerformanceColor('satisfaction', metrics.satisfactionRating)}>
                {metrics.satisfactionRating.toFixed(1)}/5
              </Badge>
            </div>
            
            <div className="flex items-center justify-between">
              <span className="text-gray-600">Escalation</span>
              <Badge className={getPerformanceColor('escalation', metrics.escalationRate)}>
                {metrics.escalationRate.toFixed(0)}%
              </Badge>
            </div>
          </div>
        </div>
        
        <div className="pt-2 border-t text-center">
          <span className="text-xs text-gray-500">
            Total Sessions: {metrics.totalSessions}
          </span>
        </div>
      </CardContent>
    </Card>
  );
}