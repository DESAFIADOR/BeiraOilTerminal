import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";

interface ShipLocationSelectorProps {
  isOpen: boolean;
  onClose: () => void;
  onLocationSelected: (location: 'at_bar' | 'expected') => void;
}

export function ShipLocationSelector({ isOpen, onClose, onLocationSelected }: ShipLocationSelectorProps) {
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Selecionar Localização</DialogTitle>
        </DialogHeader>
        <div className="p-4">
          <p>Componente de seleção de localização</p>
        </div>
      </DialogContent>
    </Dialog>
  );
}