import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';

interface CommunicationPanelProps {
  isOpen: boolean;
  onClose: () => void;
}

export function CommunicationPanel({ isOpen, onClose }: CommunicationPanelProps) {
  const [selectedChannel, setSelectedChannel] = useState('vhf');
  const [message, setMessage] = useState('');

  const communicationChannels = [
    { id: 'vhf', name: 'VHF Canal 16', frequency: '156.800 MHz', status: 'online', icon: '📻' },
    { id: 'pilots', name: 'Serviço de Praticagem', frequency: 'Canal 12', status: 'online', icon: '⚓' },
    { id: 'tugboats', name: 'Rebocadores', frequency: 'Canal 6', status: 'online', icon: '🚢' },
    { id: 'port_control', name: 'Controlo Portuário', frequency: 'Canal 14', status: 'online', icon: '🏢' },
    { id: 'emergency', name: 'Emergência Marítima', frequency: 'Canal 16', status: 'standby', icon: '🚨' },
    { id: 'customs', name: 'Alfândega', frequency: 'Telefone', status: 'online', icon: '🛃' }
  ];

  const recentMessages = [
    { time: '14:32', from: 'M/V AMFITRION', channel: 'VHF 16', message: 'Terminal da Beira, M/V AMFITRION requesting berth instructions' },
    { time: '14:28', from: 'Praticagem', channel: 'Canal 12', message: 'Piloto embarcando no AMFITRION às 14:45' },
    { time: '14:15', from: 'Rebocador BEIRA 1', channel: 'Canal 6', message: 'Aguardando instruções para assistência' },
    { time: '13:58', from: 'Controlo Torre', channel: 'Canal 14', message: 'Berço 12 liberado para próximo navio' }
  ];

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-6xl h-[700px] overflow-hidden">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-3 text-xl">
            <span className="text-2xl">📡</span>
            Centro de Comunicações Marítimas
            <span className="text-2xl">⚓</span>
          </DialogTitle>
        </DialogHeader>

        <Tabs defaultValue="channels" className="h-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="channels">Canais de Comunicação</TabsTrigger>
            <TabsTrigger value="messages">Mensagens Recentes</TabsTrigger>
            <TabsTrigger value="emergency">Procedimentos de Emergência</TabsTrigger>
          </TabsList>

          <TabsContent value="channels" className="space-y-4 h-full overflow-y-auto">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {communicationChannels.map((channel) => (
                <Card key={channel.id} className="cursor-pointer hover:shadow-lg transition-shadow">
                  <CardHeader className="pb-2">
                    <CardTitle className="flex items-center justify-between text-sm">
                      <div className="flex items-center gap-2">
                        <span className="text-xl">{channel.icon}</span>
                        {channel.name}
                      </div>
                      <Badge variant={channel.status === 'online' ? 'default' : 'secondary'}>
                        {channel.status === 'online' ? 'Online' : 'Standby'}
                      </Badge>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-gray-600 mb-3">{channel.frequency}</p>
                    <Button 
                      variant="outline" 
                      size="sm" 
                      className="w-full"
                      onClick={() => setSelectedChannel(channel.id)}
                    >
                      Conectar Canal
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>

            <Card className="mt-4">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <span className="text-xl">📞</span>
                  Interface de Comunicação
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="text-sm font-medium">Canal Selecionado</label>
                    <Input 
                      value={communicationChannels.find(c => c.id === selectedChannel)?.name || ''} 
                      readOnly 
                    />
                  </div>
                  <div>
                    <label className="text-sm font-medium">Frequência</label>
                    <Input 
                      value={communicationChannels.find(c => c.id === selectedChannel)?.frequency || ''} 
                      readOnly 
                    />
                  </div>
                </div>
                <div>
                  <label className="text-sm font-medium">Mensagem</label>
                  <Textarea 
                    placeholder="Digite sua mensagem..."
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    rows={3}
                  />
                </div>
                <div className="flex gap-2">
                  <Button className="flex-1">
                    📢 Transmitir Mensagem
                  </Button>
                  <Button variant="outline">
                    🎧 Escutar Canal
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="messages" className="space-y-4 h-full overflow-y-auto">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <span className="text-xl">💬</span>
                  Registro de Comunicações
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {recentMessages.map((msg, index) => (
                  <div key={index} className="border-l-4 border-blue-500 pl-4 py-2 bg-blue-50">
                    <div className="flex justify-between items-start mb-1">
                      <span className="font-semibold text-sm">{msg.from}</span>
                      <div className="text-xs text-gray-500">
                        {msg.time} - {msg.channel}
                      </div>
                    </div>
                    <p className="text-sm">{msg.message}</p>
                  </div>
                ))}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="emergency" className="space-y-4 h-full overflow-y-auto">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Card className="border-red-200 bg-red-50">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-red-700">
                    <span className="text-xl">🚨</span>
                    Emergência Marítima
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <Button className="w-full bg-red-600 hover:bg-red-700">
                    🆘 MAYDAY - Emergência Máxima
                  </Button>
                  <Button variant="outline" className="w-full border-orange-500 text-orange-700">
                    ⚠️ PAN-PAN - Urgência
                  </Button>
                  <Button variant="outline" className="w-full border-yellow-500 text-yellow-700">
                    🔍 SÉCURITÉ - Segurança
                  </Button>
                </CardContent>
              </Card>

              <Card className="border-blue-200 bg-blue-50">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-blue-700">
                    <span className="text-xl">🏥</span>
                    Contactos de Emergência
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-2 text-sm">
                  <div><strong>Guarda Costeira:</strong> +258 23 303 000</div>
                  <div><strong>Bombeiros Portuários:</strong> +258 23 326 145</div>
                  <div><strong>Hospital da Beira:</strong> +258 23 313 034</div>
                  <div><strong>Polícia Marítima:</strong> +258 23 300 080</div>
                  <div><strong>Praticagem 24h:</strong> +258 84 500 1200</div>
                  <div><strong>Controlo Torre:</strong> +258 23 303 100</div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}