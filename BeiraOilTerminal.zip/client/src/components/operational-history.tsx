import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { 
  Clock, Ship, Search, Calendar, FileText, Filter, Download, 
  Archive, Activity, AlertCircle, CheckCircle, XCircle, RotateCcw,
  Package, Building2, User, Scale
} from "lucide-react";
import { formatDate, formatTime } from "@/lib/utils";

// Helper function to format date and time together
const formatDateTime = (dateStr: string) => {
  const date = new Date(dateStr);
  return `${formatDate(date)} ${formatTime(date)}`;
};

interface OperationalRecord {
  id: number;
  shipId: number;
  shipName: string;
  operationType: string;
  pressure?: number;
  dischargeRate?: number;
  dischargeStartTime?: string;
  dischargeEndTime?: string;
  stopStartTime?: string;
  stopEndTime?: string;
  stopType?: string;
  stopComment?: string;
  resumeComment?: string;
  hasLineDisplacement?: boolean;
  lineDisplacementDuration?: string;
  parcelId?: number;
  recordedAt: string;
}

interface Parcel {
  id: number;
  parcelNumber: string;
  product: string;
  volumeMT: string;
  volumeM3: string;
  density15C: string;
  receiver: string;
  parcelOwner: string;
}

export function OperationalHistory() {
  const [dateFilter, setDateFilter] = useState('');
  const [shipFilter, setShipFilter] = useState('');
  const [operationFilter, setOperationFilter] = useState('');

  const { data: operationalHistory, isLoading } = useQuery({
    queryKey: ['/api/operational-discharge/history', dateFilter, shipFilter, operationFilter],
    queryFn: async () => {
      const params = new URLSearchParams();
      if (dateFilter) params.append('date', dateFilter);
      if (shipFilter) params.append('ship', shipFilter);
      if (operationFilter) params.append('operation', operationFilter);
      
      const response = await fetch(`/api/operational-discharge/history?${params.toString()}`);
      if (!response.ok) throw new Error('Failed to fetch operational history');
      return response.json();
    }
  });

  const { data: ships } = useQuery({
    queryKey: ['/api/ships/summary'],
    queryFn: async () => {
      const response = await fetch('/api/ships/summary');
      if (!response.ok) throw new Error('Failed to fetch ships');
      return response.json();
    }
  });

  const getOperationIcon = (operationType: string) => {
    switch(operationType) {
      case 'start': return <CheckCircle className="w-4 h-4 text-green-600" />;
      case 'stop': return <XCircle className="w-4 h-4 text-red-600" />;
      case 'resume': return <RotateCcw className="w-4 h-4 text-yellow-600" />;
      case 'end': return <AlertCircle className="w-4 h-4 text-gray-600" />;
      case 'hourly_update': return <Activity className="w-4 h-4 text-blue-600" />;
      default: return <Clock className="w-4 h-4 text-gray-500" />;
    }
  };

  const getOperationLabel = (operationType: string) => {
    switch(operationType) {
      case 'start': return 'Início da Descarga';
      case 'stop': return 'Parada da Descarga';
      case 'resume': return 'Retoma da Descarga';
      case 'end': return 'Fim da Descarga';
      case 'hourly_update': return 'Actualização Horária';
      default: return operationType.replace('_', ' ');
    }
  };

  const getOperationColor = (operationType: string) => {
    switch(operationType) {
      case 'start': return 'bg-green-50 border-l-4 border-green-400';
      case 'stop': return 'bg-red-50 border-l-4 border-red-400';
      case 'resume': return 'bg-yellow-50 border-l-4 border-yellow-400';
      case 'end': return 'bg-gray-50 border-l-4 border-gray-400';
      case 'hourly_update': return 'bg-blue-50 border-l-4 border-blue-400';
      default: return 'bg-gray-50 border-l-4 border-gray-300';
    }
  };

  const findParcelInfo = (parcelId: number, shipId: number) => {
    const ship = ships?.find((s: any) => s.id === shipId);
    return ship?.parcels?.find((p: Parcel) => p.id === parcelId);
  };

  const exportHistory = () => {
    if (!operationalHistory) return;
    
    const csvContent = "data:text/csv;charset=utf-8," 
      + "Data/Hora,Navio,Operação,Parcela,Produto,Volume MT,Recebedor,Pressão,Taxa Descarga,Comentários\n"
      + operationalHistory.map((record: OperationalRecord) => {
          const parcel = findParcelInfo(record.parcelId || 0, record.shipId);
          return [
            formatDateTime(record.recordedAt),
            record.shipName,
            getOperationLabel(record.operationType),
            parcel?.parcelNumber || '',
            parcel?.product || '',
            parcel?.volumeMT || '',
            parcel?.receiver || '',
            record.pressure || '',
            record.dischargeRate || '',
            record.stopComment || record.resumeComment || ''
          ].map(field => `"${field}"`).join(',');
        }).join('\n');

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `historico_operacional_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">
          <Activity className="w-8 h-8 animate-spin mx-auto mb-2 text-blue-600" />
          <p className="text-gray-500">Carregando histórico operacional...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 flex items-center gap-2">
            <Archive className="w-6 h-6 text-blue-600" />
            Histórico Operacional
          </h1>
          <p className="text-gray-600 mt-1">
            Histórico completo do controlo operacional de descarga de navios
          </p>
        </div>
        <Button onClick={exportHistory} className="flex items-center gap-2">
          <Download className="w-4 h-4" />
          Exportar CSV
        </Button>
      </div>

      {/* Filters */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Filter className="w-5 h-5" />
            Filtros
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <Label htmlFor="dateFilter">Data</Label>
              <Input
                id="dateFilter"
                type="date"
                value={dateFilter}
                onChange={(e) => setDateFilter(e.target.value)}
                placeholder="Filtrar por data"
              />
            </div>
            <div>
              <Label htmlFor="shipFilter">Navio</Label>
              <Input
                id="shipFilter"
                type="text"
                value={shipFilter}
                onChange={(e) => setShipFilter(e.target.value)}
                placeholder="Nome do navio"
              />
            </div>
            <div>
              <Label htmlFor="operationFilter">Tipo de Operação</Label>
              <select
                id="operationFilter"
                value={operationFilter}
                onChange={(e) => setOperationFilter(e.target.value)}
                className="w-full h-10 px-3 rounded-md border border-input bg-background text-sm"
              >
                <option value="">Todas as operações</option>
                <option value="start">Início da Descarga</option>
                <option value="stop">Parada da Descarga</option>
                <option value="resume">Retoma da Descarga</option>
                <option value="end">Fim da Descarga</option>
                <option value="hourly_update">Actualização Horária</option>
              </select>
            </div>
          </div>
          {(dateFilter || shipFilter || operationFilter) && (
            <div className="mt-4 pt-4 border-t">
              <Button 
                variant="outline" 
                onClick={() => {
                  setDateFilter('');
                  setShipFilter('');
                  setOperationFilter('');
                }}
                className="flex items-center gap-2"
              >
                <XCircle className="w-4 h-4" />
                Limpar Filtros
              </Button>
            </div>
          )}
        </CardContent>
      </Card>

      {/* History Records */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileText className="w-5 h-5" />
            Registos Operacionais
            {operationalHistory && (
              <Badge variant="secondary" className="ml-2">
                {operationalHistory.length} registos
              </Badge>
            )}
          </CardTitle>
        </CardHeader>
        <CardContent>
          {!operationalHistory || operationalHistory.length === 0 ? (
            <div className="text-center py-8">
              <Archive className="w-16 h-16 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-500">Nenhum registo operacional encontrado</p>
              <p className="text-sm text-gray-400 mt-1">
                {dateFilter || shipFilter || operationFilter 
                  ? "Tente ajustar os filtros para ver mais resultados"
                  : "Os registos operacionais aparecerão aqui quando forem criados"
                }
              </p>
            </div>
          ) : (
            <div className="space-y-4 max-h-[600px] overflow-y-auto">
              {operationalHistory.map((record: OperationalRecord) => {
                const parcel = findParcelInfo(record.parcelId || 0, record.shipId);
                
                return (
                  <div 
                    key={record.id} 
                    className={`p-4 rounded-lg ${getOperationColor(record.operationType)}`}
                  >
                    <div className="flex justify-between items-start mb-3">
                      <div className="flex items-center gap-3">
                        {getOperationIcon(record.operationType)}
                        <div>
                          <h3 className="font-semibold text-gray-900">
                            {getOperationLabel(record.operationType)}
                          </h3>
                          <p className="text-sm text-gray-600">
                            <Ship className="w-3 h-3 inline mr-1" />
                            {record.shipName}
                          </p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="text-sm font-mono text-gray-700">
                          {formatDateTime(record.recordedAt)}
                        </p>
                      </div>
                    </div>

                    {/* Parcel Information */}
                    {record.parcelId && parcel && (
                      <div className="bg-white bg-opacity-60 rounded-lg p-3 mb-3">
                        <h4 className="font-medium text-purple-800 mb-2 flex items-center gap-1">
                          <Package className="w-4 h-4" />
                          Parcela: {parcel.parcelNumber} - {parcel.product}
                        </h4>
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-sm">
                          <div className="flex items-center gap-1">
                            <Scale className="w-3 h-3 text-gray-500" />
                            <span>{parcel.volumeMT} MT ({parcel.volumeM3} m³)</span>
                          </div>
                          <div className="flex items-center gap-1">
                            <Building2 className="w-3 h-3 text-gray-500" />
                            <span>{parcel.receiver}</span>
                          </div>
                          {parcel.parcelOwner && (
                            <div className="flex items-center gap-1">
                              <User className="w-3 h-3 text-gray-500" />
                              <span>{parcel.parcelOwner}</span>
                            </div>
                          )}
                          {parcel.density15C && (
                            <div className="flex items-center gap-1">
                              <Scale className="w-3 h-3 text-gray-500" />
                              <span>{parcel.density15C} kg/m³</span>
                            </div>
                          )}
                        </div>
                      </div>
                    )}

                    {/* Operation Details */}
                    {(record.pressure || record.dischargeRate || record.stopComment || record.resumeComment) && (
                      <div className="bg-white bg-opacity-60 rounded-lg p-3">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-sm">
                          {record.pressure && (
                            <div>
                              <span className="font-medium">Pressão:</span> {record.pressure} bar
                            </div>
                          )}
                          {record.dischargeRate && (
                            <div>
                              <span className="font-medium">Taxa de Descarga:</span> {record.dischargeRate} m³/h
                            </div>
                          )}
                          {record.stopComment && (
                            <div className="md:col-span-2">
                              <span className="font-medium">Motivo da Parada:</span> {record.stopComment}
                            </div>
                          )}
                          {record.resumeComment && (
                            <div className="md:col-span-2">
                              <span className="font-medium">Comentário de Retoma:</span> {record.resumeComment}
                            </div>
                          )}
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}