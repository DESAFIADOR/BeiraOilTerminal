import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Anchor, Clock, CheckCircle, Waves, Edit, Info, Package, Users, Calendar } from "lucide-react";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";

interface Ship {
  id: number;
  name: string;
  countermark: string;
  draft: string;
  shipAgent: string;
  cargoAgent: string;
  cargoType: string;
  status: string;
  arrivalDateTime: string;
  berthingConfirmed: boolean;
  confirmationReceivedAt?: string;
  parcels: Array<{
    parcelNumber: string;
    volume: string;
    receiver: string;
    status: string;
  }>;
  latestProgress?: {
    discharged: string;
    remaining: string;
    percentage: string;
    estimatedCompletionHours?: string;
  };
}

interface ShipStatusCardProps {
  ship: Ship;
  title: string;
  statusBadge: string;
  statusColor: "green" | "yellow" | "blue" | "gray";
  showProgress: boolean;
  onUpdateDischarge?: () => void;
  onMoveToBar?: () => void;
  onMoveToBerth?: () => void;
}

export function ShipStatusCard({ 
  ship, 
  title, 
  statusBadge, 
  statusColor, 
  showProgress,
  onUpdateDischarge,
  onMoveToBar,
  onMoveToBerth
}: ShipStatusCardProps) {
  const getStatusClasses = (color: string) => {
    switch (color) {
      case "green":
        return "bg-green-50 border-green-200 text-green-800";
      case "yellow":
        return "bg-yellow-50 border-yellow-200 text-yellow-800";
      case "blue":
        return "bg-blue-50 border-blue-200 text-blue-800";
      default:
        return "bg-gray-50 border-gray-200 text-gray-800";
    }
  };

  const getHeaderClasses = (color: string) => {
    switch (color) {
      case "green":
        return "bg-green-50 border-green-200";
      case "yellow":
        return "bg-yellow-50 border-yellow-200";
      case "blue":
        return "bg-blue-50 border-blue-200";
      default:
        return "bg-gray-50 border-gray-200";
    }
  };

  const getIconColor = (color: string) => {
    switch (color) {
      case "green":
        return "text-green-800";
      case "yellow":
        return "text-yellow-800";
      case "blue":
        return "text-blue-800";
      default:
        return "text-gray-800";
    }
  };

  const formatDateTime = (dateString: string) => {
    try {
      return format(new Date(dateString), "dd/MM/yyyy 'às' HH:mm", { locale: ptBR });
    } catch {
      return dateString;
    }
  };

  const estimatedHours = ship.latestProgress?.estimatedCompletionHours 
    ? parseFloat(ship.latestProgress.estimatedCompletionHours) 
    : null;

  return (
    <Card className="overflow-hidden">
      <div className={`${getHeaderClasses(statusColor)} border-b px-6 py-4`}>
        <div className="flex items-center justify-between">
          <h2 className={`text-lg font-semibold ${getIconColor(statusColor)} flex items-center`}>
            {statusColor === "green" ? (
              <Anchor className="mr-2" />
            ) : (
              <Clock className="mr-2" />
            )}
            {title}
          </h2>
          <Badge className={getStatusClasses(statusColor)}>
            {statusBadge}
          </Badge>
        </div>
      </div>
      
      <CardContent className="p-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
          <div>
            <h3 className="text-xl font-bold text-gray-900 mb-4">{ship.name}</h3>
            <div className="space-y-3">
              <div className="flex justify-between">
                <span className="text-gray-600">Contra Marca:</span>
                <span className="font-medium">{ship.countermark}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Calado:</span>
                <span className="font-medium">{ship.draft}m</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Agente:</span>
                <span className="font-medium">{ship.shipAgent}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Tipo de Carga:</span>
                <span className="font-medium">{ship.cargoType}</span>
              </div>
              {ship.arrivalDateTime && (
                <div className="flex justify-between">
                  <span className="text-gray-600">Chegada na Barra:</span>
                  <span className="font-medium">{formatDateTime(ship.arrivalDateTime)}</span>
                </div>
              )}
            </div>
          </div>
          
          <div>
            {showProgress && ship.latestProgress ? (
              <>
                <div className="flex items-center justify-between mb-4">
                  <h4 className="font-semibold text-gray-900">Progresso de Descarga</h4>
                  {onUpdateDischarge && (
                    <Button
                      onClick={onUpdateDischarge}
                      size="sm"
                      variant="outline"
                      className="text-teal-600 border-teal-600 hover:bg-teal-50"
                    >
                      <Edit className="w-4 h-4 mr-1" />
                      Atualizar
                    </Button>
                  )}
                </div>
                <div className="space-y-4">
                  <div>
                    <div className="flex justify-between text-sm mb-2">
                      <span className="text-gray-600">Concluído</span>
                      <span className="font-medium">{parseFloat(ship.latestProgress.percentage).toFixed(1)}%</span>
                    </div>
                    <Progress value={parseFloat(ship.latestProgress.percentage)} className="h-3" />
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <span className="text-gray-600 block">Descarregado:</span>
                      <span className="font-bold text-green-600">{parseFloat(ship.latestProgress.discharged).toLocaleString()} m³</span>
                    </div>
                    <div>
                      <span className="text-gray-600 block">Remanescente:</span>
                      <span className="font-bold text-orange-600">{parseFloat(ship.latestProgress.remaining).toLocaleString()} m³</span>
                    </div>
                  </div>
                  
                  {estimatedHours && (
                    <div className="bg-blue-50 rounded-lg p-3">
                      <p className="text-sm text-blue-800">
                        <Clock className="inline w-4 h-4 mr-1" />
                        Previsão de término: <span className="font-semibold">{estimatedHours.toFixed(1)}h restantes</span>
                      </p>
                    </div>
                  )}
                </div>
              </>
            ) : (
              <div>
                <h4 className="font-semibold text-gray-900 mb-4">Status de Atracação</h4>
                <div className="space-y-4">
                  {ship.berthingConfirmed ? (
                    <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                      <div className="flex items-center">
                        <CheckCircle className="text-green-500 mr-2" />
                        <span className="text-green-800 font-medium">Confirmação Recebida</span>
                      </div>
                      {ship.confirmationReceivedAt && (
                        <p className="text-sm text-green-700 mt-1">
                          Agente confirmou atracação em {formatDateTime(ship.confirmationReceivedAt)}
                        </p>
                      )}
                    </div>
                  ) : (
                    <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                      <div className="flex items-center">
                        <Clock className="text-yellow-500 mr-2" />
                        <span className="text-yellow-800 font-medium">Aguardando Confirmação</span>
                      </div>
                      <p className="text-sm text-yellow-700 mt-1">
                        Email de confirmação será enviado quando aplicável
                      </p>
                    </div>
                  )}
                  
                  <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                    <div className="flex items-center">
                      <Waves className="text-blue-500 mr-2" />
                      <span className="text-blue-800 font-medium">Calado Compatível</span>
                    </div>
                    <p className="text-sm text-blue-700 mt-1">
                      Verificação automática com base na maré atual
                    </p>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
        
        {/* Cargo Parcels */}
        {ship.parcels && ship.parcels.length > 0 && (
          <div>
            <h4 className="font-semibold text-gray-900 mb-4">Parcelas de Carga</h4>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-4 py-2 text-left font-medium text-gray-700">Parcela</th>
                    <th className="px-4 py-2 text-left font-medium text-gray-700">Volume</th>
                    <th className="px-4 py-2 text-left font-medium text-gray-700">Recebedor</th>
                    <th className="px-4 py-2 text-left font-medium text-gray-700">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200">
                  {ship.parcels.map((parcel, index) => (
                    <tr key={index}>
                      <td className="px-4 py-2 font-medium">{parcel.parcelNumber}</td>
                      <td className="px-4 py-2">{parseFloat(parcel.volume).toLocaleString()} m³</td>
                      <td className="px-4 py-2">{parcel.receiver}</td>
                      <td className="px-4 py-2">
                        <Badge
                          variant="outline"
                          className={
                            parcel.status === "completed"
                              ? "bg-green-100 text-green-800"
                              : parcel.status === "in_progress"
                              ? "bg-blue-100 text-blue-800"
                              : "bg-gray-100 text-gray-800"
                          }
                        >
                          {parcel.status === "completed"
                            ? "Concluída"
                            : parcel.status === "in_progress"
                            ? "Em Andamento"
                            : "Pendente"}
                        </Badge>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
        
        {/* Action Buttons */}
        {onMoveToBar && ship.status === "expected" && (
          <div className="mt-6 pt-4 border-t border-gray-200">
            <Button
              onClick={onMoveToBar}
              className="w-full bg-blue-600 hover:bg-blue-700 text-white"
            >
              <Waves className="w-4 h-4 mr-2" />
              Mover para Navios na Barra
            </Button>
          </div>
        )}
        
        {/* Action Button for Moving to Berth */}
        {onMoveToBerth && ship.status === "next_to_berth" && (
          <div className="mt-6 pt-4 border-t border-gray-200">
            <Button
              onClick={onMoveToBerth}
              className="w-full bg-green-600 hover:bg-green-700 text-white"
            >
              <Anchor className="w-4 h-4 mr-2" />
              Mover para Navio no Cais
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
