import { useState, useEffect, useRef } from "react";
import { createPortal } from "react-dom";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Info, Edit, X, Users, Download, Printer, Clock, Save, XCircle, Plus, Trash2, Check, Ship, Anchor } from "lucide-react";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import { ShipEditForm } from "./ship-edit-form";
import { CargoAgentsManager } from "./cargo-agents-manager";
import { EditBerthingModal } from "./edit-berthing-modal";
import { EditUndockingModal } from "./edit-undocking-modal";
import { ShipMovementModal } from "./ship-movement-modal";
import { BerthingRegistrationModal } from "./berthing-registration-modal";
import { DischargeControlModal } from "./discharge-control/DischargeControlModal";
import { useAuth } from "@/contexts/AuthContext";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

interface ShipInfoModalProps {
  isOpen: boolean;
  shipId: number | null;
  onClose: () => void;
  defaultTab?: string;
}

export function ShipInfoModal({ isOpen, shipId, onClose, defaultTab = "info" }: ShipInfoModalProps) {
  const [mounted, setMounted] = useState(false);
  const [isEditBerthingOpen, setIsEditBerthingOpen] = useState(false);
  const [isEditUndockingOpen, setIsEditUndockingOpen] = useState(false);
  const [isShipMovementOpen, setIsShipMovementOpen] = useState(false);
  const [isBerthingRegistrationOpen, setIsBerthingRegistrationOpen] = useState(false);
  const [isDischargeControlOpen, setIsDischargeControlOpen] = useState(false);
  const [activeTab, setActiveTab] = useState(defaultTab);
  const [isEditing, setIsEditing] = useState(false);
  const [editData, setEditData] = useState<any>({});
  const [editingParcels, setEditingParcels] = useState<any[]>([]);
  const [localParcelData, setLocalParcelData] = useState<Record<number, any>>({});
  const [isEditingParcels, setIsEditingParcels] = useState(false);
  const [originalParcelData, setOriginalParcelData] = useState<Record<number, any>>({});
  const printRef = useRef<HTMLDivElement>(null);
  const { canEdit, user, isLoading: authLoading } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Mutation para atualizar dados do navio
  const updateShipMutation = useMutation({
    mutationFn: async (updatedData: any) => {
      const response = await fetch(`/api/ships/${shipId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updatedData)
      });
      if (!response.ok) throw new Error('Failed to update ship');
      return response.json();
    },
    onSuccess: (updatedShip) => {
      // Invalidar todas as queries relacionadas
      queryClient.invalidateQueries({ queryKey: ['/api/ships'] });
      queryClient.invalidateQueries({ queryKey: [`/api/ships/${shipId}`] });
      
      // Atualizar o cache diretamente com os novos dados
      queryClient.setQueryData([`/api/ships/${shipId}`], updatedShip);
      
      // Forçar refetch dos dados para atualização imediata
      queryClient.refetchQueries({ queryKey: ['/api/ships'] });
      queryClient.refetchQueries({ queryKey: [`/api/ships/${shipId}`] });
      
      // Resetar estado de edição e dados locais
      setIsEditing(false);
      setEditData({
        name: updatedShip.name || '',
        countermark: updatedShip.countermark || '',
        draft: updatedShip.draft || '',
        cargoType: updatedShip.cargoType || '',
        shipowner: updatedShip.shipowner || '',
        cargoDestination: updatedShip.cargoDestination || '',
        operationType: updatedShip.operationType || 'Nacional',
        shipAgent: updatedShip.shipAgent || '',
        cargoAgent: updatedShip.cargoAgent || '',
        shipAgentEmail: updatedShip.shipAgentEmail || '',
        cargoAgentEmail: updatedShip.cargoAgentEmail || ''
      });
      
      toast({
        title: "Sucesso",
        description: "Dados do navio atualizados com sucesso"
      });
    },
    onError: (error) => {
      toast({
        title: "Erro",
        description: "Falha ao atualizar dados do navio",
        variant: "destructive"
      });
    }
  });

  // Mutations para gerenciar parcelas de carga
  const addParcelMutation = useMutation({
    mutationFn: async (parcelData: any) => {
      const response = await fetch(`/api/ships/${shipId}/parcels`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(parcelData)
      });
      if (!response.ok) throw new Error('Failed to add parcel');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/ships'] });
      queryClient.invalidateQueries({ queryKey: [`/api/ships/${shipId}`] });
      toast({
        title: "Sucesso",
        description: "Nova parcela adicionada com sucesso"
      });
    },
    onError: () => {
      toast({
        title: "Erro",
        description: "Falha ao adicionar nova parcela",
        variant: "destructive"
      });
    }
  });

  const updateParcelMutation = useMutation({
    mutationFn: async ({ parcelId, parcelData }: { parcelId: number; parcelData: any }) => {
      const response = await fetch(`/api/parcels/${parcelId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(parcelData)
      });
      if (!response.ok) throw new Error('Failed to update parcel');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/ships'] });
      queryClient.invalidateQueries({ queryKey: [`/api/ships/${shipId}`] });
      toast({
        title: "Sucesso",
        description: "Parcela atualizada com sucesso"
      });
    },
    onError: () => {
      toast({
        title: "Erro",
        description: "Falha ao atualizar parcela",
        variant: "destructive"
      });
    }
  });

  const deleteParcelMutation = useMutation({
    mutationFn: async (parcelId: number) => {
      const response = await fetch(`/api/parcels/${parcelId}`, {
        method: 'DELETE'
      });
      if (!response.ok) throw new Error('Failed to delete parcel');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/ships'] });
      queryClient.invalidateQueries({ queryKey: [`/api/ships/${shipId}`] });
      toast({
        title: "Sucesso",
        description: "Parcela removida com sucesso"
      });
    },
    onError: () => {
      toast({
        title: "Erro",
        description: "Falha ao remover parcela",
        variant: "destructive"
      });
    }
  });

  // Funções para gerenciar edição de parcelas
  const startParcelEditing = () => {
    if (ship?.parcels) {
      // Salvar dados originais
      const originalData: Record<number, any> = {};
      ship.parcels.forEach((parcel: any) => {
        originalData[parcel.id] = { ...parcel };
      });
      setOriginalParcelData(originalData);
      setLocalParcelData(originalData);
      setIsEditingParcels(true);
    }
  };

  const saveParcelChanges = async () => {
    try {
      // Salvar todas as alterações
      for (const parcelId in localParcelData) {
        const parcelData = localParcelData[parcelId];
        const originalData = originalParcelData[parcelId];
        
        // Verificar se houve mudanças
        if (JSON.stringify(parcelData) !== JSON.stringify(originalData)) {
          // Validar e limpar dados numéricos antes de enviar
          const cleanedData = {
            product: parcelData.product || '',
            volumeMT: parcelData.volumeMT && parcelData.volumeMT.trim() !== '' ? parcelData.volumeMT : null,
            volumeM3: parcelData.volumeM3 && parcelData.volumeM3.trim() !== '' ? parcelData.volumeM3 : null,
            density15C: parcelData.density15C && parcelData.density15C.trim() !== '' ? parcelData.density15C : null,
            receiver: parcelData.receiver || '',
            owner: parcelData.owner || '',
          };
          
          await updateParcelMutation.mutateAsync({
            parcelId: parseInt(parcelId),
            parcelData: cleanedData
          });
        }
      }
      
      setIsEditingParcels(false);
      setOriginalParcelData({});
      setLocalParcelData({});
      
      toast({
        title: "Sucesso",
        description: "Todas as parcelas foram atualizadas"
      });
    } catch (error) {
      toast({
        title: "Erro",
        description: "Falha ao salvar alterações",
        variant: "destructive"
      });
    }
  };

  const cancelParcelEditing = () => {
    setLocalParcelData({});
    setOriginalParcelData({});
    setIsEditingParcels(false);
  };

  useEffect(() => {
    setMounted(true);
    console.log('ShipInfoModal mounted, activeTab:', activeTab);
    return () => setMounted(false);
  }, []);

  useEffect(() => {
    console.log('ShipInfoModal activeTab changed to:', activeTab);
  }, [activeTab]);

  useEffect(() => {
    if (isOpen) {
      setActiveTab(defaultTab);
    }
  }, [isOpen, defaultTab]);

  const { data: ship, isLoading, error } = useQuery<any>({
    queryKey: [`/api/ships/${shipId}`],
    enabled: isOpen && !!shipId,
    staleTime: 0, // Don't cache to ensure fresh data
  });

  const { data: berthingData } = useQuery<any>({
    queryKey: [`/api/ships/${shipId}/berthing`],
    enabled: isOpen && !!shipId,
    staleTime: 0,
  });

  const { data: undockingData } = useQuery<any>({
    queryKey: [`/api/ships/${shipId}/undocking`],
    enabled: isOpen && !!shipId,
    staleTime: 0,
  });

  // Inicializar dados de edição quando o navio carrega
  useEffect(() => {
    if (ship) {
      setEditData({
        name: ship.name || '',
        countermark: ship.countermark || '',
        draft: ship.draft || '',
        cargoType: ship.cargoType || '',
        shipowner: ship.shipowner || '',
        cargoDestination: ship.cargoDestination || '',
        operationType: ship.operationType || 'Nacional',
        shipAgent: ship.shipAgent || '',
        cargoAgent: ship.cargoAgent || '',
        shipAgentEmail: ship.shipAgentEmail || '',
        cargoAgentEmail: ship.cargoAgentEmail || ''
      });
      setEditingParcels(ship.parcels ? [...ship.parcels] : []);
    }
  }, [ship]);

  // Funções para gerenciar parcelas de carga
  const generateParcelNumber = () => {
    const existingNumbers = (ship?.parcels || []).map((p: any) => {
      const match = p.parcelNumber?.match(/P(\d+)/);
      return match ? parseInt(match[1]) : 0;
    });
    const maxNumber = Math.max(0, ...existingNumbers);
    return `P${String(maxNumber + 1).padStart(3, '0')}`;
  };

  const addNewParcel = () => {
    const newParcel = {
      parcelNumber: generateParcelNumber(),
      product: 'Gasolina',
      volumeMT: '',
      volumeM3: '',
      density15C: '',
      receiver: '',
      owner: ''
    };
    addParcelMutation.mutate(newParcel);
  };

  // Debounce timer
  const debounceRef = useRef<Record<string, NodeJS.Timeout>>({});

  const updateParcel = (parcelId: number, field: string, value: string) => {
    // Update local state and calculate conversions if needed
    setLocalParcelData(prev => {
      const currentData = { ...prev[parcelId] };
      currentData[field] = value;

      // Auto-calculate conversions when density is available
      const density = parseFloat(field === 'density15C' ? value : currentData.density15C);
      
      if (density && density > 0) {
        if (field === 'volumeMT') {
          // Convert MT to m³: Volume (m³) = Massa (MT) / Densidade
          const mt = parseFloat(value);
          if (mt && mt > 0) {
            currentData.volumeM3 = (mt / density).toFixed(3);
          }
        } else if (field === 'volumeM3') {
          // Convert m³ to MT: Massa (MT) = Volume (m³) * Densidade
          const m3 = parseFloat(value);
          if (m3 && m3 > 0) {
            currentData.volumeMT = (m3 * density).toFixed(3);
          }
        } else if (field === 'density15C') {
          // Recalculate both conversions when density changes
          const mt = parseFloat(currentData.volumeMT);
          const m3 = parseFloat(currentData.volumeM3);
          
          if (mt && mt > 0) {
            currentData.volumeM3 = (mt / density).toFixed(3);
          } else if (m3 && m3 > 0) {
            currentData.volumeMT = (m3 * density).toFixed(3);
          }
        }
      }

      return {
        ...prev,
        [parcelId]: currentData
      };
    });
  };

  const removeParcel = (parcelId: number) => {
    if (confirm('Tem certeza que deseja remover esta parcela?')) {
      deleteParcelMutation.mutate(parcelId);
    }
  };

  // Debug log para verificar permissões
  if (ship) {
    console.log('Debug - User:', user, 'CanEdit:', canEdit, 'Ship status:', ship?.status, 'AuthLoading:', authLoading);
  }

  const handleDownloadPDF = async () => {
    if (!ship) return;
    
    try {
      const { default: jsPDF } = await import('jspdf');
      const { default: html2canvas } = await import('html2canvas');
      
      // Create a temporary div with ship information for PDF
      const tempDiv = document.createElement('div');
      tempDiv.style.cssText = `
        position: absolute;
        left: -9999px;
        top: -9999px;
        width: 800px;
        background: white;
        padding: 20px;
        font-family: Arial, sans-serif;
      `;
      
      tempDiv.innerHTML = `
        <div style="border-bottom: 2px solid #1d4ed8; padding-bottom: 15px; margin-bottom: 20px;">
          <h1 style="color: #1d4ed8; margin: 0; font-size: 24px;">INFORMAÇÕES DO NAVIO</h1>
          <p style="color: #666; margin: 5px 0 0 0; font-size: 14px;">Beira Oil Terminal - CFM</p>
        </div>
        
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 25px;">
          <div>
            <h3 style="color: #1d4ed8; font-size: 16px; margin: 0 0 10px 0; border-bottom: 1px solid #e5e7eb; padding-bottom: 5px;">DADOS BÁSICOS</h3>
            <p><strong>Nome:</strong> ${ship.name || 'N/A'}</p>
            <p><strong>Contramarco:</strong> ${ship.countermark || 'N/A'}</p>
            <p><strong>Calado:</strong> ${ship.draft || 'N/A'}</p>
            <p><strong>Armador:</strong> ${ship.shipowner || 'N/A'}</p>
            <p><strong>Destino da Carga:</strong> ${ship.cargoDestination || 'N/A'}</p>
            <p><strong>Tipo de Operação:</strong> ${ship.operationType || 'N/A'}</p>
          </div>
          <div>
            <h3 style="color: #1d4ed8; font-size: 16px; margin: 0 0 10px 0; border-bottom: 1px solid #e5e7eb; padding-bottom: 5px;">AGENTES</h3>
            <p><strong>Agente do Navio:</strong> ${ship.shipAgent || 'N/A'}</p>
            <p><strong>Email Agente Navio:</strong> ${ship.shipAgentEmail || 'N/A'}</p>
            <p><strong>Agente da Carga:</strong> ${ship.cargoAgent || 'N/A'}</p>
            <p><strong>Email Agente Carga:</strong> ${ship.cargoAgentEmail || 'N/A'}</p>
          </div>
        </div>
        
        <div style="margin-bottom: 25px;">
          <h3 style="color: #1d4ed8; font-size: 16px; margin: 0 0 15px 0; border-bottom: 1px solid #e5e7eb; padding-bottom: 5px;">STATUS OPERACIONAL</h3>
          <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 15px;">
            <p><strong>Status:</strong> ${ship.status === 'at_berth' ? 'No Cais' : ship.status === 'next_to_berth' ? 'Próximo ao Cais' : ship.status === 'at_bar' ? 'Na Barra' : ship.status}</p>
            <p><strong>Instrução de Descarga:</strong> ${ship.hasDischargeInstructions ? 'Sim' : 'Não'}</p>
            <p><strong>Confirmação Atracação:</strong> ${berthingData?.lastRopeTime ? 'Sim' : 'Pendente'}</p>
          </div>
        </div>
        
        ${ship.parcels && ship.parcels.length > 0 ? `
          <div>
            <h3 style="color: #1d4ed8; font-size: 16px; margin: 0 0 15px 0; border-bottom: 1px solid #e5e7eb; padding-bottom: 5px;">PARCELAS DE CARGA</h3>
            <table style="width: 100%; border-collapse: collapse; font-size: 12px;">
              <thead>
                <tr style="background: #f3f4f6;">
                  <th style="border: 1px solid #d1d5db; padding: 8px; text-align: left;">Parcela</th>
                  <th style="border: 1px solid #d1d5db; padding: 8px; text-align: left;">Produto</th>
                  <th style="border: 1px solid #d1d5db; padding: 8px; text-align: left;">Volume MT</th>
                  <th style="border: 1px solid #d1d5db; padding: 8px; text-align: left;">Volume m³</th>
                  <th style="border: 1px solid #d1d5db; padding: 8px; text-align: left;">Densidade</th>
                  <th style="border: 1px solid #d1d5db; padding: 8px; text-align: left;">Recebedor</th>
                  <th style="border: 1px solid #d1d5db; padding: 8px; text-align: left;">Dono</th>
                </tr>
              </thead>
              <tbody>
                ${ship.parcels.map((parcel: any) => `
                  <tr>
                    <td style="border: 1px solid #d1d5db; padding: 8px;">${parcel.parcelNumber || 'N/A'}</td>
                    <td style="border: 1px solid #d1d5db; padding: 8px;">${parcel.product || 'N/A'}</td>
                    <td style="border: 1px solid #d1d5db; padding: 8px;">${parcel.volumeMT || 'N/A'}</td>
                    <td style="border: 1px solid #d1d5db; padding: 8px;">${parcel.volumeM3 || 'N/A'}</td>
                    <td style="border: 1px solid #d1d5db; padding: 8px;">${parcel.density15C || 'N/A'}</td>
                    <td style="border: 1px solid #d1d5db; padding: 8px;">${parcel.receiver || 'N/A'}</td>
                    <td style="border: 1px solid #d1d5db; padding: 8px;">${parcel.owner || 'N/A'}</td>
                  </tr>
                `).join('')}
              </tbody>
            </table>
          </div>
        ` : ''}
        
        <div style="margin-top: 30px; padding-top: 15px; border-top: 1px solid #e5e7eb; font-size: 12px; color: #666; text-align: center;">
          <p>Documento gerado em ${new Date().toLocaleString('pt-BR', { timeZone: 'Africa/Maputo' })} - Beira Oil Terminal</p>
        </div>
      `;
      
      document.body.appendChild(tempDiv);
      
      // Generate canvas from HTML
      const canvas = await html2canvas(tempDiv, {
        scale: 2,
        useCORS: true,
        allowTaint: true,
        backgroundColor: '#ffffff'
      });
      
      // Remove temporary div
      document.body.removeChild(tempDiv);
      
      // Create PDF
      const pdf = new jsPDF('p', 'mm', 'a4');
      const imgData = canvas.toDataURL('image/png');
      const pdfWidth = pdf.internal.pageSize.getWidth();
      const pdfHeight = (canvas.height * pdfWidth) / canvas.width;
      
      pdf.addImage(imgData, 'PNG', 0, 0, pdfWidth, pdfHeight);
      pdf.save(`${ship.name || 'navio'}-informacoes.pdf`);
      
      toast({
        title: "Sucesso",
        description: "PDF gerado e baixado com sucesso"
      });
    } catch (error) {
      console.error('Erro ao gerar PDF:', error);
      toast({
        title: "Erro",
        description: "Falha ao gerar PDF",
        variant: "destructive"
      });
    }
  };

  const handlePrint = () => {
    if (!ship) return;
    
    // Create a new window for printing
    const printWindow = window.open('', '_blank');
    if (!printWindow) {
      toast({
        title: "Erro",
        description: "Não foi possível abrir janela de impressão",
        variant: "destructive"
      });
      return;
    }
    
    const printContent = `
      <!DOCTYPE html>
      <html>
        <head>
          <title>Informações do Navio - ${ship.name}</title>
          <style>
            body { font-family: Arial, sans-serif; margin: 20px; line-height: 1.4; }
            .header { border-bottom: 2px solid #1d4ed8; padding-bottom: 15px; margin-bottom: 20px; }
            .header h1 { color: #1d4ed8; margin: 0; font-size: 24px; }
            .header p { color: #666; margin: 5px 0 0 0; font-size: 14px; }
            .section { margin-bottom: 25px; }
            .section h3 { color: #1d4ed8; font-size: 16px; margin: 0 0 10px 0; border-bottom: 1px solid #e5e7eb; padding-bottom: 5px; }
            .grid-2 { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; }
            .grid-3 { display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 15px; }
            table { width: 100%; border-collapse: collapse; font-size: 12px; }
            th, td { border: 1px solid #d1d5db; padding: 8px; text-align: left; }
            th { background: #f3f4f6; }
            .footer { margin-top: 30px; padding-top: 15px; border-top: 1px solid #e5e7eb; font-size: 12px; color: #666; text-align: center; }
            @media print { .no-print { display: none; } }
          </style>
        </head>
        <body>
          <div class="header">
            <h1>INFORMAÇÕES DO NAVIO</h1>
            <p>Beira Oil Terminal - CFM</p>
          </div>
          
          <div class="grid-2 section">
            <div>
              <h3>DADOS BÁSICOS</h3>
              <p><strong>Nome:</strong> ${ship.name || 'N/A'}</p>
              <p><strong>Contramarco:</strong> ${ship.countermark || 'N/A'}</p>
              <p><strong>Calado:</strong> ${ship.draft || 'N/A'}</p>
              <p><strong>Armador:</strong> ${ship.shipowner || 'N/A'}</p>
              <p><strong>Destino da Carga:</strong> ${ship.cargoDestination || 'N/A'}</p>
              <p><strong>Tipo de Operação:</strong> ${ship.operationType || 'N/A'}</p>
            </div>
            <div>
              <h3>AGENTES</h3>
              <p><strong>Agente do Navio:</strong> ${ship.shipAgent || 'N/A'}</p>
              <p><strong>Email Agente Navio:</strong> ${ship.shipAgentEmail || 'N/A'}</p>
              <p><strong>Agente da Carga:</strong> ${ship.cargoAgent || 'N/A'}</p>
              <p><strong>Email Agente Carga:</strong> ${ship.cargoAgentEmail || 'N/A'}</p>
            </div>
          </div>
          
          <div class="section">
            <h3>STATUS OPERACIONAL</h3>
            <div class="grid-3">
              <p><strong>Status:</strong> ${ship.status === 'at_berth' ? 'No Cais' : ship.status === 'next_to_berth' ? 'Próximo ao Cais' : ship.status === 'at_bar' ? 'Na Barra' : ship.status}</p>
              <p><strong>Instrução de Descarga:</strong> ${ship.hasDischargeInstructions ? 'Sim' : 'Não'}</p>
              <p><strong>Confirmação Atracação:</strong> ${berthingData?.lastRopeTime ? 'Sim' : 'Pendente'}</p>
            </div>
          </div>
          
          ${ship.parcels && ship.parcels.length > 0 ? `
            <div class="section">
              <h3>PARCELAS DE CARGA</h3>
              <table>
                <thead>
                  <tr>
                    <th>Parcela</th>
                    <th>Produto</th>
                    <th>Volume MT</th>
                    <th>Volume m³</th>
                    <th>Densidade</th>
                    <th>Recebedor</th>
                    <th>Dono</th>
                  </tr>
                </thead>
                <tbody>
                  ${ship.parcels.map((parcel: any) => `
                    <tr>
                      <td>${parcel.parcelNumber || 'N/A'}</td>
                      <td>${parcel.product || 'N/A'}</td>
                      <td>${parcel.volumeMT || 'N/A'}</td>
                      <td>${parcel.volumeM3 || 'N/A'}</td>
                      <td>${parcel.density15C || 'N/A'}</td>
                      <td>${parcel.receiver || 'N/A'}</td>
                      <td>${parcel.owner || 'N/A'}</td>
                    </tr>
                  `).join('')}
                </tbody>
              </table>
            </div>
          ` : ''}
          
          <div class="footer">
            <p>Documento gerado em ${new Date().toLocaleString('pt-BR', { timeZone: 'Africa/Maputo' })} - Beira Oil Terminal</p>
          </div>
        </body>
      </html>
    `;
    
    printWindow.document.write(printContent);
    printWindow.document.close();
    
    // Wait for content to load, then print
    printWindow.onload = () => {
      printWindow.print();
      printWindow.close();
    };
  };

  // Prevent scrolling when modal is open
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }
    return () => {
      document.body.style.overflow = 'unset';
    };
  }, [isOpen]);

  // Inicializar dados de edição quando o navio é carregado
  useEffect(() => {
    if (ship) {
      setEditData({
        name: ship.name || '',
        countermark: ship.countermark || '',
        draft: ship.draft || '',
        cargoType: ship.cargoType || '',
        shipowner: ship.shipowner || '',
        cargoDestination: ship.cargoDestination || '',
        operationType: ship.operationType || 'nacional',
        shipAgent: ship.shipAgent || '',
        shipAgentEmail: ship.shipAgentEmail || '',
        cargoAgent: ship.cargoAgent || '',
        cargoAgentEmail: ship.cargoAgentEmail || ''
      });
    }
  }, [ship]);

  const handleStartEdit = () => {
    console.log('Iniciando edição...');
    setIsEditing(true);
  };

  const handleCancelEdit = () => {
    setIsEditing(false);
    // Resetar dados de edição
    if (ship) {
      setEditData({
        name: ship.name || '',
        countermark: ship.countermark || '',
        draft: ship.draft || '',
        cargoType: ship.cargoType || '',
        shipowner: ship.shipowner || '',
        cargoDestination: ship.cargoDestination || '',
        operationType: ship.operationType || 'nacional',
        shipAgent: ship.shipAgent || '',
        shipAgentEmail: ship.shipAgentEmail || '',
        cargoAgent: ship.cargoAgent || '',
        cargoAgentEmail: ship.cargoAgentEmail || ''
      });
    }
  };

  const handleSaveEdit = () => {
    updateShipMutation.mutate(editData);
  };

  const handleFieldChange = (field: string, value: string) => {
    setEditData((prev: any) => ({
      ...prev,
      [field]: value
    }));
  };

  if (!mounted || !isOpen || !shipId) return null;

  const modalContent = (
    <div 
      className="fixed inset-0 z-[9999] bg-black/50 flex items-center justify-center p-4"
      style={{ zIndex: 9999 }}
    >
      <div 
        className="bg-white rounded-lg max-w-6xl w-full max-h-[90vh] overflow-hidden shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Fixed Header */}
        <div className="sticky top-0 bg-white border-b p-6 flex items-center justify-between z-10">
          <div>
            <h2 className="text-xl font-semibold text-gray-900">Detalhes do Navio</h2>
            <p className="text-sm text-gray-500 mt-1">
              Informações completas sobre o navio, agentes, carga e status operacional.
            </p>
          </div>
          <div className="flex items-center gap-2">
            {canEdit && ship?.status === 'at_berth' && (
              <Button
                variant="outline"
                size="sm"
                onClick={() => setIsDischargeControlOpen(true)}
                className="flex items-center gap-2 bg-blue-50 border-blue-200 hover:bg-blue-100"
              >
                <Anchor className="h-4 w-4 text-blue-600" />
                Controlo de Descarga
              </Button>
            )}
            <Button
              variant="outline"
              size="sm"
              onClick={handleDownloadPDF}
              className="flex items-center gap-2"
            >
              <Download className="h-4 w-4" />
              PDF
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={handlePrint}
              className="flex items-center gap-2"
            >
              <Printer className="h-4 w-4" />
              Imprimir
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={onClose}
              className="h-10 w-10 p-0 hover:bg-gray-100 rounded-full"
            >
              <X className="h-5 w-5" />
            </Button>
          </div>
        </div>

        {/* Content Area */}
        <div className="overflow-y-auto max-h-[calc(90vh-100px)]">
          {isLoading ? (
            <div className="flex items-center justify-center p-8">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
              <p className="ml-3 text-gray-600">Carregando informações do navio...</p>
            </div>
          ) : error ? (
            <div className="p-8 text-center text-red-500">
              <p>Erro ao carregar dados do navio</p>
              <p className="text-sm text-gray-500 mt-2">ID: {shipId}</p>
            </div>
          ) : ship ? (
            <div className="p-6" ref={printRef}>
              <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
                <TabsList className="grid w-full grid-cols-4 mb-6">
                  <TabsTrigger 
                    value="info" 
                    className="flex items-center gap-2"
                    onClick={() => console.log('Info tab clicked')}
                  >
                    <Info className="h-4 w-4" />
                    Informações
                  </TabsTrigger>
                  <TabsTrigger 
                    value="move" 
                    className="flex items-center gap-2"
                    disabled={!user?.permissions?.includes('move_ships')}
                    onClick={() => {
                      console.log('Move tab clicked');
                      if (user?.permissions?.includes('move_ships')) {
                        setActiveTab('move');
                      }
                    }}
                  >
                    <Ship className="h-4 w-4" />
                    MOVER
                  </TabsTrigger>
                  <TabsTrigger 
                    value="berth" 
                    className="flex items-center gap-2"
                    disabled={!user?.permissions?.includes('register_undocking')}
                    onClick={() => {
                      console.log('Berth tab clicked');
                      if (user?.permissions?.includes('register_undocking')) {
                        setActiveTab('berth');
                      }
                    }}
                  >
                    <Anchor className="h-4 w-4" />
                    ATRACAR NAVIO
                  </TabsTrigger>
                  <TabsTrigger 
                    value="download" 
                    className="flex items-center gap-2"
                    disabled={!user?.permissions?.includes('view_ships') && !user?.permissions?.includes('view_ships_public')}
                    onClick={() => {
                      console.log('Download tab clicked');
                      if (user?.permissions?.includes('view_ships') || user?.permissions?.includes('view_ships_public')) {
                        setActiveTab('download');
                      }
                    }}
                  >
                    <Download className="h-4 w-4" />
                    DOWNLOAD PDF
                  </TabsTrigger>
                </TabsList>

                <TabsContent value="info" className="space-y-6">
                  {/* Botões de Edição - para operadores/admins em navios não partidos */}
                  {(user?.role === 'operator' || user?.role === 'admin') && ship?.status !== 'departed' && (
                    <div className="flex justify-end mb-4">
                      {!isEditing ? (
                        <Button
                          onClick={handleStartEdit}
                          className="bg-blue-600 hover:bg-blue-700 text-white"
                        >
                          <Edit className="h-4 w-4 mr-2" />
                          Editar Informações
                        </Button>
                      ) : (
                        <div className="flex space-x-2">
                          <Button
                            onClick={handleCancelEdit}
                            variant="outline"
                            disabled={updateShipMutation.isPending}
                          >
                            <XCircle className="h-4 w-4 mr-2" />
                            Cancelar
                          </Button>
                          <Button
                            onClick={handleSaveEdit}
                            className="bg-green-600 hover:bg-green-700 text-white"
                            disabled={updateShipMutation.isPending}
                          >
                            <Save className="h-4 w-4 mr-2" />
                            {updateShipMutation.isPending ? 'Salvando...' : 'Salvar'}
                          </Button>
                        </div>
                      )}
                    </div>
                  )}



                  {/* Informações Gerais */}
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <h3 className="text-lg font-semibold text-gray-800 mb-3">Informações Gerais</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <span className="text-sm font-medium text-gray-600 block">Nome do Navio</span>
                        {isEditing ? (
                          <Input
                            value={editData.name}
                            onChange={(e) => handleFieldChange('name', e.target.value)}
                            className="mt-1"
                          />
                        ) : (
                          <p className="text-gray-900">{ship?.name || "N/A"}</p>
                        )}
                      </div>
                      <div>
                        <span className="text-sm font-medium text-gray-600 block">Contra Marca</span>
                        {isEditing ? (
                          <Input
                            value={editData.countermark}
                            onChange={(e) => handleFieldChange('countermark', e.target.value)}
                            className="mt-1"
                          />
                        ) : (
                          <p className="text-gray-900">{ship?.countermark || "N/A"}</p>
                        )}
                      </div>
                      <div>
                        <span className="text-sm font-medium text-gray-600 block">Calado</span>
                        {isEditing ? (
                          <Input
                            value={editData.draft}
                            onChange={(e) => handleFieldChange('draft', e.target.value)}
                            placeholder="Ex: 12.5"
                            className="mt-1"
                          />
                        ) : (
                          <p className="text-gray-900">{ship?.draft || "N/A"}m</p>
                        )}
                      </div>
                      <div>
                        <span className="text-sm font-medium text-gray-600 block">Tipo de Carga</span>
                        {isEditing ? (
                          <Input
                            value={editData.cargoType}
                            onChange={(e) => handleFieldChange('cargoType', e.target.value)}
                            className="mt-1"
                          />
                        ) : (
                          <p className="text-gray-900">{ship?.cargoType || "N/A"}</p>
                        )}
                      </div>
                      <div>
                        <span className="text-sm font-medium text-gray-600 block">Armador</span>
                        {isEditing ? (
                          <Input
                            value={editData.shipowner}
                            onChange={(e) => handleFieldChange('shipowner', e.target.value)}
                            className="mt-1"
                          />
                        ) : (
                          <p className="text-gray-900">{ship?.shipowner || "N/A"}</p>
                        )}
                      </div>
                      <div>
                        <span className="text-sm font-medium text-gray-600 block">Destino da Carga</span>
                        {isEditing ? (
                          <Input
                            value={editData.cargoDestination}
                            onChange={(e) => handleFieldChange('cargoDestination', e.target.value)}
                            className="mt-1"
                          />
                        ) : (
                          <p className="text-gray-900">{ship?.cargoDestination || "N/A"}</p>
                        )}
                      </div>
                      <div>
                        <span className="text-sm font-medium text-gray-600 block">Tipo de Operação</span>
                        {isEditing ? (
                          <Select
                            value={editData.operationType}
                            onValueChange={(value) => handleFieldChange('operationType', value)}
                          >
                            <SelectTrigger className="mt-1">
                              <SelectValue placeholder="Selecione o tipo de operação" />
                            </SelectTrigger>
                            <SelectContent position="popper" sideOffset={4} className="z-[9999]">
                              <SelectItem value="nacional">Nacional</SelectItem>
                              <SelectItem value="transito">Trânsito</SelectItem>
                              <SelectItem value="combinado">Combinado</SelectItem>
                              <SelectItem value="lpg">LPG</SelectItem>
                            </SelectContent>
                          </Select>
                        ) : (
                          <p className="text-gray-900">
                            {ship?.operationType === 'nacional' ? 'Nacional' :
                             ship?.operationType === 'transito' ? 'Trânsito' : 
                             ship?.operationType === 'combinado' ? 'Combinado' :
                             ship?.operationType === 'lpg' ? 'LPG' :
                             ship?.operationType || "N/A"}
                          </p>
                        )}
                      </div>
                      <div>
                        <span className="text-sm font-medium text-gray-600 block">Status Atual</span>
                        <p className="text-gray-900">
                          {ship?.status === 'expected' ? 'Esperado' :
                           ship?.status === 'at_bar' ? 'Na Barra' :
                           ship?.status === 'next_to_berth' ? 'Próximo a Atracar' :
                           ship?.status === 'at_berth' ? 'Atracado' :
                           ship?.status === 'departed' ? 'Partiu' :
                           ship?.status || "N/A"}
                        </p>
                      </div>
                    </div>
                  </div>

                  {/* Agentes */}
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <h3 className="text-lg font-semibold text-gray-800 mb-3">Agentes</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <span className="text-sm font-medium text-gray-600 block">Agente do Navio</span>
                        {isEditing ? (
                          <div className="space-y-2">
                            <Input
                              value={editData.shipAgent}
                              onChange={(e) => handleFieldChange('shipAgent', e.target.value)}
                              placeholder="Nome do agente"
                              className="mt-1"
                            />
                            <Input
                              value={editData.shipAgentEmail}
                              onChange={(e) => handleFieldChange('shipAgentEmail', e.target.value)}
                              placeholder="email@exemplo.com"
                              type="email"
                            />
                          </div>
                        ) : (
                          <>
                            <p className="text-gray-900">{ship?.shipAgent || "N/A"}</p>
                            {ship?.shipAgentEmail && (
                              <>
                                <span className="text-xs font-medium text-gray-500 block mt-1">Email</span>
                                <p className="text-sm text-blue-600">{ship.shipAgentEmail}</p>
                              </>
                            )}
                          </>
                        )}
                      </div>
                      <div>
                        <span className="text-sm font-medium text-gray-600 block">Agente da Carga</span>
                        {isEditing ? (
                          <div className="space-y-2">
                            <Input
                              value={editData.cargoAgent}
                              onChange={(e) => handleFieldChange('cargoAgent', e.target.value)}
                              placeholder="Nome do agente"
                              className="mt-1"
                            />
                            <Input
                              value={editData.cargoAgentEmail}
                              onChange={(e) => handleFieldChange('cargoAgentEmail', e.target.value)}
                              placeholder="email@exemplo.com"
                              type="email"
                            />
                          </div>
                        ) : (
                          <>
                            <p className="text-gray-900">{ship?.cargoAgent || "N/A"}</p>
                            {ship?.cargoAgentEmail && (
                              <>
                                <span className="text-xs font-medium text-gray-500 block mt-1">Email</span>
                                <p className="text-sm text-blue-600">{ship.cargoAgentEmail}</p>
                              </>
                            )}
                          </>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Parcelas de Carga */}
                  {ship?.parcels && (
                    <div className="bg-gray-50 p-4 rounded-lg">
                      <div className="flex justify-between items-center mb-3">
                        <h3 className="text-lg font-semibold text-gray-800">Parcelas de Carga</h3>
                        {(user?.role === 'operator' || user?.role === 'admin') && ship?.status !== 'departed' && (
                          <div className="flex gap-2">
                            {isEditingParcels ? (
                              <>
                                <Button
                                  onClick={saveParcelChanges}
                                  size="sm"
                                  className="bg-green-600 hover:bg-green-700 text-white"
                                  disabled={updateParcelMutation.isPending}
                                >
                                  <Check className="h-4 w-4 mr-1" />
                                  Salvar
                                </Button>
                                <Button
                                  onClick={cancelParcelEditing}
                                  size="sm"
                                  variant="outline"
                                  className="border-gray-300"
                                >
                                  <X className="h-4 w-4 mr-1" />
                                  Cancelar
                                </Button>
                              </>
                            ) : (
                              <>
                                <Button
                                  onClick={startParcelEditing}
                                  size="sm"
                                  className="bg-blue-600 hover:bg-blue-700 text-white"
                                  disabled={ship?.parcels?.length === 0}
                                >
                                  <Edit className="h-4 w-4 mr-1" />
                                  Editar
                                </Button>
                                <Button
                                  onClick={addNewParcel}
                                  size="sm"
                                  className="bg-green-600 hover:bg-green-700 text-white"
                                  disabled={addParcelMutation.isPending}
                                >
                                  <Plus className="h-4 w-4 mr-1" />
                                  Adicionar
                                </Button>
                              </>
                            )}
                          </div>
                        )}
                      </div>
                      <div className="space-y-3">
                        {ship.parcels.length === 0 ? (
                          <div className="text-center py-8 text-gray-500">
                            <p>Nenhuma parcela cadastrada</p>
                            {(user?.role === 'operator' || user?.role === 'admin') && ship?.status !== 'departed' && (
                              <p className="text-sm mt-2">Clique em "Adicionar Parcela" para começar</p>
                            )}
                          </div>
                        ) : (
                          ship.parcels
                            .sort((a: any, b: any) => {
                              // Extrair números das parcelas para ordenação
                              const aNum = parseInt(a.parcelNumber?.replace('P', '') || '0');
                              const bNum = parseInt(b.parcelNumber?.replace('P', '') || '0');
                              return aNum - bNum;
                            })
                            .map((parcel: any, index: number) => (
                            <div key={parcel.id || index} className="bg-white p-3 rounded border">
                              <div className="grid grid-cols-2 md:grid-cols-6 gap-3">
                                {/* Número da Parcela */}
                                <div>
                                  <span className="text-xs font-medium text-gray-600 block">Número</span>
                                  <p className="text-sm font-medium">{parcel.parcelNumber}</p>
                                </div>
                                
                                {/* Produto */}
                                <div>
                                  <span className="text-xs font-medium text-gray-600 block">Produto</span>
                                  {isEditingParcels ? (
                                    <Select
                                      value={localParcelData[parcel.id]?.product || parcel.product || 'Gasolina'}
                                      onValueChange={(value) => updateParcel(parcel.id, 'product', value)}
                                    >
                                      <SelectTrigger className="h-8 text-sm w-full">
                                        <SelectValue placeholder="Selecione o produto" />
                                      </SelectTrigger>
                                      <SelectContent position="popper" sideOffset={4} className="z-[9999]">
                                        <SelectItem value="Gasolina">Gasolina</SelectItem>
                                        <SelectItem value="Diesel">Diesel</SelectItem>
                                        <SelectItem value="Jet A1">Jet A1</SelectItem>
                                        <SelectItem value="LPG">LPG</SelectItem>
                                      </SelectContent>
                                    </Select>
                                  ) : (
                                    <p className="text-sm">{localParcelData[parcel.id]?.product || parcel.product}</p>
                                  )}
                                </div>
                                
                                {/* Volume MT */}
                                <div>
                                  <span className="text-xs font-medium text-gray-600 block">Volume MT</span>
                                  {isEditingParcels ? (
                                    <Input
                                      value={localParcelData[parcel.id]?.volumeMT || parcel.volumeMT || ''}
                                      onChange={(e) => updateParcel(parcel.id, 'volumeMT', e.target.value)}
                                      placeholder="0.00"
                                      className="h-8 text-sm"
                                    />
                                  ) : (
                                    <p className="text-sm">{localParcelData[parcel.id]?.volumeMT || parcel.volumeMT} MT</p>
                                  )}
                                </div>
                                
                                {/* Volume M³ */}
                                <div>
                                  <span className="text-xs font-medium text-gray-600 block">Volume m³</span>
                                  {isEditingParcels ? (
                                    <Input
                                      value={localParcelData[parcel.id]?.volumeM3 || parcel.volumeM3 || ''}
                                      onChange={(e) => updateParcel(parcel.id, 'volumeM3', e.target.value)}
                                      placeholder="0.00"
                                      className="h-8 text-sm"
                                    />
                                  ) : (
                                    <p className="text-sm">{localParcelData[parcel.id]?.volumeM3 || parcel.volumeM3} m³</p>
                                  )}
                                </div>
                                
                                {/* Densidade */}
                                <div>
                                  <span className="text-xs font-medium text-gray-600 block">Densidade</span>
                                  {isEditingParcels ? (
                                    <Input
                                      value={localParcelData[parcel.id]?.density15C || parcel.density15C || ''}
                                      onChange={(e) => updateParcel(parcel.id, 'density15C', e.target.value)}
                                      placeholder="0.000"
                                      className="h-8 text-sm"
                                    />
                                  ) : (
                                    <p className="text-sm">{localParcelData[parcel.id]?.density15C || parcel.density15C}</p>
                                  )}
                                </div>
                                
                                {/* Ações */}
                                <div className="flex items-end justify-end">
                                  {isEditingParcels && (
                                    <Button
                                      onClick={() => removeParcel(parcel.id)}
                                      size="sm"
                                      variant="outline"
                                      className="h-8 w-8 p-0 text-red-600 hover:text-red-800 hover:bg-red-50"
                                      disabled={deleteParcelMutation.isPending}
                                    >
                                      <Trash2 className="h-3 w-3" />
                                    </Button>
                                  )}
                                </div>
                              </div>
                              
                              {/* Segunda linha: Recebedor e Dono */}
                              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mt-3 pt-3 border-t border-gray-100">
                                <div>
                                  <span className="text-xs font-medium text-gray-600 block">Recebedor</span>
                                  {isEditingParcels ? (
                                    <Input
                                      value={localParcelData[parcel.id]?.receiver || parcel.receiver || ''}
                                      onChange={(e) => updateParcel(parcel.id, 'receiver', e.target.value)}
                                      placeholder="Nome do recebedor"
                                      className="h-8 text-sm"
                                    />
                                  ) : (
                                    <p className="text-sm">{localParcelData[parcel.id]?.receiver || parcel.receiver}</p>
                                  )}
                                </div>
                                <div>
                                  <span className="text-xs font-medium text-gray-600 block">Dono da Parcela</span>
                                  {isEditingParcels ? (
                                    <Input
                                      value={localParcelData[parcel.id]?.owner || parcel.owner || ''}
                                      onChange={(e) => updateParcel(parcel.id, 'owner', e.target.value)}
                                      placeholder="Nome do proprietário"
                                      className="h-8 text-sm"
                                    />
                                  ) : (
                                    <p className="text-sm">{localParcelData[parcel.id]?.owner || parcel.owner}</p>
                                  )}
                                </div>
                              </div>
                            </div>
                          ))
                        )}
                      </div>
                    </div>
                  )}

                  {/* Status Operacional */}
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <h3 className="text-lg font-semibold text-gray-800 mb-3">Status Operacional</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <span className="text-sm font-medium text-gray-600 block">Instrução de Descarga</span>
                        <p className="text-gray-900">
                          {ship?.hasDischargeInstructions ? 
                            <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-green-100 text-green-800">
                              ✓ Com Instrução
                            </span> :
                            <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-red-100 text-red-800">
                              ✗ Sem Instrução
                            </span>
                          }
                        </p>
                      </div>
                      <div>
                        <span className="text-sm font-medium text-gray-600 block">Confirmação de Atracação</span>
                        <p className="text-gray-900">
                          {(ship?.berthingConfirmed || (berthingData && (berthingData as any).lastRopeTime)) ? 
                            <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-green-100 text-green-800">
                              ✓ Sim
                            </span> :
                            <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-yellow-100 text-yellow-800">
                              ⏳ Pendente
                            </span>
                          }
                        </p>
                      </div>
                    </div>
                  </div>

                  {/* Dados de Atracação */}
                  {berthingData && (
                    <div className="bg-blue-50 p-4 rounded-lg">
                      <div className="flex items-center justify-between mb-3">
                        <h3 className="text-lg font-semibold text-gray-800">Dados de Atracação</h3>
                        {canEdit && (
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => {
                              console.log("Edit berthing button clicked", {
                                shipId: ship?.id,
                                berthingData,
                                isEditBerthingOpen,
                                canEdit
                              });
                              setIsEditBerthingOpen(true);
                              console.log("After setting isEditBerthingOpen to true");
                              setTimeout(() => {
                                console.log("State after timeout:", isEditBerthingOpen);
                              }, 100);
                            }}
                            className="flex items-center gap-2"
                          >
                            <Clock className="w-4 h-4" />
                            Editar
                          </Button>
                        )}
                      </div>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <span className="text-sm font-medium text-gray-600 block">Primeira Corda</span>
                          <p className="text-gray-900">
                            {berthingData.firstRopeTime ? 
                              `${new Date(berthingData.firstRopeTime).toLocaleDateString('pt-BR', {
                                day: '2-digit',
                                month: '2-digit',
                                year: 'numeric',
                                timeZone: 'Africa/Maputo'
                              })} ${new Date(berthingData.firstRopeTime).toLocaleTimeString('pt-BR', {
                                hour: '2-digit',
                                minute: '2-digit',
                                timeZone: 'Africa/Maputo'
                              })}` : 
                              "Não registrado"
                            }
                          </p>
                        </div>
                        <div>
                          <span className="text-sm font-medium text-gray-600 block">Última Corda</span>
                          <p className="text-gray-900">
                            {berthingData.lastRopeTime ? 
                              `${new Date(berthingData.lastRopeTime).toLocaleDateString('pt-BR', {
                                day: '2-digit',
                                month: '2-digit',
                                year: 'numeric',
                                timeZone: 'Africa/Maputo'
                              })} ${new Date(berthingData.lastRopeTime).toLocaleTimeString('pt-BR', {
                                hour: '2-digit',
                                minute: '2-digit',
                                timeZone: 'Africa/Maputo'
                              })}` : 
                              "Não registrado"
                            }
                          </p>
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Dados da Desatracação */}
                  <div className="bg-red-50 p-4 rounded-lg">
                    <div className="flex items-center justify-between mb-3">
                      <h3 className="text-lg font-semibold text-gray-800">Dados da Desatracação</h3>
                      {canEdit && (
                        <div className="flex flex-col items-end">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => setIsEditUndockingOpen(true)}
                            disabled={!ship?.latestProgress || ship.latestProgress.percentage < 100}
                            className={`flex items-center gap-2 ${
                              !ship?.latestProgress || ship.latestProgress.percentage < 100
                                ? 'opacity-50 cursor-not-allowed' 
                                : ''
                            }`}
                          >
                            <Clock className="w-4 h-4" />
                            Editar
                          </Button>
                          {(!ship?.latestProgress || ship.latestProgress.percentage < 100) && (
                            <span className="text-xs text-red-600 mt-1">
                              Requer descarga 100% concluída
                            </span>
                          )}
                        </div>
                      )}
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <span className="text-sm font-medium text-gray-600 block">Primeira Corda</span>
                        <p className="text-gray-900">
                          {undockingData?.firstRopeTime ? 
                            `${new Date(undockingData.firstRopeTime).toLocaleDateString('pt-BR', {
                              day: '2-digit',
                              month: '2-digit',
                              year: 'numeric',
                              timeZone: 'Africa/Maputo'
                            })} ${new Date(undockingData.firstRopeTime).toLocaleTimeString('pt-BR', {
                              hour: '2-digit',
                              minute: '2-digit',
                              timeZone: 'Africa/Maputo'
                            })}` : 
                            "Não registrado"
                          }
                        </p>
                      </div>
                      <div>
                        <span className="text-sm font-medium text-gray-600 block">Última Corda</span>
                        <p className="text-gray-900">
                          {undockingData?.lastRopeTime ? 
                            `${new Date(undockingData.lastRopeTime).toLocaleDateString('pt-BR', {
                              day: '2-digit',
                              month: '2-digit',
                              year: 'numeric',
                              timeZone: 'Africa/Maputo'
                            })} ${new Date(undockingData.lastRopeTime).toLocaleTimeString('pt-BR', {
                              hour: '2-digit',
                              minute: '2-digit',
                              timeZone: 'Africa/Maputo'
                            })}` : 
                            "Não registrado"
                          }
                        </p>
                      </div>
                    </div>
                  </div>

                  {/* Datas Importantes */}
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <h3 className="text-lg font-semibold text-gray-800 mb-3">Datas Importantes</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <span className="text-sm font-medium text-gray-600 block">Chegada na Barra</span>
                        <p className="text-gray-900">
                          {ship?.arrivalDateTime ? 
                            `${new Date(ship.arrivalDateTime).toLocaleDateString('pt-BR', {
                              day: '2-digit',
                              month: '2-digit',
                              year: 'numeric',
                              timeZone: 'Africa/Maputo'
                            })} ${new Date(ship.arrivalDateTime).toLocaleTimeString('pt-BR', {
                              hour: '2-digit',
                              minute: '2-digit',
                              timeZone: 'Africa/Maputo'
                            })}` : 
                            "Data não informada"
                          }
                        </p>
                      </div>
                      <div>
                        <span className="text-sm font-medium text-gray-600 block">Início da Descarga</span>
                        <p className="text-gray-900">
                          {ship?.dischargeStartedAt ? 
                            `${new Date(ship.dischargeStartedAt).toLocaleDateString('pt-BR', {
                              day: '2-digit',
                              month: '2-digit',
                              year: 'numeric',
                              timeZone: 'Africa/Maputo'
                            })} ${new Date(ship.dischargeStartedAt).toLocaleTimeString('pt-BR', {
                              hour: '2-digit',
                              minute: '2-digit',
                              timeZone: 'Africa/Maputo'
                            })}` : 
                            "Data não informada"
                          }
                        </p>
                      </div>
                      <div>
                        <span className="text-sm font-medium text-gray-600 block">Término da Descarga</span>
                        <p className="text-gray-900">
                          {ship?.dischargeCompletedAt ? 
                            `${new Date(ship.dischargeCompletedAt).toLocaleDateString('pt-BR', {
                              day: '2-digit',
                              month: '2-digit',
                              year: 'numeric',
                              timeZone: 'Africa/Maputo'
                            })} ${new Date(ship.dischargeCompletedAt).toLocaleTimeString('pt-BR', {
                              hour: '2-digit',
                              minute: '2-digit',
                              timeZone: 'Africa/Maputo'
                            })}` : 
                            "Data não informada"
                          }
                        </p>
                      </div>
                      {ship?.departedAt && (
                        <div>
                          <span className="text-sm font-medium text-gray-600 block">Data de Partida</span>
                          <p className="text-gray-900">
                            {new Date(ship.departedAt).toLocaleDateString('pt-BR', {
                              day: '2-digit',
                              month: '2-digit',
                              year: 'numeric',
                              timeZone: 'Africa/Maputo'
                            })} {new Date(ship.departedAt).toLocaleTimeString('pt-BR', {
                              hour: '2-digit',
                              minute: '2-digit',
                              timeZone: 'Africa/Maputo'
                            })}
                          </p>
                        </div>
                      )}
                      {ship?.updatedAt && (
                        <div>
                          <span className="text-sm font-medium text-gray-600 block">Última Atualização</span>
                          <p className="text-gray-900">
                            {new Date(ship.updatedAt).toLocaleDateString('pt-BR', {
                              day: '2-digit',
                              month: '2-digit',
                              year: 'numeric',
                              timeZone: 'Africa/Maputo'
                            })} {new Date(ship.updatedAt).toLocaleTimeString('pt-BR', {
                              hour: '2-digit',
                              minute: '2-digit',
                              timeZone: 'Africa/Maputo'
                            })}
                          </p>
                        </div>
                      )}
                      {ship?.createdAt && (
                        <div>
                          <span className="text-sm font-medium text-gray-600 block">Data de Cadastro</span>
                          <p className="text-gray-900">
                            {new Date(ship.createdAt).toLocaleDateString('pt-BR', {
                              day: '2-digit',
                              month: '2-digit',
                              year: 'numeric',
                              timeZone: 'Africa/Maputo'
                            })} {new Date(ship.createdAt).toLocaleTimeString('pt-BR', {
                              hour: '2-digit',
                              minute: '2-digit',
                              timeZone: 'Africa/Maputo'
                            })}
                          </p>
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Histórico Operacional para Navios Desatracados */}
                  {ship?.status === 'departed' && (
                    <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
                      <h3 className="text-lg font-semibold text-blue-800 mb-3">Histórico Operacional Completo</h3>
                      <div className="space-y-3">
                        {ship.arrivalDateTime && (
                          <div className="flex items-center text-sm">
                            <div className="w-3 h-3 bg-blue-500 rounded-full mr-3"></div>
                            <span className="text-gray-600 mr-2">Chegada na Barra:</span>
                            <span className="text-gray-900">{format(new Date(ship.arrivalDateTime), "dd/MM/yyyy HH:mm", { locale: ptBR })}</span>
                          </div>
                        )}
                        
                        {ship.berthingStartedAt && (
                          <div className="flex items-center text-sm">
                            <div className="w-3 h-3 bg-green-500 rounded-full mr-3"></div>
                            <span className="text-gray-600 mr-2">Início da Atracação:</span>
                            <span className="text-gray-900">{format(new Date(ship.berthingStartedAt), "dd/MM/yyyy HH:mm", { locale: ptBR })}</span>
                          </div>
                        )}
                        
                        {ship.departedAt && (
                          <div className="flex items-center text-sm">
                            <div className="w-3 h-3 bg-red-500 rounded-full mr-3"></div>
                            <span className="text-gray-600 mr-2">Desatracação:</span>
                            <span className="text-gray-900">{format(new Date(ship.departedAt), "dd/MM/yyyy HH:mm", { locale: ptBR })}</span>
                          </div>
                        )}
                        
                        {ship.berthingStartedAt && ship.departedAt && (
                          <div className="flex items-center text-sm bg-white p-2 rounded border">
                            <div className="w-3 h-3 bg-purple-500 rounded-full mr-3"></div>
                            <span className="text-gray-600 mr-2">Duração Total no Cais:</span>
                            <span className="text-gray-900 font-medium">
                              {(() => {
                                const start = new Date(ship.berthingStartedAt);
                                const end = new Date(ship.departedAt);
                                const diffMs = end.getTime() - start.getTime();
                                const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
                                const diffMinutes = Math.floor((diffMs % (1000 * 60 * 60)) / (1000 * 60));
                                return `${diffHours}h ${diffMinutes}min`;
                              })()}
                            </span>
                          </div>
                        )}
                      </div>
                    </div>
                  )}

                  {/* Progresso de Descarga */}
                  {ship?.latestProgress && (
                    <div className="bg-gray-50 p-4 rounded-lg">
                      <h3 className="text-lg font-semibold text-gray-800 mb-3">Progresso de Descarga</h3>
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div>
                          <span className="text-sm font-medium text-gray-600 block">Percentual Concluído</span>
                          <div className="flex items-center mt-1">
                            <div className="flex-1 bg-gray-200 rounded-full h-2 mr-2">
                              <div 
                                className="bg-green-600 h-2 rounded-full transition-all duration-300"
                                style={{ width: `${ship.latestProgress.percentage}%` }}
                              ></div>
                            </div>
                            <span className="text-sm font-semibold text-gray-900">
                              {ship.latestProgress.percentage}%
                            </span>
                          </div>
                        </div>
                        <div>
                          <span className="text-sm font-medium text-gray-600 block">Volume Descarregado</span>
                          <p className="text-gray-900">{ship.latestProgress.discharged} MT</p>
                        </div>
                        <div>
                          <span className="text-sm font-medium text-gray-600 block">Volume Restante</span>
                          <p className="text-gray-900">{ship.latestProgress.remaining} MT</p>
                        </div>
                        {ship.latestProgress.recordedAt && (
                          <div className="md:col-span-3">
                            <span className="text-sm font-medium text-gray-600 block">Última Atualização</span>
                            <p className="text-gray-900">
                              {format(new Date(ship.latestProgress.recordedAt), "dd/MM/yyyy HH:mm", { locale: ptBR })}
                            </p>
                          </div>
                        )}
                      </div>
                    </div>
                  )}

                  {/* Volume Total da Carga */}
                  {ship?.parcels && ship.parcels.length > 0 && (
                    <div className="bg-gray-50 p-4 rounded-lg">
                      <h3 className="text-lg font-semibold text-gray-800 mb-3">Resumo da Carga</h3>
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div>
                          <span className="text-sm font-medium text-gray-600 block">Total de Parcelas</span>
                          <p className="text-gray-900">{ship.parcels.length}</p>
                        </div>
                        <div>
                          <span className="text-sm font-medium text-gray-600 block">Volume Total</span>
                          <p className="text-gray-900">
                            {ship.parcels.reduce((total: number, parcel: any) => total + parseFloat(parcel.volumeMT || 0), 0).toFixed(2)} MT
                          </p>
                        </div>
                        <div>
                          <span className="text-sm font-medium text-gray-600 block">Recebedores Únicos</span>
                          <p className="text-gray-900">
                            {new Set(ship.parcels.map((parcel: any) => parcel.receiver)).size}
                          </p>
                        </div>
                      </div>
                    </div>
                  )}
                </TabsContent>

                {/* Tab MOVER - Movement Operations */}
                <TabsContent value="move" className="space-y-6">
                  <div className="bg-gray-50 p-6 rounded-lg">
                    <h3 className="text-lg font-semibold text-gray-800 mb-4">Operações de Movimento do Navio</h3>
                    <p className="text-gray-600 mb-6">
                      Gerencie a movimentação e posicionamento do navio no terminal.
                    </p>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <Button
                        onClick={() => setIsShipMovementOpen(true)}
                        className="bg-blue-600 hover:bg-blue-700 text-white h-16 flex flex-col items-center justify-center gap-2"
                        disabled={!user?.permissions?.includes('move_ships')}
                      >
                        <Ship className="h-6 w-6" />
                        <span>Movimentar Navio</span>
                      </Button>
                      
                      <Button
                        onClick={() => {
                          toast({
                            title: "Em desenvolvimento",
                            description: "Funcionalidade de troca de posição será implementada em breve",
                          });
                        }}
                        variant="outline"
                        className="h-16 flex flex-col items-center justify-center gap-2"
                        disabled={!user?.permissions?.includes('move_ships')}
                      >
                        <Ship className="h-6 w-6" />
                        <span>Trocar Posição</span>
                      </Button>
                    </div>
                    
                    {!user?.permissions?.includes('move_ships') && (
                      <p className="text-sm text-gray-500 mt-4">
                        Você não tem permissão para mover navios. Entre em contato com o administrador.
                      </p>
                    )}
                  </div>
                </TabsContent>

                {/* Tab ATRACAR NAVIO - Berthing Operations */}
                <TabsContent value="berth" className="space-y-6">
                  <div className="bg-gray-50 p-6 rounded-lg">
                    <h3 className="text-lg font-semibold text-gray-800 mb-4">Operações de Atracação</h3>
                    <p className="text-gray-600 mb-6">
                      Registre e gerencie as operações de atracação e desatracação do navio.
                    </p>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <Button
                        onClick={() => setIsBerthingRegistrationOpen(true)}
                        className="bg-green-600 hover:bg-green-700 text-white h-16 flex flex-col items-center justify-center gap-2"
                        disabled={!user?.permissions?.includes('register_undocking')}
                      >
                        <Anchor className="h-6 w-6" />
                        <span>Registrar Atracação</span>
                      </Button>
                      
                      <Button
                        onClick={() => setIsEditUndockingOpen(true)}
                        variant="outline"
                        className="h-16 flex flex-col items-center justify-center gap-2"
                        disabled={!user?.permissions?.includes('register_undocking')}
                      >
                        <Ship className="h-6 w-6" />
                        <span>Registrar Desatracação</span>
                      </Button>
                    </div>
                    
                    {berthingData && (
                      <div className="mt-6 p-4 bg-white rounded border">
                        <h4 className="font-medium text-gray-800 mb-2">Status de Atracação</h4>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                          {berthingData.firstRopeTime && (
                            <div>
                              <span className="font-medium">Primeira Amarra:</span>
                              <p className="text-gray-600">
                                {format(new Date(berthingData.firstRopeTime), "dd/MM/yyyy 'às' HH:mm", { locale: ptBR })}
                              </p>
                            </div>
                          )}
                          {berthingData.lastRopeTime && (
                            <div>
                              <span className="font-medium">Última Amarra:</span>
                              <p className="text-gray-600">
                                {format(new Date(berthingData.lastRopeTime), "dd/MM/yyyy 'às' HH:mm", { locale: ptBR })}
                              </p>
                            </div>
                          )}
                        </div>
                      </div>
                    )}
                    
                    {!user?.permissions?.includes('register_undocking') && (
                      <p className="text-sm text-gray-500 mt-4">
                        Você não tem permissão para registrar operações de atracação. Entre em contato com o administrador.
                      </p>
                    )}
                  </div>
                </TabsContent>

                {/* Tab DOWNLOAD PDF */}
                <TabsContent value="download" className="space-y-6">
                  <div className="bg-gray-50 p-6 rounded-lg">
                    <h3 className="text-lg font-semibold text-gray-800 mb-4">Download de Relatórios</h3>
                    <p className="text-gray-600 mb-6">
                      Gere e baixe relatórios completos sobre o navio e suas operações.
                    </p>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <Button
                        onClick={handleDownloadPDF}
                        className="bg-red-600 hover:bg-red-700 text-white h-16 flex flex-col items-center justify-center gap-2"
                      >
                        <Download className="h-6 w-6" />
                        <span>Baixar PDF Completo</span>
                      </Button>
                      
                      <Button
                        onClick={handlePrint}
                        variant="outline"
                        className="h-16 flex flex-col items-center justify-center gap-2"
                      >
                        <Printer className="h-6 w-6" />
                        <span>Imprimir Relatório</span>
                      </Button>
                    </div>
                    
                    <div className="mt-6 p-4 bg-white rounded border">
                      <h4 className="font-medium text-gray-800 mb-2">Informações do Relatório</h4>
                      <ul className="text-sm text-gray-600 space-y-1">
                        <li>• Dados básicos do navio e agentes</li>
                        <li>• Informações completas de todas as parcelas</li>
                        <li>• Status operacional atual</li>
                        <li>• Histórico de atracação e desatracação</li>
                        <li>• Data e hora de geração do documento</li>
                      </ul>
                    </div>
                  </div>
                </TabsContent>

                {canEdit && ship.status !== 'departed' && (
                  <TabsContent value="edit">
                    <ShipEditForm ship={ship} />
                  </TabsContent>
                )}
              </Tabs>
            </div>
          ) : (
            <div className="p-8 text-center text-gray-500">
              Navio não encontrado
            </div>
          )}
        </div>
      </div>
      
      {/* Edit Berthing Modal */}
      <EditBerthingModal
        isOpen={isEditBerthingOpen}
        onClose={() => {
          console.log("Closing edit berthing modal");
          setIsEditBerthingOpen(false);
          // Refresh berthing data after closing
          queryClient.invalidateQueries({ queryKey: ["/api/ships", ship?.id, "berthing"] });
        }}
        shipId={ship?.id || 0}
        shipName={ship?.name || ''}
        currentBerthing={berthingData ? {
          firstRopeTime: berthingData.firstRopeTime,
          lastRopeTime: berthingData.lastRopeTime,
        } : undefined}
      />

      {/* Edit Undocking Modal */}
      <EditUndockingModal
        isOpen={isEditUndockingOpen}
        onClose={() => {
          setIsEditUndockingOpen(false);
          // Refresh undocking data after closing
          queryClient.invalidateQueries({ queryKey: ["/api/ships", ship?.id, "undocking"] });
        }}
        shipId={ship?.id || 0}
        shipName={ship?.name || ''}
        currentUndocking={undockingData ? {
          firstRopeTime: undockingData.firstRopeTime,
          lastRopeTime: undockingData.lastRopeTime,
        } : undefined}
      />

      {/* Movement Modal */}
      <ShipMovementModal
        isOpen={isShipMovementOpen}
        onClose={() => setIsShipMovementOpen(false)}
      />

      {/* Berthing Registration Modal */}
      <BerthingRegistrationModal
        isOpen={isBerthingRegistrationOpen}
        onClose={() => setIsBerthingRegistrationOpen(false)}
      />

      {/* Discharge Control Modal */}
      <DischargeControlModal
        isOpen={isDischargeControlOpen}
        onClose={() => setIsDischargeControlOpen(false)}
        ship={ship}
      />
    </div>
  );

  return createPortal(modalContent, document.body);
}