import React, { useState } from 'react';
import { Bot } from 'lucide-react';
import { VirtualAssistant } from './virtual-assistant';

interface SimpleAssistantButtonProps {
  user?: any;
  onClick?: () => void;
  className?: string;
}

export function SimpleAssistantButton({ user, onClick, className }: SimpleAssistantButtonProps) {
  return (
    <>
      <style>
        {`
          @keyframes bounce {
            0%, 20%, 50%, 80%, 100% {
              transform: translateY(0);
            }
            40% {
              transform: translateY(-10px);
            }
            60% {
              transform: translateY(-5px);
            }
          }
          .assistant-bounce {
            animation: bounce 2s infinite;
          }
        `}
      </style>
      <div
        onClick={onClick}
        className={className || "fixed bottom-6 right-6 w-16 h-16 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white rounded-full shadow-2xl hover:shadow-3xl transition-all duration-300 cursor-pointer flex items-center justify-center z-50 assistant-bounce"}
      >
        <div className="flex flex-col items-center">
          <Bot className="w-6 h-6" />
        </div>
      </div>
    </>
  );
}