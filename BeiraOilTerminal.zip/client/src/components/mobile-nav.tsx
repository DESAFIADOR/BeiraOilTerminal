import { useState } from "react";
import { Menu, X, Home, Ship, Users, Settings, LogOut } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/contexts/AuthContext";
import { USER_LEVELS, type UserRole } from "@shared/userLevels";

interface MobileNavProps {
  onNavigate?: (path: string) => void;
}

export function MobileNav({ onNavigate }: MobileNavProps) {
  const [isOpen, setIsOpen] = useState(false);
  const { user, isAuthenticated } = useAuth();

  const handleLogout = async () => {
    try {
      await fetch('/api/logout', {
        method: 'POST',
        credentials: 'include'
      });
      window.location.href = '/login';
    } catch (error) {
      console.error('Logout error:', error);
      window.location.href = '/login';
    }
  };

  const menuItems = [
    { 
      icon: Home, 
      label: "Dashboard", 
      path: "/", 
      permission: null 
    },
    { 
      icon: Ship, 
      label: "Navios", 
      path: "/ships", 
      permission: "view_ships" 
    },
    { 
      icon: Users, 
      label: "Usuários", 
      path: "/admin", 
      permission: "manage_users_advanced" 
    },
    { 
      icon: Settings, 
      label: "Configurações", 
      path: "/settings", 
      permission: "system_configuration_basic" 
    },
  ];

  const hasPermission = (permission: string | null) => {
    if (!permission) return true;
    if (!user?.permissions) return false;
    return user.permissions.includes(permission);
  };

  const getUserRoleInfo = () => {
    if (!user?.role) return null;
    return USER_LEVELS[user.role as UserRole];
  };

  const roleInfo = getUserRoleInfo();

  return (
    <>
      {/* Mobile Menu Button */}
      <Button
        variant="ghost"
        size="sm"
        onClick={() => setIsOpen(true)}
        className="md:hidden fixed top-4 right-4 z-50 bg-white shadow-lg"
      >
        <Menu className="w-5 h-5" />
      </Button>

      {/* Mobile Menu Overlay */}
      {isOpen && (
        <div className="fixed inset-0 z-50 md:hidden">
          {/* Backdrop */}
          <div 
            className="absolute inset-0 bg-black/50 backdrop-blur-sm"
            onClick={() => setIsOpen(false)}
          />
          
          {/* Menu Panel */}
          <div className="absolute right-0 top-0 h-full w-80 max-w-[85vw] bg-white shadow-2xl">
            <div className="flex flex-col h-full">
              {/* Header */}
              <div className="p-6 border-b bg-gradient-to-r from-blue-600 to-blue-700">
                <div className="flex items-center justify-between mb-4">
                  <h2 className="text-xl font-bold text-white">Menu</h2>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setIsOpen(false)}
                    className="text-white hover:bg-white/20"
                  >
                    <X className="w-5 h-5" />
                  </Button>
                </div>
                
                {/* User Info */}
                {isAuthenticated && user && (
                  <div className="text-white">
                    <p className="font-medium">{user.firstName || user.username}</p>
                    <p className="text-sm text-blue-100">
                      {roleInfo?.name || user.role}
                    </p>
                    {roleInfo && (
                      <div className="text-xs text-blue-200 mt-1">
                        Nível {roleInfo.hierarchyLevel} • {user.permissions?.length || 0} permissões
                      </div>
                    )}
                  </div>
                )}
              </div>

              {/* Navigation */}
              <nav className="flex-1 p-4">
                <ul className="space-y-2">
                  {menuItems.map((item) => {
                    const Icon = item.icon;
                    const canAccess = hasPermission(item.permission);
                    
                    return (
                      <li key={item.path}>
                        <button
                          onClick={() => {
                            if (canAccess) {
                              onNavigate?.(item.path);
                              setIsOpen(false);
                            }
                          }}
                          disabled={!canAccess}
                          className={`w-full flex items-center space-x-3 p-3 rounded-lg transition-colors ${
                            canAccess
                              ? 'hover:bg-gray-100 text-gray-700 hover:text-gray-900'
                              : 'text-gray-400 cursor-not-allowed'
                          }`}
                        >
                          <Icon className="w-5 h-5" />
                          <span className="font-medium">{item.label}</span>
                          {!canAccess && (
                            <span className="ml-auto text-xs bg-gray-200 px-2 py-1 rounded">
                              Restrito
                            </span>
                          )}
                        </button>
                      </li>
                    );
                  })}
                </ul>
              </nav>

              {/* Footer */}
              <div className="p-4 border-t">
                {isAuthenticated ? (
                  <Button
                    onClick={handleLogout}
                    variant="outline"
                    className="w-full flex items-center justify-center space-x-2"
                  >
                    <LogOut className="w-4 h-4" />
                    <span>Sair</span>
                  </Button>
                ) : (
                  <Button
                    onClick={() => window.location.href = '/login'}
                    className="w-full"
                  >
                    Entrar
                  </Button>
                )}
                
                <div className="text-center mt-4">
                  <p className="text-xs text-gray-500">
                    Terminal da Beira v2.0
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
}