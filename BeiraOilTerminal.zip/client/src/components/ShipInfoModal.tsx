import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";

interface ShipInfoModalProps {
  isOpen: boolean;
  onClose: () => void;
  ship: any;
}

export function ShipInfoModal({ isOpen, onClose, ship }: ShipInfoModalProps) {
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Informações do Navio - {ship?.name}</DialogTitle>
        </DialogHeader>
        <div className="p-4">
          <p>Componente de informações do navio</p>
        </div>
      </DialogContent>
    </Dialog>
  );
}