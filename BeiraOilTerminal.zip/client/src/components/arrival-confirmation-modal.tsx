import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { X } from "lucide-react";

interface ArrivalConfirmationModalProps {
  isOpen: boolean;
  onClose: () => void;
  arrival: any;
  onSuccess: () => void;
}

export function ArrivalConfirmationModal({ 
  isOpen, 
  onClose, 
  arrival, 
  onSuccess 
}: ArrivalConfirmationModalProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const [formData, setFormData] = useState({
    arrivalDate: "",
    arrivalTime: "",
    countermark: ""
  });

  const confirmArrivalMutation = useMutation({
    mutationFn: async (data: any) => {
      const arrivalDateTime = new Date(`${data.arrivalDate}T${data.arrivalTime}`);
      
      return await apiRequest(`/api/agents/predictions/${arrival.id}/confirm`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          arrivalDateTime,
          countermark: data.countermark
        })
      });
    },
    onSuccess: () => {
      toast({
        title: "Sucesso",
        description: "Chegada confirmada com sucesso!",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/agents/predictions'] });
      onSuccess();
      onClose();
      setFormData({
        arrivalDate: "",
        arrivalTime: "",
        countermark: ""
      });
    },
    onError: (error) => {
      toast({
        title: "Erro",
        description: "Falha ao confirmar chegada.",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    confirmArrivalMutation.mutate(formData);
  };

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle className="flex items-center justify-between">
            Confirmar Chegada - {arrival?.shipName}
            <Button
              variant="ghost"
              size="sm"
              onClick={onClose}
              className="h-6 w-6 p-0"
            >
              <X className="h-4 w-4" />
            </Button>
          </DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="arrivalDate">Data de Chegada</Label>
              <Input
                id="arrivalDate"
                type="date"
                value={formData.arrivalDate}
                onChange={(e) => handleInputChange('arrivalDate', e.target.value)}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="arrivalTime">Hora de Chegada</Label>
              <Input
                id="arrivalTime"
                type="time"
                value={formData.arrivalTime}
                onChange={(e) => handleInputChange('arrivalTime', e.target.value)}
                required
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="countermark">Contramarcha</Label>
            <Input
              id="countermark"
              value={formData.countermark}
              onChange={(e) => handleInputChange('countermark', e.target.value)}
              placeholder="Digite a contramarcha do navio"
              required
            />
          </div>

          <div className="flex justify-end space-x-2">
            <Button type="button" variant="outline" onClick={onClose}>
              Cancelar
            </Button>
            <Button 
              type="submit" 
              disabled={confirmArrivalMutation.isPending}
            >
              {confirmArrivalMutation.isPending ? "Confirmando..." : "Confirmar Chegada"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}