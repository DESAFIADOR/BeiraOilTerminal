import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { useQuery } from "@tanstack/react-query";
import { AlertTriangle, Wind, Eye, Thermometer, Droplets, Gauge, Waves, Clock } from "lucide-react";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";

interface WeatherData {
  temperature: number;
  humidity: number;
  pressure: number;
  visibility: number;
  windSpeed: number;
  windDirection: number;
  windGust?: number;
  weatherCondition: string;
  waveHeight?: number;
  seaState?: number;
  alerts: WeatherAlert[];
  lastUpdated: Date;
}

interface WeatherAlert {
  id: number;
  type: string;
  severity: 'low' | 'medium' | 'high' | 'critical';
  title: string;
  description: string;
  windSpeed?: number;
  isActive: boolean;
  triggeredAt: Date;
}

const getWindDirection = (degrees: number): string => {
  const directions = ['N', 'NNE', 'NE', 'ENE', 'E', 'ESE', 'SE', 'SSE', 'S', 'SSW', 'SW', 'WSW', 'W', 'WNW', 'NW', 'NNW'];
  return directions[Math.round(degrees / 22.5) % 16];
};

const getSeaStateDescription = (seaState: number): string => {
  const descriptions = [
    'Calmo',
    'Ondulação leve', 
    'Ondas pequenas',
    'Ondas pequenas',
    'Ondas moderadas',
    'Ondas grandes',
    'Ondas muito grandes',
    'Ondas altas',
    'Ondas muito altas',
    'Ondas fenomenais'
  ];
  return descriptions[seaState] || 'Desconhecido';
};

const getSeverityColor = (severity: string) => {
  switch (severity) {
    case 'critical': return 'bg-red-600 text-white';
    case 'high': return 'bg-red-500 text-white';
    case 'medium': return 'bg-orange-500 text-white';
    case 'low': return 'bg-yellow-500 text-black';
    default: return 'bg-gray-500 text-white';
  }
};

const getWindSpeedColor = (windSpeed: number) => {
  if (windSpeed >= 50) return 'text-red-600 font-bold';
  if (windSpeed >= 40) return 'text-red-500 font-bold';
  if (windSpeed >= 30) return 'text-orange-500 font-semibold';
  if (windSpeed >= 25) return 'text-yellow-600 font-semibold';
  return 'text-green-600';
};

export function WeatherMonitoringCard() {
  const { data: weatherData, isLoading, error, refetch } = useQuery<WeatherData>({
    queryKey: ['/api/weather/current'],
    refetchInterval: 60000, // Update every minute
  });

  const { data: alerts } = useQuery<WeatherAlert[]>({
    queryKey: ['/api/weather/alerts'],
    refetchInterval: 30000, // Check alerts every 30 seconds
  });

  if (isLoading) {
    return (
      <Card className="border-0 shadow-sm">
        <CardHeader className="pb-3">
          <CardTitle className="text-lg font-semibold flex items-center gap-2">
            <Wind className="w-5 h-5 text-blue-600" />
            Monitoramento Meteorológico
          </CardTitle>
        </CardHeader>
        <CardContent className="pt-0">
          <div className="animate-pulse space-y-3">
            <div className="h-4 bg-gray-200 rounded w-3/4"></div>
            <div className="h-4 bg-gray-200 rounded w-1/2"></div>
            <div className="h-4 bg-gray-200 rounded w-2/3"></div>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (error) {
    return (
      <Card className="border-0 shadow-sm">
        <CardHeader className="pb-3">
          <CardTitle className="text-lg font-semibold flex items-center gap-2">
            <Wind className="w-5 h-5 text-red-600" />
            Monitoramento Meteorológico
          </CardTitle>
        </CardHeader>
        <CardContent className="pt-0">
          <Alert className="border-red-200 bg-red-50">
            <AlertTriangle className="w-4 h-4 text-red-600" />
            <AlertDescription className="text-red-700">
              Erro ao carregar dados meteorológicos. Tentando reconectar...
            </AlertDescription>
          </Alert>
        </CardContent>
      </Card>
    );
  }

  const activeAlerts = alerts?.filter(alert => alert.isActive) || weatherData?.alerts || [];
  const highWindAlert = activeAlerts.find(alert => alert.type === 'high_wind');

  return (
    <Card className="border-0 shadow-sm">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg font-semibold flex items-center gap-2">
            <Wind className="w-5 h-5 text-blue-600" />
            Monitoramento Meteorológico
          </CardTitle>
          <div className="flex items-center gap-2 text-xs text-gray-500">
            <Clock className="w-3 h-3" />
            {weatherData && new Date(weatherData.lastUpdated).toLocaleTimeString('pt-BR', {
              hour: '2-digit',
              minute: '2-digit',
              timeZone: 'Africa/Maputo'
            })}
          </div>
        </div>
      </CardHeader>
      
      <CardContent className="pt-0 space-y-4">
        {/* Active Weather Alerts */}
        {activeAlerts.length > 0 && (
          <div className="space-y-2">
            {activeAlerts.map((alert) => (
              <Alert key={alert.id} className="border-red-200 bg-red-50">
                <AlertTriangle className="w-4 h-4 text-red-600" />
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <strong className="text-red-800">{alert.title}</strong>
                    <Badge className={getSeverityColor(alert.severity)} variant="secondary">
                      {alert.severity.toUpperCase()}
                    </Badge>
                  </div>
                  <AlertDescription className="text-red-700 text-sm">
                    {alert.description}
                  </AlertDescription>
                  {alert.windSpeed && (
                    <div className="text-xs text-red-600 mt-1">
                      Vento: {alert.windSpeed.toFixed(1)} nós
                    </div>
                  )}
                </div>
              </Alert>
            ))}
          </div>
        )}

        {/* Wind Information - Primary Focus */}
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-2">
              <Wind className="w-4 h-4 text-blue-600" />
              <span className="font-medium text-blue-800">Condições do Vento</span>
            </div>
            {weatherData && weatherData.windSpeed >= 25 && (
              <Badge className="bg-red-100 text-red-800 border-red-200" variant="outline">
                ⚠️ ALERTA
              </Badge>
            )}
          </div>
          
          {weatherData && (
            <div className="grid grid-cols-2 gap-3 text-sm">
              <div>
                <div className="text-gray-600">Velocidade</div>
                <div className={`text-lg font-bold ${getWindSpeedColor(weatherData.windSpeed)}`}>
                  {weatherData.windSpeed.toFixed(1)} nós
                </div>
              </div>
              <div>
                <div className="text-gray-600">Direção</div>
                <div className="text-lg font-semibold text-gray-700">
                  {getWindDirection(weatherData.windDirection)} ({weatherData.windDirection}°)
                </div>
              </div>
              {weatherData.windGust && (
                <div className="col-span-2">
                  <div className="text-gray-600">Rajadas</div>
                  <div className={`text-base font-semibold ${getWindSpeedColor(weatherData.windGust)}`}>
                    {weatherData.windGust.toFixed(1)} nós
                  </div>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Weather Conditions Grid */}
        {weatherData && (
          <div className="grid grid-cols-2 gap-3 text-sm">
            <div className="flex items-center gap-2">
              <Thermometer className="w-4 h-4 text-orange-500" />
              <div>
                <div className="text-gray-600">Temperatura</div>
                <div className="font-semibold">{weatherData.temperature.toFixed(1)}°C</div>
              </div>
            </div>
            
            <div className="flex items-center gap-2">
              <Droplets className="w-4 h-4 text-blue-500" />
              <div>
                <div className="text-gray-600">Umidade</div>
                <div className="font-semibold">{weatherData.humidity}%</div>
              </div>
            </div>
            
            <div className="flex items-center gap-2">
              <Gauge className="w-4 h-4 text-purple-500" />
              <div>
                <div className="text-gray-600">Pressão</div>
                <div className="font-semibold">{weatherData.pressure.toFixed(1)} hPa</div>
              </div>
            </div>
            
            <div className="flex items-center gap-2">
              <Eye className="w-4 h-4 text-gray-500" />
              <div>
                <div className="text-gray-600">Visibilidade</div>
                <div className="font-semibold">{weatherData.visibility.toFixed(1)} km</div>
              </div>
            </div>
          </div>
        )}

        {/* Sea Conditions */}
        {weatherData && weatherData.seaState !== undefined && (
          <div className="bg-teal-50 border border-teal-200 rounded-lg p-3">
            <div className="flex items-center gap-2 mb-2">
              <Waves className="w-4 h-4 text-teal-600" />
              <span className="font-medium text-teal-800">Estado do Mar</span>
            </div>
            <div className="text-sm">
              <div className="text-gray-600">Condição</div>
              <div className="font-semibold text-teal-700">
                {getSeaStateDescription(weatherData.seaState)} (Escala {weatherData.seaState})
              </div>
              {weatherData.waveHeight && (
                <div className="mt-1">
                  <span className="text-gray-600">Altura das ondas: </span>
                  <span className="font-semibold">{weatherData.waveHeight.toFixed(1)}m</span>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Weather Description */}
        {weatherData && (
          <div className="text-center p-2 bg-gray-50 rounded-lg">
            <div className="text-sm text-gray-600">Condição Atual</div>
            <div className="font-medium text-gray-800 capitalize">
              {weatherData.weatherCondition}
            </div>
          </div>
        )}

        {/* High Wind Alert Information */}
        {weatherData && weatherData.windSpeed >= 20 && (
          <div className="text-xs text-gray-600 bg-yellow-50 border border-yellow-200 rounded p-2">
            <strong>Nota:</strong> Ventos acima de 25 nós podem afetar operações portuárias. 
            Monitore continuamente as condições meteorológicas durante as operações.
          </div>
        )}
      </CardContent>
    </Card>
  );
}