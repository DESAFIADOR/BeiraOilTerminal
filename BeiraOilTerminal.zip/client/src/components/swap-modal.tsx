import { useState, useEffect } from "react";
import { useQueryClient, useMutation, useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { apiRequest } from "@/lib/queryClient";
import { RefreshCw, X } from "lucide-react";

interface SwapOperation {
  id?: number;
  shipId: number;
  swapType: string;
  originalValue: string;
  newValue: string;
  reason: string;
  authorizedBy: string;
  status: string;
}

interface Ship {
  id: number;
  name: string;
  countermark: string;
  status: string;
}

interface SwapModalProps {
  isOpen: boolean;
  onClose: () => void;
  swapOperation?: SwapOperation | null;
}

export function SwapModal({ isOpen, onClose, swapOperation }: SwapModalProps) {
  const queryClient = useQueryClient();
  const [formData, setFormData] = useState<SwapOperation>({
    shipId: 0,
    swapType: "",
    originalValue: "",
    newValue: "",
    reason: "",
    authorizedBy: "",
    status: "pending",
  });

  const { data: ships = [] } = useQuery({
    queryKey: ["/api/ships"],
    enabled: isOpen,
  });

  const createSwapMutation = useMutation({
    mutationFn: async (data: SwapOperation) => {
      return await apiRequest("/api/swap-operations", {
        method: "POST",
        body: JSON.stringify(data),
        headers: { "Content-Type": "application/json" },
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/swap-operations"] });
      onClose();
      resetForm();
    },
  });

  const updateSwapMutation = useMutation({
    mutationFn: async (data: SwapOperation) => {
      return await apiRequest(`/api/swap-operations/${data.id}`, {
        method: "PATCH",
        body: JSON.stringify(data),
        headers: { "Content-Type": "application/json" },
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/swap-operations"] });
      onClose();
      resetForm();
    },
  });

  useEffect(() => {
    if (swapOperation) {
      setFormData(swapOperation);
    } else {
      resetForm();
    }
  }, [swapOperation, isOpen]);

  const resetForm = () => {
    setFormData({
      shipId: 0,
      swapType: "",
      originalValue: "",
      newValue: "",
      reason: "",
      authorizedBy: "",
      status: "pending",
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (swapOperation?.id) {
      updateSwapMutation.mutate(formData);
    } else {
      createSwapMutation.mutate(formData);
    }
  };

  const handleInputChange = (field: keyof SwapOperation, value: string | number) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        <div className="p-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-bold text-gray-800 flex items-center gap-3">
              <RefreshCw className="w-6 h-6 text-purple-500" />
              {swapOperation ? "Editar Operação SWAP" : "Nova Operação SWAP"}
            </h2>
            <Button variant="outline" size="sm" onClick={onClose}>
              <X className="w-4 h-4" />
            </Button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="shipId">Navio</Label>
                <Select 
                  value={formData.shipId.toString()} 
                  onValueChange={(value) => handleInputChange('shipId', parseInt(value))}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Selecionar navio" />
                  </SelectTrigger>
                  <SelectContent>
                    {ships.map((ship: Ship) => (
                      <SelectItem key={ship.id} value={ship.id.toString()}>
                        {ship.name} ({ship.countermark})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="swapType">Tipo de SWAP</Label>
                <Select 
                  value={formData.swapType} 
                  onValueChange={(value) => handleInputChange('swapType', value)}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Selecionar tipo" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="cargo_swap">Troca de Carga</SelectItem>
                    <SelectItem value="berth_swap">Troca de Berço</SelectItem>
                    <SelectItem value="schedule_swap">Troca de Cronograma</SelectItem>
                    <SelectItem value="agent_swap">Troca de Agente</SelectItem>
                    <SelectItem value="priority_swap">Troca de Prioridade</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="originalValue">Valor Original</Label>
                <Input
                  id="originalValue"
                  value={formData.originalValue}
                  onChange={(e) => handleInputChange('originalValue', e.target.value)}
                  placeholder="Ex: Berço 1, Carga A, Agente X"
                  required
                />
              </div>

              <div>
                <Label htmlFor="newValue">Novo Valor</Label>
                <Input
                  id="newValue"
                  value={formData.newValue}
                  onChange={(e) => handleInputChange('newValue', e.target.value)}
                  placeholder="Ex: Berço 2, Carga B, Agente Y"
                  required
                />
              </div>
            </div>

            <div>
              <Label htmlFor="reason">Motivo da Operação SWAP</Label>
              <Textarea
                id="reason"
                value={formData.reason}
                onChange={(e) => handleInputChange('reason', e.target.value)}
                placeholder="Descreva o motivo da necessidade da operação SWAP..."
                rows={3}
                required
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="authorizedBy">Autorizado Por</Label>
                <Input
                  id="authorizedBy"
                  value={formData.authorizedBy}
                  onChange={(e) => handleInputChange('authorizedBy', e.target.value)}
                  placeholder="Nome do responsável"
                  required
                />
              </div>

              <div>
                <Label htmlFor="status">Status</Label>
                <Select 
                  value={formData.status} 
                  onValueChange={(value) => handleInputChange('status', value)}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="pending">Pendente</SelectItem>
                    <SelectItem value="approved">Aprovado</SelectItem>
                    <SelectItem value="completed">Concluído</SelectItem>
                    <SelectItem value="cancelled">Cancelado</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="flex justify-end gap-3 pt-4 border-t">
              <Button type="button" variant="outline" onClick={onClose}>
                Cancelar
              </Button>
              <Button 
                type="submit" 
                disabled={createSwapMutation.isPending || updateSwapMutation.isPending}
                className="bg-purple-600 hover:bg-purple-700"
              >
                {createSwapMutation.isPending || updateSwapMutation.isPending ? (
                  <RefreshCw className="w-4 h-4 animate-spin mr-2" />
                ) : null}
                {swapOperation ? "Atualizar SWAP" : "Criar SWAP"}
              </Button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}