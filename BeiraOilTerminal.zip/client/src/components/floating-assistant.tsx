import React, { useState } from 'react';
import { Bot } from 'lucide-react';
import { VirtualAssistant } from './virtual-assistant';
import { useTranslation } from '@/contexts/LanguageContext';

interface FloatingAssistantProps {
  user?: any;
}

export function FloatingAssistant({ user }: FloatingAssistantProps) {
  const [isOpen, setIsOpen] = useState(false);
  const { t } = useTranslation();

  const buttonStyle = {
    position: 'fixed' as const,
    bottom: '24px',
    right: '24px',
    zIndex: 10000,
    width: '70px',
    height: '70px',
    borderRadius: '50%',
    backgroundColor: '#2563eb',
    color: 'white',
    border: 'none',
    cursor: 'pointer',
    display: 'flex',
    flexDirection: 'column' as const,
    alignItems: 'center',
    justifyContent: 'center',
    boxShadow: '0 10px 25px rgba(0,0,0,0.3)',
    transition: 'all 0.3s ease',
    animation: 'bounce 2s infinite'
  };

  return (
    <>
      <style>
        {`
          @keyframes bounce {
            0%, 20%, 50%, 80%, 100% {
              transform: translateY(0);
            }
            40% {
              transform: translateY(-10px);
            }
            60% {
              transform: translateY(-5px);
            }
          }
        `}
      </style>
      
      <button
        onClick={() => setIsOpen(true)}
        style={buttonStyle}
        onMouseEnter={(e) => {
          e.currentTarget.style.backgroundColor = '#1d4ed8';
          e.currentTarget.style.transform = 'scale(1.1)';
        }}
        onMouseLeave={(e) => {
          e.currentTarget.style.backgroundColor = '#2563eb';
          e.currentTarget.style.transform = 'scale(1)';
        }}
      >
        <Bot size={32} />
        <span style={{ fontSize: '10px', marginTop: '2px' }}>AI</span>
      </button>

      {/* Tooltip */}
      <div
        style={{
          position: 'fixed',
          bottom: '100px',
          right: '24px',
          backgroundColor: 'rgba(0,0,0,0.8)',
          color: 'white',
          padding: '8px 12px',
          borderRadius: '8px',
          fontSize: '12px',
          zIndex: 9999,
          whiteSpace: 'nowrap',
          pointerEvents: 'none'
        }}
      >
        {t("Assistente Virtual") || "Virtual Assistant"}
        <br />
        <span style={{ fontSize: '10px', opacity: 0.7 }}>Chat • Voz • Multilíngue</span>
      </div>

      <VirtualAssistant
        user={user}
        isOpen={isOpen}
        onClose={() => setIsOpen(false)}
      />
    </>
  );
}