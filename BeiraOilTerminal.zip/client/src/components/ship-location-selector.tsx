import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Anchor, Clock } from "lucide-react";

interface ShipLocationSelectorProps {
  isOpen: boolean;
  onClose: () => void;
  onLocationSelected: (location: 'at_bar' | 'expected') => void;
}

export function ShipLocationSelector({ isOpen, onClose, onLocationSelected }: ShipLocationSelectorProps) {
  const [selectedLocation, setSelectedLocation] = useState<'at_bar' | 'expected' | null>(null);

  const handleContinue = () => {
    if (selectedLocation) {
      onLocationSelected(selectedLocation);
    }
  };

  const handleClose = () => {
    setSelectedLocation(null);
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="text-xl font-bold text-blue-600 text-center">
            Localização do Navio
          </DialogTitle>
        </DialogHeader>
        
        <div className="space-y-4 py-4">
          <p className="text-center text-gray-600 mb-6">
            Onde está localizado o navio que deseja registrar?
          </p>
          
          <div className="space-y-3">
            {/* Navio na Barra */}
            <div 
              className={`flex items-center p-4 border-2 rounded-lg cursor-pointer transition-all ${
                selectedLocation === 'at_bar' 
                  ? 'border-blue-500 bg-blue-50' 
                  : 'border-gray-300 hover:border-blue-300 hover:bg-blue-25'
              }`}
              onClick={() => setSelectedLocation('at_bar')}
            >
              <div className="flex items-center justify-center w-12 h-12 bg-blue-100 rounded-full mr-4">
                <Anchor className="w-6 h-6 text-blue-600" />
              </div>
              <div className="flex-1">
                <div className="font-semibold text-blue-600 text-lg">Navio na Barra</div>
                <div className="text-sm text-gray-600">
                  O navio já chegou e está aguardando na barra para atracar
                </div>
              </div>
              <div className="ml-4">
                <input
                  type="radio"
                  name="location"
                  value="at_bar"
                  checked={selectedLocation === 'at_bar'}
                  onChange={() => setSelectedLocation('at_bar')}
                  className="w-5 h-5 text-blue-600"
                />
              </div>
            </div>

            {/* Navio Previsto */}
            <div 
              className={`flex items-center p-4 border-2 rounded-lg cursor-pointer transition-all ${
                selectedLocation === 'expected' 
                  ? 'border-green-500 bg-green-50' 
                  : 'border-gray-300 hover:border-green-300 hover:bg-green-25'
              }`}
              onClick={() => setSelectedLocation('expected')}
            >
              <div className="flex items-center justify-center w-12 h-12 bg-green-100 rounded-full mr-4">
                <Clock className="w-6 h-6 text-green-600" />
              </div>
              <div className="flex-1">
                <div className="font-semibold text-green-600 text-lg">Navio Previsto</div>
                <div className="text-sm text-gray-600">
                  O navio ainda não chegou, mas tem data prevista de chegada
                </div>
              </div>
              <div className="ml-4">
                <input
                  type="radio"
                  name="location"
                  value="expected"
                  checked={selectedLocation === 'expected'}
                  onChange={() => setSelectedLocation('expected')}
                  className="w-5 h-5 text-green-600"
                />
              </div>
            </div>
          </div>

          <div className="flex justify-end space-x-3 pt-6 border-t border-gray-200">
            <Button 
              type="button" 
              onClick={handleClose} 
              variant="outline"
            >
              Cancelar
            </Button>
            <Button 
              onClick={handleContinue}
              disabled={!selectedLocation}
              className="bg-blue-600 hover:bg-blue-700"
            >
              Continuar
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}