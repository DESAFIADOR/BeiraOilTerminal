import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { isUnauthorizedError } from "@/lib/authUtils";
import { Settings, AlertTriangle, CheckCircle } from "lucide-react";

interface BerthMaintenanceModalProps {
  isOpen: boolean;
  onClose: () => void;
}

interface MaintenanceData {
  isUnderMaintenance: boolean;
  maintenancePeriod?: string;
  description?: string;
}

interface MaintenanceStatus {
  isUnderMaintenance: boolean;
  maintenancePeriod?: string;
  description?: string;
}

export function BerthMaintenanceModal({ isOpen, onClose }: BerthMaintenanceModalProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [maintenancePeriod, setMaintenancePeriod] = useState("");
  const [description, setDescription] = useState("");
  const [isUnderMaintenance, setIsUnderMaintenance] = useState(false);

  // Fetch current maintenance status
  const { data: maintenanceStatus, isLoading } = useQuery<MaintenanceStatus>({
    queryKey: ["/api/berth/maintenance"],
    enabled: isOpen,
  });

  // Set maintenance mutation
  const setMaintenanceMutation = useMutation({
    mutationFn: async (data: MaintenanceData) => {
      await apiRequest("/api/berth/maintenance", "POST", data);
    },
    onSuccess: () => {
      toast({
        title: "Sucesso",
        description: isUnderMaintenance 
          ? "Cais colocado em manutenção com sucesso!"
          : "Manutenção do cais finalizada!",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/berth/maintenance"] });
      queryClient.invalidateQueries({ queryKey: ["/api/ships"] });
      onClose();
      resetForm();
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Erro",
        description: "Falha ao atualizar status de manutenção. Tente novamente.",
        variant: "destructive",
      });
    },
  });

  // End maintenance mutation
  const endMaintenanceMutation = useMutation({
    mutationFn: async () => {
      await apiRequest("/api/berth/maintenance/end", "POST", {});
    },
    onSuccess: () => {
      toast({
        title: "Sucesso",
        description: "Manutenção do cais finalizada com sucesso!",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/berth/maintenance"] });
      queryClient.invalidateQueries({ queryKey: ["/api/ships"] });
      onClose();
      resetForm();
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Erro",
        description: "Falha ao finalizar manutenção. Tente novamente.",
        variant: "destructive",
      });
    },
  });

  const resetForm = () => {
    setMaintenancePeriod("");
    setDescription("");
    setIsUnderMaintenance(false);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (isUnderMaintenance && !maintenancePeriod.trim()) {
      toast({
        title: "Erro",
        description: "Por favor, informe o período da manutenção.",
        variant: "destructive",
      });
      return;
    }

    const data: MaintenanceData = {
      isUnderMaintenance,
      maintenancePeriod: isUnderMaintenance ? maintenancePeriod.trim() : undefined,
      description: description.trim() || undefined,
    };

    setMaintenanceMutation.mutate(data);
  };

  const handleEndMaintenance = () => {
    endMaintenanceMutation.mutate();
  };

  const currentlyInMaintenance = maintenanceStatus?.isUnderMaintenance;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Settings className="w-5 h-5 text-orange-600" />
            Manutenção do Cais
          </DialogTitle>
          <DialogDescription>
            Controle o status de manutenção do cais 12 para operações portuárias.
          </DialogDescription>
        </DialogHeader>

        {isLoading ? (
          <div className="text-center py-8">
            <div className="w-8 h-8 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
            <p className="text-gray-600">Carregando status de manutenção...</p>
          </div>
        ) : (
          <div className="space-y-6">
            {/* Current Status */}
            {currentlyInMaintenance && (
              <div className="p-4 bg-orange-50 border border-orange-200 rounded-lg">
                <div className="flex items-center gap-2 mb-2">
                  <AlertTriangle className="w-4 h-4 text-orange-600" />
                  <span className="font-medium text-orange-800">CAIS EM MANUTENÇÃO</span>
                </div>
                {maintenanceStatus?.maintenancePeriod && (
                  <p className="text-sm text-orange-700">
                    Período: {maintenanceStatus.maintenancePeriod}
                  </p>
                )}
                {maintenanceStatus?.description && (
                  <p className="text-sm text-orange-700 mt-1">
                    {maintenanceStatus.description}
                  </p>
                )}
                <Button
                  onClick={handleEndMaintenance}
                  disabled={endMaintenanceMutation.isPending}
                  className="mt-3 bg-green-600 hover:bg-green-700 text-white"
                  size="sm"
                >
                  {endMaintenanceMutation.isPending ? "Finalizando..." : "Finalizar Manutenção"}
                </Button>
              </div>
            )}

            {/* Maintenance Form */}
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="flex items-center justify-between">
                <Label htmlFor="maintenance-switch" className="text-sm font-medium">
                  Colocar cais em manutenção
                </Label>
                <Switch
                  id="maintenance-switch"
                  checked={isUnderMaintenance}
                  onCheckedChange={setIsUnderMaintenance}
                  disabled={currentlyInMaintenance}
                />
              </div>

              {isUnderMaintenance && (
                <>
                  <div>
                    <Label htmlFor="maintenance-period">Período da Manutenção *</Label>
                    <Input
                      id="maintenance-period"
                      placeholder="Ex: 15/06/2025 08:00 - 16/06/2025 18:00"
                      value={maintenancePeriod}
                      onChange={(e) => setMaintenancePeriod(e.target.value)}
                      required
                    />
                  </div>

                  <div>
                    <Label htmlFor="description">Descrição da Manutenção</Label>
                    <Textarea
                      id="description"
                      placeholder="Descreva o tipo de manutenção que será realizada..."
                      value={description}
                      onChange={(e) => setDescription(e.target.value)}
                      rows={3}
                    />
                  </div>
                </>
              )}

              <div className="flex gap-3 pt-4">
                <Button
                  type="button"
                  variant="outline"
                  onClick={onClose}
                  className="flex-1"
                >
                  Cancelar
                </Button>
                <Button
                  type="submit"
                  disabled={setMaintenanceMutation.isPending || currentlyInMaintenance}
                  className="flex-1 bg-orange-600 hover:bg-orange-700"
                >
                  {setMaintenanceMutation.isPending 
                    ? "Atualizando..." 
                    : isUnderMaintenance 
                      ? "Iniciar Manutenção" 
                      : "Confirmar"
                  }
                </Button>
              </div>
            </form>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}