import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Ship, Info, User, Package, MapPin, Clock } from "lucide-react";
import { useTranslation } from "@/contexts/LanguageContext";

interface Ship {
  id: number;
  name: string;
  countermark: string;
  draft: number;
  cargoType: string;
  shipAgent: string;
  cargoAgent: string;
  shipowner: string;
  cargoDestination: string;
  operationType: 'Nacional' | 'Trânsito' | 'Combinado' | 'LPG';
  status: 'expected' | 'at_bar' | 'next_to_berth' | 'at_berth' | 'departed';
  hasDischargeInstructions: boolean;
  berthConfirmed: boolean;
  arrivalAtBar: string;
  shipAgentEmail?: string;
  cargoAgentEmail?: string;
  parcels?: Array<{
    id: number;
    parcelNumber: string;
    product: string;
    volumeMT: number;
    volumeM3: number;
    density: number;
    receiver: string;
    owner: string;
  }>;
}

interface ShipCardProps {
  ship: Ship;
  onClick?: (ship: Ship) => void;
}

export function ShipCard({ ship, onClick }: ShipCardProps) {
  const { t } = useTranslation();

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'expected': return 'bg-yellow-100 text-yellow-800';
      case 'at_bar': return 'bg-blue-100 text-blue-800';
      case 'next_to_berth': return 'bg-orange-100 text-orange-800';
      case 'at_berth': return 'bg-green-100 text-green-800';
      case 'departed': return 'bg-gray-100 text-gray-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getOperationTypeColor = (type: string) => {
    switch (type) {
      case 'Nacional': return 'bg-green-100 text-green-800';
      case 'Trânsito': return 'bg-blue-100 text-blue-800';
      case 'Combinado': return 'bg-purple-100 text-purple-800';
      case 'LPG': return 'bg-orange-100 text-orange-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <Card className="card-hover cursor-pointer" onClick={() => onClick?.(ship)}>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2 text-lg">
            <Ship className="w-5 h-5 text-blue-600" />
            {ship.name}
          </CardTitle>
          <Button variant="ghost" size="sm">
            <Info className="w-4 h-4" />
          </Button>
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          <Badge className={getStatusColor(ship.status)}>
            {ship.status.replace('_', ' ').toUpperCase()}
          </Badge>
          <Badge className={getOperationTypeColor(ship.operationType)}>
            {ship.operationType}
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="grid grid-cols-2 gap-4 text-sm">
          <div className="flex items-center gap-2">
            <Package className="w-4 h-4 text-gray-500" />
            <span className="text-gray-600">Contramarca:</span>
            <span className="font-medium">{ship.countermark}</span>
          </div>
          <div className="flex items-center gap-2">
            <MapPin className="w-4 h-4 text-gray-500" />
            <span className="text-gray-600">Calado:</span>
            <span className="font-medium">{ship.draft}m</span>
          </div>
        </div>
        
        <div className="text-sm">
          <div className="flex items-center gap-2 mb-1">
            <User className="w-4 h-4 text-gray-500" />
            <span className="text-gray-600">Agente:</span>
            <span className="font-medium">{ship.shipAgent}</span>
          </div>
        </div>

        {ship.parcels && ship.parcels.length > 0 && (
          <div className="text-sm">
            <span className="text-gray-600">Parcelas:</span>
            <span className="font-medium ml-1">{ship.parcels.length}</span>
            <span className="text-gray-500 ml-1">
              ({ship.parcels.reduce((sum, p) => sum + p.volumeMT, 0).toLocaleString()} MT)
            </span>
          </div>
        )}

        <div className="flex items-center gap-2 text-xs text-gray-500">
          <Clock className="w-3 h-3" />
          {ship.arrivalAtBar}
        </div>
      </CardContent>
    </Card>
  );
}