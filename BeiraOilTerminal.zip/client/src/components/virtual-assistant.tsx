import React, { useState, useRef, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { 
  MessageCircle, 
  Send, 
  Mic, 
  MicOff, 
  Volume2, 
  VolumeX,
  Bot,
  User,
  X,
  ThumbsUp,
  ThumbsDown,
  Phone,
  Shield
} from 'lucide-react';
import { useTranslation } from '@/contexts/LanguageContext';
import { apiRequest } from '@/lib/queryClient';
import { useMutation, useQuery } from '@tanstack/react-query';
import { GDPRNotice } from './gdpr-notice';
import type { ChatMessage, ChatSession } from '@shared/assistant-types';

interface VirtualAssistantProps {
  user?: any;
  isOpen: boolean;
  onClose: () => void;
}

export function VirtualAssistant({ user, isOpen, onClose }: VirtualAssistantProps) {
  const { t, language } = useTranslation();
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [currentMessage, setCurrentMessage] = useState('');
  const [sessionId, setSessionId] = useState<string | null>(null);
  const [isRecording, setIsRecording] = useState(false);
  const [audioEnabled, setAudioEnabled] = useState(false);
  const [showFeedback, setShowFeedback] = useState(false);
  const [showGDPRNotice, setShowGDPRNotice] = useState(true);
  const [gdprAccepted, setGdprAccepted] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);

  // Create chat session when component opens
  const createSessionMutation = useMutation({
    mutationFn: async () => {
      const userRole = user?.role || 'visitor';
      const response = await apiRequest('/api/gemini-ai/session', 'POST', {
        userRole,
        language
      });
      return response.json();
    },
    onSuccess: (data) => {
      setSessionId(data.sessionId);
    }
  });

  // Send message mutation
  const sendMessageMutation = useMutation({
    mutationFn: async ({ message, sessionId }: { message: string; sessionId: string }) => {
      const userRole = user?.role || 'visitor';
      const response = await apiRequest('/api/gemini-ai/message', 'POST', {
        sessionId,
        message,
        userRole,
        language
      });
      return response.json();
    },
    onSuccess: (data) => {
      const assistantMessage: ChatMessage = {
        id: Date.now().toString(),
        content: data.response,
        role: 'assistant',
        timestamp: new Date(),
      };
      
      setMessages(prev => [...prev, assistantMessage]);
      
      // Show escalation option if needed
      if (data.requiresEscalation) {
        setShowFeedback(true);
      }
      
      // Generate and play audio response if enabled
      if (audioEnabled && data.response) {
        handleTextToSpeech(data.response, language).catch(console.error);
      }
    }
  });

  // End session mutation
  const endSessionMutation = useMutation({
    mutationFn: async ({ sessionId, rating, escalation }: { 
      sessionId: string; 
      rating?: number; 
      escalation?: string 
    }) => {
      const response = await apiRequest('/api/assistant/session/end', 'POST', {
        sessionId,
        satisfactionRating: rating,
        escalationReason: escalation
      });
      return response.json();
    }
  });

  useEffect(() => {
    if (isOpen && !sessionId && gdprAccepted) {
      createSessionMutation.mutate();
    }
  }, [isOpen, gdprAccepted]);

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentMessage.trim() || !sessionId) return;

    const userMessage: ChatMessage = {
      id: Date.now().toString(),
      content: currentMessage,
      role: 'user',
      timestamp: new Date(),
    };

    setMessages(prev => [...prev, userMessage]);
    sendMessageMutation.mutate({ message: currentMessage, sessionId });
    setCurrentMessage('');
  };

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;
      audioChunksRef.current = [];

      mediaRecorder.ondataavailable = (event) => {
        audioChunksRef.current.push(event.data);
      };

      mediaRecorder.onstop = async () => {
        const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/wav' });
        await processVoiceMessage(audioBlob);
        stream.getTracks().forEach(track => track.stop());
      };

      mediaRecorder.start();
      setIsRecording(true);
    } catch (error) {
      console.error('Error starting recording:', error);
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
    }
  };

  const processVoiceMessage = async (audioBlob: Blob) => {
    try {
      // Convert blob to base64
      const reader = new FileReader();
      reader.onloadend = async () => {
        const base64Audio = (reader.result as string).split(',')[1];
        
        // Send to speech-to-text API
        const response = await apiRequest('/api/assistant/speech-to-text', {
          method: 'POST',
          body: { audioData: base64Audio, language }
        });
        
        if (response.transcription) {
          const voiceMessage: ChatMessage = {
            id: Date.now().toString(),
            content: response.transcription,
            role: 'user',
            timestamp: new Date(),
          };
          setMessages(prev => [...prev, voiceMessage]);
          
          // Process the transcribed message
          if (sessionId) {
            sendMessageMutation.mutate({ message: response.transcription, sessionId });
          }
        }
      };
      reader.readAsDataURL(audioBlob);
    } catch (error) {
      console.error('Error processing voice message:', error);
      const fallbackMessage: ChatMessage = {
        id: Date.now().toString(),
        content: t("Erro ao processar áudio") || "Error processing audio",
        role: 'user',
        timestamp: new Date(),
      };
      setMessages(prev => [...prev, fallbackMessage]);
    }
  };

  const playAudioResponse = (audioUrl: string) => {
    const audio = new Audio(audioUrl);
    audio.play().catch(error => console.error('Error playing audio:', error));
  };

  const handleFeedback = (rating: number) => {
    if (sessionId) {
      endSessionMutation.mutate({ sessionId, rating });
      setShowFeedback(false);
    }
  };

  const handleEscalation = () => {
    if (sessionId) {
      endSessionMutation.mutate({ 
        sessionId, 
        escalation: 'User requested human operator' 
      });
      setShowFeedback(false);
      // TODO: Implement actual escalation to human operator
      alert(t("Conectando com operador humano...") || "Connecting to human operator...");
    }
  };

  const handleGDPRAccept = () => {
    setGdprAccepted(true);
    setShowGDPRNotice(false);
    localStorage.setItem('gdpr-accepted', 'true');
  };

  const handleGDPRDecline = () => {
    onClose();
  };

  const handleClose = () => {
    if (sessionId && !endSessionMutation.isPending) {
      endSessionMutation.mutate({ sessionId });
    }
    onClose();
    setMessages([]);
    setSessionId(null);
    setShowFeedback(false);
    setShowGDPRNotice(true);
    setGdprAccepted(false);
  };

  // Check GDPR acceptance on component mount
  useEffect(() => {
    const gdprStatus = localStorage.getItem('gdpr-accepted');
    if (gdprStatus === 'true') {
      setGdprAccepted(true);
      setShowGDPRNotice(false);
    }
  }, []);

  if (!isOpen) return null;

  return (
    <>
      {/* GDPR Notice */}
      <GDPRNotice
        isVisible={showGDPRNotice}
        onAccept={handleGDPRAccept}
        onDecline={handleGDPRDecline}
      />

      {/* Main Assistant Interface */}
      {gdprAccepted && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <Card className="w-full max-w-5xl h-[800px] flex flex-col shadow-2xl">
        <CardHeader className="bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-t-lg">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Bot className="w-7 h-7" />
              <CardTitle className="text-2xl font-bold antialiased" style={{ fontFamily: 'system-ui, -apple-system, sans-serif' }}>
                {t("Assistente Virtual") || "Virtual Assistant"}
              </CardTitle>
              {user && (
                <Badge variant="secondary" className="text-xs">
                  {user.role?.toUpperCase()}
                </Badge>
              )}
              <Badge variant="outline" className="text-xs">
                GDPR Compliant
              </Badge>
            </div>
            <div className="flex items-center gap-2">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setAudioEnabled(!audioEnabled)}
                className="text-white hover:bg-white/20"
              >
                {audioEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
              </Button>
              <Button
                variant="ghost"
                size="sm"
                onClick={handleClose}
                className="text-white hover:bg-white/20"
              >
                <X className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </CardHeader>

        <CardContent className="flex-1 flex flex-col p-0">
          {/* Messages Area */}
          <div className="flex-1 overflow-y-auto p-8 space-y-8">
            {messages.length === 0 && (
              <div className="text-center text-gray-600 py-12">
                <Bot className="w-20 h-20 mx-auto mb-6 text-blue-500" />
                <p className="text-xl font-semibold leading-relaxed antialiased" style={{ fontFamily: 'system-ui, -apple-system, sans-serif' }}>{t("Olá! Sou o assistente virtual do Terminal de Beira. Como posso ajudá-lo?") || 
                     "Hello! I'm the Beira Terminal virtual assistant. How can I help you?"}</p>
              </div>
            )}
            
            {messages.map((message) => (
              <div
                key={message.id}
                className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                <div
                  className={`max-w-[85%] p-6 rounded-lg shadow-sm ${
                    message.role === 'user'
                      ? 'bg-blue-600 text-white'
                      : 'bg-gray-50 text-gray-900 border border-gray-200'
                  }`}
                >
                  <div className="flex items-start gap-4">
                    {message.role === 'assistant' && <Bot className="w-7 h-7 mt-1 flex-shrink-0 text-blue-500" />}
                    {message.role === 'user' && <User className="w-7 h-7 mt-1 flex-shrink-0" />}
                    <div className="flex-1">
                      <p className="text-xl leading-relaxed font-semibold antialiased" style={{ 
                        fontFamily: 'system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif', 
                        fontSize: '20px', 
                        lineHeight: '1.7',
                        fontWeight: '600',
                        letterSpacing: '0.01em',
                        textRendering: 'optimizeLegibility',
                        WebkitFontSmoothing: 'antialiased',
                        MozOsxFontSmoothing: 'grayscale'
                      }}>
                        {message.content}
                      </p>
                      <p className="text-lg opacity-80 mt-4 font-medium" style={{ fontSize: '16px', fontWeight: '500' }}>
                        {new Date(message.timestamp).toLocaleTimeString()}
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            ))}
            
            {sendMessageMutation.isPending && (
              <div className="flex justify-start">
                <div className="bg-gray-100 text-gray-800 p-6 rounded-lg max-w-[85%] border border-gray-200 shadow-sm">
                  <div className="flex items-center gap-4">
                    <Bot className="w-7 h-7 text-blue-500" />
                    <div className="flex items-center gap-2">
                      <span className="text-lg font-medium antialiased" style={{ fontFamily: 'system-ui, -apple-system, sans-serif' }}>Digitando</span>
                      <div className="flex space-x-2">
                        <div className="w-3 h-3 bg-blue-400 rounded-full animate-bounce"></div>
                        <div className="w-3 h-3 bg-blue-400 rounded-full animate-bounce delay-100"></div>
                        <div className="w-3 h-3 bg-blue-400 rounded-full animate-bounce delay-200"></div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}
            
            <div ref={messagesEndRef} />
          </div>

          {/* Feedback Section */}
          {showFeedback && (
            <div className="border-t bg-yellow-50 p-4">
              <div className="flex items-center justify-between mb-2">
                <p className="text-sm text-gray-700">
                  {t("Esta resposta foi útil?") || "Was this response helpful?"}
                </p>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={handleEscalation}
                  className="text-blue-600"
                >
                  <Phone className="w-4 h-4 mr-1" />
                  {t("Falar com Operador") || "Talk to Operator"}
                </Button>
              </div>
              <div className="flex gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => handleFeedback(5)}
                  className="text-green-600"
                >
                  <ThumbsUp className="w-4 h-4 mr-1" />
                  {t("Sim") || "Yes"}
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => handleFeedback(2)}
                  className="text-red-600"
                >
                  <ThumbsDown className="w-4 h-4 mr-1" />
                  {t("Não") || "No"}
                </Button>
              </div>
            </div>
          )}

          {/* Input Area */}
          <div className="border-t p-8 bg-gray-50">
            <form onSubmit={handleSendMessage} className="flex gap-4">
              <div className="flex-1 flex gap-4">
                <Input
                  value={currentMessage}
                  onChange={(e) => setCurrentMessage(e.target.value)}
                  placeholder={t("Digite sua mensagem...") || "Type your message..."}
                  disabled={sendMessageMutation.isPending}
                  className="flex-1 text-xl py-5 px-6 border-2 border-gray-400 focus:border-blue-600 rounded-lg font-semibold antialiased shadow-sm"
                  style={{ 
                    fontFamily: 'system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif', 
                    fontSize: '20px', 
                    minHeight: '64px',
                    fontWeight: '600',
                    letterSpacing: '0.01em',
                    textRendering: 'optimizeLegibility',
                    WebkitFontSmoothing: 'antialiased',
                    MozOsxFontSmoothing: 'grayscale',
                    color: '#1f2937'
                  }}
                />
                <Button
                  type="button"
                  variant="outline"
                  size="lg"
                  onClick={isRecording ? stopRecording : startRecording}
                  className={`p-4 border-2 ${isRecording ? "text-red-600 border-red-300" : "text-gray-600 border-gray-300"}`}
                  style={{ minHeight: '56px', minWidth: '56px' }}
                >
                  {isRecording ? <MicOff className="w-6 h-6" /> : <Mic className="w-6 h-6" />}
                </Button>
              </div>
              <Button
                type="submit"
                disabled={!currentMessage.trim() || sendMessageMutation.isPending}
                className="bg-blue-600 hover:bg-blue-700 px-8 py-4 text-lg font-semibold"
                size="lg"
                style={{ minHeight: '56px' }}
              >
                <Send className="w-6 h-6" />
              </Button>
            </form>
          </div>
        </CardContent>
      </Card>
    </div>
      )}
    </>
  );
}