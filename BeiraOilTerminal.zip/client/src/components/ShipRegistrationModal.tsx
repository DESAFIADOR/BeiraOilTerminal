import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";

interface ShipRegistrationModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
  initialLocation?: 'at_bar' | 'expected' | null;
}

export function ShipRegistrationModal({ isOpen, onClose, onSuccess, initialLocation }: ShipRegistrationModalProps) {
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Registrar Navio</DialogTitle>
        </DialogHeader>
        <div className="p-4">
          <p>Componente de registo de navio</p>
        </div>
      </DialogContent>
    </Dialog>
  );
}