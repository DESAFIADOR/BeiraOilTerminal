import React, { useEffect, useRef, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Waves, Thermometer, RefreshCw } from 'lucide-react';

interface MarineData {
  time: string[];
  wave_height: number[];
  water_temperature: number[];
}

interface TideChartProps {
  isVisible?: boolean;
}

export function TideChart({ isVisible = true }: TideChartProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const chartRef = useRef<any>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [lastUpdate, setLastUpdate] = useState<Date | null>(null);
  const [currentData, setCurrentData] = useState<{
    waveHeight: number;
    waterTemp: number;
  } | null>(null);

  const loadChart = async () => {
    if (!canvasRef.current || !isVisible) return;
    
    // Load Chart.js dynamically
    const Chart = (await import('chart.js/auto')).default;
    
    return Chart;
  };

  const fetchMarineData = async (): Promise<MarineData | null> => {
    try {
      setIsLoading(true);
      const response = await fetch(
        "https://marine-api.open-meteo.com/v1/marine?latitude=-19.84&longitude=34.85&hourly=wave_height,water_temperature&timezone=Africa/Maputo"
      );
      
      if (!response.ok) {
        throw new Error(`API error: ${response.status}`);
      }
      
      const data = await response.json();
      
      if (!data.hourly) {
        throw new Error('Invalid data structure from Open-Meteo API');
      }
      
      return data.hourly;
    } catch (error) {
      console.error('Error fetching marine data:', error);
      return null;
    } finally {
      setIsLoading(false);
    }
  };

  const createChart = async () => {
    const Chart = await loadChart();
    if (!Chart || !canvasRef.current) return;

    const marineData = await fetchMarineData();
    if (!marineData) return;

    // Get current data (latest values)
    const latestIndex = marineData.wave_height.length - 1;
    if (latestIndex >= 0) {
      setCurrentData({
        waveHeight: marineData.wave_height[latestIndex] || 0,
        waterTemp: marineData.water_temperature[latestIndex] || 0
      });
    }

    // Destroy existing chart
    if (chartRef.current) {
      chartRef.current.destroy();
    }

    const ctx = canvasRef.current.getContext('2d');
    if (!ctx) return;

    // Take only next 24 hours of data for better visualization
    const hours24 = marineData.time.slice(0, 24);
    const waves24 = marineData.wave_height.slice(0, 24);
    const temp24 = marineData.water_temperature.slice(0, 24);

    chartRef.current = new Chart(ctx, {
      type: 'line',
      data: {
        labels: hours24.map(time => {
          const date = new Date(time);
          return date.toLocaleTimeString('pt-MZ', { 
            hour: '2-digit', 
            minute: '2-digit',
            timeZone: 'Africa/Maputo'
          });
        }),
        datasets: [
          {
            label: 'Altura da Onda (m)',
            data: waves24,
            borderColor: 'rgb(59, 130, 246)',
            backgroundColor: 'rgba(59, 130, 246, 0.1)',
            borderWidth: 2,
            fill: true,
            tension: 0.4
          },
          {
            label: 'Temperatura da Água (°C)',
            data: temp24,
            borderColor: 'rgb(239, 68, 68)',
            backgroundColor: 'rgba(239, 68, 68, 0.1)',
            borderWidth: 2,
            borderDash: [5, 5],
            fill: false,
            tension: 0.4,
            yAxisID: 'y1'
          }
        ]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        interaction: {
          mode: 'index',
          intersect: false,
        },
        scales: {
          x: {
            title: {
              display: true,
              text: 'Hora (Próximas 24h)',
              font: { weight: 'bold' }
            },
            grid: {
              color: 'rgba(0, 0, 0, 0.1)'
            }
          },
          y: {
            type: 'linear',
            display: true,
            position: 'left',
            title: {
              display: true,
              text: 'Altura da Onda (m)',
              font: { weight: 'bold' }
            },
            beginAtZero: true,
            grid: {
              color: 'rgba(59, 130, 246, 0.1)'
            }
          },
          y1: {
            type: 'linear',
            display: true,
            position: 'right',
            title: {
              display: true,
              text: 'Temperatura (°C)',
              font: { weight: 'bold' }
            },
            grid: {
              drawOnChartArea: false,
            },
          }
        },
        plugins: {
          legend: {
            position: 'bottom' as const,
            labels: {
              usePointStyle: true,
              padding: 20
            }
          },
          tooltip: {
            backgroundColor: 'rgba(0, 0, 0, 0.8)',
            titleColor: 'white',
            bodyColor: 'white',
            borderColor: 'rgba(255, 255, 255, 0.2)',
            borderWidth: 1
          }
        }
      }
    });

    setLastUpdate(new Date());
  };

  useEffect(() => {
    if (isVisible) {
      createChart();
    }
  }, [isVisible]);

  const handleRefresh = () => {
    createChart();
  };

  if (!isVisible) return null;

  return (
    <Card className="w-full">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg font-semibold flex items-center gap-2">
            <Waves className="h-5 w-5 text-blue-600" />
            Monitoramento Marítimo - Porto da Beira
          </CardTitle>
          <Button
            onClick={handleRefresh}
            disabled={isLoading}
            variant="outline"
            size="sm"
            className="flex items-center gap-2"
          >
            <RefreshCw className={`h-4 w-4 ${isLoading ? 'animate-spin' : ''}`} />
            Atualizar
          </Button>
        </div>
        
        {/* Current Conditions */}
        {currentData && (
          <div className="flex gap-4 mt-2">
            <div className="flex items-center gap-2 text-sm">
              <Waves className="h-4 w-4 text-blue-600" />
              <span className="font-medium">Altura atual:</span>
              <span className="text-blue-600 font-bold">{currentData.waveHeight.toFixed(1)}m</span>
            </div>
            <div className="flex items-center gap-2 text-sm">
              <Thermometer className="h-4 w-4 text-red-500" />
              <span className="font-medium">Temperatura:</span>
              <span className="text-red-500 font-bold">{currentData.waterTemp.toFixed(1)}°C</span>
            </div>
          </div>
        )}
        
        {lastUpdate && (
          <p className="text-xs text-gray-500 mt-1">
            Última atualização: {lastUpdate.toLocaleString('pt-MZ', { timeZone: 'Africa/Maputo' })}
          </p>
        )}
      </CardHeader>
      
      <CardContent>
        <div className="h-64 w-full">
          <canvas
            ref={canvasRef}
            className="w-full h-full"
            style={{ maxHeight: '256px' }}
          />
        </div>
        
        {isLoading && (
          <div className="flex items-center justify-center py-4">
            <RefreshCw className="h-5 w-5 animate-spin mr-2" />
            <span className="text-sm text-gray-600">Carregando dados marítimos...</span>
          </div>
        )}
        
        <div className="mt-4 text-xs text-gray-500 border-t pt-2">
          <p><strong>Fonte:</strong> Open-Meteo Marine API</p>
          <p><strong>Localização:</strong> Porto da Beira (-19.84°, 34.85°)</p>
          <p><strong>Fuso Horário:</strong> Africa/Maputo (UTC+2)</p>
        </div>
      </CardContent>
    </Card>
  );
}