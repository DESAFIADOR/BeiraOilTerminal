import React from 'react';
import { useTranslation } from '@/contexts/LanguageContext';

interface LocalizedDateDisplayProps {
  date: Date;
  format?: 'full' | 'short' | 'time' | 'date';
  className?: string;
}

export function LocalizedDateDisplay({ 
  date, 
  format = 'full', 
  className = '' 
}: LocalizedDateDisplayProps) {
  const { language } = useTranslation();
  
  const formatDate = (date: Date, format: string, lang: string): string => {
    const locale = lang === 'en' ? 'en-US' : 'pt-MZ';
    const timeZone = 'Africa/Maputo';
    
    const options: Intl.DateTimeFormatOptions = { timeZone };
    
    switch (format) {
      case 'full':
        return date.toLocaleString(locale, {
          ...options,
          year: 'numeric',
          month: 'long',
          day: 'numeric',
          hour: '2-digit',
          minute: '2-digit'
        });
      case 'short':
        return date.toLocaleString(locale, {
          ...options,
          month: 'short',
          day: 'numeric',
          hour: '2-digit',
          minute: '2-digit'
        });
      case 'time':
        return date.toLocaleTimeString(locale, {
          ...options,
          hour: '2-digit',
          minute: '2-digit'
        });
      case 'date':
        return date.toLocaleDateString(locale, {
          ...options,
          year: 'numeric',
          month: 'long',
          day: 'numeric'
        });
      default:
        return date.toLocaleString(locale, options);
    }
  };

  return (
    <span className={className} title={formatDate(date, 'full', language)}>
      {formatDate(date, format, language)}
    </span>
  );
}

interface LocalizedNumberDisplayProps {
  value: number;
  type?: 'number' | 'currency' | 'percent';
  currency?: string;
  minimumFractionDigits?: number;
  maximumFractionDigits?: number;
  className?: string;
}

export function LocalizedNumberDisplay({ 
  value, 
  type = 'number',
  currency = 'MZN',
  minimumFractionDigits,
  maximumFractionDigits,
  className = '' 
}: LocalizedNumberDisplayProps) {
  const { language } = useTranslation();
  
  const formatNumber = (
    value: number, 
    type: string, 
    lang: string,
    options: any = {}
  ): string => {
    const locale = lang === 'en' ? 'en-US' : 'pt-MZ';
    
    const formatOptions: Intl.NumberFormatOptions = {
      minimumFractionDigits,
      maximumFractionDigits,
      ...options
    };
    
    switch (type) {
      case 'currency':
        formatOptions.style = 'currency';
        formatOptions.currency = currency;
        break;
      case 'percent':
        formatOptions.style = 'percent';
        break;
      default:
        // number format
        break;
    }
    
    return value.toLocaleString(locale, formatOptions);
  };

  return (
    <span className={className}>
      {formatNumber(value, type, language, {
        minimumFractionDigits,
        maximumFractionDigits
      })}
    </span>
  );
}