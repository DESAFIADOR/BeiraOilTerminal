import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Plus, Edit, Anchor, ShipWheel, ArrowUpDown, TrendingUp, BarChart3, Settings } from "lucide-react";

interface QuickActionsProps {
  onRegisterShip: () => void;
  onUpdateDischarge: () => void;
  onRegisterBerthing: () => void;
  onUndockShip: () => void;
  onShipMovement: () => void;
  onAdvancedDischarge: () => void;
  onDischargePlanning: () => void;
  onRatesConfiguration: () => void;
  canUndock: boolean;
  canBerth: boolean;
  hasShipAtBerth: boolean;
  canEdit: boolean;
}

export function QuickActions({ onRegisterShip, onUpdateDischarge, onRegisterBerthing, onUndockShip, onShipMovement, onAdvancedDischarge, onDischargePlanning, onRatesConfiguration, canUndock, canBerth, hasShipAtBerth, canEdit }: QuickActionsProps) {
  // Não mostrar ações rápidas para usuários públicos
  if (!canEdit) {
    return null;
  }

  return (
    <Card className="shadow-sm hover:shadow-md transition-shadow border-0">
      <CardContent className="p-4 sm:p-6">
        <h3 className="text-base sm:text-lg font-semibold text-gray-900 mb-3 sm:mb-4">
          <span className="hidden sm:inline">Ações Rápidas</span>
          <span className="sm:hidden">Ações</span>
        </h3>
        <div className="space-y-2 sm:space-y-3">
          <Button 
            onClick={onRegisterShip}
            className="w-full bg-blue-600 hover:bg-blue-700 text-sm sm:text-base py-2 sm:py-3"
          >
            <Plus className="w-3 h-3 sm:w-4 sm:h-4 mr-1 sm:mr-2" />
            <span className="hidden sm:inline">Registrar Navio</span>
            <span className="sm:hidden">Registrar</span>
          </Button>
          <Button 
            onClick={onRegisterBerthing}
            disabled={!canBerth}
            className={`w-full text-sm sm:text-base py-2 sm:py-3 ${
              canBerth 
                ? 'bg-orange-600 hover:bg-orange-700' 
                : 'bg-gray-400 cursor-not-allowed'
            }`}
            title={
              !canBerth ? "Cais ocupado - atracação não disponível" : "Registrar atracação"
            }
          >
            <Anchor className="w-3 h-3 sm:w-4 sm:h-4 mr-1 sm:mr-2" />
            <span className="hidden sm:inline">Atracação do Navio</span>
            <span className="sm:hidden">Atracação</span>
          </Button>
          <Button 
            onClick={onShipMovement}
            className="w-full bg-purple-600 hover:bg-purple-700 text-sm sm:text-base py-2 sm:py-3"
          >
            <ArrowUpDown className="w-3 h-3 sm:w-4 sm:h-4 mr-1 sm:mr-2" />
            <span className="hidden sm:inline">Movimentação de Navios</span>
            <span className="sm:hidden">Movimentação</span>
          </Button>
          <Button 
            onClick={onUpdateDischarge}
            className="w-full bg-teal-600 hover:bg-teal-700 text-sm sm:text-base py-2 sm:py-3"
          >
            <Edit className="w-3 h-3 sm:w-4 sm:h-4 mr-1 sm:mr-2" />
            <span className="hidden sm:inline">Atualizar Descarga</span>
            <span className="sm:hidden">Descarga</span>
          </Button>
          <Button 
            onClick={onAdvancedDischarge}
            disabled={!hasShipAtBerth}
            className={`w-full text-sm sm:text-base py-2 sm:py-3 ${
              hasShipAtBerth 
                ? 'bg-indigo-600 hover:bg-indigo-700 text-white' 
                : 'bg-gray-300 text-gray-500 cursor-not-allowed'
            }`}
            title={
              !hasShipAtBerth ? "Nenhum navio no cais - controle não disponível" : "Controle avançado de descarga"
            }
          >
            <TrendingUp className="w-3 h-3 sm:w-4 sm:h-4 mr-1 sm:mr-2" />
            <span className="hidden sm:inline">Controle Avançado</span>
            <span className="sm:hidden">Avançado</span>
          </Button>
          <Button 
            onClick={onDischargePlanning}
            className="w-full bg-indigo-600 hover:bg-indigo-700 text-sm sm:text-base py-2 sm:py-3"
          >
            <BarChart3 className="w-3 h-3 sm:w-4 sm:h-4 mr-1 sm:mr-2" />
            <span className="hidden sm:inline">Plano de Descarga</span>
            <span className="sm:hidden">Plano</span>
          </Button>
          <Button 
            onClick={onRatesConfiguration}
            className="w-full bg-yellow-600 hover:bg-yellow-700 text-sm sm:text-base py-2 sm:py-3"
          >
            <Settings className="w-3 h-3 sm:w-4 sm:h-4 mr-1 sm:mr-2" />
            <span className="hidden sm:inline">Configurar Rates</span>
            <span className="sm:hidden">Rates</span>
          </Button>
          <Button 
            onClick={onUndockShip}
            disabled={!canUndock}
            className={`w-full text-sm sm:text-base py-2 sm:py-3 ${
              canUndock 
                ? 'bg-red-600 hover:bg-red-700 text-white' 
                : 'bg-gray-300 text-gray-500 cursor-not-allowed'
            }`}
          >
            <ShipWheel className="w-3 h-3 sm:w-4 sm:h-4 mr-1 sm:mr-2" />
            <span className="hidden sm:inline">Desatracar Navio</span>
            <span className="sm:hidden">Desatracar</span>
          </Button>
          
        </div>
      </CardContent>
    </Card>
  );
}
