import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Play, Square, RotateCcw, Clock, AlertTriangle, Gauge, Droplets } from "lucide-react";
import { OperationalDischargeRecord } from "@shared/schema";

interface OperationalDischargeModalProps {
  isOpen: boolean;
  onClose: () => void;
  shipId: number;
  shipName: string;
}

interface FormData {
  pressure: string;
  dischargeRate: string;
  dischargeStartTime: string;
  dischargeEndTime: string;
  stopStartTime: string;
  stopEndTime: string;
  stopType: string;
  stopComment: string;
  resumeComment: string;
  hasLineDisplacement: boolean;
  lineDisplacementDuration: string;
  parcelId: string;
  operationType: string;
  parcelProgress: Record<number, { 
    discharged: number; 
    percentage: number; 
    startTime?: string; 
    lastUpdate?: string;
    parcelNumber?: string;
    product?: string;
  }>;
}

// Using the type from shared schema
type OperationalRecord = OperationalDischargeRecord;

export function OperationalDischargeModal({ 
  isOpen, 
  onClose, 
  shipId, 
  shipName 
}: OperationalDischargeModalProps) {
  const [activeTab, setActiveTab] = useState("start");
  const [formData, setFormData] = useState<FormData>({
    pressure: "",
    dischargeRate: "",
    dischargeStartTime: "",
    dischargeEndTime: "",
    stopStartTime: "",
    stopEndTime: "",
    stopType: "",
    stopComment: "",
    resumeComment: "",
    hasLineDisplacement: false,
    lineDisplacementDuration: "",
    parcelId: "",
    operationType: "start",
    parcelProgress: {} as Record<number, { 
      discharged: number; 
      percentage: number; 
      startTime?: string; 
      lastUpdate?: string;
      parcelNumber?: string;
      product?: string;
    }>
  });

  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Buscar parcelas do navio
  const { data: ship = { parcels: [] } } = useQuery<{ parcels: any[] }>({
    queryKey: [`/api/ships/${shipId}`],
    enabled: isOpen
  });

  // Buscar registros operacionais existentes
  const { data: operationalRecords = [], refetch: refetchRecords } = useQuery<OperationalRecord[]>({
    queryKey: [`/api/ships/${shipId}/operational-discharge`],
    enabled: isOpen
  });

  // Buscar último registro operacional
  const { data: latestRecord } = useQuery({
    queryKey: [`/api/ships/${shipId}/latest-operational-discharge`],
    enabled: isOpen
  });

  const createRecordMutation = useMutation({
    mutationFn: async (data: any) => {
      return await apiRequest(`/api/ships/${shipId}/operational-discharge`, 'POST', data);
    },
    onSuccess: () => {
      toast({
        title: "Sucesso",
        description: "Registro operacional criado com sucesso",
      });
      refetchRecords();
      queryClient.invalidateQueries({ queryKey: [`/api/ships/${shipId}`] });
      setFormData({
        pressure: "",
        dischargeRate: "",
        dischargeStartTime: "",
        dischargeEndTime: "",
        stopStartTime: "",
        stopEndTime: "",
        stopType: "",
        stopComment: "",
        resumeComment: "",
        hasLineDisplacement: false,
        lineDisplacementDuration: "",
        parcelId: "",
        operationType: "start",
        parcelProgress: {} as Record<number, { discharged: number; percentage: number }>
      });
    },
    onError: (error: any) => {
      toast({
        title: "Erro",
        description: error.message || "Erro ao criar registro operacional",
        variant: "destructive",
      });
    }
  });

  const handleSubmit = () => {
    const now = new Date().toISOString();
    
    let submitData: any = {
      operationType: formData.operationType,
      parcelId: formData.parcelId === 'all' ? null : (formData.parcelId ? parseInt(formData.parcelId) : null)
    };

    switch (formData.operationType) {
      case "start":
        submitData = {
          ...submitData,
          pressure: formData.pressure ? parseFloat(formData.pressure) : null,
          dischargeRate: formData.dischargeRate ? parseFloat(formData.dischargeRate) : null,
          dischargeStartTime: formData.dischargeStartTime || now,
          hasLineDisplacement: formData.hasLineDisplacement,
          lineDisplacementDuration: formData.lineDisplacementDuration ? parseFloat(formData.lineDisplacementDuration) : null
        };
        break;
      case "stop":
        submitData = {
          ...submitData,
          stopStartTime: formData.stopStartTime || now,
          stopType: formData.stopType,
          stopComment: formData.stopComment
        };
        break;
      case "resume":
        submitData = {
          ...submitData,
          stopEndTime: formData.stopEndTime || now,
          resumeComment: formData.resumeComment,
          pressure: formData.pressure ? parseFloat(formData.pressure) : null,
          dischargeRate: formData.dischargeRate ? parseFloat(formData.dischargeRate) : null
        };
        break;
      case "end":
        submitData = {
          ...submitData,
          dischargeEndTime: formData.dischargeEndTime || now
        };
        break;
      case "hourly_update":
        submitData = {
          ...submitData,
          pressure: formData.pressure ? parseFloat(formData.pressure) : null,
          dischargeRate: formData.dischargeRate ? parseFloat(formData.dischargeRate) : null
        };
        break;
    }

    createRecordMutation.mutate(submitData);
  };

  const getCurrentDateTime = () => {
    const now = new Date();
    const utcPlus2 = new Date(now.getTime() + (2 * 60 * 60 * 1000));
    return utcPlus2.toISOString().slice(0, 16);
  };

  const formatDateTime = (dateInput: string | Date) => {
    if (!dateInput) return "-";
    const date = typeof dateInput === 'string' ? new Date(dateInput) : dateInput;
    return date.toLocaleString('pt-BR', {
      timeZone: 'Africa/Maputo',
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  useEffect(() => {
    if (isOpen) {
      setFormData(prev => ({
        ...prev,
        operationType: activeTab
      }));
    }
  }, [activeTab, isOpen]);

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Gauge className="w-5 h-5 text-blue-600" />
            Controlo Operacional de Descarga - {shipName}
          </DialogTitle>
          <DialogDescription>
            Registe dados operacionais de descarga incluindo pressão, taxa de descarga, e eventos operacionais
          </DialogDescription>
        </DialogHeader>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Formulário Principal */}
          <div className="lg:col-span-2">
            <Tabs value={activeTab} onValueChange={setActiveTab}>
              <TabsList className="grid w-full grid-cols-5">
                <TabsTrigger value="start" className="flex items-center gap-1">
                  <Play className="w-3 h-3" />
                  Início
                </TabsTrigger>
                <TabsTrigger value="stop" className="flex items-center gap-1">
                  <Square className="w-3 h-3" />
                  Parar
                </TabsTrigger>
                <TabsTrigger value="resume" className="flex items-center gap-1">
                  <RotateCcw className="w-3 h-3" />
                  Retomar
                </TabsTrigger>
                <TabsTrigger value="hourly_update" className="flex items-center gap-1">
                  <Clock className="w-3 h-3" />
                  Update
                </TabsTrigger>
                <TabsTrigger value="end" className="flex items-center gap-1">
                  <AlertTriangle className="w-3 h-3" />
                  Fim
                </TabsTrigger>
              </TabsList>

              <div className="mt-4 space-y-4">
                {/* Seleção de Parcela */}
                <div>
                  <Label htmlFor="parcelId">Parcela</Label>
                  <Select value={formData.parcelId} onValueChange={(value) => setFormData(prev => ({ ...prev, parcelId: value }))}>
                    <SelectTrigger>
                      <SelectValue placeholder="Selecionar parcela" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Todas as parcelas</SelectItem>
                      {ship?.parcels?.map((parcel: any) => (
                        <SelectItem key={parcel.id} value={parcel.id.toString()}>
                          {parcel.parcelNumber} - {parcel.product} ({parcel.volumeMT} MT)
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <TabsContent value="start" className="space-y-4">
                  <div>
                    <Label htmlFor="parcelId">Parcela</Label>
                    <Select value={formData.parcelId} onValueChange={(value) => setFormData(prev => ({ ...prev, parcelId: value }))}>
                      <SelectTrigger>
                        <SelectValue placeholder="Selecionar parcela" />
                      </SelectTrigger>
                      <SelectContent>
                        {ship?.parcels?.map((parcel: any) => (
                          <SelectItem key={parcel.id} value={parcel.id.toString()}>
                            {parcel.parcelNumber} - {parcel.product} ({parcel.volumeMT} MT)
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="dischargeStartTime">Hora de Início</Label>
                    <Input
                      id="dischargeStartTime"
                      type="datetime-local"
                      value={formData.dischargeStartTime || getCurrentDateTime()}
                      onChange={(e) => setFormData(prev => ({ ...prev, dischargeStartTime: e.target.value }))}
                    />
                  </div>
                  
                </TabsContent>

                <TabsContent value="stop" className="space-y-4">
                  <div>
                    <Label htmlFor="parcelId">Parcela</Label>
                    <Select value={formData.parcelId} onValueChange={(value) => setFormData(prev => ({ ...prev, parcelId: value }))}>
                      <SelectTrigger>
                        <SelectValue placeholder="Selecionar parcela" />
                      </SelectTrigger>
                      <SelectContent>
                        {ship?.parcels?.map((parcel: any) => (
                          <SelectItem key={parcel.id} value={parcel.id.toString()}>
                            {parcel.parcelNumber} - {parcel.product} ({parcel.volumeMT} MT)
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="stopStartTime">Hora da Parada</Label>
                    <Input
                      id="stopStartTime"
                      type="datetime-local"
                      value={formData.stopStartTime || getCurrentDateTime()}
                      onChange={(e) => setFormData(prev => ({ ...prev, stopStartTime: e.target.value }))}
                    />
                  </div>
                  <div>
                    <Label htmlFor="stopType">Tipo de Parada</Label>
                    <Select value={formData.stopType} onValueChange={(value) => setFormData(prev => ({ ...prev, stopType: value }))}>
                      <SelectTrigger>
                        <SelectValue placeholder="Selecionar tipo" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="line_displacement">Line Displacement</SelectItem>
                        <SelectItem value="parcel_change">Mudança de Parcela</SelectItem>
                        <SelectItem value="maintenance">Manutenção</SelectItem>
                        <SelectItem value="weather">Condições Meteorológicas</SelectItem>
                        <SelectItem value="other">Outro</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="stopComment">Comentário da Parada</Label>
                    <Textarea
                      id="stopComment"
                      value={formData.stopComment}
                      onChange={(e) => setFormData(prev => ({ ...prev, stopComment: e.target.value }))}
                      placeholder="Descrever motivo da parada..."
                      rows={3}
                    />
                  </div>
                </TabsContent>

                <TabsContent value="resume" className="space-y-4">
                  <div>
                    <Label htmlFor="parcelId">Parcela</Label>
                    <Select value={formData.parcelId} onValueChange={(value) => setFormData(prev => ({ ...prev, parcelId: value }))}>
                      <SelectTrigger>
                        <SelectValue placeholder="Selecionar parcela" />
                      </SelectTrigger>
                      <SelectContent>
                        {ship?.parcels?.map((parcel: any) => (
                          <SelectItem key={parcel.id} value={parcel.id.toString()}>
                            {parcel.parcelNumber} - {parcel.product} ({parcel.volumeMT} MT)
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="stopEndTime">Hora da Retoma</Label>
                    <Input
                      id="stopEndTime"
                      type="datetime-local"
                      value={formData.stopEndTime || getCurrentDateTime()}
                      onChange={(e) => setFormData(prev => ({ ...prev, stopEndTime: e.target.value }))}
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="resumeComment">Comentário da Retoma</Label>
                    <Textarea
                      id="resumeComment"
                      value={formData.resumeComment}
                      onChange={(e) => setFormData(prev => ({ ...prev, resumeComment: e.target.value }))}
                      placeholder="Descrever condições da retoma..."
                      rows={3}
                    />
                  </div>
                </TabsContent>

                <TabsContent value="hourly_update" className="space-y-4">
                  {/* Progresso de Descarga por Parcela */}
                  <div className="space-y-4">
                    <h4 className="font-medium text-gray-800">Progresso de Descarga por Parcela</h4>
                    {ship?.parcels?.map((parcel: any) => (
                      <div key={parcel.id} className="border border-gray-200 rounded-lg p-3">
                        <div className="flex justify-between items-center mb-2">
                          <span className="font-medium text-sm">
                            {parcel.parcelNumber} - {parcel.product}
                          </span>
                          <span className="text-xs text-gray-500">
                            {parcel.volumeMT} MT total
                          </span>
                        </div>
                        {formData.parcelProgress?.[parcel.id] && (
                          <div className="mb-2 p-2 bg-blue-50 rounded text-xs">
                            <div className="flex justify-between">
                              <span className="text-blue-700">
                                Início: {(() => {
                                  const startTime = formData.parcelProgress[parcel.id].startTime;
                                  if (!startTime) return 'N/A';
                                  try {
                                    return new Date(startTime).toLocaleString('pt-PT', {
                                      timeZone: 'Africa/Maputo',
                                      day: '2-digit',
                                      month: '2-digit',
                                      year: 'numeric',
                                      hour: '2-digit',
                                      minute: '2-digit'
                                    });
                                  } catch {
                                    return 'N/A';
                                  }
                                })()}
                              </span>
                              <span className="text-blue-600">
                                Última actualização: {(() => {
                                  const lastUpdate = formData.parcelProgress[parcel.id].lastUpdate;
                                  if (!lastUpdate) return 'N/A';
                                  try {
                                    return new Date(lastUpdate).toLocaleString('pt-PT', {
                                      timeZone: 'Africa/Maputo',
                                      hour: '2-digit',
                                      minute: '2-digit'
                                    });
                                  } catch {
                                    return 'N/A';
                                  }
                                })()}
                              </span>
                            </div>
                          </div>
                        )}
                        <div className="grid grid-cols-2 gap-2">
                          <div>
                            <Label htmlFor={`discharged-${parcel.id}`} className="text-xs">
                              Descarregado (MT)
                            </Label>
                            <Input
                              id={`discharged-${parcel.id}`}
                              type="number"
                              step="0.1"
                              placeholder="0.0"
                              className="h-8 text-sm"
                              value={formData.parcelProgress?.[parcel.id]?.discharged || ''}
                              onChange={(e) => {
                                const value = parseFloat(e.target.value) || 0;
                                const percentage = Math.min((value / parcel.volumeMT) * 100, 100);
                                const currentTime = getCurrentDateTime();
                                setFormData(prev => ({
                                  ...prev,
                                  parcelProgress: {
                                    ...prev.parcelProgress,
                                    [parcel.id]: {
                                      discharged: value,
                                      percentage: percentage,
                                      startTime: prev.parcelProgress?.[parcel.id]?.startTime || currentTime,
                                      lastUpdate: currentTime,
                                      parcelNumber: parcel.parcelNumber,
                                      product: parcel.product
                                    }
                                  }
                                }));
                              }}
                            />
                          </div>
                          <div>
                            <Label className="text-xs">Progresso (%)</Label>
                            <div className="h-8 flex items-center text-sm font-medium text-blue-600">
                              {(() => {
                                const percentage = formData.parcelProgress?.[parcel.id]?.percentage || 0;
                                return typeof percentage === 'number' ? percentage.toFixed(1) : '0.0';
                              })()}%
                            </div>
                          </div>
                        </div>
                        <div className="mt-2 bg-gray-200 rounded-full h-2">
                          <div 
                            className="bg-blue-600 h-2 rounded-full transition-all duration-300"
                            style={{ 
                              width: `${(() => {
                                const percentage = formData.parcelProgress?.[parcel.id]?.percentage || 0;
                                return typeof percentage === 'number' ? Math.min(percentage, 100) : 0;
                              })()}%` 
                            }}
                          />
                        </div>
                      </div>
                    ))}
                  </div>

                  {/* Progresso Global */}
                  <div className="border-t pt-4">
                    <h4 className="font-medium text-gray-800 mb-3">Progresso Global do Navio</h4>
                    <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                      <div className="grid grid-cols-3 gap-4 text-center">
                        <div>
                          <div className="text-lg font-bold text-blue-800">
                            {(() => {
                              const totalDischarged = Object.values(formData.parcelProgress || {})
                                .reduce((sum: number, progress: any) => sum + (parseFloat(progress?.discharged) || 0), 0);
                              return typeof totalDischarged === 'number' ? totalDischarged.toFixed(1) : '0.0';
                            })()} MT
                          </div>
                          <div className="text-xs text-blue-600">Total Descarregado</div>
                        </div>
                        <div>
                          <div className="text-lg font-bold text-gray-700">
                            {(() => {
                              const total = ship?.parcels?.reduce((sum: number, p: any) => sum + (parseFloat(p.volumeMT) || 0), 0) || 0;
                              return typeof total === 'number' ? total.toFixed(1) : '0.0';
                            })()} MT
                          </div>
                          <div className="text-xs text-gray-600">Carga Total</div>
                        </div>
                        <div>
                          <div className="text-lg font-bold text-green-600">
                            {(() => {
                              const totalCargo = ship?.parcels?.reduce((sum: number, p: any) => sum + (parseFloat(p.volumeMT) || 0), 0) || 0;
                              const totalDischarged = Object.values(formData.parcelProgress || {})
                                .reduce((sum: number, progress: any) => sum + (parseFloat(progress?.discharged) || 0), 0);
                              const percentage = totalCargo > 0 ? ((totalDischarged / totalCargo) * 100) : 0;
                              return typeof percentage === 'number' ? percentage.toFixed(1) : '0.0';
                            })()}%
                          </div>
                          <div className="text-xs text-green-600">Progresso Global</div>
                        </div>
                      </div>
                      <div className="mt-3 bg-gray-200 rounded-full h-3">
                        <div 
                          className="bg-gradient-to-r from-blue-500 to-green-500 h-3 rounded-full transition-all duration-300"
                          style={{ 
                            width: `${(() => {
                              const totalCargo = ship?.parcels?.reduce((sum: number, p: any) => sum + (parseFloat(p.volumeMT) || 0), 0) || 0;
                              const totalDischarged = Object.values(formData.parcelProgress || {})
                                .reduce((sum: number, progress: any) => sum + (parseFloat(progress?.discharged) || 0), 0);
                              const percentage = totalCargo > 0 ? (totalDischarged / totalCargo) * 100 : 0;
                              return typeof percentage === 'number' ? Math.min(percentage, 100) : 0;
                            })()}%` 
                          }}
                        />
                      </div>
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="pressure">Pressão Atual (bar)</Label>
                      <Input
                        id="pressure"
                        type="number"
                        step="0.1"
                        value={formData.pressure}
                        onChange={(e) => setFormData(prev => ({ ...prev, pressure: e.target.value }))}
                        placeholder="0.0"
                      />
                    </div>
                    <div>
                      <Label htmlFor="dischargeRate">Taxa Atual (m³/h)</Label>
                      <Input
                        id="dischargeRate"
                        type="number"
                        step="0.1"
                        value={formData.dischargeRate}
                        onChange={(e) => setFormData(prev => ({ ...prev, dischargeRate: e.target.value }))}
                        placeholder="0.0"
                      />
                    </div>
                  </div>
                  <div className="p-4 bg-blue-50 rounded-lg">
                    <p className="text-sm text-blue-800 font-medium">
                      Actualizações de hora em hora para controlo contínuo
                    </p>
                    <p className="text-xs text-blue-600 mt-1">
                      Registar pressão e taxa actuais para cálculo preciso de previsão
                    </p>
                  </div>
                </TabsContent>

                <TabsContent value="end" className="space-y-4">
                  <div>
                    <Label htmlFor="parcelId">Parcela</Label>
                    <Select value={formData.parcelId} onValueChange={(value) => setFormData(prev => ({ ...prev, parcelId: value }))}>
                      <SelectTrigger>
                        <SelectValue placeholder="Selecionar parcela" />
                      </SelectTrigger>
                      <SelectContent>
                        {ship?.parcels?.map((parcel: any) => (
                          <SelectItem key={parcel.id} value={parcel.id.toString()}>
                            {parcel.parcelNumber} - {parcel.product} ({parcel.volumeMT} MT)
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="dischargeEndTime">Hora de Término</Label>
                    <Input
                      id="dischargeEndTime"
                      type="datetime-local"
                      value={formData.dischargeEndTime || getCurrentDateTime()}
                      onChange={(e) => setFormData(prev => ({ ...prev, dischargeEndTime: e.target.value }))}
                    />
                  </div>
                  <div className="p-4 bg-red-50 rounded-lg border border-red-200">
                    <p className="text-sm text-red-800 font-medium">
                      Finalizar descarga da parcela/navio
                    </p>
                    <p className="text-xs text-red-600 mt-1">
                      Esta acção marca o fim completo da operação de descarga
                    </p>
                  </div>
                </TabsContent>

                <div className="flex gap-2 pt-4">
                  <Button 
                    onClick={handleSubmit} 
                    disabled={createRecordMutation.isPending}
                    className="flex-1"
                  >
                    {createRecordMutation.isPending ? "Registando..." : "Registar"}
                  </Button>
                  <Button variant="outline" onClick={onClose}>
                    Fechar
                  </Button>
                </div>
              </div>
            </Tabs>
          </div>

          {/* Histórico de Registros */}
          <div>
            <Card>
              <CardHeader>
                <CardTitle className="text-sm flex items-center gap-2">
                  <Droplets className="w-4 h-4" />
                  Histórico Operacional
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2 max-h-96 overflow-y-auto">
                {operationalRecords.length === 0 ? (
                  <p className="text-sm text-gray-500 text-center py-4">
                    Nenhum registro operacional
                  </p>
                ) : (
                  operationalRecords.slice(0, 10).map((record: OperationalRecord) => (
                    <div key={record.id} className="p-3 bg-gray-50 rounded-lg text-xs border-l-4 border-blue-400">
                      <div className="flex justify-between items-start mb-2">
                        <div className="flex flex-col">
                          <span className="font-medium capitalize text-blue-800">
                            {(() => {
                              switch(record.operationType) {
                                case 'start': return '🟢 Início da Descarga';
                                case 'stop': return '🔴 Parada da Descarga';
                                case 'resume': return '🟡 Retoma da Descarga';
                                case 'end': return '⚫ Fim da Descarga';
                                case 'hourly_update': return '📊 Actualização Horária';
                                default: return record.operationType.replace('_', ' ');
                              }
                            })()}
                          </span>
                          {record.parcelId && (
                            <div className="text-xs text-purple-600 font-medium mt-1 space-y-1">
                              <div className="flex items-center gap-1">
                                📦 <span>{(() => {
                                  const parcel = ship?.parcels?.find((p: any) => p.id === record.parcelId);
                                  if (!parcel) return `Parcela ID ${record.parcelId}`;
                                  return `${parcel.parcelNumber} - ${parcel.product}`;
                                })()}</span>
                              </div>
                              {(() => {
                                const parcel = ship?.parcels?.find((p: any) => p.id === record.parcelId);
                                if (!parcel) return null;
                                return (
                                  <div className="ml-4 space-y-1 text-purple-500">
                                    <div className="flex items-center gap-1">
                                      📊 <span>{parcel.volumeMT} MT ({parcel.volumeM3} m³)</span>
                                    </div>
                                    <div className="flex items-center gap-1">
                                      🏢 <span>Recebedor: {parcel.receiver}</span>
                                    </div>
                                    {parcel.parcelOwner && (
                                      <div className="flex items-center gap-1">
                                        👤 <span>Dono: {parcel.parcelOwner}</span>
                                      </div>
                                    )}
                                    {parcel.density && (
                                      <div className="flex items-center gap-1">
                                        ⚖️ <span>Densidade: {parcel.density} kg/m³</span>
                                      </div>
                                    )}
                                  </div>
                                );
                              })()}
                            </div>
                          )}
                        </div>
                        <span className="text-gray-500 font-mono text-xs">
                          {record.recordedAt ? formatDateTime(record.recordedAt.toString()) : 'N/A'}
                        </span>
                      </div>
                      
                      {/* Operational Details */}
                      <div className="space-y-1">
                        {record.pressure && (
                          <div className="text-gray-700 flex items-center gap-1">
                            <span className="font-medium">Pressão:</span> {record.pressure} bar
                          </div>
                        )}
                        {record.dischargeRate && (
                          <div className="text-gray-700 flex items-center gap-1">
                            <span className="font-medium">Taxa:</span> {record.dischargeRate} m³/h
                          </div>
                        )}
                        
                        {/* Stop Reasons */}
                        {record.operationType === 'stop' && record.stopType && (
                          <div className="text-red-700 bg-red-50 p-2 rounded mt-2">
                            <div className="font-medium">Motivo da Parada:</div>
                            <div>{(() => {
                              switch(record.stopType) {
                                case 'line_displacement': return '🔧 Line Displacement';
                                case 'parcel_change': return '📦 Mudança de Parcela';
                                case 'maintenance': return '⚙️ Manutenção';
                                case 'weather': return '🌧️ Condições Meteorológicas';
                                case 'other': return '❓ Outro';
                                default: return record.stopType;
                              }
                            })()}</div>
                            {record.stopComment && (
                              <div className="mt-1 italic">"{record.stopComment}"</div>
                            )}
                          </div>
                        )}
                        
                        {/* Resume Reasons */}
                        {record.operationType === 'resume' && record.resumeComment && (
                          <div className="text-green-700 bg-green-50 p-2 rounded mt-2">
                            <div className="font-medium">Retoma da Operação:</div>
                            <div className="italic">"{record.resumeComment}"</div>
                          </div>
                        )}
                        
                        {/* Start Information */}
                        {record.operationType === 'start' && (
                          <div className="text-green-700 bg-green-50 p-2 rounded mt-2">
                            <div className="font-medium">Início da Descarga</div>
                            {record.hasLineDisplacement && (
                              <div className="text-sm">
                                📍 Line Displacement programado: {record.lineDisplacementDuration}h
                              </div>
                            )}
                          </div>
                        )}
                        
                        {/* End Information */}
                        {record.operationType === 'end' && (
                          <div className="text-gray-700 bg-gray-100 p-2 rounded mt-2">
                            <div className="font-medium">✅ Descarga Concluída</div>
                          </div>
                        )}
                      </div>
                    </div>
                  ))
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}