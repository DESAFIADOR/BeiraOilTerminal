import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogTrigger } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Anchor, Clock, CheckCircle, Waves, Edit, Info, Package, Users, Calendar, Navigation, Hash, TrendingUp, MapPin, Ship, Settings, Save, X, Plus, Trash2 } from "lucide-react";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { UndockingModal } from "@/components/undocking-modal";
import { useAuth } from "@/contexts/AuthContext";

interface Ship {
  id: number;
  name: string;
  countermark: string;
  draft: string;
  shipAgent: string;
  cargoAgent: string;
  cargoType: string;
  operationType: string;
  status: string;
  arrivalDateTime: string | Date;
  berthingConfirmed: boolean | null;
  confirmationReceivedAt?: string | Date | null;
  parcels: Array<{
    parcelNumber: string;
    volume: string;
    receiver: string;
    owner: string;
    status: string;
  }>;
  latestProgress?: {
    discharged: string;
    remaining: string;
    percentage: string;
    estimatedCompletionHours?: string;
  };
}

interface EnhancedShipCardProps {
  ship: Ship;
  title: string;
  statusBadge: string;
  statusColor: "green" | "yellow" | "blue" | "gray";
  showProgress: boolean;
  onUpdateDischarge?: () => void;
  onMoveToBar?: () => void;
  onMoveToBerth?: () => void;
  onUndock?: () => void;
  onStartMaintenance?: () => void;
}

// Schema de validação para parcelas de carga
const cargoParcelSchema = z.object({
  parcelNumber: z.string().min(1, "Número da parcela é obrigatório"),
  volume: z.string().min(1, "Volume é obrigatório"),
  receiver: z.string().min(1, "Recebedor é obrigatório"),
  owner: z.string().min(1, "Dono da parcela é obrigatório"),
  status: z.enum(["pending", "loading", "completed"]),
});

// Schema de validação para edição do navio
const editShipSchema = z.object({
  name: z.string().min(1, "Nome do navio é obrigatório"),
  countermark: z.string().min(1, "Contra marca é obrigatória"),
  draft: z.string().min(1, "Calado é obrigatório"),
  shipAgent: z.string().min(1, "Agente do navio é obrigatório"),
  cargoAgent: z.string().min(1, "Agente da carga é obrigatório"),
  cargoType: z.string().min(1, "Tipo de carga é obrigatório"),
  operationType: z.enum(["nacional", "transito", "combinado"]),
  arrivalDateTime: z.string().min(1, "Data de chegada é obrigatória"),
  status: z.enum(["expected", "at_bar", "next_to_berth", "at_berth"]),
  parcels: z.array(cargoParcelSchema).min(1, "Pelo menos uma parcela é obrigatória"),
});

type EditShipFormData = z.infer<typeof editShipSchema>;
type CargoParcel = z.infer<typeof cargoParcelSchema>;



export function EnhancedShipCard({ 
  ship, 
  title, 
  statusBadge, 
  statusColor, 
  showProgress,
  onUpdateDischarge,
  onMoveToBar,
  onMoveToBerth,
  onUndock,
  onStartMaintenance,
}: EnhancedShipCardProps) {
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isUndockingModalOpen, setIsUndockingModalOpen] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { user } = useAuth();
  const canEdit = user?.role === "operator" || user?.role === "admin";
  
  // Query to check berthing record for undocking validation
  const { data: berthingRecord } = useQuery({
    queryKey: ["/api/ships", ship.id, "berthing"],
    queryFn: async () => {
      const response = await fetch(`/api/ships/${ship.id}/berthing`);
      if (!response.ok) return null;
      return response.json();
    },
    enabled: ship.status === 'at_berth' && !!onUndock,
  });
  
  // State para gerenciar parcelas no formulário  
  const [parcels, setParcels] = useState<CargoParcel[]>(
    ship.parcels?.map(parcel => ({
      parcelNumber: parcel.parcelNumber || "",
      volume: parcel.volume || "",
      receiver: parcel.receiver || "",
      owner: parcel.owner || "",
      status: (parcel.status as "pending" | "loading" | "completed") || "pending",
    })) || [{ parcelNumber: "", volume: "", receiver: "", owner: "", status: "pending" }]
  );

  // Fetch user permissions
  const { data: userPermissions = [] } = useQuery({
    queryKey: ['/api/user/permissions'],
    staleTime: 5 * 60 * 1000, // Cache for 5 minutes
  });

  // Form para edição do navio
  const editForm = useForm<EditShipFormData>({
    resolver: zodResolver(editShipSchema),
    defaultValues: {
      name: ship.name || "",
      countermark: ship.countermark || "",
      draft: ship.draft || "",
      shipAgent: ship.shipAgent || "",
      cargoAgent: ship.cargoAgent || "",
      cargoType: ship.cargoType || "",
      operationType: (ship.operationType as "nacional" | "transito" | "combinado") || "nacional",
      arrivalDateTime: ship.arrivalDateTime ? 
        new Date(ship.arrivalDateTime).toISOString().slice(0, 16) : "",
      status: ship.status as "expected" | "at_bar" | "next_to_berth" | "at_berth",
      parcels: parcels,
    },
  });

  // Mutation para atualizar informações do navio
  const updateShipMutation = useMutation({
    mutationFn: async (data: EditShipFormData) => {
      const updateData = {
        ...data,
        parcels: parcels.filter(p => p.parcelNumber && p.parcelNumber.trim() !== ""), // Remove parcelas vazias
      };
      const response = await fetch(`/api/ships/${ship.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updateData),
      });
      if (!response.ok) throw new Error('Erro ao atualizar navio');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/ships'] });
      queryClient.invalidateQueries({ queryKey: ['/api/ships', ship.id] });
      toast({
        title: "Sucesso",
        description: "Informações do navio atualizadas com sucesso!",
      });
      setIsDialogOpen(false);
    },
    onError: () => {
      toast({
        title: "Erro",
        description: "Erro ao atualizar informações do navio.",
        variant: "destructive",
      });
    },
  });

  // Check if user has specific permission
  const hasPermission = (permission: string) => {
    const permissions = userPermissions as any[];
    return Array.isArray(permissions) && permissions.some((p: any) => p.permission === permission);
  };

  // Funções para gerenciar parcelas
  const addParcel = () => {
    const newParcel = { parcelNumber: "", volume: "", receiver: "", owner: "", status: "pending" as const };
    const currentParcels = editForm.getValues('parcels');
    const updatedParcels = [...currentParcels, newParcel];
    setParcels(updatedParcels);
    editForm.setValue('parcels', updatedParcels);
  };

  const removeParcel = (index: number) => {
    const currentParcels = editForm.getValues('parcels');
    if (currentParcels.length > 1) {
      const newParcels = currentParcels.filter((_, i) => i !== index);
      setParcels(newParcels);
      editForm.setValue('parcels', newParcels);
    }
  };

  const updateParcel = (index: number, field: keyof CargoParcel, value: string) => {
    const currentParcels = editForm.getValues('parcels');
    const newParcels = [...currentParcels];
    newParcels[index] = { ...newParcels[index], [field]: value };
    setParcels(newParcels);
    editForm.setValue('parcels', newParcels);
  };

  // Component to show berthing status in ship details
  const BerthingStatusIcon = ({ shipId }: { shipId: number }) => {
    const { data: berthingRecord, isLoading } = useQuery({
      queryKey: ["/api/ships", shipId, "berthing"],
      refetchInterval: 2000, // Auto-refresh every 2 seconds for real-time sync
      refetchOnWindowFocus: true, // Refresh when tab becomes active
    });

    if (isLoading) {
      return (
        <div className="flex items-center space-x-3 p-3 border border-gray-200 rounded-lg shadow-md bg-white">
          <div className="w-8 h-8 bg-orange-100 rounded-lg flex items-center justify-center shadow-sm">
            <Anchor className="w-4 h-4 text-orange-600" />
          </div>
          <div>
            <span className="text-sm text-gray-600">Atracação:</span>
            <p className="font-medium text-gray-500">Carregando...</p>
          </div>
        </div>
      );
    }

    return (
      <div className="flex items-center space-x-3 p-3 border border-gray-200 rounded-lg shadow-md bg-white">
        <div className="w-8 h-8 bg-orange-100 rounded-lg flex items-center justify-center shadow-sm">
          <Anchor className="w-4 h-4 text-orange-600" />
        </div>
        <div>
          <span className="text-sm text-gray-600">Atracação:</span>
          {berthingRecord && (berthingRecord as any).lastRopeTime ? (
            <p className="font-medium text-orange-800">
              {new Date((berthingRecord as any).lastRopeTime).toLocaleDateString('pt-BR', {
                day: '2-digit',
                month: '2-digit',
                year: 'numeric',
                timeZone: 'Africa/Maputo'
              })} {new Date((berthingRecord as any).lastRopeTime).toLocaleTimeString('pt-BR', {
                hour: '2-digit',
                minute: '2-digit',
                timeZone: 'Africa/Maputo'
              })}
            </p>
          ) : (
            <p className="font-medium text-gray-500">Não registrada</p>
          )}
        </div>
      </div>
    );
  };

  // Component to fetch and display berthing data
  const BerthingInfo = ({ shipId }: { shipId: number }) => {
    const { data: berthingRecord, isLoading, refetch } = useQuery({
      queryKey: ["/api/ships", shipId, "berthing"],
      refetchInterval: 2000, // Auto-refresh every 2 seconds for real-time sync
      refetchOnWindowFocus: true, // Refresh when tab becomes active
    });

    if (isLoading) {
      return (
        <div className="flex justify-center">
          <div className="text-center p-8 border border-gray-200 rounded-lg shadow-md bg-white">
            <div className="w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-4 shadow-sm">
              <Anchor className="w-8 h-8 text-orange-600" />
            </div>
            <h4 className="font-semibold text-lg text-gray-800 mb-2">Data da Atracação</h4>
            <p className="text-xl text-gray-500">Carregando...</p>
          </div>
        </div>
      );
    }

    return (
      <div className="flex justify-center">
        <div className="text-center p-8 border border-gray-200 rounded-lg shadow-md bg-white">
          <div className="w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-4 shadow-sm">
            <Anchor className="w-8 h-8 text-orange-600" />
          </div>
          <h4 className="font-semibold text-lg text-gray-800 mb-2">Data da Atracação</h4>
          {berthingRecord && (berthingRecord as any).lastRopeTime ? (
            <div className="space-y-4">
              {/* Data oficial da atracação baseada na última corda */}
              <div className="bg-orange-50 p-4 rounded-lg border border-orange-200">
                <p className="text-sm text-orange-700 mb-2 font-medium">Data Oficial da Atracação</p>
                <p className="text-2xl font-bold text-orange-800">
                  {new Date((berthingRecord as any).lastRopeTime).toLocaleDateString('pt-BR', {
                    day: '2-digit',
                    month: '2-digit',
                    year: 'numeric',
                    timeZone: 'Africa/Maputo'
                  })}
                </p>
                <p className="text-xl font-medium text-orange-600 mt-1">
                  {new Date((berthingRecord as any).lastRopeTime).toLocaleTimeString('pt-BR', {
                    hour: '2-digit',
                    minute: '2-digit',
                    timeZone: 'Africa/Maputo'
                  })}
                </p>
                <p className="text-xs text-orange-600 mt-2">Horário da última corda</p>
              </div>
              
              {/* Detalhes completos */}
              <div className="grid grid-cols-2 gap-3 text-sm">
                <div className="text-center p-3 bg-gray-50 rounded border">
                  <p className="text-gray-600 mb-1">Primeira Corda</p>
                  <p className="font-semibold text-gray-800">
                    {new Date((berthingRecord as any).firstRopeTime).toLocaleDateString('pt-BR', {
                      day: '2-digit',
                      month: '2-digit',
                      timeZone: 'Africa/Maputo'
                    })} {new Date((berthingRecord as any).firstRopeTime).toLocaleTimeString('pt-BR', {
                      hour: '2-digit',
                      minute: '2-digit',
                      timeZone: 'Africa/Maputo'
                    })}
                  </p>
                </div>
                <div className="text-center p-3 bg-gray-50 rounded border">
                  <p className="text-gray-600 mb-1">Última Corda</p>
                  <p className="font-semibold text-gray-800">
                    {new Date((berthingRecord as any).lastRopeTime).toLocaleDateString('pt-BR', {
                      day: '2-digit',
                      month: '2-digit',
                      timeZone: 'Africa/Maputo'
                    })} {new Date((berthingRecord as any).lastRopeTime).toLocaleTimeString('pt-BR', {
                      hour: '2-digit',
                      minute: '2-digit',
                      timeZone: 'Africa/Maputo'
                    })}
                  </p>
                </div>
              </div>
              
              <p className="text-sm text-green-600 mt-3 font-medium">✓ Atracação Confirmada</p>
            </div>
          ) : (
            <>
              <p className="text-xl text-gray-500 mb-2">Aguardando Registro</p>
              <p className="text-sm text-gray-400">Use "Atracação do Navio" para registrar</p>
            </>
          )}
        </div>
      </div>
    );
  };

  const getBadgeColor = (color: string) => {
    switch (color) {
      case "green": return "bg-green-100 text-green-800";
      case "yellow": return "bg-yellow-100 text-yellow-800";
      case "blue": return "bg-blue-100 text-blue-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  const getDisplayInfo = () => {
    if (ship.status === "at_berth") {
      return {
        primary: ship.name,
        secondary: ship.cargoType,
        label: "Produto em descarga"
      };
    } else if (ship.status === "next_to_berth") {
      return {
        primary: ship.name,
        secondary: `${ship.countermark} - ${ship.cargoType}`,
        label: "Contra marca e produto"
      };
    } else {
      return {
        primary: ship.name,
        secondary: ship.cargoType,
        label: "Tipo de carga"
      };
    }
  };

  const displayInfo = getDisplayInfo();

  return (
    <>
    <Card className="hover:shadow-md transition-shadow cursor-pointer border-0 shadow-sm">
      <CardContent className="p-4 sm:p-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-3 sm:mb-4 space-y-3 sm:space-y-0">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 sm:w-10 sm:h-10 bg-blue-100 rounded-lg flex items-center justify-center flex-shrink-0">
              <Anchor className="w-4 h-4 sm:w-5 sm:h-5 text-blue-600" />
            </div>
            <div className="min-w-0 flex-1">
              <h3 className="font-semibold text-base sm:text-lg truncate">{title}</h3>
              <div className="flex flex-wrap gap-2 mt-1">
                <Badge className={`${getBadgeColor(statusColor)} text-xs sm:text-sm`}>
                  {statusBadge}
                </Badge>
                {ship.cargoAgent?.toUpperCase().includes('IMOPETRO') && (
                  <Badge className="bg-red-100 text-red-800 text-xs sm:text-sm">
                    🚨 PRIORIDADE - Decreto 89/2019
                  </Badge>
                )}
                {ship.operationType && (
                  <Badge className={`text-xs sm:text-sm ${
                    ship.operationType === 'nacional' ? 'bg-blue-100 text-blue-800' : 
                    ship.operationType === 'combinado' ? 'bg-purple-100 text-purple-800' : 
                    ship.operationType === 'LPG' ? 'bg-orange-100 text-orange-800' :
                    'bg-green-100 text-green-800'
                  }`}>
                    {ship.operationType === 'nacional' ? 'NACIONAL' : 
                     ship.operationType === 'combinado' ? 'COMBINADO' : 
                     ship.operationType === 'LPG' ? 'LPG' : 'TRÂNSITO'}
                  </Badge>
                )}
              </div>
            </div>
          </div>
          
          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <Button variant="ghost" size="sm" className="text-blue-600 hover:text-blue-800">
                <Info className="w-4 h-4 mr-1" />
                Detalhes
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-6xl max-h-[90vh] overflow-y-auto p-6">
              <DialogHeader>
                <DialogTitle className="text-xl">Detalhes do Navio - {ship.name}</DialogTitle>
                <DialogDescription>
                  Informações completas sobre o navio, agentes, carga e status operacional.
                </DialogDescription>
              </DialogHeader>
              
              <Tabs defaultValue="general" className="w-full">
                <div className="space-y-2">
                  <TabsList className="grid w-full grid-cols-3 gap-1">
                    <TabsTrigger value="general" className="text-xs lg:text-sm">
                      <Info className="w-3 h-3 lg:w-4 lg:h-4 mr-1 lg:mr-2" />
                      <span className="hidden sm:inline">Geral</span>
                      <span className="sm:hidden">Info</span>
                    </TabsTrigger>
                    {canEdit && (
                      <TabsTrigger value="agents" className="text-xs lg:text-sm">
                        <Users className="w-3 h-3 lg:w-4 lg:h-4 mr-1 lg:mr-2" />
                        <span className="hidden sm:inline">Agentes</span>
                        <span className="sm:hidden">Agent</span>
                      </TabsTrigger>
                    )}
                    <TabsTrigger value="cargo" className="text-xs lg:text-sm">
                      <Package className="w-3 h-3 lg:w-4 lg:h-4 mr-1 lg:mr-2" />
                      <span className="hidden sm:inline">Carga Total</span>
                      <span className="sm:hidden">Carga</span>
                    </TabsTrigger>
                  </TabsList>
                  
                  <TabsList className="grid w-full grid-cols-2 gap-1">
                    <TabsTrigger value="arrival" className="text-xs lg:text-sm">
                      <MapPin className="w-3 h-3 lg:w-4 lg:h-4 mr-1 lg:mr-2" />
                      <span className="hidden sm:inline">Data de Chegada na Barra</span>
                      <span className="sm:hidden">Chegada</span>
                    </TabsTrigger>
                    <TabsTrigger value="berthing" className="text-xs lg:text-sm">
                      <Anchor className="w-3 h-3 lg:w-4 lg:h-4 mr-1 lg:mr-2" />
                      <span className="hidden sm:inline">Data da Atracação</span>
                      <span className="sm:hidden">Atracação</span>
                    </TabsTrigger>
                  </TabsList>
                  
                  {canEdit && (
                    <TabsList className="grid w-full grid-cols-1 gap-1 mt-2">
                      <TabsTrigger value="edit" className="text-xs lg:text-sm">
                        <Edit className="w-3 h-3 lg:w-4 lg:h-4 mr-1 lg:mr-2" />
                        <span className="hidden sm:inline">Editar Informações</span>
                        <span className="sm:hidden">Editar</span>
                      </TabsTrigger>
                    </TabsList>
                  )}
                </div>
                
                <TabsContent value="general" className="space-y-4 mt-4">
                  <div className="grid grid-cols-2 gap-6">
                    <div>
                      <h4 className="font-semibold mb-4 flex items-center">
                        <Navigation className="w-5 h-5 mr-2 text-blue-600" />
                        Informações do Navio
                      </h4>
                      <div className="space-y-4">
                        <div className="flex items-center space-x-3 p-3 border border-gray-200 rounded-lg shadow-md bg-white">
                          <div className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center shadow-sm">
                            <Navigation className="w-4 h-4 text-blue-600" />
                          </div>
                          <div>
                            <span className="text-sm text-gray-600">Nome:</span>
                            <p className="font-medium text-lg">{ship.name}</p>
                          </div>
                        </div>
                        <div className="flex items-center space-x-3 p-3 border border-gray-200 rounded-lg shadow-md bg-white">
                          <div className="w-8 h-8 bg-gray-100 rounded-lg flex items-center justify-center shadow-sm">
                            <Hash className="w-4 h-4 text-gray-600" />
                          </div>
                          <div>
                            <span className="text-sm text-gray-600">Contra Marca:</span>
                            <p className="font-medium">{ship.countermark}</p>
                          </div>
                        </div>
                        <div className="flex items-center space-x-3 p-3 border border-gray-200 rounded-lg shadow-md bg-white">
                          <div className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center shadow-sm">
                            <Anchor className="w-4 h-4 text-blue-600" />
                          </div>
                          <div>
                            <span className="text-sm text-gray-600">Calado:</span>
                            <p className="font-medium">{ship.draft}m</p>
                          </div>
                        </div>
                        <div className="flex items-center space-x-3 p-3 border border-gray-200 rounded-lg shadow-md bg-white">
                          <div className="w-8 h-8 bg-green-100 rounded-lg flex items-center justify-center shadow-sm">
                            <TrendingUp className="w-4 h-4 text-green-600" />
                          </div>
                          <div>
                            <span className="text-sm text-gray-600">Status:</span>
                            <Badge className={getBadgeColor(statusColor)}>
                              {statusBadge}
                            </Badge>
                          </div>
                        </div>
                        
                        <BerthingStatusIcon shipId={ship.id} />

                      </div>
                    </div>
                    

                  </div>
                </TabsContent>
                

                
                <TabsContent value="agents" className="space-y-4 mt-4">
                  <div className="space-y-6">
                    <div>
                      <h4 className="font-semibold mb-4 flex items-center">
                        <Users className="w-5 h-5 mr-2 text-blue-600" />
                        Agentes Responsáveis
                      </h4>
                      <div className="space-y-4">
                        <div className="flex items-center space-x-3 p-3 border border-gray-200 rounded-lg shadow-md bg-white">
                          <div className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center shadow-sm">
                            <Navigation className="w-4 h-4 text-blue-600" />
                          </div>
                          <div>
                            <span className="text-sm text-gray-600">Agente do Navio:</span>
                            <p className="font-bold text-lg text-blue-800">{ship.shipAgent}</p>
                          </div>
                        </div>
                        <div className="flex items-center space-x-3 p-3 border border-gray-200 rounded-lg shadow-md bg-white">
                          <div className="w-8 h-8 bg-green-100 rounded-lg flex items-center justify-center shadow-sm">
                            <Package className="w-4 h-4 text-green-600" />
                          </div>
                          <div>
                            <span className="text-sm text-gray-600">Agente da Carga:</span>
                            <p className="font-bold text-lg text-green-800">{ship.cargoAgent}</p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </TabsContent>
                
                <TabsContent value="cargo" className="space-y-4 mt-4">
                  <div className="flex justify-center">
                    <div className="text-center p-8 border border-gray-200 rounded-lg shadow-md bg-white">
                      <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4 shadow-sm">
                        <Package className="w-8 h-8 text-blue-600" />
                      </div>
                      <h4 className="font-semibold text-lg text-gray-800 mb-4">Carga Total a ser Descarregada</h4>
                      <p className="text-3xl font-bold text-blue-800 mb-2">
                        {(ship.parcels || []).reduce((total, parcel) => {
                          const volume = parseFloat((parcel.volume || "0").replace(/[^\d.-]/g, '')) || 0;
                          return total + volume;
                        }, 0).toLocaleString('pt-BR')} MT
                      </p>
                      <div className="text-sm text-gray-600 mt-4">
                        <p className="font-medium">Detalhamento por Parcela:</p>
                        <div className="space-y-2 mt-2">
                          {(ship.parcels || []).map((parcel, index) => (
                            <div key={index} className="bg-gray-50 p-2 rounded border text-xs">
                              <div className="flex justify-between font-medium">
                                <span>{parcel.parcelNumber}:</span>
                                <span>{parcel.volume}</span>
                              </div>
                              <div className="flex justify-between text-gray-500 mt-1">
                                <span>Dono: {parcel.owner}</span>
                                <span>Recebedor: {parcel.receiver}</span>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>
                </TabsContent>
                
                <TabsContent value="arrival" className="space-y-4 mt-4">
                  <div className="flex justify-center">
                    <div className="text-center p-8 border border-gray-200 rounded-lg shadow-md bg-white">
                      <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4 shadow-sm">
                        <MapPin className="w-8 h-8 text-green-600" />
                      </div>
                      <h4 className="font-semibold text-lg text-gray-800 mb-2">Data de Chegada na Barra</h4>
                      <p className="text-2xl font-bold text-green-800">
                        {ship.arrivalDateTime ? format(new Date(ship.arrivalDateTime), "dd/MM/yyyy", { locale: ptBR }) : 'Data não disponível'}
                      </p>
                      <p className="text-xl font-medium text-green-600 mt-2">
                        {ship.arrivalDateTime ? format(new Date(ship.arrivalDateTime), "HH:mm", { locale: ptBR }) : '--:--'}
                      </p>
                    </div>
                  </div>
                </TabsContent>
                
                <TabsContent value="berthing" className="space-y-4 mt-4">
                  <div className="relative">
                    <BerthingInfo shipId={ship.id} />
                    <div className="absolute top-2 right-2">
                      <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" title="Sincronização em tempo real ativa"></div>
                    </div>
                  </div>
                </TabsContent>

                {canEdit && (
                  <TabsContent value="edit" className="space-y-4 mt-4">
                      <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4 mb-6">
                        <div className="flex items-center">
                          <Edit className="w-5 h-5 text-yellow-600 mr-2" />
                          <h3 className="font-semibold text-yellow-800">Edição de Informações do Navio</h3>
                        </div>
                        <p className="text-sm text-yellow-700 mt-1">
                          Esta funcionalidade permite editar todas as informações do navio. 
                          Disponível apenas para operadores e navios não desatracados.
                        </p>
                      </div>

                      <Form {...editForm}>
                        <form onSubmit={editForm.handleSubmit((data) => updateShipMutation.mutate(data))} className="space-y-6">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <FormField
                            control={editForm.control}
                            name="name"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Nome do Navio</FormLabel>
                                <FormControl>
                                  <Input placeholder="Ex: HANSA OSLO" {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />

                          <FormField
                            control={editForm.control}
                            name="countermark"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Contra Marca</FormLabel>
                                <FormControl>
                                  <Input placeholder="Ex: 158-25" {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />

                          <FormField
                            control={editForm.control}
                            name="draft"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Calado (metros)</FormLabel>
                                <FormControl>
                                  <Input placeholder="Ex: 7.5" {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />

                          <FormField
                            control={editForm.control}
                            name="status"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Status do Navio</FormLabel>
                                <Select onValueChange={field.onChange} defaultValue={field.value}>
                                  <FormControl>
                                    <SelectTrigger>
                                      <SelectValue placeholder="Selecione o status" />
                                    </SelectTrigger>
                                  </FormControl>
                                  <SelectContent>
                                    <SelectItem value="expected">Esperado</SelectItem>
                                    <SelectItem value="at_bar">Na Barra</SelectItem>
                                    <SelectItem value="next_to_berth">Próximo do Cais</SelectItem>
                                    <SelectItem value="at_berth">No Cais</SelectItem>
                                  </SelectContent>
                                </Select>
                                <FormMessage />
                              </FormItem>
                            )}
                          />

                          <FormField
                            control={editForm.control}
                            name="shipAgent"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Agente do Navio</FormLabel>
                                <FormControl>
                                  <Input placeholder="Nome do agente do navio" {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />

                          <FormField
                            control={editForm.control}
                            name="cargoAgent"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Agente da Carga</FormLabel>
                                <FormControl>
                                  <Input placeholder="Nome do agente da carga" {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />

                          <FormField
                            control={editForm.control}
                            name="cargoType"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Tipo de Carga</FormLabel>
                                <FormControl>
                                  <Input placeholder="Ex: Diesel, Gasolina, Jet Fuel" {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />

                          <FormField
                            control={editForm.control}
                            name="arrivalDateTime"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Data e Hora de Chegada na Barra</FormLabel>
                                <FormControl>
                                  <Input type="datetime-local" {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>

                        {/* Seção de Edição de Parcelas de Carga */}
                        <div className="space-y-4">
                          <div className="flex items-center justify-between">
                            <h4 className="text-lg font-semibold text-gray-800">Parcelas de Carga</h4>
                            <Button
                              type="button"
                              onClick={addParcel}
                              variant="outline"
                              size="sm"
                              className="text-green-600 border-green-600 hover:bg-green-50"
                            >
                              <Plus className="w-4 h-4 mr-2" />
                              Adicionar Parcela
                            </Button>
                          </div>

                          <div className="space-y-4">
                            {parcels.map((parcel, index) => (
                              <div key={index} className="p-4 border border-gray-200 rounded-lg bg-gray-50">
                                <div className="flex items-center justify-between mb-3">
                                  <h5 className="font-medium text-gray-700">Parcela {index + 1}</h5>
                                  {parcels.length > 1 && (
                                    <Button
                                      type="button"
                                      onClick={() => removeParcel(index)}
                                      variant="outline"
                                      size="sm"
                                      className="text-red-600 border-red-600 hover:bg-red-50"
                                    >
                                      <Trash2 className="w-4 h-4" />
                                    </Button>
                                  )}
                                </div>
                                
                                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                                  <div>
                                    <Label>Número da Parcela</Label>
                                    <Input
                                      value={parcel.parcelNumber}
                                      onChange={(e) => updateParcel(index, 'parcelNumber', e.target.value)}
                                      placeholder="Ex: P001"
                                    />
                                  </div>
                                  
                                  <div>
                                    <Label>Volume (MT)</Label>
                                    <Input
                                      value={parcel.volume}
                                      onChange={(e) => updateParcel(index, 'volume', e.target.value)}
                                      placeholder="Ex: 5000.00"
                                    />
                                  </div>
                                  
                                  <div>
                                    <Label>Status</Label>
                                    <Select
                                      value={parcel.status}
                                      onValueChange={(value: "pending" | "loading" | "completed") => 
                                        updateParcel(index, 'status', value)
                                      }
                                    >
                                      <SelectTrigger>
                                        <SelectValue />
                                      </SelectTrigger>
                                      <SelectContent>
                                        <SelectItem value="pending">Aguardando</SelectItem>
                                        <SelectItem value="loading">Em Descarga</SelectItem>
                                        <SelectItem value="completed">Concluída</SelectItem>
                                      </SelectContent>
                                    </Select>
                                  </div>
                                  
                                  <div>
                                    <Label>Recebedor</Label>
                                    <Input
                                      value={parcel.receiver}
                                      onChange={(e) => updateParcel(index, 'receiver', e.target.value)}
                                      placeholder="Nome do recebedor"
                                    />
                                  </div>
                                  
                                  <div>
                                    <Label>Dono da Parcela</Label>
                                    <Input
                                      value={parcel.owner}
                                      onChange={(e) => updateParcel(index, 'owner', e.target.value)}
                                      placeholder="Nome do proprietário"
                                    />
                                  </div>
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>

                        <div className="flex justify-end space-x-3 pt-4 border-t border-gray-200">
                          <Button
                            type="button"
                            variant="outline"
                            onClick={() => setIsDialogOpen(false)}
                            disabled={updateShipMutation.isPending}
                          >
                            <X className="w-4 h-4 mr-2" />
                            Cancelar
                          </Button>
                          <Button
                            type="submit"
                            disabled={updateShipMutation.isPending}
                            className="bg-blue-600 hover:bg-blue-700"
                          >
                            {updateShipMutation.isPending ? (
                              <>
                                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
                                Salvando...
                              </>
                            ) : (
                              <>
                                <Save className="w-4 h-4 mr-2" />
                                Salvar Alterações
                              </>
                            )}
                          </Button>
                        </div>
                      </form>
                    </Form>
                  </TabsContent>
                )}

              </Tabs>
            </DialogContent>
          </Dialog>
        </div>

        <div className="space-y-4">
          <div className="bg-gray-50 p-4 rounded-lg">
            <p className="text-xl font-bold text-gray-900 mb-2">{displayInfo.primary}</p>
            <div>
              <span className="text-sm text-gray-600 font-medium">{displayInfo.label}:</span>
              <p className="text-lg font-semibold text-blue-700">{displayInfo.secondary}</p>
            </div>
          </div>

          {showProgress && ship.latestProgress && (
            <div className="bg-gradient-to-r from-green-50 to-blue-50 p-4 rounded-lg border border-green-200">
              <div className="flex justify-between items-center mb-3">
                <span className="font-semibold text-gray-800 flex items-center">
                  <TrendingUp className="w-4 h-4 mr-2 text-green-600" />
                  Progresso da Descarga
                </span>
                <div className="text-right">
                  <span className="text-2xl font-bold text-green-600">{ship.latestProgress.percentage}%</span>
                  <p className="text-xs text-gray-600">Concluído</p>
                </div>
              </div>
              <Progress value={parseInt(ship.latestProgress.percentage)} className="w-full h-3" />
              <div className="flex justify-between text-xs text-gray-600 mt-2">
                <span>Descarregado: {ship.latestProgress.discharged} MT</span>
                <span>Restante: {ship.latestProgress.remaining} MT</span>
              </div>
            </div>
          )}

          {ship.berthingConfirmed && ship.confirmationReceivedAt && (
            <div className="flex items-center space-x-2 text-green-600 bg-green-50 p-2 rounded">
              <CheckCircle className="w-4 h-4" />
              <span className="text-sm font-medium">
                Confirmado em {format(new Date(ship.confirmationReceivedAt), "dd/MM/yyyy", { locale: ptBR })}
              </span>
            </div>
          )}
        </div>

        {canEdit && (
          <div className="mt-4 flex space-x-2">
            {onUpdateDischarge && hasPermission('update_discharge') && (
              <Button 
                onClick={onUpdateDischarge}
                size="sm" 
                variant="outline"
                className="flex-1"
              >
                <Edit className="w-4 h-4 mr-2" />
                Atualizar Descarga
              </Button>
            )}
            
            {onMoveToBar && hasPermission('move_ship') && (
              <Button 
                onClick={onMoveToBar}
                size="sm"
                className="flex-1 bg-blue-600 hover:bg-blue-700"
              >
                <Waves className="w-4 h-4 mr-2" />
                Mover para Barra
              </Button>
            )}
            
            {onMoveToBerth && hasPermission('move_ship') && ship.status === 'next_to_berth' && (() => {
              const areBothRopesRecorded = berthingRecord && berthingRecord.firstRopeTime && berthingRecord.lastRopeTime;
              
              return (
                <Button 
                  onClick={onMoveToBerth}
                  disabled={!areBothRopesRecorded}
                  size="sm"
                  className={`flex-1 ${areBothRopesRecorded 
                    ? 'bg-green-600 hover:bg-green-700' 
                    : 'bg-gray-400 cursor-not-allowed'
                  }`}
                  title={
                    !areBothRopesRecorded ? "Registro de atracação (duas cordas) necessário" :
                    "Pronto para mover ao cais"
                  }
                >
                  <Anchor className="w-4 h-4 mr-2" />
                  Mover para Cais
                </Button>
              );
            })()}
            
            {onUndock && hasPermission('move_ship') && ship.status === 'at_berth' && (() => {
              const isDischargeComplete = ship.latestProgress && parseFloat(ship.latestProgress.percentage) === 100;
              
              return (
                <Button 
                  onClick={() => setIsUndockingModalOpen(true)}
                  disabled={!isDischargeComplete}
                  size="sm"
                  className={`flex-1 ${isDischargeComplete 
                    ? 'bg-red-600 hover:bg-red-700' 
                    : 'bg-gray-400 cursor-not-allowed'
                  }`}
                  title={
                    !isDischargeComplete ? "Descarga deve estar 100% concluída" :
                    "Registrar desatracação"
                  }
                >
                  <Navigation className="w-4 h-4 mr-2" />
                  Desatracado
                </Button>
              );
            })()}
            
            {onStartMaintenance && hasPermission('move_ship') && (
              <Button 
                onClick={onStartMaintenance}
                size="sm"
                className="flex-1 bg-orange-600 hover:bg-orange-700"
              >
                <Settings className="w-4 h-4 mr-2" />
                Manutenção do Cais
              </Button>
            )}
          </div>
        )}
      </CardContent>
    </Card>

    {canEdit && (
      <UndockingModal
        isOpen={isUndockingModalOpen}
        onClose={() => setIsUndockingModalOpen(false)}
        shipId={ship.id}
        shipName={ship.name}
        onSuccess={() => {
          if (onUndock) onUndock();
        }}
      />
    )}
    </>
  );
}