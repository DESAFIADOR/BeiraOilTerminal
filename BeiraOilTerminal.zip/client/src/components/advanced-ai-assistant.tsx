import React, { useState, useRef, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { 
  MessageCircle, 
  Send, 
  Mic, 
  MicOff, 
  Bot,
  User,
  X,
  Volume2,
  Star,
  AlertTriangle,
  CheckCircle,
  Clock,
  Zap
} from 'lucide-react';
import { useTranslation } from '@/contexts/LanguageContext';
import { LocalizedDateDisplay, LocalizedNumberDisplay } from './localized-date-display';

interface ChatMessage {
  id: string;
  content: string;
  role: 'user' | 'assistant';
  timestamp: Date;
  confidence?: number;
  requiresEscalation?: boolean;
  responseTimeMs?: number;
  suggestions?: string[];
  errorCode?: string;
  errorTitle?: string;
  actionText?: string;
}

interface AdvancedAIAssistantProps {
  user?: any;
  isOpen: boolean;
  onClose: () => void;
}

export function AdvancedAIAssistant({ user, isOpen, onClose }: AdvancedAIAssistantProps) {
  const { t, language } = useTranslation();
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [currentMessage, setCurrentMessage] = useState('');
  const [sessionId, setSessionId] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const [sessionInfo, setSessionInfo] = useState<any>(null);
  const [satisfactionRating, setSatisfactionRating] = useState<number>(0);
  const [showFeedback, setShowFeedback] = useState(false);
  
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);

  // Auto scroll to bottom
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // Create session when component opens
  useEffect(() => {
    if (isOpen && !sessionId) {
      createSession();
    }
  }, [isOpen]);

  const createSession = async () => {
    try {
      setIsLoading(true);
      const response = await fetch('/api/advanced-ai/session', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userRole: user?.role || 'visitor',
          language: language
        }),
      });

      if (response.ok) {
        const data = await response.json();
        setSessionId(data.sessionId);
        setSessionInfo(data);
        console.log('[AdvancedAI] Session created:', data.sessionId);
        
        // Add welcome message
        const welcomeMessage: ChatMessage = {
          id: 'welcome',
          content: language === 'en' ? 
            'Welcome to the Advanced AI Assistant for Beira Oil Terminal! I can help you with ship operations, terminal information, and provide real-time support. How may I assist you today?' :
            'Bem-vindo ao Assistente IA Avançado do Terminal Petrolífero da Beira! Posso ajudá-lo com operações de navios, informações do terminal e fornecer suporte em tempo real. Como posso ajudá-lo hoje?',
          role: 'assistant',
          timestamp: new Date(),
          confidence: 1.0,
          suggestions: language === 'en' ? [
            'Show current ships status',
            'Terminal operations information', 
            'Berthing conditions today'
          ] : [
            'Mostrar status dos navios atuais',
            'Informações das operações do terminal',
            'Condições de atracação hoje'
          ]
        };
        setMessages([welcomeMessage]);
      } else {
        throw new Error('Failed to create session');
      }
    } catch (error) {
      console.error('[AdvancedAI] Session creation failed:', error);
      const errorMessage: ChatMessage = {
        id: 'error',
        content: language === 'en' ? 
          'Unable to connect to AI service. Please check your connection and try again.' :
          'Não foi possível conectar ao serviço de IA. Verifique sua conexão e tente novamente.',
        role: 'assistant',
        timestamp: new Date(),
        confidence: 0.1,
        requiresEscalation: true
      };
      setMessages([errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  const sendMessage = async (messageText?: string, suggestion?: boolean) => {
    const text = messageText || currentMessage.trim();
    if (!text || !sessionId || isLoading) return;

    const userMessage: ChatMessage = {
      id: Date.now().toString(),
      content: text,
      role: 'user',
      timestamp: new Date(),
    };

    setMessages(prev => [...prev, userMessage]);
    if (!suggestion) setCurrentMessage('');
    setIsLoading(true);

    try {
      const response = await fetch('/api/advanced-ai/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          sessionId,
          message: text,
          userRole: user?.role || 'visitor',
          language: language,
        }),
      });

      if (response.ok) {
        const data = await response.json();
        
        const assistantMessage: ChatMessage = {
          id: (Date.now() + 1).toString(),
          content: data.response,
          role: 'assistant',
          timestamp: new Date(),
          confidence: data.confidence,
          requiresEscalation: data.requiresEscalation,
          responseTimeMs: data.responseTimeMs,
          suggestions: data.suggestions,
          errorCode: data.errorCode,
          errorTitle: data.errorTitle,
          actionText: data.actionText
        };

        setMessages(prev => [...prev, assistantMessage]);
        
        // Show feedback prompt if confidence is low or escalation needed
        if (data.confidence < 0.6 || data.requiresEscalation) {
          setTimeout(() => setShowFeedback(true), 2000);
        }
      } else {
        throw new Error('Failed to get response');
      }
    } catch (error) {
      console.error('[AdvancedAI] Message failed:', error);
      const errorMessage: ChatMessage = {
        id: (Date.now() + 1).toString(),
        content: language === 'en' ? 
          'I encountered a technical issue. Please try rephrasing your question or contact support.' :
          'Encontrei um problema técnico. Tente reformular sua pergunta ou entre em contato com o suporte.',
        role: 'assistant',
        timestamp: new Date(),
        confidence: 0.1,
        requiresEscalation: true,
      };
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;
      audioChunksRef.current = [];

      mediaRecorder.ondataavailable = (event) => {
        audioChunksRef.current.push(event.data);
      };

      mediaRecorder.onstop = async () => {
        const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
        const audioData = await blobToBase64(audioBlob);
        
        try {
          const response = await fetch('/api/advanced-ai/speech-to-text', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ audioData, language }),
          });

          if (response.ok) {
            const data = await response.json();
            if (data.transcription) {
              await sendMessage(data.transcription);
            }
          }
        } catch (error) {
          console.error('[AdvancedAI] Speech processing failed:', error);
        }

        stream.getTracks().forEach(track => track.stop());
      };

      mediaRecorder.start();
      setIsRecording(true);
    } catch (error) {
      console.error('[AdvancedAI] Recording failed:', error);
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
    }
  };

  const playTextToSpeech = async (text: string) => {
    try {
      const response = await fetch('/api/advanced-ai/text-to-speech', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text, language }),
      });

      if (response.ok) {
        const data = await response.json();
        if (data.audioUrl) {
          const audio = new Audio(data.audioUrl);
          audio.play();
        }
      }
    } catch (error) {
      console.error('[AdvancedAI] Text-to-speech failed:', error);
    }
  };

  const endSession = async () => {
    if (!sessionId) return;
    
    try {
      await fetch(`/api/advanced-ai/session/${sessionId}/end`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ satisfactionRating }),
      });
    } catch (error) {
      console.error('[AdvancedAI] Failed to end session:', error);
    }
  };

  const handleClose = async () => {
    if (showFeedback && sessionId) {
      await endSession();
    }
    setMessages([]);
    setSessionId(null);
    setSessionInfo(null);
    setShowFeedback(false);
    setSatisfactionRating(0);
    onClose();
  };

  const blobToBase64 = (blob: Blob): Promise<string> => {
    return new Promise((resolve) => {
      const reader = new FileReader();
      reader.onloadend = () => {
        const base64 = reader.result as string;
        resolve(base64.split(',')[1]);
      };
      reader.readAsDataURL(blob);
    });
  };

  const formatConfidence = (confidence: number) => {
    if (confidence >= 0.9) return { label: 'Alta', color: 'bg-green-500', icon: CheckCircle };
    if (confidence >= 0.7) return { label: 'Boa', color: 'bg-blue-500', icon: CheckCircle };
    if (confidence >= 0.5) return { label: 'Média', color: 'bg-yellow-500', icon: AlertTriangle };
    return { label: 'Baixa', color: 'bg-red-500', icon: AlertTriangle };
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50 p-4">
      <Card className="w-full max-w-4xl h-[700px] flex flex-col shadow-2xl">
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-3 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-t-lg">
          <CardTitle className="flex items-center gap-3">
            <div className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center">
              <Zap className="h-6 w-6" />
            </div>
            <div>
              <div className="text-lg font-semibold">
                {language === 'en' ? 'Advanced AI Assistant' : 'Assistente IA Avançado'}
              </div>
              {sessionInfo && (
                <div className="text-sm text-white/80">
                  {language === 'en' ? 'Terminal Support System' : 'Sistema de Suporte do Terminal'}
                </div>
              )}
            </div>
          </CardTitle>
          <div className="flex items-center gap-3">
            {sessionInfo?.capabilities && (
              <div className="flex gap-1">
                {sessionInfo.capabilities.canViewReports && (
                  <Badge variant="secondary" className="text-xs bg-white/20 text-white border-white/30">
                    {language === 'en' ? 'Reports' : 'Relatórios'}
                  </Badge>
                )}
                {sessionInfo.capabilities.canModifyShips && (
                  <Badge variant="secondary" className="text-xs bg-white/20 text-white border-white/30">
                    {language === 'en' ? 'Operations' : 'Operações'}
                  </Badge>
                )}
              </div>
            )}
            <Button variant="ghost" size="sm" onClick={handleClose} className="text-white hover:bg-white/10">
              <X className="h-5 w-5" />
            </Button>
          </div>
        </CardHeader>

        <CardContent className="flex-1 flex flex-col p-0">
          <div className="flex-1 overflow-y-auto p-4 space-y-4">
            {messages.map((message) => (
              <div
                key={message.id}
                className={`flex items-start gap-3 ${
                  message.role === 'user' ? 'flex-row-reverse' : ''
                }`}
              >
                <div className={`w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0 ${
                  message.role === 'user' 
                    ? 'bg-blue-500 text-white' 
                    : 'bg-gradient-to-br from-blue-600 to-purple-600 text-white'
                }`}>
                  {message.role === 'user' ? <User className="h-5 w-5" /> : <Bot className="h-5 w-5" />}
                </div>
                
                <div className={`flex-1 ${message.role === 'user' ? 'text-right' : ''}`}>
                  <div className={`inline-block p-4 rounded-lg max-w-[85%] ${
                    message.role === 'user'
                      ? 'bg-blue-500 text-white ml-auto'
                      : 'bg-gray-50 border border-gray-200'
                  }`}>
                    <p className="text-sm leading-relaxed">{message.content}</p>
                    
                    {message.role === 'assistant' && (
                      <div className="mt-3 space-y-2">
                        {/* Confidence and metrics */}
                        <div className="flex items-center gap-4 text-xs">
                          {message.confidence !== undefined && (
                            <div className="flex items-center gap-2">
                              <span className="text-gray-500">Confiança:</span>
                              <div className="flex items-center gap-1">
                                {React.createElement(formatConfidence(message.confidence).icon, {
                                  className: "h-3 w-3 text-gray-400"
                                })}
                                <Progress 
                                  value={message.confidence * 100} 
                                  className="w-16 h-2"
                                />
                                <span className={`font-medium ${
                                  message.confidence >= 0.7 ? 'text-green-600' : 
                                  message.confidence >= 0.5 ? 'text-yellow-600' : 'text-red-600'
                                }`}>
                                  {Math.round(message.confidence * 100)}%
                                </span>
                              </div>
                            </div>
                          )}
                          
                          {message.responseTimeMs && (
                            <div className="flex items-center gap-1 text-gray-500">
                              <Clock className="h-3 w-3" />
                              <LocalizedNumberDisplay 
                                value={message.responseTimeMs} 
                                className="text-xs"
                              />
                              <span className="text-xs">ms</span>
                            </div>
                          )}
                          
                          <div className="flex items-center gap-1 text-gray-400 text-xs">
                            <LocalizedDateDisplay 
                              date={message.timestamp} 
                              format="time"
                            />
                          </div>
                          
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => playTextToSpeech(message.content)}
                            className="h-6 w-6 p-0 text-gray-400 hover:text-gray-600"
                          >
                            <Volume2 className="h-3 w-3" />
                          </Button>
                        </div>

                        {/* Enhanced escalation warning with localized error information */}
                        {message.requiresEscalation && (
                          <div className="space-y-2">
                            <div className="flex items-center gap-2 p-3 bg-amber-50 border border-amber-200 rounded-lg text-xs">
                              <AlertTriangle className="h-4 w-4 text-amber-500 flex-shrink-0" />
                              <div className="flex-1">
                                {message.errorTitle && (
                                  <div className="font-semibold text-amber-800 mb-1">
                                    {message.errorTitle}
                                  </div>
                                )}
                                <span className="text-amber-700">
                                  {message.confidence && message.confidence < 0.3 ? (
                                    language === 'en' ? 
                                      'Service limitation detected. For full AI capabilities, please contact your administrator.' :
                                      'Limitação de serviço detectada. Para capacidades completas de IA, contate seu administrador.'
                                  ) : (
                                    language === 'en' ? 
                                      'This query may require human assistance for optimal resolution.' :
                                      'Esta consulta pode requerer assistência humana para resolução otimizada.'
                                  )}
                                </span>
                              </div>
                              {message.actionText && (
                                <Button
                                  variant="outline"
                                  size="sm"
                                  className="text-xs bg-amber-100 border-amber-300 hover:bg-amber-200 text-amber-800"
                                  onClick={() => {
                                    // Handle action based on error type
                                    if (message.errorCode === 'insufficient_quota') {
                                      window.open('mailto:admin@terminal.com?subject=AI Service Upgrade Request', '_blank');
                                    } else if (message.errorCode === 'invalid_api_key') {
                                      window.open('/admin/settings', '_blank');
                                    }
                                  }}
                                >
                                  {message.actionText}
                                </Button>
                              )}
                            </div>
                            
                            {/* Error code for technical users */}
                            {message.errorCode && user?.role === 'admin' && (
                              <div className="text-xs text-gray-500 font-mono">
                                Error Code: {message.errorCode} | 
                                Confidence: {Math.round((message.confidence || 0) * 100)}% | 
                                Response Time: {message.responseTimeMs}ms
                              </div>
                            )}
                          </div>
                        )}

                        {/* Suggestions */}
                        {message.suggestions && message.suggestions.length > 0 && (
                          <div className="space-y-2">
                            <p className="text-xs text-gray-500 font-medium">
                              {language === 'en' ? 'Suggested follow-ups:' : 'Sugestões de acompanhamento:'}
                            </p>
                            <div className="flex flex-wrap gap-2">
                              {message.suggestions.map((suggestion, index) => (
                                <Button
                                  key={index}
                                  variant="outline"
                                  size="sm"
                                  onClick={() => sendMessage(suggestion, true)}
                                  className="text-xs h-7 px-2"
                                >
                                  {suggestion}
                                </Button>
                              ))}
                            </div>
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            ))}
            
            {isLoading && (
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-purple-600 rounded-full flex items-center justify-center">
                  <Bot className="h-5 w-5 text-white" />
                </div>
                <div className="bg-gray-50 border border-gray-200 p-4 rounded-lg">
                  <div className="flex items-center space-x-2">
                    <div className="w-2 h-2 bg-blue-500 rounded-full animate-bounce" />
                    <div className="w-2 h-2 bg-blue-500 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }} />
                    <div className="w-2 h-2 bg-blue-500 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }} />
                    <span className="text-sm text-gray-500 ml-2">
                      {language === 'en' ? 'Processing...' : 'Processando...'}
                    </span>
                  </div>
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Feedback section */}
          {showFeedback && (
            <div className="mx-4 mb-4 p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
              <h4 className="font-medium text-yellow-800 mb-2">
                {language === 'en' ? 'How was my assistance?' : 'Como foi minha assistência?'}
              </h4>
              <div className="flex items-center gap-2">
                {[1, 2, 3, 4, 5].map((star) => (
                  <Button
                    key={star}
                    variant="ghost"
                    size="sm"
                    onClick={() => setSatisfactionRating(star)}
                    className={`p-1 ${satisfactionRating >= star ? 'text-yellow-500' : 'text-gray-300'}`}
                  >
                    <Star className="h-5 w-5" fill="currentColor" />
                  </Button>
                ))}
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setShowFeedback(false)}
                  className="ml-4"
                >
                  {language === 'en' ? 'Skip' : 'Pular'}
                </Button>
              </div>
            </div>
          )}

          {/* Input section */}
          <div className="border-t border-gray-200 p-4 bg-gray-50">
            <div className="flex gap-3">
              <Input
                placeholder={language === 'en' ? 
                  'Ask about ships, operations, or terminal information...' : 
                  'Pergunte sobre navios, operações ou informações do terminal...'}
                value={currentMessage}
                onChange={(e) => setCurrentMessage(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && !e.shiftKey && sendMessage()}
                disabled={isLoading}
                className="flex-1"
              />
              <Button
                onClick={isRecording ? stopRecording : startRecording}
                variant={isRecording ? 'destructive' : 'outline'}
                size="icon"
                disabled={isLoading}
              >
                {isRecording ? <MicOff className="h-4 w-4" /> : <Mic className="h-4 w-4" />}
              </Button>
              <Button 
                onClick={() => sendMessage()} 
                disabled={!currentMessage.trim() || isLoading}
                className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
              >
                <Send className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}