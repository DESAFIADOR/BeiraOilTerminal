import React from 'react';
import { Button } from '@/components/ui/button';
import { Bot } from 'lucide-react';

export function TestAssistantButton() {
  const handleClick = () => {
    alert('Botão do assistente clicado!');
  };

  return (
    <div 
      style={{ 
        position: 'fixed',
        bottom: '24px', 
        right: '110px', 
        zIndex: 9999,
        width: '60px',
        height: '60px',
        backgroundColor: '#dc2626',
        borderRadius: '50%',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        cursor: 'pointer',
        color: 'white',
        boxShadow: '0 4px 12px rgba(0,0,0,0.3)'
      }}
      onClick={handleClick}
    >
      <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
        <Bot size={24} />
        <span style={{ fontSize: '10px' }}>TEST</span>
      </div>
    </div>
  );
}