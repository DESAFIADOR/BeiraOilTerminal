import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Shield, Eye, Download, Trash2, X } from 'lucide-react';
import { useTranslation } from '@/contexts/LanguageContext';

interface GDPRNoticeProps {
  onAccept: () => void;
  onDecline: () => void;
  isVisible: boolean;
}

export function GDPRNotice({ onAccept, onDecline, isVisible }: GDPRNoticeProps) {
  const { t } = useTranslation();

  if (!isVisible) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <Card className="w-full max-w-2xl max-h-[80vh] overflow-y-auto">
        <CardHeader className="bg-blue-600 text-white">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Shield className="w-6 h-6" />
              <CardTitle>{t("Privacidade e Proteção de Dados") || "Privacy & Data Protection"}</CardTitle>
            </div>
            <Button
              variant="ghost"
              size="sm"
              onClick={onDecline}
              className="text-white hover:bg-white/20"
            >
              <X className="w-4 h-4" />
            </Button>
          </div>
        </CardHeader>

        <CardContent className="p-6 space-y-4">
          <div className="space-y-3">
            <h3 className="font-semibold text-lg">
              {t("Como utilizamos os seus dados") || "How we use your data"}
            </h3>
            
            <div className="space-y-2 text-sm text-gray-700">
              <p>
                {t("O Assistente Virtual do Terminal de Beira processa os seguintes dados:") || 
                 "The Beira Terminal Virtual Assistant processes the following data:"}
              </p>
              
              <ul className="list-disc pl-5 space-y-1">
                <li>{t("Mensagens de chat para fornecimento de assistência") || "Chat messages for assistance provision"}</li>
                <li>{t("Nível de permissão do utilizador (Visitante/Operador/Admin)") || "User permission level (Visitor/Operator/Admin)"}</li>
                <li>{t("Idioma preferido para comunicação") || "Preferred language for communication"}</li>
                <li>{t("Classificações de satisfação (opcional)") || "Satisfaction ratings (optional)"}</li>
              </ul>
            </div>

            <div className="bg-blue-50 p-4 rounded-lg space-y-2">
              <h4 className="font-medium flex items-center gap-2">
                <Eye className="w-4 h-4" />
                {t("Base Legal") || "Legal Basis"}
              </h4>
              <p className="text-sm">
                {t("Interesse legítimo para suporte ao cliente (Artigo 6(1)(f) RGPD)") || 
                 "Legitimate interest for customer support (Article 6(1)(f) GDPR)"}
              </p>
            </div>

            <div className="space-y-2">
              <h4 className="font-medium">{t("Os seus direitos") || "Your rights"}:</h4>
              <div className="grid grid-cols-2 gap-2 text-sm">
                <Badge variant="outline" className="justify-start p-2">
                  <Download className="w-3 h-3 mr-1" />
                  {t("Exportar dados") || "Export data"}
                </Badge>
                <Badge variant="outline" className="justify-start p-2">
                  <Trash2 className="w-3 h-3 mr-1" />
                  {t("Eliminar dados") || "Delete data"}
                </Badge>
              </div>
            </div>

            <div className="bg-yellow-50 p-4 rounded-lg">
              <p className="text-sm">
                <strong>{t("Retenção de dados") || "Data retention"}:</strong>{" "}
                {t("90 dias (eliminação automática)") || "90 days (automatic deletion)"}
              </p>
              <p className="text-sm mt-1">
                <strong>{t("Contacto") || "Contact"}:</strong> dpo@cfm.co.mz
              </p>
            </div>
          </div>

          <div className="flex gap-3 pt-4 border-t">
            <Button
              onClick={onAccept}
              className="flex-1 bg-blue-600 hover:bg-blue-700"
            >
              {t("Aceitar e Continuar") || "Accept & Continue"}
            </Button>
            <Button
              onClick={onDecline}
              variant="outline"
              className="flex-1"
            >
              {t("Recusar") || "Decline"}
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}