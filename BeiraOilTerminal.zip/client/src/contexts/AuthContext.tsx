import React, { createContext, useContext } from 'react';
import { useQuery } from "@tanstack/react-query";

interface User {
  id: number;
  username: string;
  role: string;
  email?: string;
  firstName?: string;
  lastName?: string;
  permissions?: string[];
}

interface AuthContextType {
  user?: User;
  isLoading: boolean;
  isAuthenticated: boolean;
  isOperator: boolean;
  isAdmin: boolean;
  canEdit: boolean;
}

export const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const { data: user, isLoading, error } = useQuery<User | null>({
    queryKey: ["/api/user"],
    retry: false,
    refetchOnWindowFocus: false,
    refetchOnMount: true,
    refetchInterval: false,
    staleTime: 10 * 60 * 1000, // 10 minutes
  });

  // If user is null due to 401, consider not authenticated but not loading
  const isAuthenticated = !!user && user !== null;
  const actuallyLoading = isLoading && !error;

  const value = {
    user: user || undefined,
    isLoading: actuallyLoading,
    isAuthenticated,
    isOperator: user?.role === 'operator' || user?.role === 'admin',
    isAdmin: user?.role === 'admin',
    canEdit: user?.role === 'operator' || user?.role === 'admin',
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}