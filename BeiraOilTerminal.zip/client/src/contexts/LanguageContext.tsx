import React, { createContext, useContext, useState, useEffect } from 'react';

interface LanguageContextType {
  language: 'pt' | 'en';
  setLanguage: (lang: 'pt' | 'en') => void;
  t: (key: string) => string;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

const translations = {
  pt: {
    "Line Up - Beira Oil Terminal": "Line Up - Terminal de Combustíveis da Beira",
    "Sistema de Informação de Navios": "Sistema de Informação de Navios",
    "Desenvolvido por: Manuel Antonio, Eng.": "Desenvolvido por: Manuel Antonio, Eng.",
    "Entrar": "Entrar",
    "Sair": "Sair",
    "Aguardando Navio": "Aguardando Navio",
    "O cais está disponível para atracação": "O cais está disponível para atracação",
    "PRÓXIMOS 5 NAVIOS A ATRACAR": "PRÓXIMOS 5 NAVIOS A ATRACAR",
    "NAVIOS NA BARRA": "NAVIOS NA BARRA",
    "CHEGADAS ESPERADAS": "CHEGADAS ESPERADAS",
    "NAVIOS PARTIDOS": "NAVIOS PARTIDOS",
    "Clima Atual": "Clima Atual",
    "Informações de Maré": "Informações de Maré",
    "Carregando dados meteorológicos...": "Carregando dados meteorológicos...",
    "Carregando dados de maré...": "Carregando dados de maré...",
    "Nacional": "Nacional",
    "Trânsito": "Trânsito",
    "Combinado": "Combinado",
    "LPG": "LPG",
    "COM INSTRUÇÃO": "COM INSTRUÇÃO",
    "SEM INSTRUÇÃO": "SEM INSTRUÇÃO",
    "PREVISTOS A CHEGAR": "PREVISTOS A CHEGAR",
    "SWAP": "SWAP",
    "NAVIOS DESATRACADOS": "NAVIOS DESATRACADOS",
    "Período": "Período",
    "CAIS EM MANUTENÇÃO": "CAIS EM MANUTENÇÃO",
    "Nome do Navio": "Nome do Navio",
    "Contramarca": "Contramarca",
    "Calado": "Calado",
    "Tipo de Carga": "Tipo de Carga",
    "Agente do Navio": "Agente do Navio",
    "Agente da Carga": "Agente da Carga",
    "Armador": "Armador",
    "Destino da Carga": "Destino da Carga",
    "Tipo de Operação": "Tipo de Operação",
    "Parcelas": "Parcelas"
  },
  en: {
    "Line Up - Beira Oil Terminal": "Line Up - Beira Oil Terminal",
    "Sistema de Informação de Navios": "Ship Information System",
    "Desenvolvido por: Manuel Antonio, Eng.": "Developed by: Manuel Antonio, Eng.",
    "Entrar": "Login",
    "Sair": "Logout",
    "Aguardando Navio": "Waiting for Ship",
    "O cais está disponível para atracação": "The berth is available for docking",
    "PRÓXIMOS 5 NAVIOS A ATRACAR": "NEXT 5 SHIPS TO BERTH",
    "NAVIOS NA BARRA": "SHIPS AT BAR",
    "CHEGADAS ESPERADAS": "EXPECTED ARRIVALS",
    "NAVIOS PARTIDOS": "DEPARTED SHIPS",
    "Clima Atual": "Current Weather",
    "Informações de Maré": "Tide Information",
    "Carregando dados meteorológicos...": "Loading weather data...",
    "Carregando dados de maré...": "Loading tide data...",
    "Nacional": "National",
    "Trânsito": "Transit",
    "Combinado": "Combined",
    "LPG": "LPG",
    "COM INSTRUÇÃO": "WITH INSTRUCTION",
    "SEM INSTRUÇÃO": "WITHOUT INSTRUCTION",
    "PREVISTOS A CHEGAR": "EXPECTED TO ARRIVE",
    "SWAP": "SWAP",
    "NAVIOS DESATRACADOS": "UNDOCKED SHIPS",
    "Período": "Period",
    "CAIS EM MANUTENÇÃO": "BERTH UNDER MAINTENANCE",
    "Nome do Navio": "Ship Name",
    "Contramarca": "Countermark",
    "Calado": "Draft",
    "Tipo de Carga": "Cargo Type",
    "Agente do Navio": "Ship Agent",
    "Agente da Carga": "Cargo Agent",
    "Armador": "Shipowner",
    "Destino da Carga": "Cargo Destination",
    "Tipo de Operação": "Operation Type",
    "Parcelas": "Parcels"
  }
};

export function LanguageProvider({ children }: { children: React.ReactNode }) {
  const [language, setLanguage] = useState<'pt' | 'en'>('pt');

  const t = (key: string): string => {
    return translations[language][key] || key;
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useTranslation() {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error('useTranslation must be used within a LanguageProvider');
  }
  return context;
}