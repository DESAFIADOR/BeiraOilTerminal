import { useState, useEffect } from 'react';

export function useClock() {
  const [currentTime, setCurrentTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  const timeString = formatTime(currentTime);
  const dateString = formatDate(currentTime);
  
  return {
    time: timeString,
    date: dateString,
    raw: currentTime
  };
}

// Utility functions for cross-browser date formatting with Mozambique timezone
export function formatDate(date: Date | string): string {
  try {
    let dateObj: Date;
    
    if (typeof date === 'string') {
      dateObj = new Date(date);
    } else if (date instanceof Date) {
      dateObj = date;
    } else {
      return 'Data inválida';
    }
    
    // Check if date is valid
    if (!dateObj || isNaN(dateObj.getTime())) {
      return 'Data inválida';
    }
    
    const formatted = dateObj.toLocaleDateString('pt-BR', { 
      weekday: 'long', 
      year: 'numeric', 
      month: 'long', 
      day: 'numeric',
      timeZone: 'Africa/Maputo'
    });
    
    // Capitalize the first letter of day and month names
    return formatted.replace(/^(\w)/, (match) => match.toUpperCase())
                   .replace(/ de (\w)/, (match, letter) => ` de ${letter.toUpperCase()}`);
  } catch (error) {
    // Fallback for older browsers
    try {
      let dateObj: Date;
      
      if (typeof date === 'string') {
        dateObj = new Date(date);
      } else if (date instanceof Date) {
        dateObj = date;
      } else {
        return 'Data inválida';
      }
      
      // Check if date is valid
      if (!dateObj || isNaN(dateObj.getTime())) {
        return 'Data inválida';
      }
      
      const days = ['Domingo', 'Segunda-Feira', 'Terça-Feira', 'Quarta-Feira', 'Quinta-Feira', 'Sexta-Feira', 'Sábado'];
      const months = ['Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho', 'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'];
      
      return `${days[dateObj.getDay()]}, ${dateObj.getDate()} de ${months[dateObj.getMonth()]} de ${dateObj.getFullYear()}`;
    } catch (fallbackError) {
      return 'Data inválida';
    }
  }
}

// Safe padding function for cross-browser compatibility
function safePad(num: number): string {
  return num < 10 ? '0' + num : num.toString();
}

export function formatTime(date: Date | string): string {
  try {
    let dateObj: Date;
    
    if (typeof date === 'string') {
      dateObj = new Date(date);
    } else if (date instanceof Date) {
      dateObj = date;
    } else {
      return 'Hora inválida';
    }
    
    // Check if date is valid
    if (!dateObj || isNaN(dateObj.getTime())) {
      return 'Hora inválida';
    }
    
    return dateObj.toLocaleTimeString('pt-BR', { 
      hour: '2-digit', 
      minute: '2-digit', 
      second: '2-digit',
      timeZone: 'Africa/Maputo'
    });
  } catch (error) {
    // Fallback for older browsers
    try {
      let dateObj: Date;
      
      if (typeof date === 'string') {
        dateObj = new Date(date);
      } else if (date instanceof Date) {
        dateObj = date;
      } else {
        return 'Hora inválida';
      }
      
      // Check if date is valid
      if (!dateObj || isNaN(dateObj.getTime())) {
        return 'Hora inválida';
      }
      
      const hours = safePad(dateObj.getHours());
      const minutes = safePad(dateObj.getMinutes());
      const seconds = safePad(dateObj.getSeconds());
      
      return `${hours}:${minutes}:${seconds}`;
    } catch (fallbackError) {
      return 'Hora inválida';
    }
  }
}