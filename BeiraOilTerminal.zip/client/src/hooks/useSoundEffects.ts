import { useCallback, useRef } from 'react';

interface SoundEffects {
  shipMovement: () => void;
  shipBerthing: () => void;
  shipDeparture: () => void;
  notification: () => void;
  confirmation: () => void;
  error: () => void;
  warning: () => void;
  success: () => void;
}

export function useSoundEffects(): SoundEffects {
  const audioContextRef = useRef<AudioContext | null>(null);
  const isEnabledRef = useRef(true);

  const getAudioContext = useCallback(() => {
    if (!audioContextRef.current) {
      audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
    }
    return audioContextRef.current;
  }, []);

  const createOscillator = useCallback((frequency: number, type: OscillatorType = 'sine', duration: number = 0.3) => {
    if (!isEnabledRef.current) return;
    
    try {
      const audioContext = getAudioContext();
      const oscillator = audioContext.createOscillator();
      const gainNode = audioContext.createGain();

      oscillator.connect(gainNode);
      gainNode.connect(audioContext.destination);

      oscillator.frequency.setValueAtTime(frequency, audioContext.currentTime);
      oscillator.type = type;

      gainNode.gain.setValueAtTime(0.1, audioContext.currentTime);
      gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + duration);

      oscillator.start(audioContext.currentTime);
      oscillator.stop(audioContext.currentTime + duration);
    } catch (error) {
      console.warn('Sound effect failed:', error);
    }
  }, [getAudioContext]);

  const createMultiTone = useCallback((frequencies: number[], duration: number = 0.5) => {
    if (!isEnabledRef.current) return;
    
    try {
      const audioContext = getAudioContext();
      
      frequencies.forEach((freq, index) => {
        setTimeout(() => {
          const oscillator = audioContext.createOscillator();
          const gainNode = audioContext.createGain();

          oscillator.connect(gainNode);
          gainNode.connect(audioContext.destination);

          oscillator.frequency.setValueAtTime(freq, audioContext.currentTime);
          oscillator.type = 'sine';

          gainNode.gain.setValueAtTime(0.05, audioContext.currentTime);
          gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.2);

          oscillator.start(audioContext.currentTime);
          oscillator.stop(audioContext.currentTime + 0.2);
        }, index * 100);
      });
    } catch (error) {
      console.warn('Multi-tone sound effect failed:', error);
    }
  }, [getAudioContext]);

  const shipMovement = useCallback(() => {
    // Deep maritime horn sound - low frequency sweep
    createMultiTone([150, 180, 200, 220], 0.8);
  }, [createMultiTone]);

  const shipBerthing = useCallback(() => {
    // Arrival confirmation - ascending tones
    createMultiTone([200, 300, 400, 500], 1.0);
  }, [createMultiTone]);

  const shipDeparture = useCallback(() => {
    // Departure farewell - descending tones
    createMultiTone([500, 400, 300, 200], 1.0);
  }, [createMultiTone]);

  const notification = useCallback(() => {
    // Gentle notification bell
    createOscillator(800, 'sine', 0.3);
  }, [createOscillator]);

  const confirmation = useCallback(() => {
    // Positive confirmation - quick double tone
    createOscillator(600, 'sine', 0.15);
    setTimeout(() => createOscillator(800, 'sine', 0.15), 100);
  }, [createOscillator]);

  const error = useCallback(() => {
    // Alert - urgent low tone
    createOscillator(200, 'sawtooth', 0.4);
  }, [createOscillator]);

  const warning = useCallback(() => {
    // Caution - medium pulsing tone
    createMultiTone([400, 450, 400, 450], 0.6);
  }, [createMultiTone]);

  const success = useCallback(() => {
    // Success - cheerful ascending sequence
    createMultiTone([300, 400, 500, 600], 0.8);
  }, [createMultiTone]);

  return {
    shipMovement,
    shipBerthing,
    shipDeparture,
    notification,
    confirmation,
    error,
    warning,
    success,
  };
}

// Global sound preferences
export const soundPreferences = {
  enabled: true,
  volume: 0.5,
  toggle: () => {
    soundPreferences.enabled = !soundPreferences.enabled;
    localStorage.setItem('maritimeSoundsEnabled', String(soundPreferences.enabled));
  },
  load: () => {
    const saved = localStorage.getItem('maritimeSoundsEnabled');
    soundPreferences.enabled = saved !== null ? saved === 'true' : true;
  }
};

// Load preferences on module initialization
soundPreferences.load();