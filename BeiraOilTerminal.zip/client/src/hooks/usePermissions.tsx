import { useAuth } from '@/contexts/AuthContext';

export function usePermissions() {
  const { user } = useAuth();
  
  const hasPermission = (permission: string): boolean => {
    if (!user || !user.permissions) return false;
    
    return user.permissions.includes(permission);
  };

  const canViewShipDetails = (): boolean => {
    return hasPermission('view_ship_details') || hasPermission('view_ships');
  };

  const canViewParcelDetails = (): boolean => {
    return hasPermission('view_parcel_details');
  };

  const canViewVolumeData = (): boolean => {
    // Público não pode ver volumes, apenas percentagens
    return user?.role !== 'publico';
  };

  const canCreateShips = (): boolean => {
    return hasPermission('create_ships');
  };

  const canEditParcels = (): boolean => {
    const userRole = user?.role;
    
    // Line Up: pode editar parcelas apenas antes da atracação
    if (userRole === 'line_up') {
      return hasPermission('manage_parcels_pre_berth');
    }
    
    // CTOs e Admin: podem editar parcelas sempre
    return hasPermission('manage_parcels_full');
  };

  const canUpdateDischarge = (): boolean => {
    return hasPermission('update_discharge_progress') || hasPermission('update_discharge');
  };

  const canBerthUnberthShips = (): boolean => {
    return hasPermission('berth_unberth_ships');
  };

  const canViewStatistics = (): boolean => {
    return hasPermission('view_statistics');
  };

  const canViewLiveOperations = (): boolean => {
    return hasPermission('view_live_operations');
  };

  const canApproveUsers = (): boolean => {
    return hasPermission('approve_users') || hasPermission('approve_admins');
  };

  const canManageUsers = (): boolean => {
    return hasPermission('manage_users_full') || hasPermission('manage_users_advanced');
  };

  const isPublicUser = (): boolean => {
    return user?.role === 'publico';
  };

  const isLineUpUser = (): boolean => {
    return user?.role === 'line_up';
  };

  const isGestorUser = (): boolean => {
    return user?.role === 'gestores';
  };

  const isCTOUser = (): boolean => {
    return user?.role === 'ctos';
  };

  const isAdminUser = (): boolean => {
    return user?.role === 'admin';
  };

  const isDevUser = (): boolean => {
    return user?.role === 'desenvolvedor';
  };

  const isAgentUser = (): boolean => {
    return user?.role === 'agente_navio';
  };

  // Permissões específicas do Agente Navio
  const canAnnounceArrival = (): boolean => {
    return hasPermission('announce_arrival');
  };

  const canAddShip = (): boolean => {
    return hasPermission('add_ship');
  };

  const canAddParcels = (): boolean => {
    return hasPermission('add_parcels');
  };

  const canConfirmBerthing = (): boolean => {
    return hasPermission('confirm_berthing');
  };

  const canViewShipsAtBar = (): boolean => {
    return hasPermission('view_ships_at_bar');
  };

  const canViewShipsAtBerth = (): boolean => {
    return hasPermission('view_ships_at_berth');
  };

  const canViewDischargeProgress = (): boolean => {
    return hasPermission('view_discharge_progress');
  };

  const canEditParcelsByShipStatus = (shipStatus: string): boolean => {
    const userRole = user?.role;
    
    // Line Up: pode editar apenas se o navio não estiver atracado
    if (userRole === 'line_up') {
      return shipStatus !== 'at_berth';
    }
    
    // CTOs e Admin: podem editar sempre
    return hasPermission('manage_parcels_full');
  };

  return {
    hasPermission,
    canViewShipDetails,
    canViewParcelDetails,
    canViewVolumeData,
    canCreateShips,
    canEditParcels,
    canUpdateDischarge,
    canBerthUnberthShips,
    canViewStatistics,
    canViewLiveOperations,
    canApproveUsers,
    canManageUsers,
    isPublicUser,
    isLineUpUser,
    isGestorUser,
    isCTOUser,
    isAdminUser,
    isDevUser,
    isAgentUser,
    canAnnounceArrival,
    canAddShip,
    canAddParcels,
    canConfirmBerthing,
    canViewShipsAtBar,
    canViewShipsAtBerth,
    canViewDischargeProgress,
    canEditParcelsByShipStatus,
    userRole: user?.role || 'publico'
  };
}