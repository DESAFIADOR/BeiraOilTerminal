import jsPDF from 'jspdf';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';

export const generateSystemCapabilitiesPDF = () => {
  const pdf = new jsPDF();
  const currentDate = format(new Date(), "dd 'de' MMMM 'de' yyyy", { locale: ptBR });
  
  // Page margins and dimensions
  const margin = 20;
  const pageWidth = pdf.internal.pageSize.getWidth();
  const pageHeight = pdf.internal.pageSize.getHeight();
  const contentWidth = pageWidth - 2 * margin;
  let yPosition = margin;
  let pageNumber = 1;

  // Helper function to add page numbers
  const addPageNumber = () => {
    pdf.setFontSize(10);
    pdf.setFont('helvetica', 'normal');
    pdf.setTextColor(100, 100, 100);
    pdf.text(`Página ${pageNumber}`, pageWidth - margin, pageHeight - 10, { align: 'right' });
    pageNumber++;
  };

  // Helper function to add new page if needed
  const checkPageBreak = (additionalHeight: number) => {
    if (yPosition + additionalHeight > pageHeight - 50) { // Leave space for footer
      addPageNumber();
      pdf.addPage();
      yPosition = margin;
    }
  };

  // Helper function to add section break
  const addSectionBreak = () => {
    yPosition += 15;
    pdf.setDrawColor(200, 200, 200);
    pdf.line(margin, yPosition, pageWidth - margin, yPosition);
    yPosition += 15;
  };

  // Helper function to add text with line breaks and better formatting
  const addText = (text: string, fontSize: number, style: 'normal' | 'bold' = 'normal', color: string = '#000000', indent: number = 0) => {
    pdf.setFontSize(fontSize);
    pdf.setFont('helvetica', style);
    
    // Convert hex color to RGB
    const r = parseInt(color.slice(1, 3), 16);
    const g = parseInt(color.slice(3, 5), 16);
    const b = parseInt(color.slice(5, 7), 16);
    pdf.setTextColor(r, g, b);
    
    const availableWidth = contentWidth - indent;
    const lines = pdf.splitTextToSize(text, availableWidth);
    const lineHeight = fontSize * 0.6;
    
    checkPageBreak(lines.length * lineHeight + 5);
    
    lines.forEach((line: string) => {
      pdf.text(line, margin + indent, yPosition);
      yPosition += lineHeight;
    });
    
    yPosition += 3;
  };

  // Helper function to add bullet point
  const addBulletPoint = (text: string, fontSize: number = 10) => {
    checkPageBreak(20);
    pdf.setFontSize(fontSize);
    pdf.setFont('helvetica', 'normal');
    pdf.setTextColor(0, 0, 0);
    
    // Add bullet
    pdf.text('•', margin + 5, yPosition);
    
    // Add text with proper wrapping
    const lines = pdf.splitTextToSize(text, contentWidth - 15);
    lines.forEach((line: string, index: number) => {
      pdf.text(line, margin + 15, yPosition);
      if (index < lines.length - 1) {
        yPosition += fontSize * 0.6;
      }
    });
    yPosition += fontSize * 0.6 + 2;
  };

  // Header with better styling
  pdf.setFillColor(30, 64, 175);
  pdf.rect(0, 0, pageWidth, 60, 'F');
  
  pdf.setTextColor(255, 255, 255);
  pdf.setFontSize(26);
  pdf.setFont('helvetica', 'bold');
  pdf.text('SISTEMA DE GESTÃO PORTUÁRIA', pageWidth / 2, 22, { align: 'center' });
  
  pdf.setFontSize(16);
  pdf.setFont('helvetica', 'normal');
  pdf.text('Terminal de Petróleo de Beira - CFM-EP', pageWidth / 2, 35, { align: 'center' });
  
  pdf.setFontSize(14);
  pdf.setFont('helvetica', 'bold');
  pdf.text('Desenvolvido por: Manuel Antonio - Engenheiro Mecatrônico', pageWidth / 2, 48, { align: 'center' });
  
  yPosition = 80;

  // Document info box
  pdf.setFillColor(240, 248, 255);
  pdf.rect(margin, yPosition, contentWidth, 25, 'F');
  pdf.setDrawColor(30, 64, 175);
  pdf.rect(margin, yPosition, contentWidth, 25, 'S');
  
  pdf.setTextColor(30, 64, 175);
  pdf.setFontSize(14);
  pdf.setFont('helvetica', 'bold');
  pdf.text('RELATÓRIO TÉCNICO DE FUNCIONALIDADES', pageWidth / 2, yPosition + 10, { align: 'center' });
  
  pdf.setFontSize(12);
  pdf.setFont('helvetica', 'normal');
  pdf.text(`Gerado em: ${currentDate}`, pageWidth / 2, yPosition + 20, { align: 'center' });
  
  yPosition += 40;

  // Table of Contents
  addText('ÍNDICE', 16, 'bold', '#1e40af');
  addBulletPoint('1. Visão Geral do Sistema');
  addBulletPoint('2. Gestão de Navios e Operações');
  addBulletPoint('3. Sistema de Priorização IMOPETRO');
  addBulletPoint('4. Operações de Atracação e Manutenção');
  addBulletPoint('5. Monitoramento Ambiental');
  addBulletPoint('6. Relatórios e Analytics');
  addBulletPoint('7. Arquitetura Técnica');
  addBulletPoint('8. Recursos Multilíngues');
  addBulletPoint('9. Segurança e Controle de Acesso');
  addBulletPoint('10. Interface e Experiência do Usuário');
  addBulletPoint('11. Benefícios Operacionais');
  
  addSectionBreak();

  // Visão Geral
  addText('1. VISÃO GERAL DO SISTEMA', 16, 'bold', '#1e40af');
  addText('Plataforma Completa de Gestão Marítima', 14, 'bold', '#374151');
  addText('O Sistema de Gestão Portuária é uma solução web avançada desenvolvida especificamente para o Terminal de Petróleo de Beira (CFM-EP), proporcionando controle total das operações portuárias com funcionalidades especializadas para gerenciamento de navios, carga e operações de descarga.', 11, 'normal');
  
  yPosition += 10;
  addText('Características Principais:', 12, 'bold', '#1e40af');
  addBulletPoint('Plataforma 100% Web - Acesso via navegador sem necessidade de instalação');
  addBulletPoint('Sistema Bilíngue - Português e Inglês com mais de 80 traduções');
  addBulletPoint('Monitoramento 24/7 - Operação contínua com dados em tempo real');
  addBulletPoint('Atualizações Instantâneas - Interface responsável com sincronização automática');
  addBulletPoint('Compatibilidade Universal - Funciona em desktop, tablet e mobile');
  
  addSectionBreak();

  // Gestão de Navios
  addText('2. GESTÃO DE NAVIOS E OPERAÇÕES', 16, 'bold', '#1e40af');
  
  addText('2.1 Registro e Cadastramento', 13, 'bold', '#059669');
  addBulletPoint('Cadastro completo com dados técnicos: nome, contramarca, calado, LOA, beam');
  addBulletPoint('Informações de agentes: agente do navio e agente da carga com contatos');
  addBulletPoint('Especificações de carga: parcelas individuais com volumes e destinatários');
  addBulletPoint('Datas operacionais: chegada esperada na barra e ETA portuário');
  addBulletPoint('Tipo de operação: trânsito ou combinado para regras de priorização');
  
  yPosition += 5;
  addText('2.2 Controle de Status em Tempo Real', 13, 'bold', '#059669');
  addBulletPoint('ESPERADO: Navios registrados aguardando chegada');
  addBulletPoint('NA BARRA: Navios que chegaram aguardando condições para atracar');
  addBulletPoint('PRÓXIMO AO CAIS: Navio selecionado para próxima atracação');
  addBulletPoint('NO CAIS: Navio atracado realizando operações de descarga');
  addBulletPoint('PARTIDO: Navios que completaram operações e partiram');
  
  addSectionBreak();

  // Sistema de Priorização
  addText('3. SISTEMA DE PRIORIZAÇÃO IMOPETRO', 16, 'bold', '#1e40af');
  addText('Implementação do Decreto 89/2019 para priorização de navios IMOPETRO', 12, 'normal');
  
  addText('3.1 Prioridade Absoluta IMOPETRO', 13, 'bold', '#dc2626');
  addBulletPoint('Navios com agente da carga IMOPETRO recebem prioridade máxima');
  addBulletPoint('Identificação visual com badge vermelho "PRIORIDADE - Decreto 89/2019"');
  addBulletPoint('Posicionamento automático no topo da fila independente da data de chegada');
  addBulletPoint('Sistema de alerta visual para operadores');
  
  yPosition += 5;
  addText('3.2 Regra de Atracação 2:1', 13, 'bold', '#059669');
  addBulletPoint('Algoritmo processa 2 navios de trânsito seguidos de 1 navio combinado');
  addBulletPoint('Ordem cronológica respeitada dentro de cada tipo de operação');
  addBulletPoint('Badges visuais: verde para trânsito, roxo para combinado');
  addBulletPoint('Cálculo automático da sequência otimizada de atracação');
  
  addSectionBreak();

  // Operações de Atracação
  addText('4. OPERAÇÕES DE ATRACAÇÃO E MANUTENÇÃO', 16, 'bold', '#1e40af');
  
  addText('4.1 Sistema de Registro de Atracação', 13, 'bold', '#059669');
  addBulletPoint('Registro de horário da primeira espía com timestamp preciso');
  addBulletPoint('Registro de horário da última espía para conclusão da atracação');
  addBulletPoint('Cálculo automático do tempo total de operação de atracação');
  addBulletPoint('Histórico completo de todas as operações de atracação realizadas');
  addBulletPoint('Integração com status do navio - mudança automática para "No Cais"');
  
  yPosition += 5;
  addText('4.2 Gestão de Manutenção do Cais', 13, 'bold', '#059669');
  addBulletPoint('Interface administrativa para configurar períodos de manutenção');
  addBulletPoint('Bloqueio automático de novas atracações durante manutenção');
  addBulletPoint('Display visual "CAIS EM MANUTENÇÃO" no dashboard principal');
  addBulletPoint('Edição inline de períodos e descrições de manutenção');
  addBulletPoint('Controle de acesso com senha administrativa para alterações');
  
  yPosition += 5;
  addText('4.3 Sistema de Confirmação de Descarga', 13, 'bold', '#059669');
  addBulletPoint('Modo Manual: Confirmação instantânea via interface do operador');
  addBulletPoint('Modo Email: Envio automático para agentes com token de validação');
  addBulletPoint('Sistema de tokens seguros para confirmação por email');
  addBulletPoint('Mudança automática de status: "sem instrução" → "com instrução"');
  addBulletPoint('Rastreamento completo do processo de confirmação');
  
  addSectionBreak();

  // Monitoramento Ambiental
  addText('5. MONITORAMENTO AMBIENTAL', 16, 'bold', '#1e40af');
  
  addText('5.1 Sistema de Monitoramento de Marés', 13, 'bold', '#059669');
  addBulletPoint('Dados em tempo real para o Porto da Beira');
  addBulletPoint('Análise harmônica com constituintes M2, S2, N2 para previsões precisas');
  addBulletPoint('Integração com APIs NOAA e Open-Meteo para redundância');
  addBulletPoint('Cálculos de segurança baseados no calado do navio vs. profundidade do canal');
  addBulletPoint('Alertas automáticos para condições inadequadas de atracação');
  
  yPosition += 5;
  addText('5.2 Monitoramento Meteorológico', 13, 'bold', '#059669');
  addBulletPoint('Dados meteorológicos atualizados automaticamente');
  addBulletPoint('Temperatura, umidade, pressão atmosférica e velocidade do vento');
  addBulletPoint('Alertas para ventos superiores a 25 nós (condições perigosas)');
  addBulletPoint('Integração com OpenWeather API e fallback Open-Meteo');
  addBulletPoint('Histórico de condições para análises operacionais');
  
  addSectionBreak();

  // Relatórios e Analytics
  addText('6. RELATÓRIOS E ANALYTICS', 16, 'bold', '#1e40af');
  
  addText('6.1 Sistema de Relatórios Automatizados', 13, 'bold', '#059669');
  addBulletPoint('Geração automática de relatórios mensais em PDF com gráficos estatísticos');
  addBulletPoint('Chart.js integrado para visualizações de dados operacionais');
  addBulletPoint('Envio automático por email para manuel.antonio@cfm.co.mz a cada 30 dias');
  addBulletPoint('Limpeza automática de dados históricos após geração do relatório');
  addBulletPoint('Acesso histórico com logs de segurança para auditoria');
  addBulletPoint('Análises de performance: tempo médio de atracação, volumes processados');
  
  yPosition += 5;
  addText('6.2 Analytics em Tempo Real', 13, 'bold', '#059669');
  addBulletPoint('Dashboard executivo com KPIs operacionais atualizados');
  addBulletPoint('Métricas de eficiência: navios processados, tempo de permanência');
  addBulletPoint('Análise de tendências: padrões sazonais e picos operacionais');
  addBulletPoint('Relatórios de compliance IMOPETRO e regulamentações portuárias');
  addBulletPoint('Exportação de dados para análises externas (CSV, Excel)');
  
  addSectionBreak();

  // Arquitetura Técnica
  addText('7. ARQUITETURA TÉCNICA', 16, 'bold', '#1e40af');
  
  addText('7.1 Stack de Desenvolvimento', 13, 'bold', '#059669');
  addBulletPoint('Frontend: React 18 com TypeScript para desenvolvimento type-safe');
  addBulletPoint('Styling: Tailwind CSS + shadcn/ui para interface moderna e consistente');
  addBulletPoint('Backend: Express.js + Node.js para API RESTful robusta');
  addBulletPoint('ORM: Drizzle ORM com PostgreSQL para persistência de dados');
  addBulletPoint('Build Tools: Vite para desenvolvimento rápido e otimização de produção');
  
  yPosition += 5;
  addText('7.2 Infraestrutura e Deployment', 13, 'bold', '#059669');
  addBulletPoint('Database: PostgreSQL Neon Serverless para escalabilidade automática');
  addBulletPoint('Autenticação: Replit Auth com OpenID Connect + sessões PostgreSQL');
  addBulletPoint('Email: SendGrid API para notificações profissionais');
  addBulletPoint('APIs Externas: OpenWeather + Open-Meteo para dados meteorológicos');
  addBulletPoint('Deployment: Replit Autoscale com domínio personalizado');
  
  addSectionBreak();

  // Recursos Multilíngues
  addText('8. RECURSOS MULTILÍNGUES', 16, 'bold', '#1e40af');
  
  addText('8.1 Sistema de Internacionalização', 13, 'bold', '#059669');
  addBulletPoint('Interface bilíngue completa: Português (Brasil) e Inglês');
  addBulletPoint('Mais de 80 chaves de tradução cobrindo toda a aplicação');
  addBulletPoint('Seletor visual com bandeiras 🇵🇹/🇬🇧 no header principal');
  addBulletPoint('Tradução em tempo real sem necessidade de recarregar página');
  addBulletPoint('Persistência automática da preferência no localStorage');
  
  addSectionBreak();

  // Segurança e Controle de Acesso
  addText('9. SEGURANÇA E CONTROLE DE ACESSO', 16, 'bold', '#1e40af');
  
  addText('9.1 Sistema de Autenticação', 13, 'bold', '#059669');
  addBulletPoint('Replit Auth com OpenID Connect para autenticação segura');
  addBulletPoint('Sessões baseadas em PostgreSQL para persistência confiável');
  addBulletPoint('Tokens de acesso com renovação automática');
  addBulletPoint('Logout seguro com invalidação completa de sessão');
  addBulletPoint('Proteção contra ataques CSRF e session hijacking');
  
  yPosition += 5;
  addText('9.2 Controle de Permissões', 13, 'bold', '#059669');
  addBulletPoint('Sistema granular de permissões por usuário');
  addBulletPoint('Workflow de aprovação para novos operadores');
  addBulletPoint('Senha administrativa (BeiraTerm2025!) para ações críticas');
  addBulletPoint('Logs detalhados de acesso e ações para auditoria');
  addBulletPoint('Proteção de endpoints críticos com middleware de autorização');
  
  addSectionBreak();

  // Interface e Experiência
  addText('10. INTERFACE E EXPERIÊNCIA DO USUÁRIO', 16, 'bold', '#1e40af');
  
  addText('10.1 Design Responsável e Acessibilidade', 13, 'bold', '#059669');
  addBulletPoint('Design responsável otimizado para desktop, tablet e mobile');
  addBulletPoint('Tema marítimo profissional com paleta de cores apropriada');
  addBulletPoint('Ícones intuitivos da biblioteca Lucide para ações e status');
  addBulletPoint('Tipografia legível com hierarquia visual clara');
  addBulletPoint('Suporte a todos os navegadores modernos e dispositivos legacy');
  
  yPosition += 5;
  addText('10.2 Experiência do Usuário', 13, 'bold', '#059669');
  addBulletPoint('Navegação intuitiva com acesso rápido às funções principais');
  addBulletPoint('Feedback visual imediato para todas as ações do usuário');
  addBulletPoint('Loading states e indicadores de progresso em operações');
  addBulletPoint('Notificações toast para confirmações e alertas');
  addBulletPoint('Interface limpa focada na eficiência operacional');
  
  addSectionBreak();

  // Benefícios Operacionais
  addText('11. BENEFÍCIOS OPERACIONAIS', 16, 'bold', '#1e40af');
  
  addText('11.1 Eficiência Operacional', 13, 'bold', '#059669');
  addBulletPoint('Redução de 70% no tempo de processamento de documentação');
  addBulletPoint('Eliminação de planilhas manuais e processos em papel');
  addBulletPoint('Automatização completa do workflow de atracação');
  addBulletPoint('Redução de erros humanos através de validações automáticas');
  addBulletPoint('Acesso instantâneo a informações críticas 24/7');
  
  yPosition += 5;
  addText('11.2 Compliance e Governança', 13, 'bold', '#059669');
  addBulletPoint('Compliance automático com Decreto 89/2019 IMOPETRO');
  addBulletPoint('Rastreabilidade completa de todas as operações');
  addBulletPoint('Histórico imutável para auditorias e investigações');
  addBulletPoint('Relatórios padronizados para autoridades portuárias');
  addBulletPoint('Transparência total para agentes marítimos e operadores');

  // Final section and conclusion
  addSectionBreak();
  
  addText('CONCLUSÃO', 16, 'bold', '#1e40af');
  addText('O Sistema de Gestão Portuária representa um marco na modernização do Terminal de Petróleo de Beira, oferecendo uma solução completa e integrada para o controle das operações marítimas. Com sua arquitetura robusta, interface intuitiva e funcionalidades avançadas, o sistema proporciona eficiência operacional, compliance regulatório e transparência total nas operações portuárias.', 11, 'normal');
  
  yPosition += 10;
  addText('A implementação do sistema resulta em benefícios tangíveis: redução significativa de tempo de processamento, eliminação de processos manuais, melhoria na precisão operacional e compliance automático com regulamentações IMOPETRO. O sistema está preparado para futuras expansões e integrações, consolidando o Terminal de Beira como referência em gestão portuária moderna em Moçambique.', 11, 'normal');

  // Add final page number
  addPageNumber();

  // Enhanced footer with professional styling
  const totalPages = pageNumber - 1;
  
  // Add footer to all pages
  for (let i = 1; i <= totalPages; i++) {
    if (i > 1) {
      pdf.setPage(i);
    }
    
    const footerY = pageHeight - 25;
    pdf.setFillColor(240, 248, 255);
    pdf.rect(0, footerY - 5, pageWidth, 30, 'F');
    pdf.setDrawColor(30, 64, 175);
    pdf.line(0, footerY - 5, pageWidth, footerY - 5);
    
    pdf.setTextColor(30, 64, 175);
    pdf.setFontSize(10);
    pdf.setFont('helvetica', 'bold');
    pdf.text('Sistema de Gestão Portuária - Terminal de Petróleo de Beira', pageWidth / 2, footerY + 2, { align: 'center' });
    
    pdf.setFontSize(9);
    pdf.setFont('helvetica', 'normal');
    pdf.text('CFM-EP (Portos e Caminhos de Ferro de Moçambique, E.P.)', pageWidth / 2, footerY + 8, { align: 'center' });
    
    pdf.setFont('helvetica', 'bold');
    pdf.text('Autor: Manuel Antonio - Engenheiro Mecatrônico', pageWidth / 2, footerY + 14, { align: 'center' });
    
    pdf.setFontSize(8);
    pdf.setFont('helvetica', 'italic');
    pdf.setTextColor(100, 100, 100);
    pdf.text(`Documento gerado em ${currentDate} | Página ${i} de ${totalPages}`, pageWidth / 2, footerY + 20, { align: 'center' });
  }

  // Save the PDF
  pdf.save('Sistema_Funcionalidades_Beira_Terminal.pdf');
};